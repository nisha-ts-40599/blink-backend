Approve the G-GROOM gate for an issue — Phase 0 final gate before Delivery Readiness.

Verifies prerequisites before approving:
- grooming_signoff_summary artifact exists (or provide EVIDENCE_REF)
- gates.g_groom.required = true
- grooming.dor_status = ready
- no blocking open questions remain

Then records the gate decision and reports the next prompt.

**Canonical command (preferred):** `/approve-grooming <ISSUE>`

The command resolves the required role and assigned principal from the role registry. Provide an explicit human **Decision** (`approved` / `rejected` / `changes_requested`). The AI must never self-approve.

Advanced/debug:
```bash
make ai-sdlc-approve-gate ROOT=<ROOT> ISSUE=<ISSUE> GATE=G-GROOM \
  APPROVER="<Full Name>:<email>" DECISION=approved \
  EVIDENCE_REF=".cursor/ai-sdlc/workflow-state/<ISSUE>/grooming-signoff-summary.md" \
  WRITE=1
```

**Legacy shortcut:**
```bash
make ai-sdlc-approve-grooming ROOT=<ROOT> ISSUE=<ISSUE> \
  DECISION=approved WRITE=1
```

Dry-run (no changes written — omit WRITE=1):
```bash
make ai-sdlc-approve-gate ROOT=<ROOT> ISSUE=<ISSUE> GATE=G-GROOM \
  APPROVER="<Full Name>:<email>" DECISION=approved \
  EVIDENCE_REF=".cursor/ai-sdlc/workflow-state/<ISSUE>/grooming-signoff-summary.md"
```

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.

**Before approving G-GROOM:**
1. Generate the sign-off summary first: `/grooming-sign-off-capture <ISSUE>`
2. Present the summary to the designated approver.
3. Only after the approver reviews and decides: run the command above.

**Do NOT self-approve** — G-GROOM is a human gate only.

Output:
- approval status
- approver and evidence ref
- G-GROOM required / approved
- Phase 0 complete when approved — Phase 1 begins with `/classify-work <ISSUE>`
- implementation remains blocked until Delivery Readiness phase
