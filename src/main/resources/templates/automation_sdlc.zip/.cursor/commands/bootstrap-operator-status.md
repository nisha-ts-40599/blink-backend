# Bootstrap Operator Status

Read-only greenfield bootstrap route, gate, lease, execution, and next-command report.

## Command

```bash
make ai-sdlc-bootstrap-operator-status ROOT=<workspace-root> ISSUE=<issue-id>
```

JSON:

```bash
make ai-sdlc-bootstrap-operator-status ROOT=<workspace-root> FORMAT=json
```

## Shows

- Route type (manual vs managed local)
- Route state and work tier
- Required and approved gates (G-BOOTSTRAP / G-BOOTSTRAP-EXEC)
- Bootstrap plan hash
- Lease and execution step state
- Completion candidate and Phase 4 reconciliation state
- Delivery readiness (Phase 4 authority only)
- Blocking reasons and recovery options
- **Next allowed command**

## Mutations

None (read-only).
