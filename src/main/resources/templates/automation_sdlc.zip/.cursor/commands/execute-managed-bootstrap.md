# Execute Managed Bootstrap

Run governed **managed local bootstrap execution** (Phase 5.2/5.3).

**Does not set `delivery_ready`.** After successful execution, publish the completion candidate and run Phase 4 reconciliation.

## Prerequisites

- G-PLAN, G-BOOTSTRAP, and G-BOOTSTRAP-EXEC approved
- Validated bootstrap plan, execution proposal, and execution approval on disk
- Preview reviewed and current with approved plan hash
- Local-only workspace; no network or remote Git mutation

## Validate (dry-run)

```bash
make ai-sdlc-managed-execute ROOT=<workspace-root> \
  PLAN=<bootstrap-plan.yaml> PROPOSAL=<proposal.yaml> APPROVAL=<approval.yaml>
```

## Execute (mutations — requires explicit WRITE=1)

```bash
make ai-sdlc-managed-execute ROOT=<workspace-root> \
  PLAN=<bootstrap-plan.yaml> PROPOSAL=<proposal.yaml> APPROVAL=<approval.yaml> WRITE=1
```

## Resume / recover

```bash
make ai-sdlc-managed-execute ROOT=<workspace-root> --mode resume \
  PLAN=<plan> PROPOSAL=<proposal> APPROVAL=<approval> RUN_ID=<run-id> WRITE=1
```

## Outputs

- Execution run under `.cursor/ai-sdlc/bootstrap-executions/<run-id>/`
- Command and validation evidence (H10)
- Managed completion candidate YAML (not delivery readiness)

## Prohibited

- Remote repository creation, push, fetch, pull
- Setting `delivery_ready` or `context_ready`
- Framework file mutation

## Next command

```bash
make ai-sdlc-publish-bootstrap-completion ROOT=<workspace-root> RUN_ID=<run-id> WRITE=1
```

Then:

```bash
make ai-sdlc-reconcile-bootstrap-completion ROOT=<workspace-root> WRITE=1
```

## Status

```bash
make ai-sdlc-bootstrap-operator-status ROOT=<workspace-root>
```
