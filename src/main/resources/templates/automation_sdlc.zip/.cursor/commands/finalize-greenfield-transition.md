---
description: Finalize greenfield lifecycle transition to EXISTING_MANAGED after first validated implementation.
---

@ai-sdlc/prompts/includes/finalize-greenfield-transition.md
