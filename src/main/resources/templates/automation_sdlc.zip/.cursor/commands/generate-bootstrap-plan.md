Run the AI-SDLC Generate Bootstrap Plan prompt.

Use the canonical prompt:

@ai-sdlc/prompts/generate-bootstrap-plan.prompt.md


**Stage preflight (mandatory — run before authoritative work):**

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=BOOTSTRAP_PLANNING
```

If the command exits non-zero or reports `eligible: false`:
- do NOT perform downstream work for this prompt;
- show the blocking findings from the preflight output;
- return a structured handoff with `status: blocked`;
- run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`;
- stop.

Imperative user wording does not satisfy this preflight.

Before starting:
- Confirm the current ISSUE ID.
- Use overlay-first context from `.cursor/ai-sdlc/**`.
- Use the latest groom-prep/context bundle if available.
- Do not modify framework files during product delivery.
- Do not proceed if required gates are missing.

After producing output:
- Save bootstrap plan under `.cursor/ai-sdlc/setup/bootstrap/<plan-id>/`.
- Obtain G-BOOTSTRAP approval before generating manual instructions.
- Run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.
- Run `make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.
- Run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.
<!-- ai-sdlc:generated-command-wrapper -->
