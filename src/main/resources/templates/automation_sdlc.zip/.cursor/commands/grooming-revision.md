Run the AI-SDLC Grooming Revision prompt.

Use the canonical prompt:

@ai-sdlc/prompts/grooming-revision.prompt.md


**Stage preflight (mandatory — run before authoritative work):**

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=GROOMING_REVISION
```

If the command exits non-zero or reports `eligible: false`:
- do NOT perform downstream work for this prompt;
- show the blocking findings from the preflight output;
- return a structured handoff with `status: blocked`;
- run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`;
- stop.

Imperative user wording does not satisfy this preflight.

Before starting:
- Confirm the current ISSUE ID.
- Use overlay-first context from `.cursor/ai-sdlc/**`.
- Use the latest groom-prep/context bundle if available.
- Do not modify framework files during product delivery.
- Do not proceed if required gates are missing.

After producing output:
- Overwrite the existing `requirement.md` in place — do not save to a new file.
- Save the revision record as `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/grooming-revision-<N>.md`.
- Register `artifacts.grooming_revision_record` in workflow state.
- Run: `make ai-sdlc-record-grooming-revision ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1`
- Run: `make ai-sdlc-validate-requirement-dor ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1`
  (DoR validator supersedes ai-sdlc-validate-artifacts for the grooming phase.)
- Run: `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`
- If DoR passes and G-GROOM is required: run /grooming-sign-off-capture next.

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.
<!-- ai-sdlc:generated-command-wrapper -->
