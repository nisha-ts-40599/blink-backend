Run the AI-SDLC Grooming Sign-off Capture prompt.

Use the canonical prompt:

@ai-sdlc/prompts/grooming-sign-off-capture.prompt.md


**Stage preflight (mandatory — run before authoritative work):**

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=GROOMING_SIGNOFF
```

If the command exits non-zero or reports `eligible: false`:
- do NOT perform downstream work for this prompt;
- show the blocking findings from the preflight output;
- return a structured handoff with `status: blocked`;
- run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`;
- stop.

Imperative user wording does not satisfy this preflight.

Before starting:
- Confirm the current ISSUE ID.
- Use overlay-first context from `.cursor/ai-sdlc/**`.
- Use the latest groom-prep/context bundle if available.
- Do not modify framework files during product delivery.
- Do not proceed if required gates are missing.
- Never self-approve human gates, merge, deploy, rollback, or cutover.

After producing output:
- Save the sign-off summary as `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/grooming-signoff-summary.md`.
- Update `grooming.sign_off_captured_at` in workflow state.
- Present the summary to the designated approver for their decision.
- Do NOT approve G-GROOM yourself — that is a human action only.
  (No ai-sdlc-validate-artifacts step needed here — this is a pre-classify gate review.)
- When the approver is ready: `make ai-sdlc-approve-gate ROOT=<workspace-root> ISSUE=<ISSUE-ID> GATE=G-GROOM APPROVER='<Name:email>' REF='<evidence-url>' WRITE=1`

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.
<!-- ai-sdlc:generated-command-wrapper -->
