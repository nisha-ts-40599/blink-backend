Run the AI-SDLC Grooming Stakeholder Pack prompt.

Use the canonical prompt:

@ai-sdlc/prompts/grooming-stakeholder-pack.prompt.md


**Stage preflight (mandatory — run before authoritative work):**

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=CLARIFICATION
```

If the command exits non-zero or reports `eligible: false`:
- do NOT perform downstream work for this prompt;
- show the blocking findings from the preflight output;
- return a structured handoff with `status: blocked`;
- run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`;
- stop.

Imperative user wording does not satisfy this preflight.

Before starting:
- Confirm the current ISSUE ID.
- Use overlay-first context from `.cursor/ai-sdlc/**`.
- Use the latest groom-prep/context bundle if available.
- Do not modify framework files during product delivery.
- Do not proceed if required gates are missing.

After producing output:
- Save the stakeholder pack as `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/stakeholder-pack.md`.
- Register `artifacts.grooming_stakeholder_pack` in workflow state.
- Update `grooming.stakeholder_pack_generated_at` in workflow state.
- Share the pack with the designated stakeholders for review.
  (No ai-sdlc-validate-artifacts step needed here — requirement is not yet finalised.)
- Run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.
<!-- ai-sdlc:generated-command-wrapper -->
