Build the canonical implementation execution package for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/implement-prep.prompt.md

## Preferred operator path

Normal workflows should use:

```text
/sdlc-run <ISSUE>
```

This command remains available for diagnostics and compatibility.

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=IMPLEMENTATION PROMPT_STEM=implement-prep
```

## Runtime

```bash
make ai-sdlc-implementation-step-prep ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
```

## Compatibility alias

`/sdlc-implement-prep <ISSUE>`

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
