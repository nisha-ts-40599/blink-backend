Run the AI-SDLC Post-Deploy Monitoring Signal Interpretation prompt.

Use the canonical prompt:

@ai-sdlc/prompts/monitoring-interpretation.prompt.md


**Advisory only:** This command performs read-only analysis. It does not authorize workflow advancement, gate approval, or mutations.

Before starting:
- Confirm the current ISSUE ID.
- Use overlay-first context from `.cursor/ai-sdlc/**`.
- Use the latest groom-prep/context bundle if available.
- Do not modify framework files during product delivery.
- Do not proceed if required gates are missing.

After producing output:
- Save artifacts under `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/`.
- Register artifacts in workflow state when the user asks.
- Run `make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.
- Run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.
<!-- ai-sdlc:generated-command-wrapper -->
