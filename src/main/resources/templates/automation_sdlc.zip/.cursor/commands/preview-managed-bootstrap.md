# Preview Managed Bootstrap

Dry-run preview of managed local bootstrap execution before G-BOOTSTRAP-EXEC approval or execution.

## Prerequisites

- Approved bootstrap plan (`G-BOOTSTRAP`)
- Generated execution proposal

## Command

```bash
make ai-sdlc-managed-preview ROOT=<workspace-root> \
  PLAN=<bootstrap-plan.yaml> PROPOSAL=<proposal.yaml>
```

## Shows

- Workspace root and target repository paths
- Directories and files to create
- Commands to execute (local only)
- Expected validations
- Prohibited operations (network, remote Git)
- Lease requirements and completion criteria

## Mutations

**None.** Preview is non-authoritative and does not mutate project state except optional audit recording per framework conventions.

## Next commands

1. Obtain G-BOOTSTRAP-EXEC approval (managed route only)
2. `/execute-managed-bootstrap` or `make ai-sdlc-managed-execute WRITE=1`
