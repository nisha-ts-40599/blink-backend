# Reconcile Bootstrap Completion

Run **Phase 4** existing setup refresh to reconcile bootstrap completion evidence and decide delivery readiness.

**Phase 4 is the sole authority for `delivery_ready`.** Phase 5 completion candidates do not imply readiness.

## Prerequisites

- Bootstrap completion candidate published (managed or manual evidence)
- G-BOOTSTRAP approved; G-BOOTSTRAP-EXEC when managed execution was used

## Dry-run

```bash
make ai-sdlc-reconcile-bootstrap-completion ROOT=<workspace-root>
```

## Reconcile (persist readiness)

```bash
make ai-sdlc-reconcile-bootstrap-completion ROOT=<workspace-root> WRITE=1
```

Equivalent:

```bash
make ai-sdlc-existing-refresh ROOT=<workspace-root> WRITE=1
```

## Outcomes

- `READY` / `READY_WITH_WAIVERS` — delivery readiness may become true (Phase 4 only)
- `BLOCKED` / `STALE` — readiness remains false; inspect blockers

## Next command

When `delivery_ready=true`:

```bash
/sdlc-start <ISSUE>
```

Otherwise:

```bash
make ai-sdlc-bootstrap-operator-status ROOT=<workspace-root>
```
