Report the current AI-SDLC Requirement Grooming status for an issue.

Use at any time during Requirement Grooming to determine the correct next step.

**Read-only mode (inspect current state):**
```bash
make ai-sdlc-requirement-grooming-status ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

**Write mode (refresh state before reporting — runs extract + validate-dor):**
```bash
make ai-sdlc-requirement-grooming-status ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
```

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.

Output shows:
- issue id
- current stage and SDLC phase
- requirement_doc present yes/no
- AC count and confirmation count
- open / resolved / accepted / blocking-open question counts
- DoR status
- inferred tier / formal work tier
- G-GROOM required / approved
- stakeholder pack present yes/no
- grooming revision count
- signoff summary present yes/no
- next correct prompt
- implementation allowed (always NO in Requirement phase)
- warnings

Expected next prompt rules:
- no requirement.md → clarify-requirement
- requirement.md exists but extraction pending → extract-grooming-state
- DoR not ready, no stakeholder pack → grooming-stakeholder-pack
- DoR not ready, stakeholder pack exists with open Qs → grooming-revision
- DoR ready, signoff missing → grooming-sign-off-capture
- G-GROOM required but not approved → `make ai-sdlc-approve-gate ROOT=<ROOT> ISSUE=<ISSUE> GATE=G-GROOM ...`
- DoR ready and G-GROOM approved → Phase 0 exit: proceed to Phase 1 with `/classify-work <ISSUE>`

Implementation remains blocked during Phase 0 (Requirement Grooming). Phase 1 (Delivery Readiness) begins with `/classify-work`.
