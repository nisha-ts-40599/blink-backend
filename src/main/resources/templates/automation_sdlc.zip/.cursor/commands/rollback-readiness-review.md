Run the AI-SDLC Rollback Readiness Review prompt.

Use the canonical prompt:

@ai-sdlc/prompts/rollback-readiness-review.prompt.md


**Advisory only:** This command performs read-only analysis. It does not authorize workflow advancement, gate approval, or mutations.

Before starting:
- Confirm the current ISSUE ID.
- Use overlay-first context from `.cursor/ai-sdlc/**`.
- Use the latest groom-prep/context bundle if available.
- Do not modify framework files during product delivery.
- Do not proceed if required gates are missing.
- Never self-approve human gates, merge, deploy, rollback, or cutover.

After producing output:
- Save it under `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/rollback-readiness-review.md`.
- Register `artifacts.rollback_readiness_review` when the user asks.
- Do not execute rollback or approve `g_rollback` without human evidence.
- Run `make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.
- Run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.
<!-- ai-sdlc:generated-command-wrapper -->
