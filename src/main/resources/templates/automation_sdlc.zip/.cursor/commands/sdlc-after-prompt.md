Validate artifacts and re-route after completing an AI-SDLC prompt output.

1. Save output under `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/`.
2. Register the corresponding `artifacts.*` entry in workflow state when applicable.

Then run:

```bash
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout:

```bash
make ai-sdlc-validate-artifacts ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=.. ISSUE=<ISSUE-ID>
```

Do not proceed to the next SDLC stage if required artifacts, gates, or evidence are missing.
