Run the AI developer review (DEV-05) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/ai-developer-review.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=SELF_REVIEW PROMPT_STEM=ai-developer-review
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=ai_developer_review \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/ai-developer-review.yaml
```

## Enforcement

The AI review must bind `reviewed_commit`, be attributed to an AI actor, and must **not** be treated
as human developer attestation. These rules are enforced by the runtime validators
(`enterprise_dev_pipeline.py`), not by prompt prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
