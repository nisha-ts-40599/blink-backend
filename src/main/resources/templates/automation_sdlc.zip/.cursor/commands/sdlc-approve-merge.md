Capture the human G-PR-MERGE gate approval for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/gate-approval-capture.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=GATE_APPROVAL GATE=G-PR-MERGE
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Delegate to runtime (human approver only)

```bash
make ai-sdlc-approve-gate ROOT=<workspace-root> ISSUE=<ISSUE-ID> GATE=G-PR-MERGE \
  APPROVER="<Full Name>:<email>" DECISION=approved \
  EVIDENCE_REF=<provider-pr-url> WRITE=1
```

## Enforcement

Merge-gate preconditions (provider PR present, review APPROVED and current, no open P0/P1, G-QA-POST
satisfied when required) are enforced by the runtime validators (`enterprise_pr_merge.py`), not by
prompt prose alone. Merge remains human-only — **do not self-approve or self-merge.**

## Handoff

After the human merges, run `/sdlc-verify-merge <ISSUE-ID>`, then:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
