Capture the human G-QA-POST gate approval for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/gate-approval-capture.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=GATE_APPROVAL GATE=G-QA-POST
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Delegate to runtime (human approver only)

```bash
make ai-sdlc-approve-gate ROOT=<workspace-root> ISSUE=<ISSUE-ID> GATE=G-QA-POST \
  APPROVER="<Full Name>:<email>" DECISION=approved \
  EVIDENCE_REF=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/qa-signoff-recommendation.yaml WRITE=1
```

## Enforcement

QA sign-off is only a recommendation — G-QA-POST is a human gate and cannot be self-approved by an
agent. A new candidate commit invalidates G-QA-POST. These rules are enforced by the runtime
validators (`enterprise_qa_pipeline.py`, `enterprise_dev_pipeline.py`, `gate_utils.py`), not by
prompt prose alone. **Do not self-approve.**

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
