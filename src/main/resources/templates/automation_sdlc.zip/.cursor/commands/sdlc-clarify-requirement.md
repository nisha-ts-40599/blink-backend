Clarify the requirement for the current issue (requirement grooming / CLARIFICATION stage).

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/clarify-requirement.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=CLARIFICATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate produced artifacts

```bash
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-validate-requirement-dor ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

## Enforcement

Requirement gaps classified during QA or finding lifecycle route here via
`derive_finding_next_action()`. Do not proceed to implementation while
`REQUIREMENT_GAP` or incomplete grooming artifacts remain open.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
