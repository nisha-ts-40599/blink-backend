Classify a pending finding (QA-08 extension) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/classify-finding.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_VALIDATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=finding \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/findings/<FINDING-ID>.yaml
```

## Enforcement

Classification vocabulary, baseline binding, and delivery-blocking rules are enforced by
`enterprise_finding_lifecycle.py` — not by prompt prose alone. This command does not modify
product code or approve gates.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
