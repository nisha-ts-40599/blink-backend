Close out the enterprise Development + QA pipeline for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Preconditions

All pipeline phases complete: implementation, developer tests, AI review, human attestation,
validation, PR review, QA (when required) with G-QA-POST, G-PR-MERGE approved, and merge
provider-verified. Confirm with:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-enterprise-progress ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

## Delegate to runtime

```bash
make ai-sdlc-close-merge ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
make ai-sdlc-generate-closure-report ROOT=<workspace-root> ISSUE=<ISSUE-ID> \
  OUTPUT=.cursor/ai-sdlc/reports/<ISSUE-ID>.md WRITE=1
```

## Enforcement

Closure eligibility (verified merge, required evidence present, deployment-scope handling) is
enforced by the runtime validators (`closure_eligibility.py`, `enterprise_pr_merge.py`), not by
prompt prose alone. Do not fabricate closure on unverified merges.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
