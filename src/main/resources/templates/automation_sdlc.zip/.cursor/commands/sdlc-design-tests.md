Design the QA test suite (QA-03) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/design-tests.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=TEST_DESIGN
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=test_suite \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/test-suite.yaml
```

## Enforcement

Every acceptance criterion must map to a test case, negative/boundary coverage is required when
applicable, and test-data owners must be resolved (no TBD). These rules are enforced by the runtime
validators (`enterprise_qa_pipeline.py`), not by prompt prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
