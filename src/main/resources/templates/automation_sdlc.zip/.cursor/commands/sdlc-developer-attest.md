Capture the human developer attestation (DEV-06) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/developer-attest.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=SELF_REVIEW PROMPT_STEM=developer-attest
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=developer_attestation \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/developer-attestation.yaml
```

## Enforcement

Attestation requires a **named human developer** (not an AI actor) and must bind `reviewed_commit`.
A new commit invalidates the attestation. These rules are enforced by the runtime validators
(`enterprise_dev_pipeline.py`), not by prompt prose alone. Do not self-attest as an AI agent.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
