Record developer test evidence (DEV-04) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/developer-test.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=TEST_VALIDATION PROMPT_STEM=developer-test
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=developer_test_evidence \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/developer-test-evidence.yaml
```

## Enforcement

Real command + exit_code proof (no pasted textual PASS) and tested-commit binding are enforced by
the runtime validators (`enterprise_dev_pipeline.py`), not by prompt prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
