Implement authorized defect fixes (DEV-03 scope) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/fix-defects.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=IMPLEMENTATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate produced artifacts

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=implementation_change_record \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/implementation-change-record.yaml
```

## Enforcement

Hotfix scope, pre-existing deferral, and defect lifecycle routing are enforced by
`enterprise_finding_lifecycle.py`. New commits invalidate stale review and QA evidence
(`enterprise_dev_pipeline.py`, `enterprise_pr_review.py`).

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
