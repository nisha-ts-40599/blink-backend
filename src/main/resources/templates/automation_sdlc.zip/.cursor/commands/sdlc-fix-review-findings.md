Remediate blocking PR review findings (DEV-10) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/fix-review-findings.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=PR_REVIEW
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Enforcement

This command mutates product source to resolve findings, so a new commit invalidates prior review,
QA, G-QA-POST, and G-PR-MERGE evidence (they must be re-established). Freshness/invalidation is
enforced by the runtime validators (`enterprise_dev_pipeline.py`, `enterprise_pr_merge.py`,
`enterprise_dev_qa_progress.py`), not by prompt prose alone.

## Handoff

Re-run the review and re-establish downstream evidence:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
