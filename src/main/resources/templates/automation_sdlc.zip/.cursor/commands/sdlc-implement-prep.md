Build the enterprise implementation package (DEV-01) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/implement-prep.prompt.md

## Stage preflight (mandatory — run before authoritative work)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=IMPLEMENTATION PROMPT_STEM=implement-prep
```

If the command exits non-zero or reports `eligible: false`, do not proceed: show the blocking
findings, return `status: blocked`, and run `make ai-sdlc-stage-router`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=implementation_package \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/implementation-package.yaml \
  STATE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/<ISSUE-ID>.yaml
```

## Enforcement

Gate (G-PLAN), plan-hash binding, delivery-readiness, baseline-commit, and scope rules are
enforced by the runtime validators (`validate_stage_eligibility.py`, `enterprise_dev_pipeline.py`),
not by prompt prose alone. Imperative user wording does not satisfy these checks.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
