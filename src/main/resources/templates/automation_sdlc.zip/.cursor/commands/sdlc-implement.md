Execute the planned enterprise implementation step (DEV-03) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/implement-step.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=IMPLEMENTATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the change record

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=implementation_change_record \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/implementation-change-record.yaml
```

## Enforcement

Undeclared-file, dependency-change, material-deviation, and git-verified change-record rules are
enforced by the runtime validators (`enterprise_dev_pipeline.py`), not by prompt prose alone. A new
commit invalidates downstream review/attestation/QA evidence. Imperative user wording does not
satisfy these checks.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
