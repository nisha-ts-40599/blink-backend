Link or defer a pre-existing finding with baseline evidence for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/link-preexisting-defect.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_VALIDATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate produced artifacts

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=pre_existing_assessment \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/pre-existing-assessments/<FINDING-ID>.yaml
```

## Enforcement

Pre-existing disposition and delivery-blocking policy are enforced by
`enterprise_finding_lifecycle.py`. This command does not modify product code or fabricate
external issue references.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
