Show the authoritative next AI-SDLC command for the current issue (read-only).

Requires `ISSUE=<ISSUE-ID>`.

Run the read-only stage router and enterprise progress projection:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-enterprise-progress ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.

Follow the **Authoritative next action** block at the end of the router output. Use the **Copy command** line exactly — do not follow deprecated `next_prompt` hints.

The stage router is read-only — it does not execute workflow actions or approve gates.
