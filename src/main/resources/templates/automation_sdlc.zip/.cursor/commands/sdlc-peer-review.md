Run human PR review capture (DEV-09) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/peer-review.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=PR_REVIEW
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=human_pr_review \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/human-pr-review.yaml
```

## Enforcement

Human PR review requires a **named non-AI reviewer** and `decision: APPROVED` bound to the
current provider PR head SHA. AI actors and placeholders are rejected by
`validate_human_pr_review()`. Merge approval remains a separate human gate (`/sdlc-approve-merge`).

## Handoff

If `decision: CHANGES_REQUESTED` or blocking findings exist, run `/sdlc-fix-review-findings <ISSUE-ID>`,
otherwise:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
