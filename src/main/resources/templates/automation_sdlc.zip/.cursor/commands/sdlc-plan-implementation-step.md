Plan the next enterprise implementation step (DEV-02) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/plan-implementation-step.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=IMPLEMENTATION PROMPT_STEM=plan-implementation-step
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=implementation_step_plan \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/implementation-step-plan.yaml
```

## Enforcement

Step-plan structure and package binding are enforced by the runtime validators
(`enterprise_dev_pipeline.py`), not by prompt prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
