Record post-deployment validation for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/post-deploy-validate.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=RELEASE_VERIFICATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Enforcement

Post-deploy validation applies only when deployment is in scope and requires real verification
evidence. Freshness and applicability are enforced by the runtime validators (`stage_router.py`,
`enterprise_dev_qa_progress.py`), not by prompt prose alone. Deployment execution is human/SRE-only.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
