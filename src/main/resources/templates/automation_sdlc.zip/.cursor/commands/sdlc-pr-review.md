Run the AI final PR review on the provider PR for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/pr-review.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=PR_REVIEW
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=ai_pr_review \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/ai-pr-review.yaml
```

## Enforcement

AI final review binds the provider PR head SHA and produces a recommendation only (`READY` |
`NEEDS_FIXES` | `BLOCKED`). It **cannot** satisfy human PR review or merge approval. Rules are
enforced by `enterprise_pr_review.py` and `merge_gate_preconditions()`.

## Handoff

After AI review is current, run human PR review:

```bash
/sdlc-peer-review <ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
