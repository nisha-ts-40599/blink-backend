Promote a local unpushed workflow candidate to an explicit commit (atomic invalidation).

Requires `ISSUE=<ISSUE-ID>`.

## Read-only preflight (mandatory)

Run dry-run first — no mutation without explicit authorization:

```bash
make ai-sdlc-promote-local-candidate ROOT=<workspace-root> ISSUE=<ISSUE-ID> \
  REPO_ID=<repo-id> COMMIT_SHA=<new-commit> CURRENT=<expected-current-candidate> \
  REASON="<human justification>"
```

Review the report:

- previous vs requested candidate
- git relation (`SAME`, `FAST_FORWARD`, `DIVERGED`, `ANCESTOR_REWIND`, `UNKNOWN`)
- proposed downstream invalidations and gate stale markers
- `mutation applied: no`

Stop and show blockers if status is `BLOCKED`, `CANDIDATE_CHANGED_SINCE_REVIEW`, or `REPAIR_REQUIRED`.

## Authorized mutation

Only after human confirmation of the dry-run impact:

```bash
make ai-sdlc-promote-local-candidate ROOT=<workspace-root> ISSUE=<ISSUE-ID> \
  REPO_ID=<repo-id> COMMIT_SHA=<new-commit> CURRENT=<expected-current-candidate> \
  REASON="<human justification>" WRITE=1
```

## Enforcement

- Read-only by default; `WRITE=1` required for mutation.
- Compare-and-swap: `CURRENT` must match the workflow candidate or the command returns `CANDIDATE_CHANGED_SINCE_REVIEW` with no writes.
- Does not push, create provider PRs, merge, deploy, or modify product source.
- Does not silently use repository HEAD — `COMMIT_SHA` is explicit.
- Atomic workflow mutation with downstream evidence invalidation is enforced by `local_candidate_promotion.py` and `enterprise_dev_pipeline.invalidate_on_commit_change()`, not prompt prose alone.

## Handoff

After successful promotion, recapture developer tests against the new candidate:

```bash
/sdlc-developer-test
```

Then re-run the stage router:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Do not route to `/sdlc-implement-prep`, `/sdlc-implement`, or `/sdlc-register-pr` until required recapture phases complete.
