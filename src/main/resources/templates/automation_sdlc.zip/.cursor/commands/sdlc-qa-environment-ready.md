Confirm QA environment readiness (QA-05) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/qa-environment-ready.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_VALIDATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=qa_environment_readiness \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/qa-environment-readiness.yaml
```

## Enforcement

An environment identifier is required and credential/PII fields are rejected. QA execution is
blocked until the environment is READY. These rules are enforced by the runtime validators
(`enterprise_qa_pipeline.py`), not by prompt prose alone. Never self-approve QA gates.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
