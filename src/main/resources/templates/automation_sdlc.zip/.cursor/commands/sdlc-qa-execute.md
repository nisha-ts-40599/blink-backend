Execute functional QA and record results (QA-07) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/qa-validation.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_VALIDATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=qa_execution \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/qa-execution.yaml
```

## Enforcement

A PASS requires a **named human tester** (an AI actor is rejected), tested-commit binding, and no
required test in NOT_EXECUTED. A new commit marks QA STALE. These rules are enforced by the runtime
validators (`enterprise_qa_pipeline.py`, `enterprise_dev_qa_progress.py`), not by prompt prose
alone. QA agents may not modify product source.

## Handoff

If QA fails, run `/sdlc-triage-defects <ISSUE-ID>`, otherwise:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
