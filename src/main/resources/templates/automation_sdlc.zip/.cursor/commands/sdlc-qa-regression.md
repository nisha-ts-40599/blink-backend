Run regression execution (QA-10) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/qa-regression.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_VALIDATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=regression_execution \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/regression-execution.yaml
```

## Enforcement

Regression execution must bind tested_commit, and a PASS requires recorded suite results. Regression
scope is driven by the regression analysis. These rules are enforced by the runtime validators
(`enterprise_qa_pipeline.py`), not by prompt prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
