Run the QA requirement analysis (QA-01) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/qa-requirement-analysis.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=IMPACT_ANALYSIS
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=qa_requirement_analysis \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/qa-requirement-analysis.yaml
```

## Enforcement

Acceptance-criteria coverage mapping is required, and unresolved blocking QA questions block G-PLAN.
These rules are enforced by the runtime validators (`enterprise_qa_pipeline.py`), not by prompt
prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
