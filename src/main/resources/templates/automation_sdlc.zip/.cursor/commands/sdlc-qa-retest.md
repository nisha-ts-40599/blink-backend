Retest fixed defects (QA-09) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/qa-retest.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_VALIDATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=retest_evidence \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/retest-evidence.yaml
```

## Enforcement

Retest must reference the defect id(s) and bind the fix_commit; a defect cannot be closed from
unit-test-only evidence. These rules are enforced by the runtime validators
(`enterprise_qa_pipeline.py`), not by prompt prose alone.

When recording retest evidence via CLI, pass required bindings explicitly:

```bash
make ai-sdlc-record-qa-execution ROOT=<workspace-root> ISSUE=<ISSUE-ID> \
  --retest --defect-id D-123 --fix-commit <sha> --executed-by '<tester>' \
  --status PASSED --tested-commit <sha> --write
```

Or via delivery evidence CLI:

```bash
python ai-sdlc/tools/orchestration/record_enterprise_delivery_evidence.py \
  --root <workspace-root> --issue <ISSUE-ID> \
  --action-id WRITE_QA_RETEST_EVIDENCE --defect-id D-123 --fix-commit <sha> \
  --executed-by '<tester>' --status PASSED --write
```

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
