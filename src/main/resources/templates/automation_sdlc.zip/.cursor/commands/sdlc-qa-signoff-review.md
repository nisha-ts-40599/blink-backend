Produce the QA sign-off recommendation (QA-11) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/qa-signoff-review.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_VALIDATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=qa_signoff_recommendation \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/qa-signoff-recommendation.yaml
```

## Enforcement

QA sign-off is a **recommendation only** (GO / NO_GO / GO_WITH_OBSERVATIONS / CONDITIONAL) — it can
never approve a gate. G-QA-POST requires a human gate approval via `/sdlc-approve-qa`. These rules
are enforced by the runtime validators (`enterprise_qa_pipeline.py`), not by prompt prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
