Record smoke test evidence (QA-06) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/qa-smoke.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_VALIDATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=smoke_test_evidence \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/smoke-test-evidence.yaml
```

## Enforcement

Smoke evidence must bind tested_commit and record checks; a failed smoke blocks functional QA. These
rules are enforced by the runtime validators (`enterprise_qa_pipeline.py`), not by prompt prose
alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
