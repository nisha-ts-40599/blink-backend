Author the QA strategy (QA-02) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/qa-strategy.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_STRATEGY
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=qa_strategy \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/qa-strategy.yaml
```

## Enforcement

Test levels/scope are required, and Tier 3 work requires a standalone QA strategy document. These
rules are enforced by the runtime validators (`enterprise_qa_pipeline.py`), not by prompt prose
alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
