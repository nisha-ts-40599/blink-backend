Refresh an already-registered provider PR (update head SHA / metadata) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/pr-registration.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=PR_REGISTRATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Delegate to runtime

```bash
make ai-sdlc-register-pr ROOT=<workspace-root> ISSUE=<ISSUE-ID> REPO_ID=<repo> \
  PR_URL=<provider-pr-url> SOURCE_BRANCH=<branch> TARGET_BRANCH=<base> COMMIT_SHA=<new-head-sha>
```

Registration is idempotent for an existing PR URL and updates the bound head SHA.

## Enforcement

When the PR head drifts, prior review / QA / G-QA-POST / G-PR-MERGE evidence is invalidated and must
be re-established. This is enforced by the runtime validators (`enterprise_pr_merge.py`), not by
prompt prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
