Register a draft PR candidate (DEV-08) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/register-draft-pr.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=PR_REGISTRATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=pr_registration \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/pr-registration.yaml
```

## Enforcement

A local un-pushed candidate is distinguished from a provider-hosted PR (`LOCAL_UNPUSHED` vs a real
url/number). head_sha binding is required. These rules are enforced by the runtime validators
(`enterprise_pr_merge.py`), not by prompt prose alone. Do not self-merge.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
