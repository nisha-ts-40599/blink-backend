Register a formal provider-hosted PR for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/pr-registration.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=PR_REGISTRATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Delegate to runtime

```bash
make ai-sdlc-register-pr ROOT=<workspace-root> ISSUE=<ISSUE-ID> REPO_ID=<repo> \
  PR_URL=<provider-pr-url> SOURCE_BRANCH=<branch> TARGET_BRANCH=<base> COMMIT_SHA=<head-sha>
```

## Enforcement

A provider PR requires a real url/number (a local un-pushed candidate is not a provider PR). These
rules are enforced by the runtime validators (`enterprise_pr_merge.py`), not by prompt prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
