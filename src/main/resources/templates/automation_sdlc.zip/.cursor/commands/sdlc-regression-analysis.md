Produce the risk-based regression analysis (QA-04) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/qa-strategy.prompt.md

Regression analysis is produced alongside the QA strategy / test design. Enumerate impacted areas
and their risk levels — do not derive it from modernization scope only.

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=TECHNICAL_PLAN
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate the produced artifact

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=regression_analysis \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/regression-analysis.yaml
```

## Enforcement

Impacted areas with risk levels are required, and the analysis must be risk-based (not
modernization-only). These rules are enforced by the runtime validators
(`enterprise_qa_pipeline.py`), not by prompt prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
