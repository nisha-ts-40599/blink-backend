Reopen a defect after failed retest and record reopen analysis for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/reopen-defect.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_VALIDATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate produced artifacts

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=reopen_analysis \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/reopen-analysis.yaml
```

## Enforcement

Reopen history preservation and routing to corrected implementation are enforced by
`enterprise_finding_lifecycle.py`. This command does not mark defects verified or approve gates.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
