Resume the enterprise Development + QA pipeline: show status and the next authorized action.

Requires `ISSUE=<ISSUE-ID>`.

Run the read-only stage router and the enterprise progress projection:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-enterprise-progress ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Then follow the **Copy command** line from the **Authoritative next action** block in the router output. It resolves to the single canonical next command in strict priority order (grooming → implementation package → bounded steps → developer tests → AI review → attestation → validation → draft PR → QA → sign-off → formal PR → PR review → merge → verify → post-deploy → close).

Trigger the matching slash command or `make` target shown in the authoritative block.

This command is read-only. Gate approvals and merges remain human-only. Enforcement lives in the runtime validators, not in prompt prose alone.
