Show the exact next lifecycle action for the current issue. Phase 2A is read-only planning; Phase 2B adds bounded safe-action execution when explicitly enabled in a pilot workspace.

Requires `ISSUE=<ISSUE-ID>`.

## Public syntax

```text
/sdlc-run <ISSUE>
/sdlc-run <ISSUE> MODE=compact
/sdlc-run <ISSUE> MODE=guided
/sdlc-run <ISSUE> MODE=diagnostic
/sdlc-run <ISSUE> EXECUTE=0
/sdlc-run <ISSUE> EXECUTE=1
/sdlc-run <ISSUE> DRY_RUN=1
```

Default mode: **guided**.

Default execution: **false** (`EXECUTE=0` / planner-only). Use `EXECUTE=1` only in pilot workspaces with `features.sdlc_run_execution.enabled: true`.

## Runtime

```bash
make ai-sdlc-run ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-run ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXECUTE=0
make ai-sdlc-run ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXECUTE=1
make ai-sdlc-run ROOT=<workspace-root> ISSUE=<ISSUE-ID> MODE=diagnostic
```

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.

## Behavior

### Planner-only (`EXECUTE=0`, default)

Strictly read-only. It:

- loads canonical workflow state;
- resolves the authoritative next command via `resolve_authoritative_next_command()`;
- classifies the action (READ_ONLY, LOCAL_MUTATION, HUMAN_APPROVAL, PROVIDER_WRITE, BLOCKED, COMPLETE, etc.);
- returns exactly **one** copyable command.

It does **not** modify workflow state, write artifacts, execute prompts, approve gates, register PRs, deploy, or invoke enterprise writers.

### Bounded execution (`EXECUTE=1`, pilot only)

When `features.sdlc_run_execution.enabled` is true **and** the workspace has an explicit pilot marker:

- resolve authoritative next action;
- classify and validate against `sdlc-run-execution-policy.yaml`;
- execute **at most one** permitted safe action via typed handlers (never shell-router strings);
- re-read canonical workflow state;
- return exactly **one** copyable `/sdlc-run <ISSUE>` next command.

Phase 2B never executes: human approval, provider write, repository mutation, deployment, destructive actions, or unknown handlers.

## Output contract

Every response ends with:

```text
Copy command:
<exact command>
```

When human identity or decision values cannot be resolved, the copy command falls back to:

```text
/sdlc-status <ISSUE> MODE=diagnostic
```

## Routing consistency

The copy command must match:

- `/sdlc-next`
- `/sdlc-status`
- `/sdlc-resume`
- `make ai-sdlc-stage-router`

Do not follow deprecated `next_prompt` hints.
