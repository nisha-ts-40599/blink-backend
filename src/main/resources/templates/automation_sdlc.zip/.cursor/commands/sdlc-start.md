Start AI-SDLC grooming for an issue or raw requirement description (read-only checks + context assembly).

## Supported entry modes

| Mode | Example | Behavior |
|------|---------|----------|
| Issue ID (external tracker) | `/sdlc-start PROJECT-123` | Resolve/fetch tracker context when a configured provider supplies a body |
| Issue ID (manual/read_only) | `/sdlc-start PROJ-101` | Reserve issue identity; if no body exists, route to explicit source selection — do not treat PROJ-101 as an external tracker |
| Confirmed product-scope story | `/sdlc-start PRODUCT-E001-S003` | Start grooming from a confirmed internal story; do not mutate the canonical item |
| Catalog (bare) | `/sdlc-start` | List eligible confirmed stories; do not auto-start |
| Description text | `/sdlc-start "bounded work item description"` | Generate stable `LOCAL-<hash>` work-item ID; capture verbatim description |
| Canonical setup-source reuse | `/sdlc-start PROJECT-123 --use-setup-requirement` | Explicit human selection to copy/reference the current authorized setup requirement as the work-item source |

Run preparation first (safe minimum state + source capture — **does not clarify**):

```bash
# Shell-safe (preferred for descriptions):
make ai-sdlc-sdlc-start-prep ROOT=<ROOT> INPUT_FILE=/path/to/description.txt
# Simple issue IDs only:
make ai-sdlc-sdlc-start-prep ROOT=<ROOT> INPUT='PROJ-101'
# Explicit canonical setup-requirement reuse:
make ai-sdlc-sdlc-start-prep ROOT=<ROOT> INPUT='PROJ-101' USE_SETUP_REQUIREMENT=1
```

Then run the read-only operator chain from the framework repo (or embedded layout with `ROOT=..`):

```bash
make ai-sdlc-guard-framework-clean ROOT=<ROOT>
make ai-sdlc-validate-setup-readiness ROOT=<ROOT> REQUIRE=context
make ai-sdlc-resolve-issue-tracker ROOT=<ROOT> ISSUE=<ISSUE>
make ai-sdlc-context-report ROOT=<ROOT> ISSUE=<ISSUE>
make ai-sdlc-groom-prep ROOT=<ROOT> ISSUE=<ISSUE>
make ai-sdlc-stage-router ROOT=<ROOT> ISSUE=<ISSUE>
```

`ai-sdlc-validate-setup-readiness REQUIRE=context` confirms overlay/context readiness (non-blocking assessment). Requirement grooming and `/clarify-requirement` are allowed when `delivery_ready=false`. **Implementation** remains blocked until delivery readiness is established. Complete setup via `/setup-existing-project refresh` or `/setup-existing-workspace refresh` before implementation phases.

Embedded layout:

```bash
make ai-sdlc-sdlc-start-prep ROOT=.. INPUT='PROJ-101'
make ai-sdlc-guard-framework-clean ROOT=..
make ai-sdlc-validate-setup-readiness ROOT=.. REQUIRE=context
make ai-sdlc-resolve-issue-tracker ROOT=.. ISSUE=<ISSUE>
make ai-sdlc-context-report ROOT=.. ISSUE=<ISSUE>
make ai-sdlc-groom-prep ROOT=.. ISSUE=<ISSUE>
make ai-sdlc-stage-router ROOT=.. ISSUE=<ISSUE>
```

Use overlay-first context from `.cursor/ai-sdlc/**`. Do not modify framework files during product delivery.

## Responsibility boundary

**`/sdlc-start` owns:** workspace resolution, setup validation, input classification, minimum workflow-state initialization, raw source capture, context bundle preparation, stage routing recommendation, explicit handoff.

**`/sdlc-start` must NOT:** produce `requirement.md`, acceptance criteria, open questions, classification, impact analysis, specification, technical plan, or gate approvals. Do **not** automatically execute `/clarify-requirement`.

**Allowed writes:** minimum workflow-state YAML, `raw-input.md` + `raw-input.meta.json` (description mode only), workspace cache under `.cursor/ai-sdlc/.cache/` (description capture or fetch cache), groom-prep context bundle in workspace cache, routing recommendation output.

## Handoff contract (required final output)

```text
Work item ID: <ISSUE>
Input source: issue | description
Current stage: <stage>
Prepared context:
  - <paths and bundle references>
Next authorized command:
<from prep: /clarify-requirement <ISSUE> OR /sdlc-start <ISSUE> --use-setup-requirement>

Do not continue automatically.
```

Never emit `/clarify-requirement` as the authorized command when that command is blocked for missing source.

**Immediate next step:**

- Description mode or bound source: `/clarify-requirement <ISSUE>`
- Manual issue ID with no body: follow the source-selection command (typically `/sdlc-start <ISSUE> --use-setup-requirement`). Reusing the setup requirement does **not** confirm that the whole product source is one implementation slice.

**If stage is REQUIREMENT_GROOMING — correct sequence:**

1. `/sdlc-start <ISSUE>` or `/sdlc-start "<description>"` — prep, guard, tracker resolution, context, groom-prep, stage router
2. `/clarify-requirement <ISSUE>` — produce `requirement.md` (skip if issue body unavailable in issue-ID mode)
3. Extract grooming state (auto-run by clarify-requirement, or: `make ai-sdlc-extract-grooming-state ROOT=<ROOT> ISSUE=<ISSUE> WRITE=1`)
4. `/requirement-grooming-status <ISSUE>` — check current status and determine next step
5. `/grooming-stakeholder-pack <ISSUE>` — if DoR is not ready
6. `/grooming-revision <ISSUE>` — after stakeholder feedback is available
7. `/grooming-sign-off-capture <ISSUE>` — when DoR is ready
8. Approve G-GROOM (when required — human gate only): `/approve-grooming <ISSUE>`
   Advanced/debug:
   ```bash
   make ai-sdlc-approve-gate ROOT=<ROOT> ISSUE=<ISSUE> GATE=G-GROOM \
     APPROVER="<Full Name>:<email>" DECISION=approved \
     EVIDENCE_REF=".cursor/ai-sdlc/workflow-state/<ISSUE>/grooming-signoff-summary.md" \
     WRITE=1
   ```
9. **Phase 0 exit → Phase 1 entry:** `/classify-work <ISSUE>` — only after DoR is ready and G-GROOM is approved; starts Delivery Readiness / Pre-development

**Do not run `/classify-work` until:**

- `requirement.md` exists
- grooming state has been extracted (`make ai-sdlc-extract-grooming-state WRITE=1`)
- DoR is ready (`make ai-sdlc-validate-requirement-dor WRITE=1`)
- stakeholder grooming / revision / sign-off complete as needed
- G-GROOM is approved when required (`/approve-grooming <ISSUE>` or `make ai-sdlc-approve-gate ... GATE=G-GROOM ...`)

**Implementation remains blocked** during Requirement Grooming and until later Delivery Readiness / Implementation phases complete their gates.

**Issue body / source guard (manual issue ID with no body):**

If prep reports **issue body unavailable** or `SELECT_WORK_ITEM_SOURCE`:

- State clearly: **work-item source required**
- **Do not run `/clarify-requirement`**
- **Do not ask the operator to repaste a product requirement that already exists as the canonical setup source**
- Offer only currently authorized sources (canonical setup requirement, new description, explicit file)
- Explicit reuse: `/sdlc-start <ISSUE> --use-setup-requirement` or `USE_SETUP_REQUIREMENT=1`

For an external tracker, retry fetch when credentials are already loaded:

```bash
make ai-sdlc-fetch-issue ROOT=<ROOT> ISSUE=<ISSUE>
make ai-sdlc-groom-prep ROOT=<ROOT> ISSUE=<ISSUE>
```

After a source is bound, continue from `/clarify-requirement <ISSUE>` then `/requirement-grooming-status <ISSUE>`.
