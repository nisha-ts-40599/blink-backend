Show the enterprise Development + QA pipeline status for the current issue (read-only).

Requires `ISSUE=<ISSUE-ID>`.

Run the read-only stage router and the enterprise progress projection:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-enterprise-progress ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.

Print the projected `workflow_progress` (phase-by-phase status), `implementation_coverage`, and the **Authoritative next action** block from the router output. This command is **advisory / read-only** — it does not execute workflow actions, mutate state, or approve gates.

Enforcement of gate/evidence/freshness rules lives in the runtime validators
(`stage_router.py`, `enterprise_dev_qa_progress.py`, `routing_invariants.py`), not in prompt prose alone.
