Triage QA defects (QA-08) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/triage-defects.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=QA_VALIDATION
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Validate each defect

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=defect \
  FILE=.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/defects/<DEFECT-ID>.yaml
```

## Enforcement

Each defect must link a test_case_id, record discovered_in_commit, and carry a severity. These rules
are enforced by the runtime validators (`enterprise_qa_pipeline.py`), not by prompt prose alone.
Defect remediation runs through `/sdlc-fix-review-findings` / `/sdlc-implement`, then `/sdlc-qa-retest`.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
