Record post-implementation validation evidence (DEV-07) for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/validate-implementation.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=TEST_VALIDATION PROMPT_STEM=validate-implementation
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Enforcement

Validation requires real command results bound to the current candidate commit — pasted textual
PASS is not acceptable, and a new commit marks validation STALE. These rules are enforced by the
runtime validators (`enterprise_dev_pipeline.py`, `enterprise_dev_qa_progress.py`), not by prompt
prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
