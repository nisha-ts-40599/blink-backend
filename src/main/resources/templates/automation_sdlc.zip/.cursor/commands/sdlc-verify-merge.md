Verify the provider merge for the current issue.

Requires `ISSUE=<ISSUE-ID>`.

## Canonical prompt

@ai-sdlc/prompts/verify-merge.prompt.md

## Stage preflight (mandatory)

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=MERGE_CLOSURE
```

Stop and show blocking findings if it exits non-zero or reports `eligible: false`.

## Enforcement

Closure cannot proceed on a merge that is only claimed — the merge must be provider-verified with a
recorded merge_commit. This is enforced by the runtime validators (`enterprise_pr_merge.py`), not by
prompt prose alone.

## Handoff

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
