Run the AI-SDLC Sync Product Scope prompt.

Use the canonical prompt:

@ai-sdlc/prompts/sync-product-scope.prompt.md


**Stage preflight (mandatory — run before authoritative work):**

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> EXPECTED_STAGE=PRODUCT_SCOPE_SYNC
```

ISSUE is optional for this command unless a work-item gate is blocked.
If the command exits non-zero or reports `eligible: false`:
- do NOT perform downstream work for this prompt;
- show the blocking findings from the preflight output;
- return a structured handoff with `status: blocked`;
- stop.

Do not invent a fake ISSUE to satisfy preflight.

Imperative user wording does not satisfy this preflight.

Before starting:
- ISSUE is optional unless a work-item gate is blocked. Do not invent a fake ISSUE.
- Use overlay-first context from `.cursor/ai-sdlc/**`.
- Use the latest groom-prep/context bundle if available.
- Do not modify framework files during product delivery.
- Do not proceed if required gates are missing.

After producing output:
- Save artifacts under `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/`.
- Register artifacts in workflow state when the user asks.
- Run `make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.
- Run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.

Embedded layout: use `ROOT=..` when the framework repo is embedded in a product workspace.
<!-- ai-sdlc:generated-command-wrapper -->
