## Summary

<!-- 1–2 sentences: what this PR does and why -->

## Related work

- Issue: <!-- link to GitHub issue or Jira ticket -->
- Technical plan: <!-- link to ai-sdlc/plans/[issue-id].md or PR comment -->
- Impact analysis: <!-- link to impact analysis artifact, or N/A -->
- Requirement: <!-- link to requirement doc or N/A -->

## Work tier

**Tier:** <!-- 1 / 2 / 3 / 4 — see ai-sdlc/work-tiers.md -->
**Risk rules triggered:** <!-- R-DB-001, R-AUTH-001, etc., or None -->

## Type of change

- [ ] Feature
- [ ] Bug fix
- [ ] Refactor
- [ ] Chore / tooling
- [ ] Docs only
- [ ] DB migration
- [ ] Security / auth change

## Behavior

### Before

<!-- what the system did before this change -->

### After

<!-- what the system does after this change -->

## Security / data

- **Touches auth / authz:** <!-- Yes / No -->
- **Touches sensitive or PII data:** <!-- Yes / No -->
- **New external egress or dependency:** <!-- Yes / No -->
- **Notes:** <!-- any security context relevant to reviewers -->

## API / contract changes

- [ ] No API changes
- [ ] Additive API changes only (backward compatible)
- [ ] Breaking API changes — OpenAPI diff attached or linked
- [ ] OpenAPI spec updated: <!-- path to spec file -->

## Database changes

- [ ] No DB changes
- [ ] Additive schema change (R-DB-001 — G-PLAN required)
- [ ] Destructive / wide migration (R-DB-002 — G-PLAN + G-SEC + DBA approval required)
- [ ] Migration rollback script: <!-- link or "included in PR" -->

## Tests

- [ ] Unit tests added or updated
- [ ] Integration tests added or updated
- [ ] No tests required — reason: <!-- explain -->
- Manual verification steps: <!-- commands or steps to verify locally -->

## Documentation

- [ ] No documentation changes required
- [ ] README / runbook updated
- [ ] ADR created or updated: <!-- link -->
- [ ] OpenAPI spec updated (see API section above)
- [ ] Wiki / Confluence page updated: <!-- link -->

## Rollback plan

<!-- How to roll back this change if it causes issues in production.
     For Tier 2+, this should match the rollback section of the technical plan. -->

## Approval gates

<!-- Mark which gates have been satisfied before requesting review. -->

- [ ] **G-PLAN** — Technical plan approved by engineering lead (required for Tier 2+)
  - Approved by: <!-- @mention + link to approval comment -->
- [ ] **G-SEC** — Security review approved (required for Tier 3+, R-AUTH-001, R-API-001)
  - Approved by: <!-- @mention + link to approval comment, or N/A -->
- [ ] **G-PR-MERGE** — This checklist complete; AI review findings addressed; CI green

## AI review summary

<!-- Paste the key findings from pr-review.prompt.md, or link to the review output.
     Note any must-fix items that were resolved and any advisory items deferred. -->

- Must-fix items resolved: <!-- count / description, or None -->
- Advisory items deferred: <!-- count / description with rationale, or None -->

## Engineering guardrails

> Full reference: `ai-sdlc/governance/enterprise-engineering-guardrails.md`

- [ ] Reused existing code, components, or utilities where appropriate — no new code written for something the codebase already provides
- [ ] No duplicate business logic introduced — shared logic extracted only where duplication creates real maintenance risk
- [ ] Follows existing architecture, naming conventions, layer boundaries, and error-handling patterns — no new cross-cutting patterns introduced
- [ ] No unrequested refactoring or formatting churn — diff contains only the approved change
- [ ] Bug fix uses a minimal safe change targeting the confirmed root cause; regression test included if applicable
- [ ] New dependencies justified in PR body (problem solved, license, alternative considered) — no dependency added to solve something the standard library or existing codebase already provides
- [ ] Tests cover meaningful behaviour, edge cases, and failure paths — not just happy-path coverage or metric inflation
- [ ] API, DB migration, and OpenAPI updates included where the change requires them (or explicitly marked N/A above)
- [ ] Security, logging, configuration, and PII handling reviewed where applicable — no secrets in logs, no hardcoded credentials, input validated at entry point
- [ ] Any guardrail exceptions are documented here: <!-- describe exception and rationale, or delete this line -->

## Pre-merge checklist

- [ ] CI is green on latest commit
- [ ] Branch is up to date with main (no unresolved conflicts)
- [ ] All required approval gates satisfied (see above)
- [ ] Engineering guardrails checklist complete (see above)
- [ ] PR title follows format: `type(scope): description [tier-N]`
- [ ] No unintended file changes in diff
- [ ] No secrets, credentials, or tokens in diff
- [ ] Work tier label added to this PR

## Reviewer hints

<!-- Point the reviewer to the highest-risk areas, any non-obvious decisions,
     or parts of the diff that need domain expertise to evaluate. -->
