# TalentServ AI-SDLC Framework

Reusable workflows, templates, prompts, governance rules, conformance tooling, and CI templates for an AI-assisted software development lifecycle.

**New to the framework?** [ai-sdlc/adoption/quick-start.md](ai-sdlc/adoption/quick-start.md) — up and running in 30 minutes.

**Full reference:** [ai-sdlc/README.md](ai-sdlc/README.md)

**Documentation index:** [docs/operating-model/README.md](docs/operating-model/README.md)

---

## Quick start

```bash
make ai-sdlc-install
make ai-sdlc-conformance-protected   # expected: all protected conformance checks pass
```

`make ai-sdlc-install` creates a local Python virtual environment (`.venv-ai-sdlc/`) and installs the conformance runner's Python dependencies (`jsonschema`, `PyYAML`, `yamllint`).

For protected conformance (OPA policy checks), install OPA explicitly:

```bash
make ai-sdlc-install-opa
```

After both complete, local lint, prompt-check, and full conformance commands are available.

---

## What is stable and usable today

| Component | Path | Use |
|-----------|------|-----|
| Prompt library | `ai-sdlc/prompts/` | Daily — in Cursor |
| Workflow runbooks | `ai-sdlc/workflows/` | Daily — as process guides |
| Document templates | `ai-sdlc/templates/` | Daily — for issues, PRs, plans |
| Governance docs | `ai-sdlc/governance/` | Reference — approval rules, HIL policy |
| Work-tiers model | `ai-sdlc/work-tiers.md` | Reference — tier classification |
| OPA policies | `ai-sdlc/policies/` | Enforced — via conformance runner |
| JSON schemas | `ai-sdlc/schemas/` | Validated — in CI |
| Conformance runner | `ai-sdlc/tools/` | CI — GitHub Actions, GitLab, Azure |
| CI templates | `ai-sdlc/ci/` | Copy and adapt for your CI system |
| Setup prompts | `ai-sdlc/prompts/setup-*.prompt.md` | Onboarding — project and workspace |
| Adoption guides | `ai-sdlc/adoption/` | Rollout — first week plan, workflow guide |
| Self-adoption examples | `ai-sdlc/examples/self-adoption/` | Reference configs for this repo |

---

## Reference implementation (not for production)

> `ai-sdlc/runtime/` contains a local Python orchestrator for exploring the
> framework's architecture. **It is a reference demo — not a production system.**
>
> All step executors are noop. All adapters (issue tracker, git provider, document
> store) are mocks. The approval engine returns simulated approvals in dev profile.
> No real external side effects occur.
>
> For real AI-assisted development, use the prompts, workflows, governance docs,
> and conformance tooling — not the runtime orchestrator.

---

## Conformance results

| Profile | Command | Expected result |
|---------|---------|----------------|
| Dev (local) | `make ai-sdlc-conformance` | Schema checks pass; OPA-dependent tests skipped (no OPA required) |
| Protected (CI / pre-merge) | `make ai-sdlc-conformance-protected` | All protected conformance checks pass; zero failures |
