# AI-SDLC Operating Model

This directory defines a **generic, reusable AI-assisted and agentic software development lifecycle (SDLC)** framework. Teams adapt it by copying `project-config.template.yaml` to a project-specific configuration and wiring Model Context Protocol (MCP) servers, issue trackers, CI/CD, and human approval gates to match their environment.

## Purpose

The framework provides:

- A **consistent operating model** from requirement intake through merge, deployment readiness, and post-release verification.
- **Work classification** (tiers) aligned with risk, approvals, documentation, testing, and automation depth.
- **Agent roles** with explicit responsibilities, allowed versus restricted actions, and structured handoffs (see `acp/`).
- **Workflows**, **templates**, and **parameterized prompts** that any orchestration layer (human-run, scripted, or multi-agent) can execute.
- **Governance**: approval gates, risk rules, audit expectations, human-in-the-loop policy, and an automation maturity model.

This repository does **not** implement product business logic. It supplies configuration patterns, documentation, and integration placeholders.

## Internal Production Candidate (v0.6.0)

H1–H13 stabilization baseline for controlled internal use — **not Enterprise Ready**. Authoritative docs:

- [`governance/internal-production-candidate/README.md`](governance/internal-production-candidate/README.md)

Key authority boundaries:
- **Canonical workflow YAML** = current state; **lifecycle-events.jsonl** = audit history; generated Markdown = projections only.
- **G-PR-MERGE ≠ merge**; **merge readiness ≠ merge**; **completion candidate ≠ delivery readiness** (Phase 4 authority).
- **AI review ≠ developer attestation**; PR registration does not require a URL for local candidates.

Release validation: `make ai-sdlc-release-candidate-test`

## End-to-End Flow (Conceptual)

```mermaid
flowchart LR
  subgraph intake [Intake]
    R[Requirements]
    C[Clarification]
    T[Tier / Risk]
  end
  subgraph design [Design]
    D[Docs / Spec]
    I[Issues]
    IA[Impact Analysis]
    P[Technical Plan]
  end
  subgraph build [Build]
    A[Approvals]
    S[Stepwise Implementation]
    G[Tests]
    V[Validation / CI]
  end
  subgraph ship [Ship]
    AIR[AI Review]
    HPR[Human PR Review]
    FIX[AI-Assisted Fixes]
    MR[Merge Readiness]
    DR[Deploy Readiness]
  end
  subgraph learn [Learn]
    PV[Post-Release Verification]
    KU[Knowledge Update]
  end
  R --> C --> T
  T --> D --> I
  I --> IA --> P
  P --> A --> S --> G --> V
  V --> AIR --> HPR --> FIX --> MR --> DR
  DR --> PV --> KU
```

## Core Stages Mapped to Repository Artifacts

| Stage | Description | Primary artifacts |
|-------|-------------|-------------------|
| 1. Requirement intake | Capture raw need, source, stakeholders | `templates/requirement-template.md`, `workflows/requirement-to-issue.md` |
| 2. Clarification | Resolve ambiguity, acceptance criteria | `prompts/clarify-requirement.prompt.md` |
| 3. Tier / risk classification | Drive approvals and rigor | `work-tiers.md`, `prompts/classify-work.prompt.md`, `governance/risk-rules.md` |
| 4. Documentation / spec | Authoritative technical intent | `templates/specification-template.md`, `prompts/create-spec.prompt.md` |
| 5. Issue creation | Trackable units of work | `templates/issue-template.md`, `prompts/create-issues.prompt.md` |
| 6. Pickup | Human or agent claims work under policy | `agents.md`, `governance/human-in-the-loop-policy.md` |
| 7. Impact analysis | Blast radius, dependencies, rollback | `templates/impact-analysis-template.md`, `prompts/impact-analysis.prompt.md` |
| 8. Technical planning | Steps, contracts, test strategy | `templates/technical-plan-template.md`, `prompts/technical-plan.prompt.md` |
| 9. Human approval gates | Tier-driven sign-off before high-risk change | `governance/approval-gates.md` |
| 10. Stepwise implementation | Small, reviewable increments | `workflows/plan-to-implementation.md`, `prompts/implement-step.prompt.md` |
| 11. Test generation | Automated and specified tests | `templates/test-plan-template.md`, `prompts/generate-tests.prompt.md` |
| 12. Automated validation | Lint, build, tests, scans, coverage | `ci/*`, MCP CI/test integrations |
| 13. AI code review | Structured findings | `templates/ai-review-template.md`, `prompts/pr-review.prompt.md` |
| 14. Human PR review | Mandatory per policy | `templates/pr-template.md`, `workflows/pr-review-and-fix.md` |
| 15. AI-assisted fixes | Address comments within guardrails | `prompts/fix-review-comments.prompt.md` |
| 16. Merge readiness | Checklist and tier gates | `governance/approval-gates.md` |
| 17. Deployment readiness | Environment, rollback, observability | `templates/release-checklist-template.md`, `workflows/release-readiness.md` |
| 18. Post-release verification | SLOs, smoke, feature flags | `workflows/post-release-verification.md`, `prompts/release-verification.prompt.md` |
| 19. Knowledge update | Docs, ADRs, runbooks | `templates/adr-template.md`, `prompts/update-docs.prompt.md` |

## How Configuration Drives Behavior

1. Copy `project-config.template.yaml` to your repository (for example `project-config.yaml`) and fill **project name**, **domain**, **stacks**, **tooling**, **security model**, **branching**, **deployment**, **observability**, and **definition of done**.
2. Map **approval rules** to your organization's roles (for example engineering lead, security, SRE).
3. Align **work tiers** with your risk appetite using `work-tiers.md` as the baseline; adjust thresholds in config if needed.
4. Wire **MCP** using `mcp/mcp-config.template.yaml` and enforce **mcp-permissions.md** and **mcp-security-guidelines.md**.
5. Attach **prompts** to your agent runtime, substituting placeholders (`{{PROJECT_CONTEXT}}`, etc.) from the active issue and config.

## Setting Up AI-SDLC for a Project

Every project that adopts this framework needs two files:

| File | Purpose |
|------|---------|
| `ai-sdlc/project-config.yaml` | Machine-readable project identity, stack, tooling, approval rules, and definition of done. Drives CI and governance tooling. |
| `ai-sdlc/project-context.md` | Human-readable project context injected as `{{PROJECT_CONTEXT}}` into every workflow prompt. Makes prompts produce project-specific output. |

Use the appropriate setup prompt to generate both files in a single agent session.

### For an existing repository

Use `ai-sdlc/prompts/setup-existing-project.prompt.md`.

The agent will:
1. Inspect the repository — structure, stack, CI, tests, security tooling, branch conventions.
2. Produce a repository profile and identify missing setup items.
3. Propose a filled `project-config.yaml` and `project-context.md`.
4. Recommend the safest first adoption scope.
5. Recommend a first pilot task.
6. List files to create and files not to touch.

```
Use prompts/setup-existing-project.prompt.md
PROJECT_CONTEXT: unknown — agent will inspect
```

### For a greenfield project

Use `ai-sdlc/prompts/setup-new-project.prompt.md`.

The agent will:
1. Gather or infer project intent — ask only essential missing questions.
2. Propose the technology profile and CI commands.
3. Generate a filled `project-config.yaml` and `project-context.md`.
4. Recommend initial workflows and work tier examples.
5. Produce a first 2-week rollout plan.
6. List all files to create with priorities.

```
Use prompts/setup-new-project.prompt.md
PROJECT_INTENT: <what the project does — domain, users, value delivered>
```

### After generation

Before committing either file:

- Review every value marked `# confirm` or `[to be confirmed]`.
- Validate approval roles map to real team identities.
- Confirm CI commands are accurate for the project's actual build system.
- Run `make ai-sdlc-conformance` to verify schema and registry integrity.
- Commit `project-config.yaml` and `project-context.md` on a feature branch and get a peer review.

### Template reference

`ai-sdlc/templates/project-context-template.md` is the base template populated by both setup prompts. It covers: project summary, architecture, tech stack, module map, SDLC operating rules, work tier examples, approval rules, CI commands, security rules, manual vs automated boundaries, definition of done, and prompt placeholder values.

---

## Setting Up AI-SDLC for Multi-Repo Workspaces

Many real systems are developed across multiple repositories opened together
in a Cursor workspace — for example: frontend UI, backend API, database migrations,
shared library, and infrastructure. The workspace-level setup adds a coordination
layer on top of per-repo setup.

### File locations

**Workspace-level** (in the tooling repo or workspace root):

| File | Purpose |
|------|---------|
| `ai-sdlc/workspace-config.yaml` | Machine-readable workspace identity, repo roster, cross-repo dependencies, deployment order, shared approval rules |
| `ai-sdlc/workspace-context.md` | Human-readable workspace context injected as `{{WORKSPACE_CONTEXT}}` into workspace-level prompts |

**Per-repo** (one set per repository):

| File | Purpose |
|------|---------|
| `ai-sdlc/projects/<repo-id>/project-config.yaml` | Per-repo config (from `project-config.template.yaml`) |
| `ai-sdlc/projects/<repo-id>/project-context.md` | Per-repo context injected as `{{PROJECT_CONTEXT}}` into repo-scoped prompts |

### For an existing multi-repo workspace

Use `ai-sdlc/prompts/setup-existing-workspace.prompt.md`.

The agent will:
1. Discover and classify all repositories in the workspace.
2. Profile each repo — stack, commands, CI, test coverage, security surfaces.
3. Map cross-repo dependencies, API contracts, and shared databases.
4. Infer the deployment topology and ordering.
5. Propose `workspace-config.yaml`, `workspace-context.md`, and per-repo context files.
6. Identify missing setup items (BLOCKING / RECOMMENDED / OPTIONAL).
7. Recommend a first cross-repo pilot task.
8. List all files to create with priorities.

```
Use prompts/setup-existing-workspace.prompt.md
WORKSPACE_CONTEXT: unknown — agent will inspect
```

### For a new multi-repo workspace

Use `ai-sdlc/prompts/setup-new-workspace.prompt.md`.

The agent will:
1. Gather system intent and planned repository roster.
2. Ask only essential missing questions in a single grouped message.
3. Map cross-repo dependencies and deployment order.
4. Generate `workspace-config.yaml`, `workspace-context.md`, and per-repo context files.
5. Recommend repo creation order, CI pipeline structure, and cross-repo approval rules.
6. Produce a first 2-week rollout plan for the full workspace.

```
Use prompts/setup-new-workspace.prompt.md
PROJECT_INTENT: <what the system does — domain, users, repos planned>
```

### After generation

Before committing any generated file:

- Review every `# confirm` and `[to be confirmed]` value.
- Validate cross-repo dependency types and contract surfaces are accurate.
- Confirm deployment order reflects actual operational sequencing.
- Confirm approval roles map to real team identities.
- Run `make ai-sdlc-conformance-protected` to verify schema and registry integrity.
- Commit on a feature branch with peer review before merging.

### Template references

| Template | Used for |
|----------|---------|
| `templates/workspace-config-template.yaml` | Workspace-level config |
| `templates/workspace-context-template.md` | Workspace-level context (cross-repo prompts) |
| `templates/repo-context-template.md` | Per-repo context (repo-scoped prompts) |
| `templates/project-context-template.md` | Per-repo context for standalone (non-workspace) projects |

### Cross-repo change governance

For changes that span two or more repositories:

- Any change touching 2+ repos is Tier 2 minimum.
- Database schema changes and API contract breaking changes are Tier 3 minimum.
- All affected repo PRs must be approved before any is merged.
- Merges follow deployment order.
- See `governance/multi-repo-merge-deploy-readiness.md` for detailed merge and deploy readiness rules.

---

## Human-in-the-Loop and Production Safety

High-impact actions (merge to protected branches, production deploy, secret rotation, infrastructure mutation) remain **human-gated** by default. Agents and automation perform analysis, drafting, branch creation, test execution, and PR preparation within **allowed** MCP scopes. See `governance/human-in-the-loop-policy.md` and `mcp/mcp-permissions.md`.

## Automation Maturity

Teams progress from **assisted** (AI drafts, humans execute) to **semi-autonomous** (orchestrated pipelines with explicit gates). Refer to `governance/automation-maturity-model.md`.

## Directory Index

| Path | Role |
|------|------|
| `project-config.template.yaml` | Master project adaptation template |
| `work-tiers.md` | Tier definitions and rigor matrix |
| `agents.md` | Agent model: roles, I/O, guardrails |
| `workflows/` | Stage-to-stage procedure markdown |
| `templates/` | Document and checklist templates (includes `project-context-template.md`, `workspace-config-template.yaml`, `workspace-context-template.md`, `repo-context-template.md`) |
| `prompts/` | Reusable parameterized LLM prompts (includes `setup-existing-project`, `setup-new-project`, `setup-existing-workspace`, `setup-new-workspace`) |
| `mcp/` | MCP configuration and security patterns |
| `acp/` | Agent communication protocol (handoffs) |
| `governance/` | Approvals, risk, audit, HITL, maturity, multi-repo readiness |
| `ci/` | Generic CI/CD stage templates |
| `ci/profiles/` | Reusable stack command profiles |
| `schemas/` | Executable JSON Schemas for ACP/workflow/governance |
| `schemas/schema-registry.yaml` | Resolver map from object type to schema path |
| `policies/` | OPA/Rego policy-as-code modules |
| `registry/` | Central ID registry (artifacts/events/gates/escalations/policies) |
| `tests/` | Runtime conformance fixtures and expected outcomes |
| `tools/conformance-runner/` | Lightweight Python conformance utility |
| `tools/install-opa.sh` | Local OPA bootstrap helper |
| `examples/java-spring-react-postgres.yaml` | Sample project config — Java + React + PostgreSQL |
| `examples/self-adoption/` | Reference self-adoption configs: this repo as single-project + multi-repo workspace example |
| `adoption/` | Practical onboarding and rollout package |
| `adoption/quick-start.md` | **Start here** — 30-minute onboarding: 2 files, 4 prompts, 3 rules, first pilot |
| `docs/operating-model/README.md` | **Documentation index** — operator, adoption, governance, reference |
| `docs/operating-model/current-sdlc-flow.md` | Textual lifecycle authority (implemented flow) |
| `docs/operating-model/ai-sdlc-workflow-visual-guide.md` | Visual workflow companion |
| `docs/operating-model/ai-sdlc-command-and-prompt-reference.md` | Complete command and prompt inventory |
| `adoption/prompt-quick-reference.md` | Curated daily-use prompt quick reference |
| `adoption/first-week-rollout-plan.md` | Day-by-day rollout plan for first-week adoption |

## Getting Started (Minimal)

1. Add `project-config.yaml` (from template) at repo or org level.
2. Register MCP servers per `mcp/mcp-config.template.yaml`.
3. Pick a workflow (for example `workflows/requirement-to-issue.md`) and run it once end-to-end with manual tool use.
4. Add CI templates from `ci/` and replace placeholders with your build commands and secrets references.
5. Validate handoffs and workflow headers against `schemas/`.
6. Evaluate policy decisions using `policies/`.
7. Use `registry/` as source-of-truth for IDs and retention classes.
8. Run conformance fixtures from `tests/` via `tools/conformance-runner/run_conformance.py`.
9. Use `tests/policy-test-matrix.yaml` to control schema/policy assertions.
10. Wire `ci/ai-sdlc-conformance-job.*` templates into your CI system.
11. Use `adoption/README.md` and related guides to onboard new teams.

## Local Quick Start

```bash
make ai-sdlc-install
make ai-sdlc-conformance
```

Strict enforcement (fails when OPA-required tests are skipped):

```bash
make ai-sdlc-conformance-strict
```

Mode-specific:

```bash
make ai-sdlc-schema-check
make ai-sdlc-policy-check
make ai-sdlc-conformance-junit
make ai-sdlc-conformance-report
```

Install local OPA helper binary:

```bash
sh ai-sdlc/tools/install-opa.sh
```

Protected/default branch enforcement:

```bash
make ai-sdlc-conformance-protected
```

Dev vs protected behavior:

- `dev`: runs lightweight schema-only tests (no OPA required). OPA-dependent tests are skipped with warnings.
  Expected: schema checks pass; OPA-dependent tests skipped.
- `protected`: requires OPA and fails on any skipped must-run/OPA-required tests.
  Expected: all protected conformance checks pass; zero failures.

Runner flags for CI-reporting:

```bash
python ai-sdlc/tools/conformance-runner/run_conformance.py --branch-profile dev --pretty-report --timings
python ai-sdlc/tools/conformance-runner/run_conformance.py --branch-profile protected --require-opa --junit-output ai-sdlc/tests/results/conformance-report.junit.xml
```

Checksum verification for OPA install (optional):

```bash
OPA_CHECKSUM="<sha256>" sh ai-sdlc/tools/install-opa.sh
```

Checksum sidecar file:

```bash
OPA_CHECKSUM_FILE=checksums/opa.sha256 sh ai-sdlc/tools/install-opa.sh
```

For integration guidance after file generation, see the **Next steps** section in your platform onboarding doc or extend this README locally with org-specific links.
