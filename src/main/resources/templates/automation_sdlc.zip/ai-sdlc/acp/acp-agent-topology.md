# Agent Communication Protocol (ACP): Topology

> **STATUS: FUTURE** — This document describes the target multi-agent
> architecture. The current runtime is a single-process local orchestrator
> with no real agent-to-agent communication. The topology diagram illustrates
> a planned distributed system that does not yet exist.



ACP defines how **logical agents** exchange **structured handoffs** without assuming a specific multi-agent framework. Orchestration may run on a human-operated runbook, a workflow engine, or a multi-agent runtime.

## Topology Overview

```text
                    +----------------+
                    | Orchestrator   |
                    +--------+-------+
                             |
        +--------------------+--------------------+
        |                    |                    |
+-------v-------+   +--------v--------+   +-------v--------+
| Requirement   |   | Issue           |   | Documentation  |
+-------+-------+   +--------+--------+   +--------+-------+
        |                    |                    |
        +--------------------+--------------------+
                             |
                    +--------v---------+
                    | Repo Analysis    |
                    +--------+---------+
                             |
                    +--------v---------+
                    | Planning         |
                    +--------+---------+
                             |
              (approval gate / human)
                             |
        +--------------------+--------------------+
        |                    |                    |
+-------v-------+   +--------v--------+   +-------v--------+
| Implementation|   | Test            |   | Security       |
+-------+-------+   +-----------------+   +-------+--------+
        |                                        |
        +----------------+---------------+-------+
                         |               |
                  +------v-----+   +-----v------+
                  | Review     |   | Release    |
                  +------------+   +------+-----+
                                          |
                                   +------v-----------+
                                   | Knowledge Update |
                                   +------------------+
```

## Control vs Data Plane

- **Control plane:** Orchestrator schedules stages, enforces gates, records state transitions (audit).
- **Data plane:** Specialist agents read/write artifacts permitted by MCP policy.

## Human Interfaces

Humans participate at:

- Tier classification confirmation
- Plan approval for Tier 2+
- PR merge and production promotion
- Exception decisions (scan waivers, emergency changes)

## Failure Handling

If an agent fails validation (for example schema mismatch on handoff), the Orchestrator **returns** the work to the originating agent with error details; partial handoffs are not promoted downstream.
