# ACP Handoff Contracts (Automation-Grade)

Handoffs are versioned, machine-validated objects (JSON or YAML UTF-8) exchanged across orchestrator components and agents. This document defines deterministic contract fields, validation rules, and lifecycle behaviors.

## Canonical Envelope

```yaml
schema_version: "2.0"
handoff_id: "{{UUID}}"
correlation_id: "{{ISSUE_OR_EPIC_ID}}"
workflow_id: "{{WF-ID}}"
parent_workflow_id: "{{WF-ID_OR_NULL}}"
from_agent: "{{AGENT_ROLE}}"
to_agent: "{{AGENT_ROLE}}"
payload_type: "{{PAYLOAD_TYPE}}"
payload_schema: "acp.schemas/{{PAYLOAD_TYPE}}/v2"
status: "pending|in_progress|completed|failed|blocked|escalated|cancelled"
retry_count: 0
idempotency_key: "{{DETERMINISTIC_HASH_OR_UUID}}"
required_artifacts:
  - "{{ARTIFACT_ID}}"
produced_artifacts:
  - "{{ARTIFACT_ID}}"
approval_state:
  required: false
  gate_ids: []
  approvals: []
  status: "not_required|pending|approved|rejected|expired"
audit_metadata:
  event_id: "{{AUD-EVT-ID}}"
  actor: "{{HUMAN_OR_AGENT_ID}}"
  source_system: "{{ORCHESTRATOR_OR_SERVICE}}"
  trace_id: "{{TRACE_ID}}"
timestamps:
  created_at: "{{RFC3339_UTC}}"
  updated_at: "{{RFC3339_UTC}}"
  due_at: "{{RFC3339_UTC_OR_NULL}}"
error_code: null
escalation_state:
  is_escalated: false
  escalation_id: null
  escalation_reason: null
payload: {}
```

## Executable Schema References

- Envelope schema: `ai-sdlc/schemas/acp/handoff-envelope.schema.json`
- Payload schemas:
  - `ai-sdlc/schemas/acp/payload-requirement.schema.json`
  - `ai-sdlc/schemas/acp/payload-impact-analysis.schema.json`
  - `ai-sdlc/schemas/acp/payload-technical-plan.schema.json`
  - `ai-sdlc/schemas/acp/payload-implementation-result.schema.json`
  - `ai-sdlc/schemas/acp/payload-pr-review.schema.json`
  - `ai-sdlc/schemas/acp/payload-release-readiness.schema.json`

These schemas are intended for automated validation in orchestrator pipelines and conformance tests.

## Field Semantics

- `schema_version`: Contract compatibility marker. Required on every handoff.
- `handoff_id`: Immutable unique ID.
- `correlation_id`: End-to-end lifecycle key from requirement through release.
- `workflow_id`: Current workflow step ID (for example `WF-PR-002`).
- `parent_workflow_id`: Upstream workflow ID enabling cross-workflow lineage.
- `payload_schema`: Explicit schema reference for parser dispatch.
- `status`: Controlled state used by orchestrators for transitions.
- `retry_count`: Monotonic attempt counter managed by orchestrator.
- `idempotency_key`: Deduplication key across retries/replays.
- `required_artifacts`: Artifacts needed before execution.
- `produced_artifacts`: Artifacts produced by successful processing.
- `approval_state`: Gate fulfillment snapshot.
- `audit_metadata`: Required fields for compliance traceability.
- `timestamps`: Event-time fields used for SLAs and timeout actions.
- `error_code`: Canonical error when `status=failed|blocked`.
- `escalation_state`: Structured escalation tracking.

## Required Fields by `payload_type`

| Payload type | Required artifact IDs | Required payload keys |
|--------------|-----------------------|------------------------|
| `RequirementHandoff` | `requirement_document` | `summary`, `acceptance_criteria_draft` |
| `ClassificationHandoff` | `tier_classification_record` | `work_tier`, `rationale` |
| `ImpactHandoff` | `impact_analysis` | `affected_components`, `rollback_notes` |
| `PlanHandoff` | `approved_technical_plan` | `plan_id`, `approved_revision`, `approvers` |
| `ImplementationHandoff` | `feature_branch`, `ci_validation_records` | `pull_request_url`, `ci_status` |
| `ReviewHandoff` | `ai_review_report`, `merge_decision_artifact` | `must_fix_count`, `approval_summary` |
| `MergeDecisionHandoff` | `merge_decision_artifact` | `decision`, `final_commit_sha`, `gate_results` |
| `MergeCompletionHandoff` | `merge_completion_artifact` | `merged_commit_sha`, `merged_at`, `target_branch` |
| `ReleaseCandidateHandoff` | `release_candidate_artifact` | `release_candidate_id`, `commit_set`, `artifact_digests` |
| `DeploymentBaselineHandoff` | `deployment_baseline_artifact`, `rollback_baseline_artifact` | `environment`, `baseline_commit`, `rollback_target` |
| `PostReleaseVerificationHandoff` | `post_release_verification_artifact` | `verification_result`, `slo_delta_summary` |

## Merge-to-Release Artifacts (Canonical IDs)

- `merge_decision_artifact`
- `merge_completion_artifact`
- `release_candidate_artifact`
- `deployment_baseline_artifact`
- `rollback_baseline_artifact`
- `post_release_verification_artifact`

## Validation Rules

1. **Schema validation:** Reject handoffs failing `payload_schema`.
2. **Required fields:** All envelope required fields and payload-type fields MUST be present.
3. **Workflow consistency:** `workflow_id` must be valid for the current stage; `parent_workflow_id` must reference the initiating workflow.
4. **Artifact prerequisites:** Every `required_artifacts` ID must resolve to an existing artifact with non-terminal invalid state.
5. **Approval completeness:** When `approval_state.required=true`, `approval_state.status` must be `approved` before `status=completed`.
6. **Monotonic retry:** `retry_count` increments by 1 only when previous attempt failed with retryable code.
7. **Timestamp integrity:** `updated_at >= created_at`; future timestamps beyond tolerance are rejected.
8. **Correlation continuity:** `correlation_id` must remain constant across all handoffs in a work item chain.

## Compatibility and Versioning Rules

- **Major version (`2.x` -> `3.x`):** breaking changes; consumers must opt in.
- **Minor version (`2.0` -> `2.1`):** additive fields only; old consumers ignore unknown fields.
- **Deprecation window:** two minor versions minimum before field removal.
- **Schema registry requirement:** each `payload_schema` must be immutable and discoverable.

## Retry Semantics

- Retryable error codes: `E-TIMEOUT`, `E-TRANSIENT-UPSTREAM`, `E-RATE-LIMIT`, `E-LOCK-CONTENTION`.
- Non-retryable codes: `E-SCHEMA-INVALID`, `E-POLICY-DENIED`, `E-APPROVAL-REJECTED`, `E-NONRECOVERABLE`.
- Default max retries: `3` unless overridden by workflow `retry_policy`.
- Backoff follows workflow policy; jitter recommended to avoid thundering herd.

## Idempotency Behavior

1. Orchestrator calculates `idempotency_key` from stable inputs (`correlation_id`, `workflow_id`, `payload_type`, payload digest).
2. Replayed handoff with same key and same payload digest returns prior terminal result.
3. Same key with different payload digest returns `E-IDEMPOTENCY-CONFLICT`.
4. Artifact writes must be idempotent by artifact ID + version.

## Failure Handling

- On `failed`, handoff must include:
  - `error_code`
  - `audit_metadata.event_id`
  - updated `timestamps.updated_at`
- If failure is retryable, set `status=blocked` and schedule retry.
- If non-retryable, set `status=failed` and emit escalation where required.

## Escalation Handling

- Set `escalation_state.is_escalated=true` when:
  - required approval timed out,
  - policy conflict occurs,
  - high-severity validation fails on Tier 3+.
- Provide:
  - `escalation_id` (for example `ESC-POLICY-001`)
  - `escalation_reason`
- Escalated handoffs cannot transition to `completed` without explicit human resolution artifact.

## Error Code Catalog (Core)

- `E-SCHEMA-INVALID`
- `E-REQUIRED-FIELD-MISSING`
- `E-ARTIFACT-NOT-FOUND`
- `E-APPROVAL-PENDING`
- `E-APPROVAL-REJECTED`
- `E-POLICY-DENIED`
- `E-IDEMPOTENCY-CONFLICT`
- `E-TIMEOUT`
- `E-TRANSIENT-UPSTREAM`
