# ACP Workflow Example

> **STATUS: FUTURE** — This example illustrates how ACP handoffs would flow
> through the multi-agent topology described in `acp-agent-topology.md`.
> The current runtime emits `ImplementationResultHandoff` and
> `PostReleaseVerificationHandoff` only. The other handoff types shown here
> are not emitted by any current code.

 (Deterministic Merge-to-Release)

This example demonstrates the deterministic lifecycle closure:

PR reviewed -> PR approved -> merge decision recorded -> PR merged -> merge completion recorded -> release candidate assembled -> release readiness verified -> deployment approved -> deployment baseline captured -> deployment executed -> post-release verification completed -> rollback baseline retained.

## Scenario

Tier 3 change adds an authenticated analytics endpoint in `analytics-api` with shared auth middleware impact.

## Example Sequence

### 1) Review complete -> merge decision recorded

```yaml
schema_version: "2.0"
handoff_id: "h-0100"
correlation_id: "ISSUE-5001"
workflow_id: "WF-PR-002"
parent_workflow_id: "WF-PR-001"
from_agent: "review"
to_agent: "orchestrator"
payload_type: "MergeDecisionHandoff"
payload_schema: "acp.schemas/MergeDecisionHandoff/v2"
status: "completed"
retry_count: 0
idempotency_key: "example-idempotency-key-merge-decision-5001"
required_artifacts: ["ai_review_report", "human_review_decisions"]
produced_artifacts: ["merge_decision_artifact"]
approval_state:
  required: true
  gate_ids: ["G-PR-MERGE"]
  approvals:
    - approver_id: "group:eng-leads"
      status: "approved"
  status: "approved"
audit_metadata:
  event_id: "AUD-EVT-PR-DECISION-001"
  actor: "agent:review"
  source_system: "orchestrator"
  trace_id: "trace-5001-100"
timestamps:
  created_at: "2026-05-11T10:15:00Z"
  updated_at: "2026-05-11T10:15:05Z"
  due_at: null
error_code: null
escalation_state:
  is_escalated: false
  escalation_id: null
  escalation_reason: null
payload:
  decision: "approved_for_merge"
  final_commit_sha: "abc1234"
  gate_results:
    G-PR-MERGE: "approved"
```

### 2) PR merged -> merge completion recorded

```yaml
schema_version: "2.0"
handoff_id: "h-0101"
correlation_id: "ISSUE-5001"
workflow_id: "WF-PR-002"
parent_workflow_id: "WF-PR-001"
from_agent: "orchestrator"
to_agent: "release"
payload_type: "MergeCompletionHandoff"
payload_schema: "acp.schemas/MergeCompletionHandoff/v2"
status: "completed"
retry_count: 0
idempotency_key: "example-idempotency-key-merge-complete-5001"
required_artifacts: ["merge_decision_artifact"]
produced_artifacts: ["merge_completion_artifact"]
approval_state:
  required: true
  gate_ids: ["G-PR-MERGE"]
  approvals: []
  status: "approved"
audit_metadata:
  event_id: "AUD-EVT-PR-MERGED-001"
  actor: "human:release_manager"
  source_system: "git_source_control"
  trace_id: "trace-5001-101"
timestamps:
  created_at: "2026-05-11T10:20:00Z"
  updated_at: "2026-05-11T10:20:05Z"
  due_at: null
error_code: null
escalation_state:
  is_escalated: false
  escalation_id: null
  escalation_reason: null
payload:
  merged_commit_sha: "def5678"
  target_branch: "main"
  merged_at: "2026-05-11T10:19:55Z"
```

### 3) Release candidate assembled

```yaml
schema_version: "2.0"
handoff_id: "h-0102"
correlation_id: "ISSUE-5001"
workflow_id: "WF-REL-001"
parent_workflow_id: "WF-PR-002"
from_agent: "release"
to_agent: "orchestrator"
payload_type: "ReleaseCandidateHandoff"
payload_schema: "acp.schemas/ReleaseCandidateHandoff/v2"
status: "completed"
retry_count: 0
idempotency_key: "example-idempotency-key-release-candidate-5001"
required_artifacts: ["merge_completion_artifact"]
produced_artifacts: ["release_candidate_artifact"]
approval_state:
  required: false
  gate_ids: []
  approvals: []
  status: "not_required"
audit_metadata:
  event_id: "AUD-EVT-REL-CANDIDATE-001"
  actor: "agent:release"
  source_system: "orchestrator"
  trace_id: "trace-5001-102"
timestamps:
  created_at: "2026-05-11T10:25:00Z"
  updated_at: "2026-05-11T10:25:10Z"
  due_at: null
error_code: null
escalation_state:
  is_escalated: false
  escalation_id: null
  escalation_reason: null
payload:
  release_candidate_id: "RC-2026.05.11-01"
  commit_set: ["def5678"]
  artifact_digests:
    - name: "container-image-analytics-api"
      sha256: "{{HASH}}"
```

### 4) Release readiness + deployment approval + baseline capture

```yaml
schema_version: "2.0"
handoff_id: "h-0103"
correlation_id: "ISSUE-5001"
workflow_id: "WF-REL-001"
parent_workflow_id: "WF-PR-002"
from_agent: "orchestrator"
to_agent: "release"
payload_type: "DeploymentBaselineHandoff"
payload_schema: "acp.schemas/DeploymentBaselineHandoff/v2"
status: "completed"
retry_count: 0
idempotency_key: "example-idempotency-key-deploy-baseline-5001"
required_artifacts: ["release_candidate_artifact", "release_checklist_with_evidence"]
produced_artifacts: ["deployment_baseline_artifact", "rollback_baseline_artifact"]
approval_state:
  required: true
  gate_ids: ["G-REL-PROD"]
  approvals:
    - approver_id: "group:sre-core"
      status: "approved"
  status: "approved"
audit_metadata:
  event_id: "AUD-EVT-DEPLOY-BASELINE-001"
  actor: "human:sre_duty_manager"
  source_system: "orchestrator"
  trace_id: "trace-5001-103"
timestamps:
  created_at: "2026-05-11T11:00:00Z"
  updated_at: "2026-05-11T11:00:06Z"
  due_at: null
error_code: null
escalation_state:
  is_escalated: false
  escalation_id: null
  escalation_reason: null
payload:
  environment: "production"
  baseline_commit: "def5678"
  rollback_target: "pre-release-tag-2026.05.10"
```

### 5) Deployment executed -> post-release verification completed

```yaml
schema_version: "2.0"
handoff_id: "h-0104"
correlation_id: "ISSUE-5001"
workflow_id: "WF-REL-002"
parent_workflow_id: "WF-REL-001"
from_agent: "release"
to_agent: "knowledge_update"
payload_type: "PostReleaseVerificationHandoff"
payload_schema: "acp.schemas/PostReleaseVerificationHandoff/v2"
status: "completed"
retry_count: 0
idempotency_key: "example-idempotency-key-post-release-5001"
required_artifacts: ["deployment_baseline_artifact", "rollback_baseline_artifact"]
produced_artifacts: ["post_release_verification_artifact"]
approval_state:
  required: false
  gate_ids: []
  approvals: []
  status: "not_required"
audit_metadata:
  event_id: "AUD-EVT-POSTREL-001"
  actor: "agent:release"
  source_system: "orchestrator"
  trace_id: "trace-5001-104"
timestamps:
  created_at: "2026-05-11T13:00:00Z"
  updated_at: "2026-05-11T13:30:00Z"
  due_at: null
error_code: null
escalation_state:
  is_escalated: false
  escalation_id: null
  escalation_reason: null
payload:
  verification_result: "passed"
  slo_delta_summary: "no material regression"
  rollback_baseline_retained_until: "2026-05-18T00:00:00Z"
```
