# Contract 01: Requirement Analyst → Clarification Agent

## Source agent
Requirement Analyst

## Target agent
Clarification Agent

## Purpose
Hand off a structured but potentially ambiguous requirement for targeted clarification before classification begins. This contract is triggered when the Requirement Analyst identifies open questions, conflicting assumptions, or vague acceptance criteria that block reliable tier classification.

## SDLC stage transition
`REQUIREMENT` → `REQUIREMENT` (clarification sub-loop; resolves before advancing to `CLASSIFIED`)

## Required inputs (from Requirement Analyst)

| Input | Format | Required |
|-------|--------|---------|
| Structured requirement doc | Markdown | Yes |
| Open questions list | Ordered list (blocking / non-blocking) | Yes |
| Proposed acceptance criteria draft | Given/When/Then or equivalent | Yes |
| Domain context references | Links or embedded content | Recommended |
| Conflicting assumptions (if any) | Structured list | If present |

## Required outputs (expected from Clarification Agent)

| Output | Format | Required |
|--------|--------|---------|
| Resolved open questions | Each question with: proposed answer, confidence, human confirmation required? | Yes |
| Conflict analysis | Identified conflicts with proposed resolution | If conflicts exist |
| Revised acceptance criteria | Updated list based on resolved questions | Yes |
| Remaining unresolved questions | Questions that require product owner / engineering lead input | If any |
| Clarification summary | One-paragraph summary for the workflow state file | Yes |

## Validation rules

1. All blocking open questions from the input list must appear in the output — either as resolved or as escalated to a named human.
2. Acceptance criteria must be measurable and testable; no criteria containing subjective terms without defined thresholds.
3. The output must not introduce new requirements beyond the scope of the input requirement.
4. Unresolved blocking questions must be escalated with a named human responsible for resolution.

## Quality checks

- SKL-001 (Requirement Clarification) applied
- SKL-002 (Ambiguity Detection) applied to acceptance criteria
- SKL-003 (Acceptance Criteria Generation) applied

## Blocking conditions

- Any blocking open question not resolved and not escalated to a named human → handoff is invalid
- New scope added beyond the original requirement → must be rejected and raised as a separate issue

## Human gate dependency

Product owner or engineering lead must confirm: (1) resolved questions, (2) revised acceptance criteria, before the workflow advances from `REQUIREMENT` to `CLASSIFIED`.

## Artifact references

- Input: `artifacts.requirement_doc` in workflow state file
- Output: updated `artifacts.requirement_doc`; `agent_outputs.clarification_summary`

## Failure / rework path

If the Clarification Agent cannot resolve a blocking question, it escalates to the responsible product owner or engineering lead with a 1-business-day SLA. Workflow stays in `BLOCKED` until the question is resolved.

## Payload type

`RequirementHandoff` (see `schemas/acp/payload-requirement.schema.json`)
