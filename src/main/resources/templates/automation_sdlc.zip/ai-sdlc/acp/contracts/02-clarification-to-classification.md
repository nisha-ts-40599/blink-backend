# Contract 02: Clarification Agent → Work Classification Agent

## Source agent
Clarification Agent

## Target agent
Work Classification Agent

## Purpose
Hand off a confirmed, unambiguous requirement with resolved acceptance criteria for work tier classification and risk detection.

## SDLC stage transition
`REQUIREMENT` → `CLASSIFIED`

## Required inputs (from Clarification Agent)

| Input | Format | Required |
|-------|--------|---------|
| Confirmed requirement doc | Markdown — all open questions resolved | Yes |
| Final acceptance criteria | Measurable, testable list | Yes |
| Human confirmation record | Who confirmed the requirement | Yes |
| Domain and data context | PHI/PII indicators, external integrations, auth involvement | Yes |

## Required outputs (expected from Work Classification Agent)

| Output | Format | Required |
|--------|--------|---------|
| Proposed work tier (1–4) | Integer with evidence | Yes |
| Evidence list | Why this tier is proposed | Yes |
| Risk flags | Any mandatory tier-elevation triggers detected (RULE-SEC-003) | Yes |
| Required gates for this tier | List of gates that apply | Yes |
| Required rigor level | Test coverage expectation, review expectation | Yes |
| Self-classification guard check | Explicit statement of what is NOT Tier 1 in this case | If Tier 1 proposed |
| Classification summary | One paragraph for workflow state | Yes |

## Validation rules

1. Proposed tier must be consistent with `work-tiers.md` criteria.
2. Risk flags must reference specific risk rules from `governance/risk-rules.md`.
3. If Tier 1 is proposed, the self-classification guard check must explicitly list all Tier 1 exclusion criteria that were evaluated and found not applicable.
4. No tier proposal may bypass mandatory escalation triggers (RULE-SEC-003).

## Quality checks

- SKL-004 (Work Tier Classification) applied
- SKL-005 (Risk Rule Detection) applied

## Blocking conditions

- Required data classification information not provided → classification cannot be produced; request from Requirement Analyst
- Mandatory escalation trigger detected and tier is below minimum → tier must be elevated before handoff is valid

## Human gate dependency

Engineering lead must confirm the proposed tier before the workflow advances to Impact Analysis. Work Classification output is **advisory** — tier is not confirmed until human validation. For Tier 2+ downgrades to Tier 1, engineering lead must provide written justification.

## Artifact references

- Input: `artifacts.requirement_doc` (confirmed version)
- Output: `agent_outputs.classification_summary`; tier stored in `work_tier` field of workflow state

## Failure / rework path

If risk flags indicate a tier higher than proposed, the Work Classification Agent must re-produce the classification at the elevated tier. No downward override without engineering lead written justification.

## Payload type

`RequirementHandoff` with classification payload extension
