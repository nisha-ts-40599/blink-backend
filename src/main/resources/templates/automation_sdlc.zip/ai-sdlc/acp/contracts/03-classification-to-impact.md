# Contract 03: Work Classification Agent → Impact Analysis Agent

## Source agent
Work Classification Agent

## Target agent
Impact Analysis Agent

## Purpose
Hand off a human-confirmed work tier and requirement to the Impact Analysis Agent for blast radius mapping, dependency analysis, and rollback strategy.

## SDLC stage transition
`CLASSIFIED` → `SPEC_DRAFTED`

## Required inputs (from Work Classification Agent)

| Input | Format | Required |
|-------|--------|---------|
| Confirmed requirement doc | Markdown | Yes |
| Human-confirmed work tier | Integer 1–4 | Yes |
| Risk flags | From classification output | Yes |
| Human confirmation record | Who confirmed the tier | Yes |

## Required outputs (expected from Impact Analysis Agent)

| Output | Format | Required |
|--------|--------|---------|
| Affected components | List of files/modules/services | Yes |
| API surface delta | New, modified, or removed endpoints | Yes |
| Schema changes | New or modified DB tables/columns/indexes | Yes |
| Downstream dependencies | Services or consumers that may be affected | Yes |
| Rollback approach | Rollback strategy per affected component | Yes |
| Test targets | Priority test targets for this change | Yes |
| Residual risks | Risks that cannot be mitigated by the plan | Yes |
| Impact summary | One paragraph for workflow state | Yes |

## Validation rules

1. All components mentioned in the acceptance criteria must appear in the affected components list.
2. Rollback approach must be present for every schema change.
3. API surface delta must include every endpoint referenced in the acceptance criteria.

## Quality checks

- SKL-006 (Impact Analysis) applied
- SKL-007 (Dependency Analysis) applied

## Blocking conditions

- Repository context not available for analysis → request engineer to supply `project-context.md` or grant MCP access
- Rollback cannot be determined → must be escalated to DBA or engineering lead before planning proceeds

## Human gate dependency

Engineering lead reviews the impact summary before G-PLAN clock starts. Complex or unexpected blast radius (Tier 3+) requires engineering lead sign-off.

## Artifact references

- Input: `artifacts.requirement_doc`, `work_tier`, `agent_outputs.classification_summary`
- Output: `agent_outputs.impact_summary`

## Failure / rework path

If the impact analysis reveals the blast radius is significantly larger than the classification assumed, the Work Classification Agent is notified to re-evaluate the tier.

## Payload type

`ImpactAnalysisHandoff` (see `schemas/acp/payload-impact-analysis.schema.json`)
