# Contract 04: Impact Analysis Agent → Technical Planning Agent

## Source agent
Impact Analysis Agent

## Target agent
Technical Planning Agent

## Purpose
Hand off the impact analysis and confirmed requirement to the Technical Planning Agent for production of an ordered, executable technical plan that triggers the G-PLAN gate.

## SDLC stage transition
`SPEC_DRAFTED` → `PLAN_DRAFTED`

## Required inputs (from Impact Analysis Agent)

| Input | Format | Required |
|-------|--------|---------|
| Impact summary | Markdown (affected components, API delta, schema changes, rollback, test targets) | Yes |
| Confirmed requirement + acceptance criteria | Markdown | Yes |
| Human-confirmed work tier | Integer 1–4 | Yes |
| Risk flags | From classification | Yes |
| Security model | From `project-config.yaml` | Yes |

## Required outputs (expected from Technical Planning Agent)

| Output | Format | Required |
|--------|--------|---------|
| Technical plan | Ordered numbered steps with description and verification criteria | Yes |
| Per-step security controls | OWASP/project-specific controls per step | Yes |
| Rollback strategy | Per-step or overall rollback procedure | Yes |
| Test strategy | Which test types, which targets, per acceptance criterion | Yes |
| Verification checkpoints | What must be true at completion of each step | Yes |
| G-PLAN ready indicator | Explicit statement that the plan is ready for engineering lead review | Yes |
| Planner summary | One paragraph for workflow state | Yes |

## Validation rules

1. Every acceptance criterion must map to at least one verification checkpoint.
2. Every schema change identified in the impact analysis must appear as a step in the plan.
3. Security controls must be present for every step that touches auth, PHI, or external systems.
4. Rollback strategy must address every schema change step.
5. Plan must not expand scope beyond the confirmed requirement.

## Quality checks

- RULE-EQ-005 (No unnecessary refactoring in scope)
- RULE-EQ-002 (Reuse-first: plan must reference existing components before proposing new ones)
- RULE-DB-001 applied if schema changes present
- SKL-008 (Reuse-First Analysis) applied

## Blocking conditions

- Impact summary missing required components → return to Impact Analysis Agent
- Scope expansion detected → raise a separate issue; remove from this plan

## Human gate dependency

**G-PLAN gate.** Engineering lead must provide written approval (comment on issue) before implementation begins. G-PLAN SLA: 2 business days from plan delivery. Plan must not be implemented without G-PLAN record.

## Artifact references

- Input: `agent_outputs.impact_summary`, `artifacts.requirement_doc`
- Output: `artifacts.plan_doc`, `agent_outputs.planner_summary`; G-PLAN SLA deadline set in `gates.g_plan.sla_due_at`

## Failure / rework path

If engineering lead rejects the plan or requests changes, the Technical Planning Agent receives the review comments and produces a revised plan. Rework count is incremented. After 3 rounds without agreement, escalate to engineering lead + product owner.

## Payload type

`TechnicalPlanHandoff` (see `schemas/acp/payload-technical-plan.schema.json`)
