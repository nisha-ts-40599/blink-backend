# Contract 05: Technical Planning Agent → Architecture Review Agent

## Source agent
Technical Planning Agent

## Target agent
Architecture Review Agent

## Purpose
For Tier 3+ work, hand off the approved technical plan for architectural alignment review before implementation begins. Detects architectural violations, identifies ADR requirements, and validates API/DB design against project conventions.

## SDLC stage transition
`PLAN_DRAFTED` → `PLAN_APPROVED` (Tier 3+ path; this contract is skipped for Tier 1–2)

**Note:** This contract is only active for Tier 3 and Tier 4. For Tier 1–2, the workflow proceeds directly from planning to implementation after G-PLAN.

## Required inputs (from Technical Planning Agent)

| Input | Format | Required |
|-------|--------|---------|
| Technical plan | Markdown | Yes |
| Impact analysis summary | Markdown | Yes |
| Existing architectural principles | From `project-context.md` | Yes |
| Existing ADR store | Path or linked content | Recommended |
| API conventions | From `project-context.md` | If API changes present |
| DB migration conventions | From `project-context.md` | If schema changes present |

## Required outputs (expected from Architecture Review Agent)

| Output | Format | Required |
|--------|--------|---------|
| Architecture review findings | Blockers / Concerns / Advisory with evidence | Yes |
| ADR recommendation | Whether a new ADR is required and for what decision | Yes |
| Pattern compliance assessment | SOLID, DRY, KISS, YAGNI per proposed plan steps | Yes |
| API design assessment | Backward compatibility, versioning, naming | If API changes |
| DB design assessment | Migration safety, constraint correctness, performance risk | If DB changes |
| Architecture review summary | One paragraph for workflow state | Yes |

## Validation rules

1. Every blocking finding must reference a specific plan step and a specific rule from `governance/enterprise-engineering-guardrails.md` or `rules/global-rule-index.md`.
2. If a new pattern not present in `project-context.md` is proposed, an ADR recommendation must be produced.
3. No blocking finding may be silently omitted or downgraded to advisory without documented justification.

## Quality checks

- RULE-EQ-004 (Architecture Alignment)
- RULE-EQ-006 (SOLID)
- RULE-EQ-007 (DRY/KISS/YAGNI)
- RULE-EQ-008 (Design patterns only when justified)
- RULE-API-001 (API contract stability)
- SKL-013 (API Contract Review) if applicable
- SKL-015 (DB Migration Risk Review) if applicable

## Blocking conditions

- Architectural blocker found → must be resolved (plan updated) before G-PLAN is issued
- ADR required but not drafted → ADR must be drafted and submitted for review before implementation

## Human gate dependency

Engineering lead or architect must review architectural blockers. If ADR is required, tech lead must draft and approve ADR. G-PLAN is not issued until architecture review blockers are resolved.

## Artifact references

- Input: `artifacts.plan_doc`
- Output: `agent_outputs.architecture_review_summary`; ADR draft (if required) added to `artifacts`

## Failure / rework path

Architectural blockers are returned to the Technical Planning Agent for plan revision. Each revision cycle increments the rework count. After 2 cycles without resolution, escalate to engineering lead and architect.

## Payload type

`TechnicalPlanHandoff` (same payload as contract 04; architecture review fields added to response)
