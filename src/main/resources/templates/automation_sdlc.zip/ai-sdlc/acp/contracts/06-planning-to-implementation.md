# Contract 06: Planning / Architecture Review → Implementation Agents

## Source agent
Technical Planning Agent (Tier 1–2) or Architecture Review Agent (Tier 3+) following G-PLAN approval

## Target agents
Backend Implementation Agent, Frontend Implementation Agent, Database Migration Agent (as applicable per plan)

## Purpose
Hand off an approved plan with a recorded G-PLAN gate to the appropriate implementation agents. This is the primary gate contract — no implementation may begin without a valid G-PLAN record.

## SDLC stage transition
`PLAN_APPROVED` → `IMPLEMENTING`

## Required inputs (for Implementation Agents)

| Input | Format | Required |
|-------|--------|---------|
| Approved technical plan with G-PLAN record | Markdown; G-PLAN comment URL | Yes |
| Current step number (N of M) | Integer | Yes |
| Project context | `project-context.md` content | Yes |
| Engineering guardrails | From `governance/enterprise-engineering-guardrails.md` | Yes |
| Repository context | Branch state, relevant file structure | Yes |
| Acceptance criteria | From confirmed requirement | Yes |
| Security controls for current step | From plan | Yes |

## Required outputs (per step, from Implementation Agents)

| Output | Format | Required |
|--------|--------|---------|
| Step implementation | Code diff / patch on feature branch | Yes |
| Step completion note | What was implemented; deviations from plan | Yes |
| Verification criteria met | Evidence that step exit criteria are satisfied | Yes |
| Deviation log | Any scope changes with rationale | If deviations occurred |
| Self-review pre-check | Guardrail checklist for the step | Yes |

## Validation rules

1. G-PLAN record must exist in `gates.g_plan.comment_url` in the workflow state file before any step begins.
2. Implementation must not exceed the scope of the current step.
3. Deviations from the plan must be logged; scope expansions require engineering lead acknowledgement.
4. Each step must satisfy its verification criteria before the next step begins.
5. Human confirmation is required between steps for Tier 2+ (Tier 1 may proceed step-by-step without per-step checkpoint).

## Quality checks

- RULE-EQ-001 to RULE-EQ-005 (all mandatory engineering rules)
- RULE-SEC-001 (Secure coding per step)
- RULE-SEC-002 (No secrets in code)
- SKL-008 (Reuse-First Analysis per step)
- SKL-009 (Duplicate Logic Detection)
- Per-step security controls from the plan

## Blocking conditions

- G-PLAN record missing → hard block; implementation must not begin
- Previous step verification criteria not met → next step must not begin
- Security control missing for a step that requires it → step must not proceed

## Human gate dependency

- **G-PLAN must exist** before any step begins (hard prerequisite)
- For Tier 2+: human reviews and confirms each step output before next step is assigned
- Scope deviations require engineering lead acknowledgement

## Artifact references

- Input: `artifacts.plan_doc`, `gates.g_plan.comment_url`
- Output: `artifacts.implementation_prs[]`; step completion notes in `agent_outputs`

## Failure / rework path

If a step fails (CI failure, verification criteria not met, test failures), the implementation agent is restarted from the failed step using the original plan plus the failure context. Rework count is incremented per step failure.

## Payload type

`TechnicalPlanHandoff` (source); `ImplementationResultHandoff` (per step output, see `schemas/acp/payload-implementation-result.schema.json`)
