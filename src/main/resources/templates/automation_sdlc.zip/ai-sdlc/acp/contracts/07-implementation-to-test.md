# Contract 07: Implementation Agent → Test Strategy / Test Generation Agent

## Source agent
Backend, Frontend, or Database Migration Implementation Agent (per step or on step set completion)

## Target agent
Test Strategy / Test Generation Agent

## Purpose
Hand off a completed implementation step or step set for test generation: unit tests, integration tests, edge cases, and regression tests aligned with the acceptance criteria.

## SDLC stage transition
`IMPLEMENTING` (step complete) → Test generation sub-loop within `IMPLEMENTING`

## Required inputs (from Implementation Agent)

| Input | Format | Required |
|-------|--------|---------|
| Code diff for the completed step | Diff or patch | Yes |
| Acceptance criteria for this step | From confirmed requirement | Yes |
| Tech stack and test framework | From `project-context.md` | Yes |
| Existing test suite structure | File paths and patterns | Yes |
| Step verification criteria | From plan | Yes |

## Required outputs (expected from Test Agent)

| Output | Format | Required |
|--------|--------|---------|
| Unit tests | Test code additions | Yes (for non-trivial logic) |
| Integration tests | Test code additions | Yes (for new endpoints/services) |
| Edge case tests | Tests for boundary conditions | Yes |
| Regression tests | Tests confirming no breakage of existing behaviour | Yes |
| Coverage gap analysis | Behaviours not yet covered | Yes |
| Test completion note | Summary of tests added and coverage change | Yes |

## Validation rules

1. Every acceptance criterion must be covered by at least one test.
2. Every new function/method must have at least one unit test.
3. Every new endpoint must have at least one integration test.
4. Regression tests must be present for any code path modified in the step.
5. Tests must follow project test naming and structure conventions.

## Quality checks

- RULE-TEST-001 (Test Quality over Test Count)
- RULE-TEST-002 (Regression test required for bug fixes)
- RULE-TEST-003 (Test conventions)
- SKL-011 (Test Coverage Reasoning)
- SKL-012 (Regression Test Identification)

## Blocking conditions

- Acceptance criteria not provided → test generation is incomplete; request from upstream
- Test framework context not available → request project-context.md update

## Human gate dependency

Test adequacy is reviewed as part of PR review (Contract 10). No separate human gate for test generation itself, but coverage must meet project threshold or PR review will surface this as a must-fix finding.

## Artifact references

- Input: `artifacts.implementation_prs[]` (current PR); `artifacts.plan_doc`
- Output: Test code added to feature branch; `artifacts.test_coverage_report` set when CI coverage report is available

## Failure / rework path

If tests reveal implementation bugs (tests fail), hand back to the Implementation Agent with failure context. Test Agent documents which tests failed and which acceptance criteria are not met.

## Payload type

`ImplementationResultHandoff` (source); test additions added to same feature branch
