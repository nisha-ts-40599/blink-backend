# Contract 08: Implementation + Test Agent → Documentation / OpenAPI Agent

## Source agents
Backend / Frontend / Database Migration Implementation Agent + Test Strategy Agent (joint handoff after all steps and tests complete)

## Target agent
Documentation / OpenAPI Agent

## Purpose
Hand off completed, tested implementation for documentation update: API docs (OpenAPI), inline docs, runbook additions, and changelog entry. Triggered when all implementation steps and tests are complete and CI is green.

## SDLC stage transition
`IMPLEMENTING` (all steps complete, tests passing) → `REVIEW_REQUESTED`

## Required inputs (from Implementation + Test Agents)

| Input | Format | Required |
|-------|--------|---------|
| Full PR diff (all steps combined) | Diff | Yes |
| Acceptance criteria | Markdown | Yes |
| Current OpenAPI spec | YAML or JSON | If API changes |
| Existing runbook index | Path or content | If operational changes |
| Existing changelog | Path or content | Yes |
| Documentation locations | From `project-context.md` | Yes |

## Required outputs (expected from Documentation Agent)

| Output | Format | Required |
|--------|--------|---------|
| Updated OpenAPI spec | Delta or full updated spec | If API changes |
| Inline code documentation updates | Docstrings, comments | If public API changes |
| User-facing documentation update | Markdown | If behaviour is user-visible |
| Changelog entry (draft) | Keep-a-changelog format | Yes |
| Runbook additions | Markdown | If new operational procedures introduced |
| Documentation gap report | Items not covered | Yes |

## Validation rules

1. Every new API endpoint must appear in the updated OpenAPI spec.
2. Every removed or modified endpoint must be updated in the OpenAPI spec.
3. Changelog entry must summarise what changed (not how).
4. Documentation must not describe intended behaviour — only implemented behaviour.

## Quality checks

- RULE-DOC-001 (Documentation Discipline)
- RULE-API-002 (OpenAPI Documentation Currency)
- SKL-014 (OpenAPI Consistency Review)
- SKL-022 (Documentation Gap Detection)

## Blocking conditions

- No OpenAPI spec exists but API changes are present → spec must be created before PR opens
- Changelog location not specified in `project-context.md` → request project-context.md update

## Human gate dependency

Engineering lead or technical writer approves docs for Tier 3+. External documentation publication is always human-approved (never agent-published). Changelog is reviewed as part of PR review.

## Artifact references

- Input: `artifacts.implementation_prs[]`, `artifacts.plan_doc`
- Output: Documentation changes committed to feature branch; `artifacts` updated with docs PR or PR branch reference

## Failure / rework path

If the PR review (Contract 10) surfaces documentation gaps as must-fix findings, the Documentation Agent receives the review comments and produces the missing documentation.

## Payload type

`ImplementationResultHandoff` (source); documentation changes on feature branch
