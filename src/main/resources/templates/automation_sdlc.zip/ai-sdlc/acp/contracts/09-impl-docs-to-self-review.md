# Contract 09: Implementation + Docs → Self Review Agent

## Source agents
Implementation Agents + Documentation / OpenAPI Agent (all complete on feature branch)

## Target agent
PR Review Agent (Self-review is performed before PR opens — it is a pre-PR gate, not a separate agent in the pipeline)

**Note:** Self-review is performed by the Implementation Agent reviewing its own output using `prompts/self-review.prompt.md`, typically with the same LLM session or a fresh session with PR diff context. It is not a separate runtime agent but a distinct reasoning step before the PR opens.

## Purpose
Perform a structured self-review of the complete feature branch diff before the PR is opened. Catch must-fix issues before requesting human review. Post the self-review output to the issue as an artifact.

## SDLC stage transition
`IMPLEMENTING` (complete) → `REVIEW_REQUESTED`

## Required inputs

| Input | Format | Required |
|-------|--------|---------|
| Full feature branch diff | Diff | Yes |
| Acceptance criteria | Markdown | Yes |
| Engineering guardrails | From `governance/enterprise-engineering-guardrails.md` | Yes |
| Technical plan | For verification against plan | Yes |
| Test coverage summary | CI output | Yes |

## Required outputs

| Output | Format | Required |
|--------|--------|---------|
| Self-review output | Structured: must-fix, advisory, informational, N/A | Yes |
| Guardrail checklist | Each guardrail: compliant / violation / N/A | Yes |
| Plan adherence check | Deviations from approved plan | Yes |
| Security checklist | No secrets, OWASP checklist per step | Yes |
| Self-review summary | One paragraph for workflow state | Yes |

## Validation rules

1. All must-fix items from self-review must be resolved before the PR is opened.
2. If deviations from the approved plan are found, they must be documented; scope expansions require engineering lead acknowledgement.
3. Security checklist must be fully completed — no N/A without justification.

## Quality checks

- RULE-EQ-001 (all guardrails)
- RULE-SEC-001 (secure coding checklist)
- RULE-SEC-002 (no secrets)
- SKL-016 (Security Risk Review)
- SKL-018 (PR Diff Review applied to self)

## Blocking conditions

- Must-fix items found in self-review → PR must not open until resolved
- Secrets detected → hard block; secret must be removed from history before proceeding

## Human gate dependency

Self-review output is an artifact reviewed by human reviewers as part of G-PR-MERGE. Humans are not required to review self-review output separately; it is part of the PR review package.

## Artifact references

- Output: `artifacts.self_review_output` (link to issue comment with self-review); `agent_outputs.self_review_summary`

## Failure / rework path

Must-fix items from self-review are sent back to the appropriate Implementation Agent for resolution before the PR opens.

## Payload type

`ImplementationResultHandoff` (self-review output extends this payload)
