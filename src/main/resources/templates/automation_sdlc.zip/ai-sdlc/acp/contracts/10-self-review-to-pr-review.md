# Contract 10: Self Review → PR Review Agent

## Source agent
Self Review step (output of Implementation Agent's self-review)

## Target agent
PR Review Agent

## Purpose
Hand off a self-reviewed, CI-passing PR for AI-assisted code review before human review is requested. AI review output is posted as a PR comment and is advisory — it does not replace human review.

## SDLC stage transition
`REVIEW_REQUESTED` → `PR_OPEN` (PR opened; AI review posted)

## Required inputs (for PR Review Agent)

| Input | Format | Required |
|-------|--------|---------|
| PR diff | GitHub PR diff | Yes |
| Linked issue | Issue URL | Yes |
| Self-review output | From Contract 09 | Yes |
| Engineering guardrails | From `governance/enterprise-engineering-guardrails.md` | Yes |
| Technical plan | For verification | Yes |
| CI check results | All CI jobs status | Yes |
| Test coverage report | CI artifact | Recommended |

## Required outputs (expected from PR Review Agent)

| Output | Format | Required |
|--------|--------|---------|
| Must-fix findings | Blockers with specific location and rule reference | Yes |
| Advisory findings | Suggestions with rationale | Yes |
| Informational findings | Notes for human reviewer attention | Yes |
| Risk statement | Overall risk level (low / medium / high) | Yes |
| Guardrail compliance summary | Which guardrails pass, which have issues | Yes |
| AI review summary | One paragraph for workflow state | Yes |

## Validation rules

1. Every must-fix finding must reference a specific line or block in the diff and a specific rule from `rules/global-rule-index.md` or `governance/enterprise-engineering-guardrails.md`.
2. AI review must not approve the PR — output is advisory input for human reviewer.
3. CI must be green before the AI review is considered complete.

## Quality checks

- RULE-EQ-001 to RULE-EQ-008 (engineering quality rules)
- RULE-SEC-001, RULE-SEC-002 (security rules)
- RULE-API-001, RULE-API-002 (API rules, if applicable)
- RULE-DOC-001 (documentation rule)
- SKL-018 (PR Diff Review)
- SKL-005 (Risk Rule Detection)

## Blocking conditions

- CI failing → AI review must note this; PR must not be submitted for human review until CI is green
- Self-review output not provided → AI review agent requests it before producing review

## Human gate dependency

**G-PR-MERGE gate:** Branch protection enforces at least 1 human reviewer approval. AI review is a required input but not a sufficient approval. Human reviewer makes an independent judgement. AI review output must not be used to skip human review.

## Artifact references

- Input: PR diff; `artifacts.self_review_output`
- Output: `artifacts.ai_review_output` (PR comment URL); `agent_outputs.ai_pr_review_summary`

## Failure / rework path

Must-fix findings from AI review are sent to the appropriate Implementation Agent for resolution. After resolution, the AI review is re-run on the updated diff.

## Payload type

`PRReviewHandoff` (see `schemas/acp/payload-pr-review.schema.json`)
