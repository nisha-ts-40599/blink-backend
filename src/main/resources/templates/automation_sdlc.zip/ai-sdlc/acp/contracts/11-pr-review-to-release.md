# Contract 11: PR Review → Release Readiness Agent

## Source agent
PR Review Agent (AI review complete; human review approved; PR merged)

## Target agent
Release Readiness Agent

## Purpose
After the PR is merged to main, hand off to the Release Readiness Agent to assemble the release checklist, verify all required artifacts, and produce a go/hold recommendation for the human deployment decision.

## SDLC stage transition
`MERGED` → `DEPLOYING` (pending G-DEPLOY)

## Required inputs (for Release Readiness Agent)

| Input | Format | Required |
|-------|--------|---------|
| Merge commit SHA | Git SHA | Yes |
| PR URL | URL | Yes |
| CI artifact checksums | CI job output | Yes |
| Release checklist template | `templates/release-checklist-template.md` | Yes |
| Environment definitions | From `project-config.yaml` | Yes |
| Rollback runbook reference | From `project-context.md` or plan | Yes |
| Deployment model | From `project-context.md` | Yes |

## Required outputs (expected from Release Readiness Agent)

| Output | Format | Required |
|--------|--------|---------|
| Release checklist (completed) | Markdown | Yes |
| Go/hold recommendation with evidence | Explicit statement + evidence links | Yes |
| Missing items list | Items that must be resolved before deployment | If any |
| Deployment sequencing | Order of operations if multiple components | If applicable |
| Rollback instructions (deployment-specific) | Specific rollback steps for this release | Yes |
| Release readiness summary | One paragraph for workflow state | Yes |

## Validation rules

1. All required artifacts must be present (test coverage report, CI green, AI review posted, human review approved).
2. Rollback instructions must be deployment-specific, not generic.
3. Go/hold recommendation must be supported by evidence links — no bare assertion.
4. AI must not approve the deployment — the output is a checklist and recommendation for human decision.

## Quality checks

- SKL-019 (Release Readiness Review)
- RULE-GOV-003 (No autonomous production deployment)

## Blocking conditions

- CI is not green → release checklist cannot be completed; deployment must not proceed
- Rollback instructions missing → must be produced before deployment
- G-PR-MERGE not recorded → deployment must not proceed (merge should not have happened without gate)

## Human gate dependency

**G-DEPLOY gate.** Authorized human (engineering lead or SRE) reviews the release checklist, makes the go/no-go decision, and executes the deployment. AI produces the checklist and recommendation; human decides and acts.

## Artifact references

- Input: `artifacts.implementation_prs[]`; `artifacts.ai_review_output`; `gates.g_pr_merge`
- Output: `artifacts.release_checklist`; `agent_outputs.release_readiness_summary`; G-DEPLOY record created on approval

## Failure / rework path

If release checklist items are missing (e.g., failing CI, missing docs), the engineering team resolves the gaps before deployment authorization is requested.

## Payload type

`ReleaseReadinessHandoff` (see `schemas/acp/payload-release-readiness.schema.json`)
