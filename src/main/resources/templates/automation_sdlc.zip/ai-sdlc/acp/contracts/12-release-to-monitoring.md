# Contract 12: Release Readiness Agent → Monitoring / Feedback Agent

## Source agent
Release Readiness Agent (post-G-DEPLOY; deployment executed by human SRE)

## Target agent
Monitoring / Feedback Agent

## Purpose
After a successful deployment, hand off to the Monitoring / Feedback Agent to interpret post-deploy observability signals during the observation window and produce a go/hold/escalate recommendation for human review.

## SDLC stage transition
`DEPLOYED` → `VERIFIED`

## Required inputs (for Monitoring / Feedback Agent)

| Input | Format | Required |
|-------|--------|---------|
| Deployment confirmation | Timestamp, environment, version | Yes |
| Monitoring window duration | Minutes/hours from `project-config.yaml` | Yes |
| Expected behaviour baseline | Normal signal ranges from runbook | Yes |
| Observability data | Metrics, traces, logs from deployment window | Yes (at window close) |
| Alert threshold definitions | From project observability config | Yes |
| Rollback runbook reference | Specific rollback steps for this release | Yes |

## Required outputs (expected from Monitoring / Feedback Agent)

| Output | Format | Required |
|--------|--------|---------|
| Signal interpretation | Normal / Anomaly / Degraded per service/endpoint | Yes |
| Anomaly characterisation | What changed, error rates, latency delta | If anomaly detected |
| Go/hold/escalate recommendation | Explicit recommendation with evidence | Yes |
| Rollback trigger conditions | Conditions under which human should rollback (for human decision) | Yes |
| Monitoring summary | One paragraph for workflow state | Yes |

## Validation rules

1. Monitoring output must never trigger autonomous action — all conditions are inputs for human decision.
2. Rollback trigger conditions are framed as conditions for a human to evaluate, not autonomous triggers.
3. Anomaly characterisation must reference specific metrics or log patterns, not bare assertions.

## Quality checks

- SKL-020 (Monitoring Signal Interpretation)
- RULE-GOV-003 (No autonomous production deployment or rollback)

## Blocking conditions

- Observability data not available → agent requests data; monitoring window is extended; human on-call is notified
- Anomaly detected → immediately surface to on-call engineer; do not wait for window to close

## Human gate dependency

Human SRE reviews go/hold/escalate recommendation. Rollback is always human-executed. Incident declaration is always human-initiated. AI Monitoring Agent must not take operational actions.

## Artifact references

- Input: `artifacts.release_checklist`; deployment event timestamp
- Output: `artifacts.monitoring_report`; `agent_outputs.monitoring_summary`

## Failure / rework path

If anomaly detected: immediately notify on-call engineer. Agent provides characterised anomaly data and rollback conditions for human decision. Human decides go/hold/rollback.

## Payload type

Custom monitoring handoff payload (to be defined when observability MCP is integrated)
