# Contract 13: Monitoring / Feedback Agent → Knowledge Update Agent

## Source agent
Monitoring / Feedback Agent (observation window complete; human has reviewed signals)

## Target agent
Knowledge Update Agent

## Purpose
After successful deployment and monitoring verification, hand off to the Knowledge Update Agent to close the lifecycle loop: update documentation, ADRs, runbooks, and knowledge bases to reflect deployed behaviour, and produce retro items and context freshness suggestions.

## SDLC stage transition
`VERIFIED` → `COMPLETE`

## Required inputs (for Knowledge Update Agent)

| Input | Format | Required |
|-------|--------|---------|
| Monitoring summary (normal/anomaly resolution) | Markdown | Yes |
| Release notes draft | From Release Readiness Agent | Yes |
| PR diff (merged changes) | Diff summary | Yes |
| Existing documentation index | Paths from `project-context.md` | Yes |
| Incident or anomaly notes | If any incidents occurred | If applicable |
| Retro input | Team retro notes if available | Recommended |

## Required outputs (expected from Knowledge Update Agent)

| Output | Format | Required |
|--------|--------|---------|
| Documentation update PR | PRs for docs/runbook/ADR updates | Yes |
| Changelog entry (finalised) | Keep-a-changelog format | Yes |
| Retro items | List of process improvement observations | Recommended |
| Project-context freshness suggestion | Fields in `project-context.md` that should be updated | Yes |
| Knowledge update summary | One paragraph for workflow state | Yes |

## Validation rules

1. Documentation must reflect deployed behaviour — not intended behaviour or pre-release spec.
2. `project-context.md` freshness must be assessed; if fields are stale, update suggestions must be produced.
3. Retro items are suggestions only — not prescriptions; human retrospective facilitator decides what to act on.
4. Changelog must be finalised and accurate before issue is closed.

## Quality checks

- RULE-DOC-001 (Documentation Discipline)
- RULE-DOC-002 (Context Freshness) — assessed at this stage
- SKL-022 (Documentation Gap Detection)
- SKL-021 (Context Freshness Check)

## Blocking conditions

- Documentation update PR cannot be opened → surface as warning; issue can still be closed with a follow-up issue for docs
- Changelog missing → must be produced before issue close

## Human gate dependency

Engineering lead or technical writer approves docs changes for Tier 3+. External documentation publication always requires human approval. Retro items are reviewed by team in retrospective (not by agent).

## Artifact references

- Input: `artifacts.monitoring_report`; `artifacts.implementation_prs[]`; `artifacts.release_checklist`
- Output: `artifacts.docs_update_pr`; issue close record; `agent_outputs.knowledge_update_summary`; `work_state.current_stage = "COMPLETE"`

## Failure / rework path

If documentation gaps are found post-close, a follow-up issue is created. The Knowledge Update Agent does not block issue closure for minor documentation gaps — it logs them as follow-up items.

## Payload type

Knowledge update handoff payload (to be formally defined; uses `ImplementationResultHandoff` as base with documentation fields)
