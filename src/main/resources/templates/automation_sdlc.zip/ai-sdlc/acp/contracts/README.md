# ACP Handoff Contracts

This directory contains per-transition ACP handoff contract specifications for the AI-SDLC
multi-agent workflow. Each file defines one agent-to-agent handoff.

> **Status:** These are **contract design documents**. The ACP message broker and runtime
> inter-agent transport are not yet implemented. At Maturity Level 1–2, handoffs are performed
> manually by engineers following the contract format as a structured checklist.
>
> Envelope schema: `schemas/acp/handoff-envelope.schema.json`
> Full handoff contracts spec: `acp/acp-handoff-contracts.md`

## Contracts in this directory

| File | From → To | Stage transition |
|------|-----------|-----------------|
| `01-analyst-to-clarification.md` | Requirement Analyst → Clarification | REQUIREMENT → CLASSIFIED |
| `02-clarification-to-classification.md` | Clarification → Work Classification | REQUIREMENT → CLASSIFIED |
| `03-classification-to-impact.md` | Work Classification → Impact Analysis | CLASSIFIED → SPEC_DRAFTED |
| `04-impact-to-planning.md` | Impact Analysis → Technical Planning | SPEC_DRAFTED → PLAN_DRAFTED |
| `05-planning-to-architecture-review.md` | Technical Planning → Architecture Review | PLAN_DRAFTED → PLAN_APPROVED (Tier 3+) |
| `06-planning-to-implementation.md` | Planning / Architecture → Implementation | PLAN_APPROVED → IMPLEMENTING |
| `07-implementation-to-test.md` | Implementation → Test | IMPLEMENTING (step complete) |
| `08-implementation-test-to-docs.md` | Implementation + Test → Documentation | IMPLEMENTING → REVIEW_REQUESTED |
| `09-impl-docs-to-self-review.md` | Implementation + Docs → Self Review | REVIEW_REQUESTED |
| `10-self-review-to-pr-review.md` | Self Review → PR Review | PR_OPEN |
| `11-pr-review-to-release.md` | PR Review → Release Readiness | MERGED → DEPLOYING |
| `12-release-to-monitoring.md` | Release Readiness → Monitoring / Feedback | DEPLOYED |
| `13-monitoring-to-knowledge.md` | Monitoring / Feedback → Knowledge Update | VERIFIED → COMPLETE |

## Contract template format

Each contract uses the following structure:

```
## Source agent
## Target agent
## Purpose
## SDLC stage transition
## Required inputs (from source agent output)
## Required outputs (expected from target agent)
## Validation rules
## Quality checks
## Blocking conditions
## Human gate dependency
## Artifact references
## Failure / rework path
## Payload type
```
