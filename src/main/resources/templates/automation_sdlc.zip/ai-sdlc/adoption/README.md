# AI-SDLC Adoption Package

This package helps a new team adopt `ai-sdlc` in a practical, low-risk way.

## Adoption goals

- Start with governance and visibility, not autonomy.
- Keep high-risk actions human-controlled.
- Prove value quickly with one pilot workflow.
- Make conformance checks and audit trails part of normal engineering work.

---

## Start here — recommended reading order

You do not need to read everything before starting. Use this order:

| # | Document | Who needs it | Time |
|---|----------|-------------|------|
| 1 | [`operator-quick-start.md`](operator-quick-start.md) | **Everyone** — 10–15 min first operator path | 15 min |
| 1b | [`operator-guide.md`](operator-guide.md) | **Operators** — full lifecycle reference | 30 min |
| 2 | [`work-tiers.md`](../work-tiers.md) | **Everyone** — tier classification | 10 min |
| 3 | [`approval-gates.md`](../governance/approval-gates.md) | Leads and reviewers | 10 min |
| 4 | [`rollback-policy-guide.md`](rollback-policy-guide.md) | Tier 3+ / merge readiness (Phase 1) | 10 min |
| 5 | [`modernization-lane-guide.md`](modernization-lane-guide.md) | Modernization/migration work (Phase 2) | 15 min |
| 6 | [`cutover-readiness-guide.md`](cutover-readiness-guide.md) | Production cutover planning (Phase 3) | 10 min |
| 7 | [`post-migration-validation-guide.md`](post-migration-validation-guide.md) | Post-cutover validation (Phase 3) | 10 min |
| 8 | [`production-migration-gates-guide.md`](production-migration-gates-guide.md) | Production migration gates (Phase 3) | 10 min |
| 9 | [`pilot-run-guide.md`](pilot-run-guide.md) | **Pilot team** — one real issue end-to-end | 30 min |
| 10 | [`pilot-plan.md`](pilot-plan.md) | **Pilot owner** — controlled internal pilot scope | 15 min |
| 11 | [`pilot-readiness-checklist.md`](pilot-readiness-checklist.md) | **Pilot owner** — go/no-go checklist | 10 min |

**Day-to-day helpers** (keep nearby while working):

| Document | Purpose |
|----------|---------|
| [`prompt-quick-reference.md`](prompt-quick-reference.md) | Prompt quick reference |
| [`first-feature-walkthrough.md`](first-feature-walkthrough.md) | First issue walkthrough |
| [`prompt-input-source-map.md`](prompt-input-source-map.md) | What to prepare before each prompt |
| [`project-config-guide.md`](project-config-guide.md) | Overlay and policy configuration |

**Setup and admin** (as needed):

| Document | Purpose |
|----------|---------|
| [`live-project-handover-guide.md`](live-project-handover-guide.md) | Onboarding a live project |
| [`mcp/github-readonly-setup.md`](../mcp/github-readonly-setup.md) | GitHub MCP |
| [`branch-protection-setup.md`](branch-protection-setup.md) | CI enforcement |
| [`../../docs/operating-model/current-sdlc-flow.md`](../../docs/operating-model/current-sdlc-flow.md) | Textual lifecycle reference |
| [`../../docs/operating-model/ai-sdlc-command-and-prompt-reference.md`](../../docs/operating-model/ai-sdlc-command-and-prompt-reference.md) | Complete command inventory |
| [`troubleshooting.md`](troubleshooting.md) | When something breaks |
| [`reason-code-runbook.md`](reason-code-runbook.md) | BLOCKED reason codes (generated) |
| [`recovery-runbook.md`](recovery-runbook.md) | Interruption and recovery |
| [`pilot-metrics.md`](pilot-metrics.md) | Pilot success metrics |
| [`pilot-rollback-triggers.md`](pilot-rollback-triggers.md) | Stop/pause triggers |

**Minimum viable start:** Read docs 1–3, configure project overlay, then start your first issue with `first-feature-walkthrough.md`.

**Pilot command discipline:** During any pilot, use `make ai-sdlc-stage-router` as the canonical routing source, `make ai-sdlc-validate-artifacts` for artifact checks, and `make ai-sdlc-validate-pre-spec` before technical-plan handoff. Complete MCP Phase 0 write-block validation before live issues. See [`pilot-run-guide.md`](pilot-run-guide.md#pilot-command-discipline).

---

## Lifecycle branches (Phase 1–3)

Most work follows the **standard path**. Optional layers apply only when classification and project policy require them.

### Standard bug/feature path

```
Requirement → Clarification / DoR → Classification → Impact (Tier 2+) → Specification
→ Spec Review Record → Pre-Spec Validation → Technical Plan
→ Gate Review → Implementation → Self Review → PR → QA → Merge Readiness
→ Deploy → Verified → Complete
```

The adaptive specification uses bug-fix, feature/enhancement, or spike/investigation
sections as appropriate. `spec_review_record` is lightweight review evidence, not a
formal G-SPEC gate.

### Tier 3+ rollback-sensitive path (Phase 1)

Same as standard, plus **`rollback_plan`** required before merge readiness for Tier 3+ or sensitive work types. Rollback **planning** only — not rollback execution.

### Modernization / migration path (Phase 2)

After impact analysis, when `work_type` or `modernization.enabled` activates the lane:

```
Modernization Assessment → Discovery → Target Architecture → Migration Strategy
→ Modernization Gate Review → Technical Plan → (rejoins standard implementation/review/deploy path)
```

Default strategy guidance: strangler fig, phased migration, modular-monolith-first — not microservices-by-default.

### Cutover-active modernization path (Phase 3)

When `cutover.required: true` or cutover policy matches, at deploy readiness:

```
Deploy Ready → Cutover Ready → Cutover → Deployed → Post-Migration Validation → Verified → Complete
```

Cutover stages are **readiness and approval control only** — no automated production execution. Standard bug/feature deploy (`Deploy Ready → Deploying → Deployed`) is unchanged when cutover is not required.

**Example workspaces** (generic fixtures):

- `ai-sdlc/examples/workspaces/rollback-tier3/` — Phase 1 rollback
- `ai-sdlc/examples/workspaces/modernization-lane/` — Phase 2 modernization
- `ai-sdlc/examples/workspaces/cutover-modernization/` — Phase 3 cutover

---

## Suggested adoption sequence (for team leads and admins)

1. Read `quick-start.md`, `work-tiers.md`, and `approval-gates.md` (see [reading order](README.md#start-here--recommended-reading-order)).
2. For Tier 3+ or rollback-sensitive work, read `rollback-policy-guide.md`.
3. For modernization/migration work, read `modernization-lane-guide.md`; for production cutover, read the Phase 3 guides in the reading order.
4. Fill project settings using `project-config-guide.md` and `project-config.template.yaml`.
5. Configure GitHub MCP per `mcp/github-readonly-setup.md`.
6. Enable CI and branch protection per `branch-protection-setup.md`.
7. Run `first-week-rollout-plan.md` for the team rollout plan.
8. Run the stakeholder walkthrough in [`first-feature-walkthrough.md`](first-feature-walkthrough.md).
9. Confirm role accountability in `roles-and-responsibilities.md`.
10. Document disallowed automation areas from `when-not-to-use-ai-automation.md`.

## Recommended starting mode

- **Automation posture**: assisted-first (AI drafts, humans approve and execute risky steps).
- **Scope**: one non-critical requirement flowing through clarification -> classification -> impact/spec -> technical plan -> PR workflow.
- **Controls**: enable conformance checks and audit logs from day one.

## What stays manual initially

- Merge to protected branches
- Production deployment approvals
- Any destructive infrastructure or data operations
- Security/compliance decisions and exception approvals

