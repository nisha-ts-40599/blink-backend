# Requirement Grooming — Guide for Business Analysts and Product Owners

**Audience:** Business analysts, product owners, and stakeholders who write or review Jira
issues before engineering runs AI-SDLC grooming.

**You do not need to run AI prompts.** Developers run grooming; your job is to provide clear
input in Jira and review the groomed output.

**Related docs for developers:** [`requirement-grooming-sop.md`](requirement-grooming-sop.md)

---

## What happens in grooming

1. A developer takes your Jira issue and runs AI-SDLC **clarify-requirement**.
2. The output becomes a groomed **requirement document** with acceptance criteria, test
   expectations, and open questions.
3. You answer any open questions and confirm acceptance criteria.
4. When the document is **Ready for classify-work**, engineering classifies risk tier and plans work.

---

## What to put in Jira before grooming

Include as much of the following as you can:

| Field | Why it matters |
|-------|----------------|
| **Clear title** | One sentence describing the outcome |
| **Problem or opportunity** | Why we are doing this |
| **Who is affected** | User role, team, or customer segment |
| **Expected outcome** | What “done” looks like in plain language |
| **Acceptance criteria** | Testable conditions (see below) |
| **Non-goals** | What is explicitly out of scope |
| **Priority / urgency** | Helps tier and scheduling |
| **Links** | Designs, specs, related issues (public or internal — no secrets) |

If information is missing, grooming will list **open questions** for you to answer.

---

## How to write a good bug report

| Include | Example |
|---------|---------|
| Steps to reproduce | 1. Log in as viewer → 2. Wait 15 min → 3. Click dashboard |
| **Current behavior** | Redirected to login unexpectedly |
| **Expected behavior** | Session stays active or warning shown |
| **Environment** | Staging, browser, role, date observed |
| **Severity / frequency** | Often / blocks work / cosmetic |
| **Sanitized error text** | “Session expired” — not full stack traces with user data |

**Do not include:** passwords, tokens, production customer records, unsanitized logs, or
screenshots with personal information.

---

## How to answer AI-SDLC clarification questions for bugs

When developers share a groomed bug with **Needs PO/QA confirmation** or **Needs runtime
verification** items, help them close gaps quickly:

| Provide | Why |
|---------|-----|
| **Exact steps** you used (role, clicks, inputs) | Builds UI reproduction path |
| **Expected vs actual behavior** | Confirms product rule vs defect |
| **Affected UI / screen** | Which client (web admin, mobile, etc.) |
| **Environment** | Staging vs production; date/time observed |
| **User role** | Admin, member, guest, etc. |
| **Sanitized screenshots** | Before/after state — redact names, emails, IDs |
| **Product-rule confirmation** | Is expected behavior defined by product policy? |
| **Configuration confirmation** | Is behavior driven by org setting, flag, or version — not a defect? |
| **Deployed version** (if known) | API/app version when issue occurred |

**Do not include:** passwords, tokens, production personal data, full unsanitized logs, or
customer records. Describe patterns instead of pasting real data.

If runtime verification is requested, work with QA to capture **before/after API response
shape** and **UI state** using sanitized test accounts only.

---

## How to write a good enhancement request

| Include | Why |
|---------|-----|
| **Current behavior** | What users see today |
| **Proposed change** | What should change |
| **User pain** | Why the change matters |
| **Backward compatibility** | Must existing users/workflows keep working? |
| **Success metric** | How we know it worked (optional but helpful) |

---

## How to write a new feature request

| Include | Why |
|---------|-----|
| **Primary user / persona** | Who benefits |
| **Workflow** | Step-by-step happy path |
| **MVP vs later** | What must ship first vs what can wait |
| **Non-goals** | Prevents scope creep |
| **Rollout expectations** | All users at once vs phased (if known) |

For large features, a short workshop before grooming saves time.

---

## What acceptance criteria should look like

Good acceptance criteria are **specific and testable**:

| Weak | Strong |
|------|--------|
| “Export works” | “User can export CSV with columns A, B, C; file downloads within 10 seconds” |
| “Fast login” | “Login completes in under 2 seconds p95 in staging load test” |
| “Secure” | “Non-admin users receive 403 when accessing admin export endpoint” |

During grooming, criteria may receive IDs (**AC-001**, **AC-002**) for traceability to tests.
You will be asked to confirm each criterion — mark **yes** or **pending** until decided.

---

## How to answer AI clarification questions

When grooming lists open questions:

1. **Answer directly** in Jira comment or sync session — developer records resolution in the requirement doc.
2. **Name an owner** if you cannot answer immediately.
3. **Accept explicitly** if a reasonable default is OK: *“Accepted: use 7-day expiry per platform standard.”*
4. **Do not leave blocking questions open** if you want work to proceed to planning.

---

## What NOT to include in Jira or grooming artifacts

| Never include | Why |
|---------------|-----|
| Passwords or API tokens | Security risk; breaks data-safety rules |
| Production customer data | Privacy and compliance |
| Private customer records | Same |
| Unsanitized production logs | May contain PII or secrets |
| Screenshots with sensitive info | Redact or describe in text instead |
| Full competitor product copy | Copyright; use pattern descriptions only |
| Proprietary third-party content | Legal risk |

Use **sanitized examples** and **pattern summaries** instead.

---

## How to review groomed output

Your developer will share `requirement.md` or a summary. Check:

- [ ] **Restatement** matches your intent
- [ ] **Acceptance criteria** are correct and testable
- [ ] **Non-goals** reflect agreed scope
- [ ] **Open questions** are resolved or explicitly accepted
- [ ] **DoR status** is **ready**
- [ ] **Grooming decision** is **Ready for classify-work**

If something is wrong, ask the developer to update the requirement — do not proceed to planning with wrong AC.

---

## What “Ready for classify-work” means

The requirement is clear enough for engineering to:

1. Assign a **work tier** (1–4) based on risk and impact
2. Route to **impact analysis** and **technical planning** if needed
3. Estimate and schedule work

It does **not** mean implementation has started or that tier is final — the engineering lead confirms tier.

---

## Public references and competitor patterns

If you mention competitors or open-source products:

- Describe **patterns** only (e.g., “industry-standard CSV export with column picker”)
- Do **not** paste competitor UI text, screenshots, or proprietary flows
- Mark ideas as **assumptions** until you confirm product direction
- Developers follow [`public-reference-and-data-safety.md`](../governance/public-reference-and-data-safety.md)

Public references are **advisory** — you make the final product decision.

---

## Approval roles (pilot teams)

Before **Tier 2+** work starts implementation, pilot teams must assign **named owners** for:

| Role | Typical responsibility |
|------|------------------------|
| Engineering Lead | Tier confirmation, technical approach |
| Product Owner | Scope and AC sign-off |
| Security Reviewer | Auth, data, compliance changes |
| Platform Owner | Infra, IaC, production deploy |

Role placeholders in config must be replaced with real names or team aliases before wider pilot.

---

## Questions?

Ask your engineering lead or the developer running AI-SDLC grooming. For process details,
developers use [`requirement-grooming-sop.md`](requirement-grooming-sop.md).
