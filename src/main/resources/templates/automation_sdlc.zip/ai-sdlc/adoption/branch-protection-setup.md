# Branch Protection Setup Guide

Branch protection makes CI conformance and human approval **mechanically enforced** on every PR — not just a convention. Configure this once per repository after the CI workflow is deployed.

> **This is a manual step.** GitHub branch protection is configured in the GitHub web UI. No automation is needed or appropriate here.

---

## Prerequisites

Before configuring branch protection:

1. `.github/workflows/ai-sdlc-conformance.yml` must be committed and pushed to `main`.
2. The workflow must have run at least once (successfully or not) so GitHub knows the check name.
3. You must have **admin** access to the repository.

---

## Step-by-step: GitHub UI

Navigate to: **Repository → Settings → Branches → Add branch ruleset** (or "Add rule" in classic branch protection).

### Branch name pattern

```
main
```

---

### Required settings (minimum for AI-SDLC enforcement)

| Setting | Value | Why |
|---------|-------|-----|
| **Require a pull request before merging** | Enabled | No direct pushes to main |
| **Required approvals** | 1 | G-PR-MERGE gate: at least one human must approve |
| **Dismiss stale reviews when new commits are pushed** | Enabled | Re-approval required if code changes after approval |
| **Require status checks to pass before merging** | Enabled | CI must be green |
| **Required status check: `AI-SDLC Conformance`** | Added | Core governance gate: schema, policy, prompt quality checks |
| **Require branches to be up to date before merging** | Enabled | Prevents "works on my branch" merges |
| **Block force pushes** | Enabled | Prevents history rewrite on main |
| **Block deletions** | Enabled | Prevents accidental deletion of main |

---

### CI status checks — full reference

The `ai-sdlc-conformance.yml` workflow runs **three independent jobs**. Each job appears as a separate status check in GitHub. You must add each check by its visible job name.

| Job name (as it appears in GitHub) | What it gates | Required level |
|------------------------------------|--------------|----------------|
| **`AI-SDLC Conformance`** | Schema validation, OPA policy checks, YAML lint, prompt catalog and structure checks | **Minimum required** — core governance gate. Block merge without this. |
| **`Secret Scan (Gitleaks)`** | Scans for accidentally committed secrets and credentials in the diff and repo | **Strongly recommended** — blocks credential leaks. Require once stable. |
| **`Dependency Audit (pip-audit)`** | Checks framework Python dependencies for known CVEs | **Strongly recommended** — blocks known-vulnerable framework deps. Require once stable. |

**Why all three matter:**

- `AI-SDLC Conformance` is the governance gate. Without it, prompt quality, schema validity, and OPA policies are not enforced on merge.
- `Secret Scan (Gitleaks)` prevents real credential commits that bypass code review. Reviewers cannot reliably spot tokens in long diffs.
- `Dependency Audit (pip-audit)` ensures the framework tooling itself is not running on a known-CVE dependency.

**Soft rollout approach:** If you want a staged rollout, require only `AI-SDLC Conformance` initially and add `Secret Scan (Gitleaks)` and `Dependency Audit (pip-audit)` as informational (not required) status checks. Promote them to required once the team has confirmed no false positives after 1–2 sprints.

**Recommended pilot setup:** Require all three from the start.

---

### How to find the correct status check names

After the workflow has run at least once:

1. Open any PR that triggered the workflow.
2. Scroll to the bottom of the PR — find the checks section.
3. You will see three separate check entries. Add each by its exact name:
   - **`AI-SDLC Conformance`**
   - **`Secret Scan (Gitleaks)`**
   - **`Dependency Audit (pip-audit)`**

The names come from the `name:` field of each job in `.github/workflows/ai-sdlc-conformance.yml`. If you rename a job in the YAML, the check name changes and you must update branch protection to match.

If the workflow has not run yet, push a test commit or open a draft PR to trigger it.

---

### Optional but recommended settings

| Setting | Recommendation | Notes |
|---------|---------------|-------|
| **Restrict who can push to matching branches** | Add engineering lead group | Prevents accidental direct push from new contributors |
| **Do not allow bypassing the above settings** | Enabled for all non-admin users | Admins retain break-glass capability; document any bypasses |
| **Require conversation resolution before merging** | Enabled | Forces explicit resolution of reviewer comments |
| **Require signed commits** | Optional | Enable if your org has commit signing policy |

---

## What branch protection enforces automatically

Once configured, the following are **mechanically enforced** — no discipline required:

- Every change to `main` must come through a PR.
- Every PR must have CI conformance green before merge is possible.
- Every PR must have at least 1 human reviewer approval.
- Stale approvals are invalidated when new commits are pushed.
- Force pushes to `main` are blocked.

---

## What branch protection does NOT enforce

These remain governed by process and prompt discipline:

| Requirement | Enforcement mechanism |
|-------------|----------------------|
| G-PLAN approval comment on the issue | Workflow guide discipline + PR template checklist |
| G-SEC approval for Tier 3+ | PR template checklist + reviewer responsibility |
| Work tier label on PR | PR template checklist + reviewer check |
| Technical plan committed to ai-sdlc/plans/ | PR template required field |
| AI review run before human review | docs/operating-model/current-sdlc-flow.md discipline |
| Secrets not in diff | `Secret Scan (Gitleaks)` CI job (require as status check — see above) |

---

## Verifying branch protection is active

After configuring, verify:

1. Attempt to push directly to `main` — should be rejected.
2. Open a PR with a failing conformance check — merge button should be greyed out.
3. Open a PR with no approvals — merge button should require approval.
4. Push a new commit after receiving an approval — approval should be dismissed.

---

## Adding required status checks for AI-SDLC jobs

The three AI-SDLC jobs (`AI-SDLC Conformance`, `Secret Scan (Gitleaks)`, `Dependency Audit (pip-audit)`) should each be added as required status checks. All must pass before merge is permitted.

When you later add a stack-specific CI workflow (e.g., `node-ci.yml` or `python-ci.yml`), add its job name to the required status checks in the same way. Multiple required checks stack — every listed check must be green before GitHub will enable the merge button.

---

## Branch protection for additional long-lived branches

If your workflow uses `develop` or `staging` branches, apply the same ruleset to those branches. Use a branch name pattern of `develop` or `staging` respectively. The minimum required settings apply equally.

---

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| Status check not appearing in dropdown | Workflow has not run yet | Push a commit or open a draft PR to trigger the workflow |
| Merge blocked even with CI green | Wrong check name added | Verify the check name exactly matches the `name:` field of the job in the workflow YAML — job names are case-sensitive |
| Only one check in the dropdown | Other jobs have not run yet | Push a commit to trigger the workflow; all three jobs must run at least once before they appear |
| Gitleaks or pip-audit not in the dropdown | Job name differs from what was added to branch protection | Check the exact `name:` field in `.github/workflows/ai-sdlc-conformance.yml` and match it precisely |
| Admin can bypass protection | "Do not allow bypassing" not enabled | Enable it; document break-glass procedure separately |
| New commits don't invalidate old approval | "Dismiss stale reviews" not enabled | Enable it in branch protection settings |
