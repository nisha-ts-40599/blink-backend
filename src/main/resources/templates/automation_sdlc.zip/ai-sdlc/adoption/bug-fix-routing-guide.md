# Bug-Fix Routing Guide

How to route a bug fix through the AI-SDLC framework based on work tier and risk level.

**Reference policies:** `ai-sdlc/work-tiers.md`, `ai-sdlc/governance/approval-gates.md`
**Reference SOPs:** `adoption/requirement-grooming-sop.md`, `docs/operating-model/requirement-and-bugfix-sop.md`

---

## How routing works

Every bug fix is classified by `classify-work` after initial grooming. The classification result
(tier 1–4 and work_type) determines which steps are required and which are optional.

The router command:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<issue-id>
```

Use this after every significant artifact write to determine the next recommended action.

**A bug does not require Greenfield Bootstrap unless implementation requires a repository
or project structure that does not already exist.**

---

## Bug-fix route matrix

| Bug type | Typical tier | Phase 0 | Phase 1 | Bootstrap | QA | PR | Release |
|----------|-------------|---------|---------|-----------|----|----|---------|
| Small low-risk bug | Tier 1 | Lite grooming; G-GROOM optional | classify-work, lightweight plan | No | Optional | G-PR-MERGE | No (unless deployed) |
| Normal bug | Tier 2 | Full grooming; G-GROOM required | impact-analysis, spec, plan | No | Required | G-PR-MERGE | If deploy required |
| High-risk production bug | Tier 3 | Full grooming + rollback analysis | Full plan + risk register | No | G-QA mandatory | G-PR-MERGE | G-DEPLOY required |
| Security-sensitive bug | Tier 4 | Full grooming + CVE/security triage | G-SEC + security model | Only if new isolation required | G-QA mandatory | G-PR-MERGE | G-DEPLOY required |
| Bug requiring new repo | Tier 2–4 | Full grooming for the bug; spec for the new service | Full plan + bootstrap spec | Yes (for new repo only) | Per-tier | G-PR-MERGE | Per-tier |

---

## Detailed routes

### Small low-risk bug (Tier 1)

**Expected characteristics:** localized behaviour, no schema or architecture change, limited blast radius, existing repository.

**Phase 0 — Intake and Grooming**

1. `make ai-sdlc-groom-prep ISSUE=<id>`
2. `/clarify-requirement` — use lite template; clarify scope, AC, and expected behaviour
3. `make ai-sdlc-extract-grooming-state WRITE=1`
4. G-GROOM: **optional** when DoR is clearly satisfied; document decision in grooming-signoff
5. `/classify-work` — confirms Tier 1

**Phase 1 — Planning**

6. `/technical-plan` — lightweight ordered steps (may be a single step for trivial bugs)
7. `make ai-sdlc-approve-gate GATE=G-PLAN DECISION=approved WRITE=1` — **required**

**Phase 2 — Implementation**

8. `/implement-step`
9. Run focused tests; confirm fix covers AC
10. `/pr-registration` → `/pr-review`
11. QA: **optional** (Tier 1); include if AC verification requires an independent check
12. G-PR-MERGE: **required** — human merge

**What may be skipped for Tier 1:**
- stakeholder pack (if DoR is self-evident)
- grooming revision loop (if no open questions)
- G-GROOM (if DoR clearly ready, documented in grooming-signoff)
- impact analysis
- specification document
- validate-pre-spec (still recommended)
- qa-validation gate
- release verification (unless deployed system)

---

### Normal bug (Tier 2)

**Expected characteristics:** functional regression, data display error, API contract mismatch, moderate blast radius.

**Phase 0 — Intake and Grooming**

1. `make ai-sdlc-groom-prep ISSUE=<id>`
2. `/clarify-requirement` — full template; code-informed analysis required for existing products
3. Grooming loop until DoR = ready
4. `/grooming-sign-off-capture`
5. G-GROOM: **required** — `make ai-sdlc-approve-grooming DECISION=approved WRITE=1`
6. `/classify-work`

**Phase 1 — Planning**

7. `/impact-analysis` — identify affected components, dependencies, blast radius
8. `/create-spec` + spec review
9. `make ai-sdlc-validate-pre-spec` — must PASS
10. `/technical-plan`
11. G-PLAN: **required**

**Phase 2 — Implementation**

12. `/implement-step`
13. `/pr-registration` → `/pr-review`
14. `/qa-validation` — **required**
15. G-PR-MERGE: **required**
16. Release verification if deployment is required

---

### High-risk production bug (Tier 3)

**Expected characteristics:** data integrity issue, payment calculation error, PII/GDPR exposure, widespread functional failure.

**Phase 0 — Intake and Grooming**

1. groom-prep → `/clarify-requirement` (full template + expanded impact assessment)
2. Grooming must include: rollback or mitigation plan, stakeholder sign-off for risk acknowledgement
3. G-GROOM: **required**
4. `/classify-work` — Tier 3 may trigger G-SEC requirement

**Phase 1 — Planning**

5. `/impact-analysis` — mandatory; must cover downstream/upstream effects
6. `/create-spec` + spec review
7. `make ai-sdlc-validate-pre-spec`
8. `/technical-plan` — must include risk register and rollback strategy
9. G-PLAN: **required**
10. G-SEC: **required** for Tier 3 payment/PII changes

**Phase 2 — Implementation**

11. Spike if required before full implementation
12. `/implement-step`
13. `/pr-registration` → `/pr-review`
14. `/qa-validation` + G-QA gate: **required**
15. G-PR-MERGE: **required**
16. G-DEPLOY: **required** before production deployment
17. `/release-verification` after deployment

---

### Security-sensitive bug (Tier 4)

**Expected characteristics:** authentication bypass, authorization failure, CVE, injection vulnerability, cryptographic weakness.

**Phase 0 — Intake and Grooming**

1. `/bug-triage` or `/cve-triage` (if CVE-referenced)
2. groom-prep → `/clarify-requirement` with `/security-assessment`
3. G-GROOM: **required**
4. `/classify-work` — Tier 4; work_type may be `security_fix`

**Phase 1 — Planning**

5. `/impact-analysis` — mandatory; include threat surface, exploitability, CVSS assessment
6. `/create-spec` — include security controls, evidence requirements
7. `/technical-plan` — full security model, minimal-footprint implementation, restricted disclosure
8. G-PLAN: **required**
9. G-SEC: **required**

**Special handling:**
- Keep evidence artifacts restricted; do not include exploit details in general workflow-state
- Coordinate disclosure timeline before merge if public CVE
- Assign a security champion reviewer for G-SEC

**Phase 2 — Implementation**

10. `/implement-step` — security champion available for review
11. `/pr-registration` → `/pr-review` (restricted reviewer set where needed)
12. G-QA: **required**
13. G-PR-MERGE: **required**
14. G-DEPLOY: **required**
15. `/release-verification` + post-release monitoring

---

### Bug requiring architecture or repository changes

Use when a bug is fixed by introducing a new service, data store, or repository boundary (for example, extracting a vulnerable component into an isolated service).

**Route:**

1. Complete the bug-fix grooming and Phase 1 planning as normal for the bug's tier
2. The technical plan identifies the new repository requirement
3. After G-PLAN approval, add the Greenfield Bootstrap path:

```text
/normalize-greenfield-project-spec  (for the new repo only)
/generate-bootstrap-plan
G-BOOTSTRAP approval
manual bootstrap execution
/setup-existing-project apply  (or /setup-existing-workspace refresh)
make ai-sdlc-validate-setup-readiness ROOT=<root> REQUIRE=delivery
```

4. Return to Phase 2 implementation once `delivery_ready = true`

The existing workspace is not re-initialized. Bootstrap scopes to the new repository only.

---

## Approval gate reference

| Gate | Tier 1 | Tier 2 | Tier 3 | Tier 4 |
|------|--------|--------|--------|--------|
| G-GROOM | Optional | Required | Required | Required |
| G-BOOTSTRAP | Only if new repo | Only if new repo | Only if new repo | Only if new repo |
| G-PLAN | Required | Required | Required | Required |
| G-SEC | No | No | Required (PII/payment) | Required |
| G-QA | Optional | Required | Required | Required |
| G-PR-MERGE | Required | Required | Required | Required |
| G-DEPLOY | Only if deployed | Only if deployed | Required | Required |

---

## Frequently asked questions

**Does every bug require full stakeholder grooming?**
No. Tier 1 bugs may use the lite requirement template. G-GROOM is optional when DoR is
clearly satisfied and documented in the grooming sign-off.

**When can groom-prep be shortened?**
For Tier 1 bugs with clear scope, reproduction steps, and obvious AC.
`classify-work` still runs to confirm the tier.

**Is `classify-work` the router?**
Yes — it is the authoritative tier router and determines all subsequent required steps.
The stage-router (`make ai-sdlc-stage-router`) then gives the recommended next action.

**When is impact analysis mandatory?**
Tier 2 and above.

**When is a technical plan required?**
Always. Tier 1 may have a lightweight single-step plan.

**When is a test plan required?**
Embedded in the technical plan for all tiers. Tier 3+ has a formal G-QA gate.

**Which approval gates are always required?**
G-PLAN and G-PR-MERGE are always required regardless of tier.

**When may implementation begin?**
After G-PLAN approval (and G-SEC for Tier 3+).

**When does QA apply?**
Required for Tier 2+. Tier 1 is optional but recommended.

**When is release validation required?**
When a production deployment is triggered. Use `/release-verification` and G-DEPLOY gate.
