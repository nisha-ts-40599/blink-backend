# Cloud Migration SDLC Guide

Cloud migration uses the **modernization lane** within the standard AI-SDLC backbone.

## Activation

Set `work_type: cloud_infra` or `modernization` with `work_subtype: on_prem_to_cloud`, or `modernization.enabled: true`.

## Required artifacts

In addition to standard modernization lane artifacts:

- `cloud_readiness_assessment` (conditional)

## Recommended strategy

1. Assess current hosting, network, IAM, and data residency.
2. Target architecture: prefer replatform or refactor-in-place before re-architecting to microservices.
3. Migration strategy: phased environment cutover planning only — **no production cutover execution in Phase 2**.
4. Regression baseline: parity checks for latency, auth, and observability.
5. Rollback touchpoints: traffic switchback, config revert (see Phase 1 `rollback_policy`).

## Human gates

Modernization gate review must record human approval before technical plan. Do not approve cloud production cutover from AI prompts.

## Phase 3

Production cutover (`CUTOVER`, `G-PROD-MIGRATION`) belongs to Phase 3.
