# Phase B Command Playbook

This playbook explains how to use the Phase B.1-B.6 AI-SDLC command spine safely from issue initialization through closure reporting. It is intended for enterprise rollout teams that need repeatable workflow-state evidence without relying on manual YAML edits.

Use only generic examples when training or documenting the flow. The examples below use `DEMO-ISSUE-1`, `demo-app`, and `https://example.test/...`.

## Purpose

The Phase B command spine gives teams a consistent way to record lifecycle evidence:

- Initialize issue workflow-state.
- Register artifact references.
- Validate and apply stage transitions.
- Record human gate decisions.
- Register PR evidence.
- Record human merge closure evidence.
- Generate an evidence-based closure report.

The commands reduce manual workflow-state editing and make lifecycle evidence easier to review. They do not replace human judgment, human approval, code review, deployment readiness review, or release ownership.

## Safety Model

- AI can draft, implement, and review work.
- Commands record evidence and enforce workflow-state rules.
- Humans approve gates and lifecycle decisions.
- Dry-run output must be reviewed before using `WRITE=1`.
- The framework records evidence; it does not create the underlying approval.
- Merge evidence does not imply deployment readiness.

## Command Inventory

| Command | Purpose | State-changing by default? |
| --- | --- | --- |
| `ai-sdlc-init-issue` | Create an issue workflow-state file | Dry-run unless `WRITE=1` |
| `ai-sdlc-register-artifact` | Record an artifact reference | Dry-run unless `WRITE=1` |
| `ai-sdlc-transition` | Validate and apply a stage transition | Dry-run unless `WRITE=1` |
| `ai-sdlc-approve-gate` | Record a human gate decision | Dry-run unless `WRITE=1` |
| `ai-sdlc-register-pr` | Record PR evidence | Dry-run unless `WRITE=1` |
| `ai-sdlc-close-merge` | Record human merge closure evidence | Dry-run unless `WRITE=1` |
| `ai-sdlc-generate-closure-report` | Generate an evidence-based Markdown report | Read-only by default; writes only with `OUTPUT=... WRITE=1` |
| `ai-sdlc-bootstrap-operator-status` | Greenfield bootstrap route, gate, and next-command status | Read-only |
| `ai-sdlc-publish-bootstrap-completion` | Publish managed bootstrap completion candidate (Phase 5) | Dry-run unless `WRITE=1` |
| `ai-sdlc-reconcile-bootstrap-completion` | Phase 4 bootstrap reconciliation / delivery readiness | Dry-run unless `WRITE=1` |
| `ai-sdlc-record-command-execution` | Record automated command evidence (H10) | Dry-run unless `WRITE=1` |
| `ai-sdlc-record-ai-review` | Record AI implementation review evidence | Dry-run unless `WRITE=1` |
| `ai-sdlc-record-developer-attestation` | Record developer self-review attestation | Dry-run unless `WRITE=1` |
| `ai-sdlc-record-qa-execution` | Record QA execution evidence | Dry-run unless `WRITE=1` |
| `ai-sdlc-evaluate-merge-readiness` | Evaluate merge readiness from evidence | Dry-run unless `WRITE=1` |

Read-only checks such as stage routing, artifact validation, readiness checks, and closure report generation should be run often. State-changing commands should be run first as dry-runs, then repeated with `WRITE=1` only after review.

## Dry-Run And WRITE=1 Rules

- Omit `WRITE=1` to preview command behavior.
- Add `WRITE=1` only after a human reviews the dry-run output.
- Use `WRITE=1` for state-changing commands only when the evidence is accurate.
- `ai-sdlc-generate-closure-report` prints Markdown to stdout by default.
- `ai-sdlc-generate-closure-report OUTPUT=...` without `WRITE=1` previews the output path and report only.
- `ai-sdlc-generate-closure-report OUTPUT=... WRITE=1` writes the Markdown report file.
- Existing closure report output files are protected. Create a new path instead of overwriting.

## End-To-End Generic Workflow

The examples below show dry-run first, then `WRITE=1` where a workflow-state mutation is intended.

### 1. Initialize Workflow-State

```bash
make ai-sdlc-init-issue \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  TITLE="Demo issue" \
  ISSUE_URL=https://example.test/browse/DEMO-ISSUE-1

make ai-sdlc-init-issue \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  TITLE="Demo issue" \
  ISSUE_URL=https://example.test/browse/DEMO-ISSUE-1 \
  WRITE=1
```

### 2. Register Requirement And Planning Artifacts

```bash
make ai-sdlc-register-artifact \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  KEY=requirement_doc \
  PATH_VALUE=.cursor/ai-sdlc/workflow-state/DEMO-ISSUE-1/requirement.md

make ai-sdlc-register-artifact \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  KEY=requirement_doc \
  PATH_VALUE=.cursor/ai-sdlc/workflow-state/DEMO-ISSUE-1/requirement.md \
  WRITE=1

make ai-sdlc-register-artifact \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  KEY=plan_doc \
  PATH_VALUE=.cursor/ai-sdlc/workflow-state/DEMO-ISSUE-1/plan.md

make ai-sdlc-register-artifact \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  KEY=plan_doc \
  PATH_VALUE=.cursor/ai-sdlc/workflow-state/DEMO-ISSUE-1/plan.md \
  WRITE=1
```

### 3. Transition Through Valid Stages

```bash
make ai-sdlc-transition \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  TARGET_STAGE=CLASSIFIED

make ai-sdlc-transition \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  TARGET_STAGE=CLASSIFIED \
  WRITE=1
```

Run the stage router and validators between major steps:

```bash
make ai-sdlc-stage-router ROOT=. ISSUE=DEMO-ISSUE-1
make ai-sdlc-validate-artifacts ROOT=. ISSUE=DEMO-ISSUE-1
```

### 4. Record Plan Approval

`G-PLAN` records that a human approved the plan. The command records the decision; it does not create the approval.

```bash
make ai-sdlc-approve-gate \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  GATE=G-PLAN \
  APPROVER="Demo Product Owner" \
  DECISION=approved \
  EVIDENCE_REF=https://example.test/approvals/demo-issue-1-plan

make ai-sdlc-approve-gate \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  GATE=G-PLAN \
  APPROVER="Demo Product Owner" \
  DECISION=approved \
  EVIDENCE_REF=https://example.test/approvals/demo-issue-1-plan \
  WRITE=1
```

### 5. Register PR Evidence

PR registration records a provider PR or a local unpushed candidate. It is not merge approval.

**Provider PR** — requires a valid provider URL:

```bash
make ai-sdlc-register-pr \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  REPO_ID=demo-app \
  PR_URL=https://example.test/demo-app/pull/1 \
  SOURCE_BRANCH=feature/demo-issue-1 \
  TARGET_BRANCH=main \
  COMMIT_SHA=abc1234 \
  WRITE=1
```

**Local unpushed candidate** — use when no provider PR exists (provider unavailable or branch not pushed). Do not invent synthetic URLs:

```bash
make ai-sdlc-register-pr \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  REPO_ID=demo-app \
  SOURCE_BRANCH=feature/demo-issue-1 \
  TARGET_BRANCH=main \
  COMMIT_SHA=abc1234 \
  CANDIDATE_TYPE=LOCAL_UNPUSHED_CANDIDATE \
  PROVIDER_UNAVAILABLE=1 \
  WRITE=1
```

Push-state semantics:

| `push_status` | Meaning |
|---------------|---------|
| `NOT_PUSHED` | Local branch only; no verified remote push |
| `PUSHED_UNVERIFIED` | Push reported locally but not provider-verified |
| `PUSHED_VERIFIED` | Authenticated provider or remote-ref evidence |
| `UNKNOWN` | Omitted at registration time — never defaults to pushed |

Local candidates use `candidate_id`, branch, commit, and target branch for identity. `pr_url` remains null.

To supersede an inaccurate registration (for example a synthetic local URL or `pushed: true` without evidence), use the correction command — do not edit workflow YAML manually:

```bash
make ai-sdlc-correct-pr-registration \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  REPO_ID=demo-app \
  WRITE=1
```

The prior registration is preserved in `implementation.pr_registration_history`. Local/manual evidence does not upgrade to provider authority.

### 6. Record PR Merge Approval

`G-PR-MERGE` records human approval to merge a specific registered PR. The evidence reference should match the registered PR or approval evidence for that PR.

```bash
make ai-sdlc-approve-gate \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  GATE=G-PR-MERGE \
  APPROVER="Demo Maintainer" \
  DECISION=approved \
  EVIDENCE_REF=https://example.test/demo-app/pull/1 \
  SOURCE_TYPE=pr

make ai-sdlc-approve-gate \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  GATE=G-PR-MERGE \
  APPROVER="Demo Maintainer" \
  DECISION=approved \
  EVIDENCE_REF=https://example.test/demo-app/pull/1 \
  SOURCE_TYPE=pr \
  WRITE=1
```

### 7. Record Merge Closure

Merge closure means a human merge happened and the merge evidence is recorded. It does not mean deployment readiness.

```bash
make ai-sdlc-close-merge \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  REPO_ID=demo-app \
  PR_URL=https://example.test/demo-app/pull/1 \
  MERGE_COMMIT_SHA=def5678 \
  MERGED_BY="Demo Maintainer" \
  MERGED_AT=2026-06-29T00:00:00Z \
  TARGET_BRANCH=main \
  MERGE_EVIDENCE_REF=https://example.test/demo-app/pull/1

make ai-sdlc-close-merge \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  REPO_ID=demo-app \
  PR_URL=https://example.test/demo-app/pull/1 \
  MERGE_COMMIT_SHA=def5678 \
  MERGED_BY="Demo Maintainer" \
  MERGED_AT=2026-06-29T00:00:00Z \
  TARGET_BRANCH=main \
  MERGE_EVIDENCE_REF=https://example.test/demo-app/pull/1 \
  WRITE=1
```

### 8. Generate Closure Report

Generate the report to stdout:

```bash
make ai-sdlc-generate-closure-report ROOT=. ISSUE=DEMO-ISSUE-1
```

Preview writing a report file:

```bash
make ai-sdlc-generate-closure-report \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  OUTPUT=.cursor/ai-sdlc/workflow-state/DEMO-ISSUE-1/closure-report.md
```

Write the Markdown report file after review:

```bash
make ai-sdlc-generate-closure-report \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  OUTPUT=.cursor/ai-sdlc/workflow-state/DEMO-ISSUE-1/closure-report.md \
  WRITE=1
```

Use `INCLUDE_RAW_EVIDENCE=1` only when a summarized raw evidence section is useful for audit review:

```bash
make ai-sdlc-generate-closure-report \
  ROOT=. \
  ISSUE=DEMO-ISSUE-1 \
  INCLUDE_RAW_EVIDENCE=1
```

## Human Approval Boundaries

- `ai-sdlc-approve-gate` records a human decision that already happened.
- The approver must be a real person or authorized approval identity for the team.
- Evidence references must point to reviewable approval evidence.
- AI-generated text may support the review, but it is not the approval.
- Conditional approvals remain incomplete until the stated conditions are met and recorded.

## Gate Rules

| Gate | Use | Notes |
| --- | --- | --- |
| `G-PLAN` | Plan approval | Required when the team needs explicit plan approval before implementation |
| `G-SEC` | Security approval | Use when the work tier, sensitivity, policy, or review requires security signoff |
| `G-PR-MERGE` | PR merge approval | Must refer to the PR or review evidence for the registered PR |
| `G-DEPLOY` | Deployment governance | Does not belong to merge closure; use only when deployment readiness or release governance requires it |

Do not approve gates from memory. Record approver, decision, evidence reference, and conditions when applicable.

## Conditional Approval Rules

- Use `DECISION=approved_with_conditions` when the human approval depends on follow-up work.
- Record conditions clearly and specifically.
- Do not treat conditional approval as valid until conditions are met.
- Do not proceed to merge closure if `G-PR-MERGE` conditions are unmet.
- Use closure report warnings to identify unmet conditions before lifecycle closure.

## PR Registration, PR Approval, And Merge Closure

- PR registration: `ai-sdlc-register-pr` records that a PR exists.
- PR approval: `ai-sdlc-approve-gate GATE=G-PR-MERGE` records human approval to merge.
- Merge closure: `ai-sdlc-close-merge` records that the human merge occurred.

These are three separate events. Do not use one as evidence for another unless the workflow-state explicitly records the appropriate command output and evidence.

## Merge And Deployment Readiness

- "Merged" means merge closure evidence exists.
- "Deploy-ready" means deployment readiness evidence exists.
- "Deployed" means explicit deployment evidence exists.
- Merge closure does not set or imply `DEPLOY_READY`.
- The B.6 closure report may state `merged_not_deploy_ready`; that is a valid post-merge status when deployment readiness is not in scope or not yet established.

## Troubleshooting

| Symptom | Likely cause | Response |
| --- | --- | --- |
| `workflow-state not found` | The issue was not initialized or `ROOT`/`ISSUE` is wrong | Run `ai-sdlc-init-issue` or correct the input values |
| Missing Make variables | Required command inputs are absent | Re-run with all required variables shown in the command usage |
| Unsupported stage transition | Target stage is invalid for current evidence | Run stage router and validators, then register missing artifacts or approvals |
| Invalid gate approval | Missing approver, evidence, decision, or unmet policy checks | Confirm the human decision and rerun dry-run before `WRITE=1` |
| Unmet conditions | Conditional approval was recorded but conditions are not met | Resolve conditions before treating the gate as valid |
| PR URL mismatch | `G-PR-MERGE` evidence does not match the registered PR | Correct the PR registration or approval evidence |
| Duplicate PR evidence | Same PR or conflicting PR data was already recorded | Review existing workflow-state and avoid overwriting valid evidence |
| Merge attempted before valid approval | `G-PR-MERGE` is missing or invalid | Record valid human approval before merge closure |
| Existing closure report output file | Output path already exists | Choose a new path; B.6 does not support overwrite |
| Legacy PR-only evidence warning | `artifacts.implementation_prs` exists without structured repo evidence | Use `ai-sdlc-register-pr` for structured PR evidence |

## Do-Not-Use Rules

- Do not manually edit workflow-state except during controlled recovery.
- Do not treat command-recorded approval as actual human approval.
- Do not treat PR registration as merge approval.
- Do not treat merge as deployment readiness.
- Do not use real client repo URLs in training examples.
- Do not use real client issue IDs in demo materials.
- Do not add deployment automation to the Phase B command spine.
- Do not use closure report generation to close an issue tracker ticket automatically.

## Review Checklist

- Workflow-state was initialized with the correct issue ID.
- Required artifacts were registered with reviewable references.
- Stage transitions were previewed before `WRITE=1`.
- Gate approvals include approver, decision, evidence, and conditions where needed.
- PR registration exists before `G-PR-MERGE`.
- Merge closure exists only after valid PR approval.
- Closure report warnings were reviewed.
- Merge, deploy-ready, and deployed language is used precisely.
