# Example: Tier 3 Production Bug Rollback Plan

Generic example — **Acme Billing Service**. No real customer data.

## Scenario

| Field | Value |
|-------|-------|
| Issue | BUG-442 |
| Work type | production_bugfix |
| Tier | 3 |
| Risk | `payment_sensitive: true` |
| Change | Fix duplicate charge on subscription renewal webhook |

## SDLC path (Phase 1)

1. Requirement → classify (Tier 3) → impact analysis → technical plan → G-PLAN / G-SEC
2. Implement → PR review → QA post-fix validation
3. **Before MERGE_READY:** run `rollback-plan.prompt.md`
4. Merge readiness blocked until `artifacts.rollback_plan` is registered

## Sample rollback plan excerpt

```markdown
# Rollback Plan: BUG-442

## Change summary
- Issue: BUG-442 — duplicate renewal charge
- Work type: production_bugfix
- Tier: 3
- Repo(s): billing-api
- PR(s): https://github.example/acme/billing-api/pull/88
- Target environment: production

## Rollback classification
- Rollback required: yes
- Rollback type: git_revert + redeploy_previous_build
- Data cleanup required: yes (erroneous charge records)
- Customer impact expected: yes (refunds may be needed)

## Rollback triggers
- Functional: duplicate charges > 0 in 15m window after deploy
- Data: reconciliation job shows mismatched ledger totals

## Rollback steps
1. Revert PR #88 merge commit on main (`git revert <sha>`)
2. Deploy previous build `billing-api:v2.14.3` via standard pipeline
3. Disable feature flag `billing.renewal_fix_v2` if enabled
4. Run reconciliation script `scripts/reconcile-renewals.sh --since=<deploy_time>` (human-approved)

## Validation after rollback
- API smoke: POST /webhooks/renewal test fixture — single charge only
- Data validation: ledger row count matches pre-deploy baseline sample
- Business validation: finance approves reconciliation report

## Status
Draft — awaiting Engineering Lead approval
```

## Workflow-state registration

```yaml
artifacts:
  rollback_plan: ".cursor/ai-sdlc/workflow-state/BUG-442/rollback-plan.md"

rollback:
  required: true
  status: draft
  type: git_revert
  owner: "Engineering Lead"
  approved: false
  data_cleanup_required: true
  data_cleanup_approved: false
```

## Validation commands

```bash
make ai-sdlc-rollback-check ROOT=<workspace> ISSUE=BUG-442
make ai-sdlc-stage-router ROOT=<workspace> ISSUE=BUG-442
```

Expected before rollback plan: `rollback_satisfied: NO`, merge readiness blocked.  
Expected after registration: rollback check passes (other merge gates still apply).

## Human approvals

- **Merge:** G-PR-MERGE (human PR review)
- **Rollback plan:** Engineering Lead + Finance for data cleanup section
- **Rollback execution:** On-call SRE — never automated by AI
