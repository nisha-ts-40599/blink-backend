# Cutover Readiness Guide (Phase 3)

Production cutover planning and readiness for modernization/migration work in the AI-SDLC backbone.

## When cutover applies

Phase 3 activates **only** when:

- `cutover.required: true` in workflow-state, or
- `modernization.cutover_required: true`, or
- Project `cutover_policy` matches work type/subtype and `required_when` risk flags.

Normal bug/feature deploy flows use `DEPLOY_READY → DEPLOYING → DEPLOYED → VERIFIED` unchanged.

## Cutover flow

```
DEPLOY_READY → CUTOVER_READY → CUTOVER → DEPLOYED → POST_MIGRATION_VALIDATION → VERIFIED → COMPLETE
```

## Required artifacts before CUTOVER_READY

| Artifact | Prompt |
|----------|--------|
| `cutover_plan` | `cutover-plan.prompt.md` |
| `rollback_plan` | (Phase 1 rollback policy) |
| `rollback_readiness_review` | `rollback-readiness-review.prompt.md` |
| `post_migration_validation_plan` | `post-migration-validation-plan.prompt.md` |
| `production_migration_approval` | `production-migration-approval.prompt.md` (Tier 4 / prod migration) |

## Safety constraints

- **Planning and approval only** — no production execution, traffic switches, or database changes.
- Rollback readiness review is **not** rollback execution.
- Human approval is mandatory for all production migration gates.

## Example workspace

```bash
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/cutover-modernization ISSUE=CUT-1
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/cutover-modernization ISSUE=CUT-1-READY
```

See also: [production-migration-gates-guide.md](production-migration-gates-guide.md), [post-migration-validation-guide.md](post-migration-validation-guide.md).
