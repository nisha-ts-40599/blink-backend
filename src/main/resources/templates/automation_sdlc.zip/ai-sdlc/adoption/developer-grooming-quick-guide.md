# Developer Grooming Quick Guide

**Purpose:** Help new developers participate in AI-SDLC grooming sessions with minimal manual confusion.

This is a generic, governed, AI-assisted SDLC framework with human gates — not a fully autonomous delivery pipeline.

---

## 1. What AI-SDLC grooming is

Grooming turns a raw tracker issue into a **Definition-of-Ready requirement** and routes the work through the correct SDLC tier and prompts. AI assists drafting and analysis; humans approve scope, tier, gates, and artifacts.

---

## 2. What to prepare before grooming

- Confirm `.cursor/ai-sdlc/project-context.md` and `project-config.yaml` exist and are current (overlay-first; fallback `ai-sdlc/` paths only when overlay is missing).
- Create or locate workflow state: `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/<ISSUE-ID>.yaml`.
- Have the issue key and any known constraints (security, dependencies, deadlines).
- Run `make ai-sdlc-resolve-issue-tracker` to see configured tracker provider (`manual` if none).
- Enable read-only MCP in Cursor if your team uses a configured tracker MCP for live evidence.

---

## 3. Commands to run first

From the framework repo directory:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
make ai-sdlc-resolve-issue-tracker ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-context-report ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-groom-prep ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout (framework repo inside a product workspace):

```bash
make ai-sdlc-guard-framework-clean ROOT=..
make ai-sdlc-resolve-issue-tracker ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-validate-artifacts ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-context-report ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-groom-prep ROOT=.. ISSUE=<ISSUE-ID>
```

If the guard fails: **stop**, file a framework gap report, do not patch framework code during product delivery.

---

## Cursor slash commands vs Make targets

- **Make commands** — deterministic read-only checks (`guard`, `resolve-issue-tracker`, `stage-router`, `validate-artifacts`, `groom-prep`, `install-cursor-commands`).
- **Cursor slash commands** — thin wrappers that invoke canonical AI-SDLC phase prompts (type `/` in chat).
- **Full prompt paths** — use only for framework maintenance or debugging (`ai-sdlc/prompts/*.prompt.md` in the framework repo).

**Where things live:**

- Canonical prompts stay in the framework repo: `automation_sdlc/ai-sdlc/prompts/`.
- Slash-command wrappers must be installed into the **consuming workspace root** at `.cursor/commands/`.
- Developers run `/clarify-requirement`, `/technical-plan`, etc. from the **product workspace** — not necessarily from the framework repo checkout.

Install or sync wrappers during setup:

```bash
make ai-sdlc-install-cursor-commands ROOT=<workspace-root>
make ai-sdlc-install-cursor-commands ROOT=..
```

Use `FORCE=1` only when intentionally overwriting customized workspace command files with framework copies.

Helper slash commands:

| Command | Purpose |
|---------|---------|
| `/sdlc-start` | Initial guard + tracker + context + groom-prep + stage-router |
| `/sdlc-next` | Run stage-router and follow the recommended prompt |
| `/sdlc-after-prompt` | Validate artifacts and re-route after saving output |

| Phase | Cursor command | Canonical prompt |
|------|----------------|------------------|
| Clarify requirement | `/clarify-requirement` | `ai-sdlc/prompts/clarify-requirement.prompt.md` |
| Classify work | `/classify-work` | `ai-sdlc/prompts/classify-work.prompt.md` |
| Impact analysis | `/impact-analysis` | `ai-sdlc/prompts/impact-analysis.prompt.md` |
| Create spec | `/create-spec` | `ai-sdlc/prompts/create-spec.prompt.md` |
| Create issues | `/create-issues` | `ai-sdlc/prompts/create-issues.prompt.md` |
| Technical plan | `/technical-plan` | `ai-sdlc/prompts/technical-plan.prompt.md` |
| Implement step | `/implement-step` | `ai-sdlc/prompts/implement-step.prompt.md` |
| Generate tests | `/generate-tests` | `ai-sdlc/prompts/generate-tests.prompt.md` |
| Self review | `/self-review` | `ai-sdlc/prompts/self-review.prompt.md` |
| PR review | `/pr-review` | `ai-sdlc/prompts/pr-review.prompt.md` |
| Release verification | `/release-verification` | `ai-sdlc/prompts/release-verification.prompt.md` |
| Stage router (advisory) | `/stage-router` | `ai-sdlc/prompts/stage-router.prompt.md` |

Command wrappers are installed under `<workspace-root>/.cursor/commands/` (run `make ai-sdlc-install-cursor-commands` during setup). They reference canonical prompts only — no duplicated prompt logic.

**Setup prompts — discovery, apply, refresh, and reset:**

| Lifecycle | Flow |
|-----------|------|
| First-time setup | discovery → **apply** |
| Existing configured workspace | discovery → **refresh** |
| Workspace/repos changed | **refresh** — do not delete `.cursor/ai-sdlc/**` |
| Destructive recreate | **reset** only — archives to `.cursor/ai-sdlc.archive/<timestamp>/` first |

- **Discovery** (default): inspect and propose — no writes.
- **Apply**: create missing overlay (`/setup-existing-workspace apply`, or reply `confirm setup`).
- **Refresh**: reconcile discovery with existing overlay (`refresh setup`, `/setup-existing-workspace refresh`).
- **Reset**: archive and recreate only with explicit confirmation.

If setup only proposes files, reply `confirm setup` for apply, or use refresh when overlay already exists.

| Setup | Cursor command | Canonical prompt |
|------|----------------|------------------|
| Existing workspace | `/setup-existing-workspace` | `ai-sdlc/prompts/setup-existing-workspace.prompt.md` |
| New workspace | `/setup-new-workspace` | `ai-sdlc/prompts/setup-new-workspace.prompt.md` |
| Existing project | `/setup-existing-project` | `ai-sdlc/prompts/setup-existing-project.prompt.md` |
| New project | `/setup-new-project` | `ai-sdlc/prompts/setup-new-project.prompt.md` |

**Future backlog:** `make ai-sdlc-refresh-overlay` may automate refresh later; refresh is prompt-driven today.

---

## 4. How to use groom-prep

`make ai-sdlc-groom-prep` combines a prefill report and context bundle for the target prompt (default: `clarify-requirement`). It reads local overlay files only — no tracker API calls.

1. Run groom-prep for your issue.
2. Open the generated context JSON and prefill report.
3. Fetch MCP-readable fields in Cursor (issue body, repo excerpts) when needed.
4. Run the target prompt with bundle + pasted MCP evidence.

---

## 5. Which prompt to run first

| Situation | Start with |
|-----------|------------|
| New or unclear requirement | `/sdlc-start <ISSUE>` then `/clarify-requirement <ISSUE>` |
| Unsure where work stands in Requirement Grooming | `/requirement-grooming-status <ISSUE>` or `make ai-sdlc-stage-router` |
| Requirement groomed, DoR ready, G-GROOM approved | `/classify-work <ISSUE>` |

After `/clarify-requirement <ISSUE>`, extract grooming state and check status — **do not** jump to classify-work:

```bash
make ai-sdlc-extract-grooming-state ROOT=<ROOT> ISSUE=<ISSUE> WRITE=1
# then /requirement-grooming-status <ISSUE>
```

If DoR is not ready, continue with `/grooming-stakeholder-pack` and `/grooming-revision`. Sign-off and `make ai-sdlc-approve-gate ... GATE=G-GROOM ...` (human gate) come before `/classify-work <ISSUE>` (Phase 1 entry) when G-GROOM is required.

---

## 6. What is auto-populated

Through overlay files + `build_context_bundle.py` / groom-prep (typical fields):

- `{{PROJECT_CONTEXT}}`, `{{PROJECT_CONFIG}}`
- `{{WORKFLOW_STATE}}`, `{{APPROVAL_RECORDS}}`, `{{CURRENT_BLOCKERS}}`
- `{{TECH_STACK}}`, `{{APPROVAL_RULES}}`, `{{ENGINEERING_GUARDRAILS}}`
- `{{AVAILABLE_ARTIFACTS}}` (from workflow-state artifact paths)

See [`prompt-input-source-map.md`](prompt-input-source-map.md) for the full map.

---

## 7. What still requires human input

- Issue body, acceptance criteria, reproduction steps (tracker MCP or paste when provider is not `manual`)
- Repository excerpts and diffs (Filesystem/Git MCP or paste)
- Live CI status, PR context, deployment evidence, monitoring signals
- Audit output (`make ai-sdlc-audit` paste for CVE triage)
- **All approval gates** (G-PLAN, G-SEC, G-PR-MERGE, G-DEPLOY) — human-owned only
- Final merge, deploy, rollback, and incident decisions

If evidence is missing, prompts must say **missing evidence** — never infer or fabricate.

---

## 8. Where artifacts are saved

Store durable outputs under the overlay workflow-state path:

```text
.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/<artifact-name>.md
```

Examples: `requirement.md`, `classification.md`, `impact-analysis.md`, `technical-plan.md`.

If no issue ID exists yet, use `.cursor/ai-sdlc/workflow-state/unassigned/<artifact-name>.md` and create a real issue ID promptly.

Do **not** store product artifacts under `automation_sdlc/ai-sdlc/`.

---

## After every prompt

1. Save the output under `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/`.
2. Register or update the corresponding `artifacts.*` entry in workflow state.
3. Run `make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.
4. Run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>`.
5. Do not proceed if required artifacts, evidence, or gates are missing.

Embedded layout (framework repo inside a product workspace):

```bash
make ai-sdlc-validate-artifacts ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=.. ISSUE=<ISSUE-ID>
```

---

## 9. What not to do

- Do not edit framework files (`ai-sdlc/prompts/`, `tools/`, etc.) during product SDLC unless in explicit framework development mode (`FRAMEWORK_DEV=1`).
- Do not run Git write operations unless explicitly requested; never push without separate approval.
- Do not invent CI results, approvals, deploy status, or monitoring metrics.
- Do not skip the guard when framework drift is possible.
- Do not treat AI output as approved requirements, specs, or merge-ready code without human review.

---

## 10. Escalation and gap-report rule

| Condition | Action |
|-----------|--------|
| Framework guard fails or tooling gap blocks workflow | File a **framework gap report** per `governance/framework-protection-rule.md` |
| Missing live evidence | Ask human to paste; mark **missing evidence** in output |
| Production, security, or customer-impact uncertainty | Escalate to engineering lead / security champion / on-call |
| Prompt or placeholder confusion | Consult [`prompt-input-source-map.md`](prompt-input-source-map.md) and [`prompt-quick-reference.md`](prompt-quick-reference.md) |

---

## Related docs

- [`architecture/normalized-issue-model.md`](../architecture/normalized-issue-model.md) — provider-neutral issue metadata
- [`prompt-input-source-map.md`](prompt-input-source-map.md) — placeholder sources and auto vs manual
- [`requirement-grooming-sop.md`](requirement-grooming-sop.md) — full grooming procedure
- [`quick-start.md`](quick-start.md) — broader onboarding
- [`framework-guard-checkpoints.md`](framework-guard-checkpoints.md) — guard checkpoints
