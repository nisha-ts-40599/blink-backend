# Enterprise defect, regression, and hotfix scope guide

This guide documents the shared enterprise quality spine for findings, defects,
retest/regression, pre-existing issues, and hotfix scope isolation.

## Finding versus defect

- A **finding** is any unexpected result (developer test, AI review, QA, UAT).
- A **defect** is a tracked remediation item, usually with test linkage and lifecycle status.
- Classify findings first; route defects through the common lifecycle engine.

## Pre-existing issues

Default policy:

1. Confirm reproduction on the baseline commit.
2. Record `pre_existing_assessment` with disposition `DEFER` or `LINK_SEPARATE_WORKFLOW`.
3. Continue current delivery when safe.

A pre-existing issue blocks only when it prevents acceptance validation, affects
release safety, or is explicitly marked `BLOCK_CURRENT_DELIVERY`.

Use `/sdlc-link-preexisting-defect` when baseline evidence is missing.

## Hotfix scope

Hotfixes must declare:

- allowed components/files;
- explicitly out-of-scope areas;
- known pre-existing issues (linked, not bundled);
- rollback plan;
- production validation when required.

Unrelated pre-existing findings must not expand hotfix scope without approved
`scope_expansion`.

## Introduced defects

`INTRODUCED_BY_CHANGE` always blocks current delivery until:

developer fix → developer tests → AI review refresh → human attestation →
automated validation → QA retest → regression → QA sign-off reconsideration.

## Incomplete fixes

Failed retest reopens the **original** defect. Record `reopen_analysis` with
prior fix commit and failure reason. Repeated High/Critical failures escalate to
senior review.

## Retest versus regression

| Scope | When |
|-------|------|
| `RETEST` | Exact failed scenario against fix commit |
| `TARGETED_REGRESSION` | Adjacent behaviors in changed capability |
| `FULL_REGRESSION` | Tier 3, cross-cutting, auth, schema, repeated failures |

Record `regression_protection` for confirmed product defects unless justified.

## Operator commands

Primary:

- `/sdlc-status` — read-only progress and finding summary
- `/sdlc-next` / `/sdlc-resume` — follow `enterprise_next_action`

Specialized:

- `/sdlc-classify-finding`
- `/sdlc-triage-defects`
- `/sdlc-fix-defects`
- `/sdlc-qa-retest`
- `/sdlc-qa-regression`
- `/sdlc-reopen-defect`
- `/sdlc-link-preexisting-defect`

## Gate effects

- **G-QA-POST** — blocks on open introduced/incomplete defects, pending classification,
  stale retest/regression, or blocking pre-existing issues.
- **G-PR-MERGE** — blocks on unresolved critical/high introduced defects, scope
  expansion without approval, and missing regression protection.

AI recommendations never approve human gates.
