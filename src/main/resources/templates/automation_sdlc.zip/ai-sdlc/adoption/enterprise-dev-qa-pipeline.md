# Enterprise Development + QA Pipeline — Operator Guide

Canonical operator guide for the enterprise Development + QA lifecycle. This is
the single source of truth for the day-to-day command spine that carries an
issue from an approved plan through implementation, developer self-verification,
QA, PR review, merge, and closure.

> **Provenance.** This pipeline is the deduplicated synthesis of the separate
> developer workflow diagrams (Nisha / Gaurav / Riya) and the QA workflow
> diagrams (`QA_MHN`, `QA_Process`, `qa-testing-workflow`). Overlapping stages,
> gates, and evidence artifacts from those diagrams were reconciled into the one
> canonical phase model documented here. Where the source diagrams disagreed,
> the stricter control (never fabricate human QA, always bind evidence to a
> commit) wins.

---

## 1. Enforcement model

The prompts describe intent; **enforcement lives in the runtime validators**, not
in prompt prose. The relevant modules are:

- `enterprise_dev_pipeline.py` — DEV-side validators (package readiness, change
  record, developer tests, AI review, human attestation, validation evidence).
- `enterprise_qa_pipeline.py` — QA-side validators (requirement analysis, test
  suite, strategy, execution, environment/smoke, defects/retest/regression,
  sign-off).
- `enterprise_dev_qa_progress.py` — canonical progress projection and next-action
  derivation. It is **legacy-tolerant** (falls back to existing
  `implementation` / `qa_execution` / `gates` / `artifacts` blocks) and **never
  fabricates human QA as PASS**.
- `stage_router.py` — surfaces the projection (`workflow_progress`) and the
  operator hint (`enterprise_next_action`) on every routing result for
  implementation/QA/merge stages.
- `validate_enterprise_artifact.py` — validates a single artifact against its
  JSON Schema plus domain rules.

If a prompt and a validator disagree, the validator wins. Do not "talk past" a
failing gate by editing prompt text.

---

## 2. Lifecycle phases

The pipeline projects a fixed, ordered set of phases. Each phase has a canonical
status (see §5). The operator never advances a phase manually — status is a
projection of the recorded evidence.

| # | Phase | Meaning | Command |
|---|-------|---------|---------|
| 1 | `implementation_package` | Approved plan bundle bound to repo + G-PLAN | `/sdlc-implement-prep` |
| 2 | `step_plan` | Per-step implementation plan | `/sdlc-plan-implementation-step` |
| 3 | `implementation` | Code change recorded (change record) | `/sdlc-implement` |
| 4 | `developer_tests` | Real developer test evidence | `/sdlc-developer-test` |
| 5 | `ai_review` | AI implementation review (advisory) | `/sdlc-ai-developer-review` |
| 6 | `human_attestation` | Human developer attestation | `/sdlc-developer-attest` |
| 7 | `validation` | Validation evidence (real command results) | `/sdlc-validate` |
| 8 | `draft_pr` | Draft PR registered | `/sdlc-register-draft-pr` |
| 9 | `peer_review_findings` | Peer review findings resolved | `/sdlc-peer-review` → `/sdlc-fix-review-findings` |
| 10 | `qa_environment` | QA environment ready | `/sdlc-qa-environment-ready` |
| 11 | `smoke` | Smoke test evidence | `/sdlc-qa-smoke` |
| 12 | `qa_execution` | QA test execution (human tester) | `/sdlc-qa-execute` |
| 13 | `defect_triage` | Defects triaged | `/sdlc-triage-defects` |
| 14 | `retest` | Fixed defects retested, bound to fix commit | `/sdlc-qa-retest` |
| 15 | `regression` | Regression executed (if required) | `/sdlc-qa-regression` |
| 16 | `qa_signoff` | QA sign-off recommendation | `/sdlc-qa-signoff-review` |
| 17 | `g_qa_post` | G-QA-POST gate | `/sdlc-approve-qa` |
| 18 | `formal_pr` | Formal provider PR (not local-unpushed) | `/sdlc-register-pr` / `/sdlc-refresh-pr` |
| 19 | `pr_review` | Formal PR review | `/sdlc-pr-review` |
| 20 | `merge_gate` | G-PR-MERGE gate | `/sdlc-approve-merge` |
| 21 | `merge_verification` | Provider merge verified | `/sdlc-verify-merge` |
| 22 | `post_deploy_validation` | Post-deploy validation | `/sdlc-post-deploy-validate` |
| 23 | `closure` | Closure report + close | `/sdlc-close` |

Planning-side QA analysis (`/sdlc-qa-requirement-analysis`, `/sdlc-qa-strategy`,
`/sdlc-design-tests`, `/sdlc-regression-analysis`) feeds phases 10–17; run it
during technical planning so QA evidence has a strategy and test suite to bind
to.

---

## 3. Work-tier matrix

QA rigor scales with work tier and risk. The `qa_post_required` /
`qa_post_satisfied` helpers (in `qa_gates.py`) decide whether the QA phases and
G-QA-POST apply.

| Tier | Typical change | QA phases (10–17) | G-QA-POST |
|------|----------------|-------------------|-----------|
| 1 | Trivial / config / docs | Usually `NOT_REQUIRED` | Not required |
| 2 | Standard feature / bugfix | Required (may fold strategy into design) | Required |
| 3 | High-risk / broad blast radius | Required + **standalone QA strategy** + regression | Required |

Tier and risk profile are read from the workflow state; do not hardcode. When in
doubt, project progress (`make ai-sdlc-enterprise-progress`) and let the
validators tell you which phases are `NOT_REQUIRED`.

---

## 4. Agents and human responsibilities

AI agents accelerate; they do not sign. The following are **human-only** and the
validators reject AI actors in these roles:

- **Developer attestation** (phase 6) — must be a human developer, not the AI
  reviewer. AI review (phase 5) is advisory and is not an attestation.
- **QA execution PASS** (phase 12) — must record a human tester. A PASS without a
  tester, or an AI tester, is rejected. `NOT_EXECUTED` can never roll up to PASS.
- **Gate approvals** — G-QA-POST and G-PR-MERGE require valid human approval;
  QA cannot approve its own gate by editing execution status.

AI-appropriate work: drafting packages/plans, generating candidate tests,
running command-based validation, summarizing review findings, projecting
progress.

---

## 5. Status vocabulary

Canonical statuses emitted by the projection:

`NOT_STARTED`, `PENDING`, `IN_PROGRESS`, `COMPLETE`, `PASS`,
`PASS_WITH_OBSERVATIONS`, `FAIL`, `BLOCKED`, `NOT_REQUIRED`, `NOT_APPLICABLE`,
`STALE`, `CONFLICTING`, `STALE_OR_CURRENT`, `NOT_READY`, `LOCAL_UNPUSHED`.

Key semantics:

- **`STALE`** — evidence exists but is bound to a commit older than the current
  candidate. It must be re-earned against the current commit. Any new commit
  invalidates downstream developer tests, AI review, attestation, validation, QA
  execution, PR review, and G-QA-POST.
- **`CONFLICTING`** — two recorded QA signals disagree (e.g. `qa_execution=PASS`
  but `validation.qa_result=FAIL`, or the gate is approved but execution failed).
  The safe next action is to re-run QA; never advance past a conflict.
- **`LOCAL_UNPUSHED`** — the candidate exists only as a local, un-pushed commit.
  It is **not** a provider PR and cannot satisfy merge gating.
- **`NOT_REQUIRED` / `NOT_APPLICABLE`** — the phase does not apply to this tier /
  risk profile / state and is not a blocker.

---

## 6. Remediation loops

The pipeline is not linear; failures route backwards deterministically:

- Developer tests `FAIL` → `/sdlc-implement` (fix code), then re-test.
- Validation `FAIL` → `/sdlc-implement`.
- Peer review blocking findings → `/sdlc-fix-review-findings`.
- QA execution `FAIL` → `/sdlc-triage-defects` → fix → `/sdlc-qa-retest`
  (retest binds to the fix commit) → `/sdlc-qa-regression` (if required).
- PR review `FAIL` (changes requested) → `/sdlc-fix-review-findings`.
- New commit anywhere → downstream `STALE` → re-earn evidence.

`CONFLICTING` QA always routes to `/sdlc-qa-execute`; `LOCAL_UNPUSHED` at merge
time always routes to `/sdlc-register-pr`.

---

## 7. Operator commands

Project current progress and next action at any time:

```bash
make ai-sdlc-enterprise-progress ROOT=. ISSUE=PROJ-123
make ai-sdlc-stage-router ROOT=. ISSUE=PROJ-123
```

`/sdlc-status` prints the projection; `/sdlc-resume` adds the derived next
action. Every `/sdlc-*` command requires `ISSUE=`, delegates to the runtime, and
hands off to `make ai-sdlc-stage-router` so the operator always sees the next
authoritative step.

Validate a single artifact:

```bash
make ai-sdlc-validate-enterprise-artifact TYPE=qa_execution FILE=path/to/exec.yaml
make ai-sdlc-validate-enterprise-artifact TYPE=implementation_package FILE=pkg.yaml STATE=state.yaml
```

---

## 8. Worked examples

**Frontend feature (Tier 2).** `/sdlc-implement-prep` → plan step → implement →
`/sdlc-developer-test` (component + interaction tests) → AI review → attest →
`/sdlc-validate` → draft PR → QA env/smoke/execute (human tester exercises the
UI) → sign-off → G-QA-POST → register PR → review → merge → close.

**API change (Tier 2/3).** Same spine, but QA execution includes contract /
negative / boundary cases; a Tier 3 API change requires a standalone QA strategy
and regression before sign-off.

**Backend / data change (Tier 3).** Standalone strategy, explicit regression
scope and execution, and post-deploy validation are all required; merge is
blocked by any open P0/P1 finding and by a missing required-QA sign-off.

---

## 9. Prohibited shortcuts

- Marking QA `PASS` without a human tester, or with an AI tester.
- Using AI review as the human attestation.
- Approving G-QA-POST / G-PR-MERGE without valid human approval.
- Treating a `LOCAL_UNPUSHED` candidate as a provider PR for merge gating.
- Advancing past a `CONFLICTING` QA state.
- Reusing `STALE` evidence after a new commit.
- Editing prompt prose to bypass a failing validator.

---

## 10. See also

- `ai-sdlc/adoption/runbooks/developer-runbook.md`
- `ai-sdlc/adoption/runbooks/qa-runbook.md`
- `ai-sdlc/adoption/runbooks/defect-remediation-runbook.md`
- `ai-sdlc/adoption/runbooks/pr-and-merge-runbook.md`
- `ai-sdlc/adoption/command-spine-playbook.md`
