# Enterprise Rollout Guide

This guide helps teams adopt the AI-SDLC framework with the Phase B command spine. It is documentation-only guidance for enterprise rollout; it does not add lifecycle stages, deployment automation, issue tracker closure, or external API integration.

Use the companion [`command-spine-playbook.md`](command-spine-playbook.md) for command-by-command examples.

## Who Should Use This Framework

Use this framework when a team needs a repeatable, auditable SDLC workflow for AI-assisted delivery. It is best suited for teams that want:

- Consistent workflow-state evidence.
- Clear gate approval records.
- Explicit artifact references.
- Clear separation between PR registration, PR approval, merge closure, deployment readiness, and deployment evidence.
- Closure reports that summarize evidence and warnings.

Do not position the framework as a replacement for product ownership, engineering accountability, security review, code review, release ownership, or deployment governance.

## Required Roles

| Role | Responsibility |
| --- | --- |
| Requester/product owner | Owns the requirement, priority, acceptance expectations, and business approval context |
| Engineering lead | Owns implementation approach, technical plan quality, and engineering readiness |
| Security reviewer where required | Reviews security-sensitive work and records or confirms `G-SEC` evidence |
| PR reviewer/maintainer | Reviews PRs and confirms whether merge approval is valid |
| Deployment/release owner where applicable | Owns deployment readiness, release timing, rollback readiness, and production release decisions |

One person may hold more than one role for small teams, but approval evidence should still make the decision boundary clear.

## New Project Or Team Adoption Checklist

- Confirm the workspace root that commands will use with `ROOT=...`.
- Confirm the issue ID convention, such as `DEMO-ISSUE-1` for training.
- Agree where issue artifacts will be stored.
- Identify who may approve `G-PLAN`, `G-SEC`, `G-PR-MERGE`, and `G-DEPLOY`.
- Run the first pilot with dry-runs before any `WRITE=1`.
- Require `WRITE=1` only after dry-run output is reviewed.
- Register artifacts through commands instead of manual workflow-state edits.
- Register PR evidence before asking for merge approval.
- Record merge closure only after valid human approval.
- Generate a closure report for every completed pilot.
- Review closure report warnings before declaring the issue ready for closure or follow-up.

## Training And Demo Script

Use only generic examples: `DEMO-ISSUE-1`, `demo-app`, and `https://example.test/...`.

1. Introduce the command spine.
   - Explain that AI can draft, implement, and review.
   - Explain that commands record evidence.
   - Explain that humans approve gates and lifecycle decisions.
2. Initialize `DEMO-ISSUE-1`.
   - Run `ai-sdlc-init-issue` dry-run.
   - Re-run with `WRITE=1` after review.
3. Register artifacts.
   - Register requirement and plan references.
   - Show that artifact registration records references, not document quality.
4. Approve `G-PLAN`.
   - Show approver, decision, and evidence reference.
   - Explain that the command records a human approval that already happened.
5. Register demo PR.
   - Use `REPO_ID=demo-app`.
   - Use `https://example.test/demo-app/pull/1`.
   - Explain that PR registration is not merge approval.
6. Approve `G-PR-MERGE`.
   - Record human approval for the registered PR.
   - Demonstrate conditional approval wording if useful.
7. Close merge.
   - Record merge commit SHA, merged by, merged at, and merge evidence reference.
   - Explain that merge closure does not imply deployment readiness.
8. Generate closure report.
   - First print to stdout.
   - Optionally preview `OUTPUT=...` without `WRITE=1`.
   - Write the report only after review.
9. Inspect warnings and next actions.
   - Identify missing artifacts, missing gates, unmet conditions, and deploy-readiness warnings.
   - Explain that warnings are review inputs, not automatic closure decisions.

## Governance Model

- AI-assisted work is allowed when the team follows the SDLC workflow.
- Human approval remains mandatory for gates and lifecycle decisions.
- Framework evidence must be auditable and reviewable.
- Dry-run review is expected before `WRITE=1`.
- Manual workflow-state edits should be avoided except during controlled recovery.
- Closure reports support review; they do not close issue tracker tickets or authorize deployment.
- Merge evidence, deployment readiness evidence, and deployment evidence are separate.

## Rollout Phases

### Phase 1: Pilot With One Team

- Select a low-risk, generic pilot issue.
- Confirm roles and approvers.
- Run all state-changing commands as dry-runs first.
- Capture closure report output and warnings.

### Phase 2: Review Closure Reports

- Review whether the report clearly explains lifecycle status.
- Confirm gate evidence is complete and understandable.
- Confirm PR, merge, and deployment readiness are not conflated.
- Capture missing evidence patterns.

### Phase 3: Expand To More Teams

- Train each team with the generic demo script.
- Require the adoption checklist before first use.
- Keep demo materials generic and free of real client URLs.
- Use closure reports as the standard pilot review artifact.

### Phase 4: Collect Failure Modes

- Track unsupported transitions, missing variables, PR URL mismatches, duplicate PR records, unmet conditions, and merge-before-approval attempts.
- Separate documentation gaps from command behavior gaps.
- Avoid changing runtime behavior during documentation rollout unless a later phase explicitly approves it.

### Phase 5: Refine Docs And Commands

- Update docs when repeated confusion is found.
- Propose command improvements only as later-phase work.
- Keep B.7 documentation-only.

## Success Criteria

- Reduced manual workflow-state YAML editing.
- Consistent gate evidence across teams.
- Clear distinction between PR registration, PR approval, and merge closure.
- Clear distinction between merged, deploy-ready, and deployed.
- Closure reports are generated for completed pilots.
- Closure report warnings are reviewed before lifecycle closure.
- Fewer ambiguous lifecycle states during enterprise rollout.
- Teams can run the generic demo without product or client references.

## Rollout Readiness Questions

- Does the team know which workspace root to use?
- Does the team know where artifacts belong?
- Are gate approvers identified before work begins?
- Is dry-run review part of the working agreement?
- Does the team understand that `WRITE=1` mutates workflow-state?
- Does the team understand that command-recorded approval is not the approval itself?
- Does the team understand that merge closure is not deployment readiness?
- Does the team know how to generate and review a closure report?

## Known Boundaries

- No new commands are introduced by this rollout guide.
- No schema changes are introduced by this rollout guide.
- No deployment automation is introduced by this rollout guide.
- No GitHub, issue tracker, or network integration is introduced by this rollout guide.
- No pilot closure or issue tracker closure is introduced by this rollout guide.
