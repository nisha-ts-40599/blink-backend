# First Feature Walkthrough

**Goal:** Show you the complete AI-SDLC flow on a realistic feature, from GitHub issue to deployed and monitored.

**What you need to read first:** `adoption/quick-start.md` (10 minutes).
**Reference while working:** `adoption/prompt-quick-reference.md`.

You do not need to read the full lifecycle docs before following this walkthrough — use [`prompt-quick-reference.md`](prompt-quick-reference.md) and `make ai-sdlc-stage-router` as you go.

---

## Scenario

**Project:** Health Platform API — a Python/FastAPI service managing NHS patient data.
**Feature:** Add a patient registration endpoint (`POST /patients`).
**Issue:** `HLTH-421` on GitHub.
**Work tier:** To be determined during classification.

This matches the existing example files in `ai-sdlc/examples/`:
- `examples/workflow-state/patient-registration.workflow-state.yaml`
- `examples/project-context/patient-registration.project-context.md`
- `examples/project-config/patient-registration.project-config.yaml`
- `examples/context-bundles/patient-registration.context-bundle.json`

You can reference these files at every step to see what the outputs should look like.

---

## Starting point

Before beginning, you have:
- [ ] `project-context.md` committed in `ai-sdlc/`
- [ ] `project-config.yaml` committed in `ai-sdlc/`
- [ ] GitHub MCP configured (or willing to paste context manually)
- [ ] `make ai-sdlc-install` completed
- [ ] A GitHub issue (`HLTH-421`) with the requirement text

---

## Files you will create during this walkthrough

| File | Created at step | Purpose |
|------|----------------|---------|
| `ai-sdlc/workflow-state/HLTH-421.yaml` | Step 2 | Tracks stage, gates, artifacts across the whole workflow |
| `ai-sdlc/workflow-state/HLTH-421/requirement.md` | Step 5 | Output of clarify-requirement |
| `ai-sdlc/workflow-state/HLTH-421/spec.md` | Step 5 | Output of create-spec |
| `ai-sdlc/workflow-state/HLTH-421/technical-plan.md` | Step 8 | Output of technical-plan |

---

## Step 1 — Create or identify the GitHub issue

**Action:** Ensure the requirement is written up as a GitHub issue before starting any AI-SDLC step.

```
Issue HLTH-421: Add patient registration endpoint (POST /patients)

As a healthcare practitioner, I need to register new patients in the system
so that I can record their NHS number, date of birth, name, and emergency contact.

Acceptance criteria (rough):
- POST /patients accepts required fields
- Returns 201 with the created patient resource
- Returns 422 if required fields are missing
- Returns 409 if NHS number already exists
```

**Output:** GitHub issue URL (`https://github.com/org/health-platform-api/issues/421`).
**Human action:** Issue is created and assigned. No AI prompt yet.

---

## Step 2 — Create the workflow-state YAML

Create a tracking file for this issue. This file is the single source of truth for stage, gates, and artifacts throughout the workflow.

```bash
mkdir -p ai-sdlc/workflow-state/HLTH-421
```

Create `ai-sdlc/workflow-state/HLTH-421.yaml`:

```yaml
schema_version: "1.0"
issue_id: "HLTH-421"
issue_url: "https://github.com/org/health-platform-api/issues/421"
title: "Add patient registration endpoint (POST /patients)"
work_tier: null          # filled in at Step 6 (classify-work)
current_stage: "REQUIREMENT"

gates:
  g_plan:
    required: null       # filled in at Step 6
    approved: false
    approver: null
    approved_at: null
    comment_url: null
  g_sec:
    required: false
    approved: false
    approver: null
    approved_at: null
    comment_url: null
  g_pr_merge:
    required: true
    approved: false
    pr_url: null
  g_deploy:
    required: true
    approved: false
    approver: null
    approved_at: null
    comment_url: null

artifacts:
  requirement_doc: null
  spec_doc: null
  plan_doc: null
  g_plan_record: null
  implementation_prs: []
  test_coverage_report: null
  ai_review_output: null
  self_review_output: null
  release_checklist: null
  monitoring_report: null

agent_outputs: {}

blocked_reasons: []
rework_count: 0
updated_at: "2026-06-16T09:00:00Z"
```

See `examples/workflow-state/patient-registration.workflow-state.yaml` for a fully filled example.

**Output:** `ai-sdlc/workflow-state/HLTH-421.yaml` created.
**Human action:** File created manually. Commit on the feature branch.

---

## Orchestration helper commands (use at every stage change)

Before advancing to any new stage, run these three checks:

```bash
# 1. Check gates — are required approvals in place?
python ai-sdlc/tools/orchestration/check_gates.py \
  --workflow-state ai-sdlc/workflow-state/HLTH-421.yaml

# 2. Validate the transition — is moving to the next stage allowed?
python ai-sdlc/tools/orchestration/validate_transition.py \
  --workflow-state ai-sdlc/workflow-state/HLTH-421.yaml \
  --target-state <NEXT_STAGE>

# 3. Preview a state update before applying (dry-run by default)
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/HLTH-421.yaml \
  --set-current-stage <NEXT_STAGE>

# 4. Apply when confirmed (add --write)
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/HLTH-421.yaml \
  --set-current-stage <NEXT_STAGE> --write
```

Run `make ai-sdlc-orchestration-check` at any time to verify all tools work on the example.

---

## Step 3 — Generate the context bundle

The context aggregator reads your files and pre-assembles most prompt placeholders automatically.

```bash
python ai-sdlc/tools/orchestration/build_context_bundle.py \
  --workflow-state ai-sdlc/workflow-state/HLTH-421.yaml \
  --project-context ai-sdlc/project-context.md \
  --project-config ai-sdlc/project-config.yaml \
  --target-agent "Requirement Analyst Agent" \
  --target-prompt clarify-requirement \
  --output /tmp/HLTH-421-context.json
```

Expected output:

```
Context bundle written to: /tmp/HLTH-421-context.json
  Issue:         HLTH-421
  Stage:         REQUIREMENT
  Tier:          unconfirmed
  Freshness:     current
  Safe to proceed: YES

Next action: Run clarify-requirement.prompt.md, supplying REQUIREMENT text from the issue.
```

**What the script fills automatically:** project context, project config, approval roles, data sensitivity flags, tech stack summary, prior agent summaries (none yet).
**What you still need to provide:** `{{REQUIREMENT}}` text from the issue body.
**Human action:** Review the output — especially the `safe_to_proceed` field and any warnings.

---

## Step 4 — Run the stage router

Use `stage-router.prompt.md` to confirm the recommended next action before running any prompt.

**In Cursor:** Open a new chat. Paste:
1. Your workflow-state YAML content as `{{WORKFLOW_STATE}}`
2. Your `project-context.md` as `{{PROJECT_CONTEXT}}`
3. Your `project-config.yaml` as `{{PROJECT_CONFIG}}`
4. Run `prompts/stage-router.prompt.md`

Expected stage router output for Stage = `REQUIREMENT`:

```
Current state: REQUIREMENT  |  Tier: unconfirmed
Safe to proceed: YES
Next agent: Requirement Analyst Agent
Next prompt: clarify-requirement.prompt.md
Required placeholders: {{REQUIREMENT}}, {{PROJECT_CONTEXT}}
Exact human action: Run clarify-requirement.prompt.md with the issue body as {{REQUIREMENT}}.
```

**Human action:** Read the recommendation. If `safe_to_proceed = no`, resolve the listed blocker first. Otherwise, proceed to Step 5.

---

## Step 5 — Clarify the requirement

**Prompt:** `prompts/clarify-requirement.prompt.md`

**Input to paste:**
- `{{REQUIREMENT}}` — the issue body from Step 1
- `{{PROJECT_CONTEXT}}` — your `project-context.md`

**In Cursor:** Open a new chat (or fresh context window). Run the prompt.

**Expected AI output:**
- Structured requirement with clear scope boundaries
- Open questions the AI couldn't resolve from context alone (e.g., "What should happen if the patient's NHS number is already in the system?")
- Draft acceptance criteria

**Human action:**
1. Take the open questions to the product owner or team.
2. Resolve every question before moving on.
3. Save the clarified requirement to `ai-sdlc/workflow-state/HLTH-421/requirement.md`.
4. Update workflow-state: `artifacts.requirement_doc: "ai-sdlc/workflow-state/HLTH-421/requirement.md"`

For HLTH-421, the resolved answers were:
- Duplicate NHS number → return `409 Conflict` with a `Location` header pointing to the existing patient
- Missing required field → return `422 Unprocessable Entity` with per-field error list

---

## Step 6 — Classify the work

**Prompt:** `prompts/classify-work.prompt.md`

**Input:**
- `{{REQUIREMENT}}` — clarified requirement from Step 5
- `{{PROJECT_CONTEXT}}` — your `project-context.md`

**Expected AI output:**

```
Recommendation: Tier 2

Justification:
- New endpoint with PHI data write path (NHS number, date of birth)
- New DB table (patients) — schema migration required
- No changes to authentication mechanism
- No external integrations
- G-PLAN required. G-SEC not required (no auth/security model changes).
```

**Human action:**
1. Review the recommendation. If you disagree, override it and document the reason on the issue.
2. Update workflow-state: `work_tier: 2`
3. Update workflow-state: `current_stage: "CLASSIFIED"`
4. Update workflow-state: `gates.g_plan.required: true`
5. Add the tier label to the GitHub issue (`tier-2`).

---

## Step 7 — Run impact analysis

**Prompt:** `prompts/impact-analysis.prompt.md`

**Input:**
- `{{REQUIREMENT}}` — clarified requirement
- `{{PROJECT_CONTEXT}}` — your `project-context.md`
- `{{TECH_STACK}}` — from `project-config.yaml` (or auto-filled by context bundle)

**Expected AI output:**

```
Affected components:
- app/models/patient.py (new SQLAlchemy model)
- app/repositories/patient_repository.py (new repository)
- app/services/patient_service.py (new service)
- app/routers/patients.py (new router)
- app/schemas/patient.py (new Pydantic schemas)
- alembic/versions/... (new migration for patients table)

DB impact: New table — patients. Forward-only (additive). Zero-downtime safe.
API surface: New endpoint POST /patients. No existing contracts affected.
Test scope: New unit tests (service + repo), new integration tests (endpoint).
Rollback: Drop table migration.
```

**Human action:** Verify the component list against your actual codebase. Add any components the AI missed.

---

## Step 8 — Create the technical plan

**Prompt:** `prompts/technical-plan.prompt.md`

**Input:**
- `{{REQUIREMENT}}` — clarified requirement with resolved questions
- `{{PROJECT_CONTEXT}}` — your `project-context.md`
- `{{SECURITY_MODEL}}` — security model section from `project-context.md`
- `{{APPROVAL_RULES}}` — approval roles from `project-config.yaml`

**Expected AI output:**

```
Technical Plan — HLTH-421: Add patient registration endpoint

Step 1: Add Patient model (SQLAlchemy) + Alembic migration
  - New table: patients (id, nhs_number_encrypted, full_name, date_of_birth_encrypted, ...)
  - PHI fields: nhs_number, date_of_birth → encrypt with AES-256 per RULE-EXT-HS-001
  - Migration: forward-only (additive), includes rollback down_revision

Step 2: Add PatientRepository
  - get_by_nhs_number (for duplicate check)
  - create (insert + return patient)

Step 3: Add PatientService
  - Validate NHS number (10 digits, Luhn check)
  - Check duplicate via repository (raise ConflictError if found)
  - Create patient via repository

Step 4: Add Pydantic schemas (PatientCreate, PatientResponse)
  - NHS number validated at schema level

Step 5: Add POST /patients endpoint in router
  - Auth required (existing JWT)
  - Calls service; maps exceptions to HTTP responses

Step 6: Tests
  - Unit: service (duplicate, validation, happy path)
  - Integration: endpoint (201, 409, 422)
```

Save to `ai-sdlc/workflow-state/HLTH-421/technical-plan.md`.
Update workflow-state: `artifacts.plan_doc: "ai-sdlc/workflow-state/HLTH-421/technical-plan.md"`, `current_stage: "PLAN_DRAFTED"`.

---

## Step 9 — Record G-PLAN approval

**Human action (not an AI step).**

The engineering lead (alice@example.com for HLTH-421) reviews the plan and posts an explicit approval comment on the GitHub issue:

```
G-PLAN approved. Plan looks good — confirm PHI encryption is applied in Step 1 and 3.
Steps are ordered correctly; migration before service before endpoint.
— Alice, 2026-06-14
```

After approval is recorded:
1. Update workflow-state: `gates.g_plan.approved: true`
2. Update workflow-state: `gates.g_plan.approver: "alice@example.com"`
3. Update workflow-state: `gates.g_plan.approved_at: "2026-06-14T14:32:00Z"`
4. Update workflow-state: `gates.g_plan.comment_url: "https://github.com/...#issuecomment-99001"`
5. Update workflow-state: `artifacts.g_plan_record: "https://github.com/...#issuecomment-99001"`
6. Update workflow-state: `current_stage: "PLAN_APPROVED"`

**Now run the context bundle again** to confirm `safe_to_proceed = yes` before implementing:

```bash
python ai-sdlc/tools/orchestration/build_context_bundle.py \
  --workflow-state ai-sdlc/workflow-state/HLTH-421.yaml \
  --project-context ai-sdlc/project-context.md \
  --project-config ai-sdlc/project-config.yaml \
  --target-agent "Backend Implementation Agent" \
  --target-prompt implement-step \
  --output /tmp/HLTH-421-impl-context.json
```

Expected: `Safe to proceed: YES`.

---

## Step 10 — Implement one approved step

**Prompt:** `prompts/implement-step.prompt.md`

Run one step at a time. Use a fresh Cursor chat per step.

**Input for Step 1 (Patient model + migration):**
- `{{CURRENT_STEP}}` — Step 1 text from the plan
- `{{REPOSITORY_CONTEXT}}` — the `app/models/` directory (paste or use GitHub MCP)
- `{{PROJECT_CONTEXT}}` — your `project-context.md`
- `{{ENGINEERING_GUARDRAILS}}` — content of `governance/enterprise-engineering-guardrails.md`

**Expected AI output:**
- `app/models/patient.py` — SQLAlchemy model with PHI encryption
- `alembic/versions/{rev}_add_patients_table.py` — migration with `upgrade()` and `downgrade()`

**Human action:**
1. Review every line of generated code — you are accountable for it.
2. Verify PHI encryption is applied to `nhs_number` and `date_of_birth` fields.
3. Apply the code to your branch.
4. Run `make test:unit` locally.
5. Repeat Steps 10 for each plan step (Steps 2–5).
6. Update workflow-state: `current_stage: "IMPLEMENTING"` after first step is applied.

---

## Step 11 — Generate tests

**Prompt:** `prompts/generate-tests.prompt.md`

Run after implementation of each plan step (or at the end of all implementation steps).

**Input:**
- `{{PROJECT_CONTEXT}}` — your `project-context.md`
- `{{TECH_STACK}}` — test framework (pytest + httpx for this project)
- `{{REPOSITORY_CONTEXT}}` — the implemented service/endpoint code

**Expected AI output:**
- `tests/unit/test_patient_service.py` — duplicate check, NHS validation, happy path
- `tests/integration/test_patients_endpoint.py` — 201, 409, 422 scenarios

**Human action:**
1. Review tests — verify they actually test the right behaviour.
2. Run: `pytest tests/ --cov=app --cov-report=term-missing`
3. Confirm coverage meets the 85% threshold (100% for security-critical paths).
4. Commit tests with the implementation.

---

## Step 12 — Update docs and OpenAPI spec

**Prompt:** `prompts/update-docs.prompt.md`

Only needed when the API surface changes. For HLTH-421, we're adding a new endpoint.

**Input:**
- `{{PROJECT_CONTEXT}}` — your `project-context.md`
- `{{TECH_STACK}}` — FastAPI auto-generates OpenAPI but the spec in `docs/openapi.yaml` needs updating
- `{{REPOSITORY_CONTEXT}}` — the new Pydantic schemas and router

**Expected AI output:**
- Updated `paths` section in `docs/openapi.yaml` for `POST /patients`
- Updated `components/schemas` for `PatientCreate` and `PatientResponse`

**Human action:** Verify the spec matches the actual implementation. No new endpoints should appear in docs without a human check.

---

## Step 13 — Run self-review

**Prompt:** `prompts/self-review.prompt.md`

Run before opening a PR. This is your last check before asking for human review.

**Input:**
- `{{PR_CONTEXT}}` — your branch diff (or GitHub MCP auto-fill)
- `{{PROJECT_CONTEXT}}` — your `project-context.md`
- `{{ENGINEERING_GUARDRAILS}}` — `governance/enterprise-engineering-guardrails.md`

**Expected AI output:**

```
Must-fix:
  [SECURITY] PHI fields must be masked in log outputs — structlog call in patient_service.py
  line 47 logs the full patient object; nhs_number will be exposed.

Should-fix:
  [TEST] test_patients_endpoint.py line 88: asserts status code only; assert response body schema.

Advisory:
  [DOCS] OpenAPI PatientResponse schema missing 'example' field.
```

**Human action:**
1. Fix all **must-fix** items before opening the PR.
2. Address or document **should-fix** items.
3. Use advisory items to improve quality; no obligation.
4. Update workflow-state: `artifacts.self_review_output: "ai-sdlc/workflow-state/HLTH-421/self-review.md"`

---

## Step 14 — Open PR and run AI PR review

**Open the PR** on GitHub. The `.github/pull_request_template.md` auto-loads with the full checklist.

Fill in the PR template, including the Engineering Guardrails checklist.

**Prompt:** `prompts/pr-review.prompt.md`

**Input:**
- `{{PR_CONTEXT}}` — the full PR diff (GitHub MCP or manual paste)
- `{{PROJECT_CONTEXT}}` — your `project-context.md`
- `{{ENGINEERING_GUARDRAILS}}` — `governance/enterprise-engineering-guardrails.md`

**Expected AI output:** Structured findings with `[MUST-FIX]`, `[SHOULD-FIX]`, `[ADVISORY]` severity labels.

**CI runs automatically** (once GitHub Actions is enabled):
- `AI-SDLC Conformance` job
- `Secret Scan (Gitleaks)` job
- `Dependency Audit (pip-audit)` job

**Human action:**
1. Fix any remaining AI must-fix items.
2. Describe how each finding was addressed in the PR description.
3. Update workflow-state: `artifacts.ai_review_output: "ai-sdlc/workflow-state/HLTH-421/pr-review.md"`, `current_stage: "PR_OPEN"`
4. Request human review from a team member.

---

## Step 15 — Human review and merge

**G-PR-MERGE gate.** This is always human. Branch protection enforces it.

The human reviewer:
1. Reads the PR description
2. Reads the AI review findings and how they were addressed
3. Reviews the diff with their own judgement
4. Approves or requests changes

**After approval:**
- All 3 CI status checks must be green
- Branch protection prevents merge unless both conditions are met
- **The engineer or reviewer clicks Merge** — not an AI, not an automation

Update workflow-state:
- `gates.g_pr_merge.approved: true`
- `artifacts.implementation_prs: ["https://github.com/org/health-platform-api/pull/88"]`
- `current_stage: "MERGED"`

---

## Step 16 — Release readiness and deployment preparation

**Prompt:** `prompts/release-verification.prompt.md`

**Input:**
- `{{RELEASE_CONTEXT}}` — what is in this release, environment, deployment steps
- `{{VALIDATION_RESULTS}}` — CI results, test coverage, security scan output
- `{{PROJECT_CONTEXT}}` — your `project-context.md`

**Expected AI output:**

```
Release Readiness Checklist — HLTH-421

✅ All CI jobs passing
✅ Unit test coverage: 91% (threshold: 85%)
✅ No new Gitleaks findings
✅ No new pip-audit critical CVEs
✅ G-PLAN approved by alice@example.com (2026-06-14)
✅ PR #88 approved by 2 reviewers
✅ Alembic migration reviewed — zero-downtime safe
✅ Rollback plan: alembic downgrade -1 + re-deploy previous image

⚠️ PHI field encryption verification recommended before deploying to production.

AI cannot approve deployment. G-DEPLOY approval required from engineering lead or SRE.
Human action: Engineering lead or SRE reviews this checklist and records explicit approval.
```

**G-DEPLOY gate:**
1. Engineering lead or SRE reviews checklist item by item.
2. Records approval: "G-DEPLOY approved — checklist confirmed. Ready for Tuesday window. — Alice"
3. Update workflow-state: `gates.g_deploy.approved: true`, `current_stage: "DEPLOYING"`

**Deployment execution:**
- SRE or authorized engineer runs the deployment command / approves the pipeline
- This is always human-executed

---

## Step 17 — Post-deploy monitoring interpretation

**Prompt:** `prompts/monitoring-interpretation.prompt.md`

Run 30–60 minutes after deployment with live metric data.

**Input:**
- `{{MONITORING_SIGNALS}}` — error rate, latency p95/p99, alert states from Datadog/Grafana
- `{{BASELINE}}` — normal values before this deployment
- `{{DEPLOYMENT_SUMMARY}}` — what was deployed, when, PR reference
- `{{PROJECT_CONTEXT}}` — your `project-context.md`

**Expected AI output:**

```
Analysis:
- POST /patients: 201 rate: 94%, 409 rate: 5.8% (expected — existing NHS numbers), 422 rate: 0.2%
- p95 latency: 180ms (baseline: 120ms) — mild increase; likely encryption overhead in first minutes
- No error rate increase on other endpoints
- No DB replication lag increase

Recommendation: Monitor p95 over next 30 minutes. Mild increase is expected for new PHI writes.
No anomalies requiring rollback. Recommend mark release as stable at T+60 minutes if p95 normalises.
```

**Human action:** SRE confirms stability and marks release stable. Update workflow-state:
- `artifacts.monitoring_report: "ai-sdlc/workflow-state/HLTH-421/monitoring.md"`
- `current_stage: "VERIFIED"`

---

## Workflow-state update summary

Use `update_workflow_state.py` for all updates — it validates the change, shows a diff, and writes atomically. Use `check_gates.py` and `validate_transition.py` before every stage advance.

| After step | `current_stage` | Fields to update |
|-----------|----------------|-----------------|
| Step 2 (file created) | `REQUIREMENT` | `issue_id`, `issue_url`, `title` |
| Step 5 (clarify) | `REQUIREMENT` | `artifacts.requirement_doc` |
| Step 6 (classify) | `CLASSIFIED` | `work_tier`, `gates.g_plan.required` |
| Step 8 (plan drafted) | `PLAN_DRAFTED` | `artifacts.plan_doc` |
| Step 9 (G-PLAN) | `PLAN_APPROVED` | `gates.g_plan.*`, `artifacts.g_plan_record` |
| Step 10 (first code) | `IMPLEMENTING` | — |
| Step 13 (self-review) | `REVIEW_REQUESTED` | `artifacts.self_review_output` |
| Step 14 (PR opened) | `PR_OPEN` | `artifacts.ai_review_output` |
| Step 15 (merged) | `MERGED` | `gates.g_pr_merge.approved`, `artifacts.implementation_prs` |
| Step 16 (G-DEPLOY) | `DEPLOYING` | `gates.g_deploy.*` |
| Step 17 (stable) | `VERIFIED` | `artifacts.monitoring_report` |

---

## What remains human-approved throughout

| Decision | Who approves | Why it cannot be AI |
|----------|-------------|---------------------|
| Requirement open questions | Product owner | Product intent is a business decision |
| Work tier override | Engineer / lead | Risk classification affects governance scope |
| G-PLAN (plan approval) | Engineering lead | Architectural and implementation accountability |
| G-SEC (Tier 3+) | Security champion | Security risk acceptance is a professional accountability |
| Code review | Human reviewer | AI review assists; human is accountable for merge quality |
| Merge to main | Human (branch protection) | Irrevocable action; human must own outcome |
| G-DEPLOY (deployment) | Engineering lead or SRE | Production changes require explicit human accountability |
| Deployment execution | SRE or authorized engineer | Production access must be human-exercised |
| Incident declaration | On-call engineer | Severity classification is a risk judgement |
| Rollback decision | SRE / incident commander | Reverting production requires human assessment |

---

## Common mistakes to avoid

| Mistake | What happens | How to avoid |
|---------|-------------|-------------|
| Starting implement-step without G-PLAN | AI generates code based on an unapproved plan; rework required | Always check `stage-router` or `context bundle safe_to_proceed = yes` before implementing |
| Mixing planning and implementation in the same Cursor chat | Context bleeds between stages; AI loses focus | One chat per stage, one chat per plan step |
| Skipping `self-review` before opening PR | Avoidable must-fix items reach human reviewers | Always run `self-review` first |
| Not updating `workflow-state.yaml` after each stage | Context bundle produces stale/incorrect routing | Update after every gate approval and stage change |
| Over-accepting AI-generated code without understanding it | PR review fails; code debt introduced | Developer must be able to explain every change |
| Classifying risky work as Tier 1 to skip G-PLAN | Ungoverned implementation; audit trail gap | See `ai-sdlc/work-tiers.md` boundary guidance |
| Using workspace-context.md in an implementation chat | AI gets confused about which repo's conventions to follow | Load only the single-repo `project-context.md` in implementation chats |
| Committing `project-context.md` with stale `last_reviewed` | Context aggregator warns; `safe_to_proceed = conditional` | Update `last_reviewed` whenever you update project context |
