# First-Week Rollout Plan

## Day 1 - Configure

- Copy template config to project-local `project-config.yaml`.
- Fill tooling mappings: source control, issue tracker, docs, CI/CD, scanners.
- Map approval roles and tier-based gate expectations.
- Review "when not to automate" guardrails with engineering and security leads.

## Day 2 - Run Conformance

- Set up Python environment and run baseline conformance:
  - `make ai-sdlc-install`
  - `make ai-sdlc-conformance`
- Review skipped vs failed tests.
- For protected branch posture, plan strict run:
  - `make ai-sdlc-conformance-protected`

## Day 3 - Run First Prompts on a Real Issue

> **Note on the runtime:** `ai-sdlc/runtime/` is a reference demo only. All step
> executors are noop; all adapters write to local mock files. Running the runtime
> does not produce governance evidence and is not part of normal adoption.
> Skip it during first-week onboarding.

- Pick one real issue from your backlog (Tier 1 or Tier 2 preferred).
- Open a new Cursor chat. Paste your `ai-sdlc/project-context.md` as context.
- Run `ai-sdlc/prompts/clarify-requirement.prompt.md` with the issue as `{{REQUIREMENT}}`.
- Review the output: restated requirement, clarifying questions, draft acceptance criteria.
- Answer the clarifying questions. Confirm or revise the acceptance criteria.
- Run `ai-sdlc/prompts/classify-work.prompt.md`. Confirm the tier.
- Record the tier label on the issue.
- Share the structured output with the team and run a short discussion on quality.

## Day 4 - Integrate CI

- Add the appropriate conformance job template from `ai-sdlc/ci/`.
- Persist conformance report artifacts in CI.
- Enable protected-branch strict profile enforcement.
- Add CI status check requirement on PR merge policy.

## Day 5 - First Complete Feature Cycle

- Pick a Tier 2 requirement from the backlog (self-contained; no production deploy required).
- Execute the full planning and implementation loop using prompts in order:
  1. `clarify-requirement.prompt.md` → confirm requirement and acceptance criteria
  2. `classify-work.prompt.md` → confirm Tier 2; record on issue
  3. `technical-plan.prompt.md` → ordered plan; get G-PLAN approval from engineering lead
  4. Implement; open a PR using `ai-sdlc/templates/pr-template.md`
  5. `pr-review.prompt.md` → structured AI review; resolve must-fix items
  6. Human reviews and merges — no exceptions
- Keep merge and deploy approvals manual.
- Run a short retrospective on friction, missing context, and prompt quality.

## End-of-week success criteria

- Team can run conformance and explain any failures.
- Team ran at least one real requirement through `clarify-requirement` + `classify-work`.
- Tier label is on every PR opened this week.
- Approval roles and gate ownership are unambiguous.
- CI conformance job runs on every PR to main.
- No team member ran the runtime orchestrator expecting real governance output.

