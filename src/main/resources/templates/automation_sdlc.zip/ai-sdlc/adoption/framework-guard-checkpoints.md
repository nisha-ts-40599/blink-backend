# Framework Guard Checkpoints — Product SDLC

Run the framework drift guard **before** product workflow steps that read or depend on
framework behavior. This keeps product delivery from patching `automation_sdlc` in place.

**Governance:** `ai-sdlc/governance/framework-protection-rule.md`

---

## Recommended commands

### Embedded framework (typical multi-repo product workspace)

Run from the **framework repository directory** (any embedded name, e.g. `automation_sdlc/`):

```bash
cd <framework-repo>
make ai-sdlc-guard-framework-clean ROOT=..
```

`<workspace-root>` is the parent directory that contains `.cursor/ai-sdlc/` and product repos.

### Standalone framework repository

When the framework repo **is** the workspace root:

```bash
make ai-sdlc-guard-framework-clean
```

Equivalent explicit form:

```bash
make ai-sdlc-guard-framework-clean ROOT=. FRAMEWORK_ROOT=.
```

---

## When to run (product SDLC)

| Stage | Run guard before |
|-------|------------------|
| Workspace setup completion | First product issue or pilot kickoff |
| Groom-prep / clarify-requirement | `make ai-sdlc-groom-prep` or clarify-requirement prompt |
| classify-work | Tier classification prompt |
| impact-analysis | Impact analysis prompt |
| technical-plan | Technical plan prompt |
| implement-step | Each implementation step / coding session |
| self-review / PR review | Self-review and PR review prompts |
| release verification | Release verification prompt |

`make ai-sdlc-groom-prep` runs the guard automatically in **product mode** (skipped when `FRAMEWORK_DEV=1`).

---

## If the guard fails (product mode)

1. **Stop** the product workflow step — do not continue classify/plan/implement/review.
2. **Do not patch** framework files during product delivery.
3. **Produce a framework gap report** (format in `framework-protection-rule.md`).
4. Continue only after:
   - framework maintainers ship a generic fix and the project updates framework version, **or**
   - a documented **safe project-level workaround** is approved by the engineering lead.
5. Do **not** set `FRAMEWORK_DEV=1` to bypass the guard during normal product delivery.

---

## Framework development mode (maintainers only)

Use only for intentional framework work (prompts, tools, schemas, policies):

```bash
FRAMEWORK_DEV=1 make ai-sdlc-guard-framework-clean
```

Local commits require **explicit user request**. Push requires **separate explicit approval**.

---

## Related commands

```bash
make ai-sdlc-validate-overlay ROOT=<workspace-root> STRICT=1 ISSUE=<ISSUE-ID>
make ai-sdlc-context-report ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
