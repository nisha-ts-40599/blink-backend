# Greenfield Project Specification (Phase 2)

Canonical desired-state input contract for new AI-SDLC projects and workspaces.

> **Phase boundary:** Phase 2 defines and validates design intent only. It does **not** create repositories, run scaffolds, install packages, write Git remotes, or deploy cloud resources.

Related:

- Phase 1 readiness foundation: [`project-delivery-readiness.md`](project-delivery-readiness.md)
- Lifecycle and readiness architecture: [`../../docs/operating-model/lifecycle-and-readiness-map.md`](../../docs/operating-model/lifecycle-and-readiness-map.md)

---

## One canonical specification

All greenfield workspace shapes use a single schema:

| Artifact | Path |
|----------|------|
| Schema | `ai-sdlc/schemas/setup/greenfield-project-spec.schema.json` |
| Template | `ai-sdlc/templates/setup/greenfield-project-spec.template.yaml` |
| Validator | `ai-sdlc/tools/setup/validate_greenfield_spec.py` |
| Normalization prompt | `ai-sdlc/prompts/normalize-greenfield-project-spec.prompt.md` |
| Review template | `ai-sdlc/templates/setup/greenfield-definition-template.md` |
| Bootstrap plan input boundary | `ai-sdlc/schemas/setup/bootstrap-plan-input.schema.json` |

Supported workspace structures:

- `single-repo` — exactly one required product repository
- `monorepo` — one Git root with declared `monorepo_modules`
- `multi-repo` — multiple independently versioned repositories

There are **no separate incompatible project and workspace input schemas**.

---

## Desired state versus detected state

| Concern | Owner in Phase 2 |
|---------|------------------|
| Design intent (repos, stacks, scaffold strategy, deployment plan) | `greenfield-project-spec.yaml` |
| Filesystem/Git/scaffold reality | setup-state, existing-* refresh, later bootstrap execution |
| `context_ready` / `delivery_ready` | setup-state only — never inferred from spec validity |

The specification must not claim that repositories, Git state, scaffolds, dependencies, or deployment resources already exist unless the user explicitly confirmed existing state with evidence in `provenance`.

---

## Input paths

Teams may start from:

1. Complete YAML specification
2. Partial YAML specification
3. Natural-language intent
4. Natural language plus architecture or repository notes
5. **Interactive initialisation input** — `.cursor/ai-sdlc/setup/project-initialisation-input.yaml` (see [`interactive-greenfield-setup.md`](interactive-greenfield-setup.md))

All paths must normalize to the same schema-valid artifact before bootstrap planning:

```bash
make ai-sdlc-validate-greenfield-spec SPEC=.cursor/ai-sdlc/greenfield-project-spec.yaml
make ai-sdlc-validate-greenfield-spec SPEC=path/to/spec.yaml FORMAT=json
make ai-sdlc-validate-greenfield-spec SPEC=path/to/spec.yaml STRICT=1
```

Free-text normalization uses `normalize-greenfield-project-spec.prompt.md`. The prompt:

- infers only low-risk structural values
- marks inferred fields in `provenance`
- preserves user-confirmed values
- does not invent owners, remotes, visibility, or security classification
- does not execute commands or collect secrets

---

## Schema domains

| Domain | Purpose |
|--------|---------|
| `metadata` | Project identity and human-owned roles |
| `workspace` | Shape, root path, framework repo exclusion |
| `project_scope` | Capabilities, non-goals, constraints |
| `architecture` | Baseline style with proposed/confirmed/deferred states |
| `repositories` | Topology, technology, scaffold, git intent, commands, dependencies |
| `deployment` | Destination and strategy planning — execution deferred |
| `ci_cd` | Pipeline intent — no workflow generation in Phase 2 |
| `security` | Classification and restrictions — no secret values |
| `issue_tracking` | Provider-neutral tracking intent |
| `approvals` | Required human approvals by role |
| `bootstrap` | Managed/manual routing metadata |
| `readiness_requirements` | Policy applied later by setup-state |
| `handoff` | Permanent maintenance command after bootstrap |
| `provenance` | Value source tracking |
| `unresolved_blocking` | Field paths blocking approval |

---

## Workspace shape rules

### Single-repo

- `workspace.structure: single-repo`
- Exactly one required product repository
- `handoff.on_success: /setup-existing-project refresh`
- Route via `/setup-new-project`

### Monorepo

- One required product repository at Git root (typically `.`)
- Package paths declared in `monorepo_modules`
- `handoff.on_success: /setup-existing-workspace refresh`
- Route via `/setup-new-workspace`

### Multi-repo

- One repository entry per independently versioned repo
- Cross-repo dependencies via `repositories[].dependencies`
- `handoff.on_success: /setup-existing-workspace refresh`
- Route via `/setup-new-workspace`

---

## Semantic validation highlights

JSON Schema is necessary but not sufficient. The semantic validator also checks:

- unique repository IDs and safe workspace-relative paths
- valid dependency references and creation-order cycles
- framework repo exclusion unless explicitly `product_tooling`
- public repository visibility requires `public_approval.status: approved`
- `initial_deployment_action: execute` is rejected in Phase 2
- command/template scaffold required fields
- required repositories cannot be `deferred` without explicit acceptance
- handoff command matches workspace structure
- secret-like keys must not contain values
- human-owned unresolved fields (advisory or blocking with `--strict`)

---

## Setup-state integration

When a valid specification is accepted, setup-state may record a **reference only**:

```yaml
greenfield_spec_ref:
  path: .cursor/ai-sdlc/greenfield-project-spec.yaml
  spec_version: "1.0"
  content_hash: "<sha256-prefix>"
  lifecycle_state: plan_ready   # or approval_required
  unresolved_blocking: []
  maintenance_command: /setup-existing-project refresh
```

Do **not** copy the full specification into setup-state.  
Do **not** mark `context_ready` or `delivery_ready` true solely because the spec validates.

---

## Setup prompt integration

Both `/setup-new-project` and `/setup-new-workspace` share the same Phase 2 entry flow:

1. detect or accept greenfield specification
2. normalize free text if needed
3. validate
4. show blocking confirmations
5. render greenfield definition review
6. stop before bootstrap planning

Routing differs only by workspace shape — wrong command redirects clearly.

Brownfield overlays and existing-* refresh flows do **not** require a greenfield specification.

---

## Examples and fixtures

Validated examples live under `ai-sdlc/tests/fixtures/greenfield-spec/`:

| Fixture | Scenario |
|---------|----------|
| `valid-single-repo-poc.yaml` | React/Vite static POC |
| `valid-multi-repo-saas.yaml` | Frontend + backend SaaS |
| `valid-monorepo.yaml` | Web app, API package, shared library |
| `valid-intentionally-empty.yaml` | Intentionally empty repository |
| `valid-deferred-infra.yaml` | Deferred optional infrastructure repo |
| `valid-manual-bootstrap.yaml` | Manual bootstrap mode |
| `invalid-public-repo-no-approval.yaml` | Public repo without approval |
| `invalid-circular-dependency.yaml` | Circular creation dependency |
| `invalid-deployment-execute.yaml` | Unsupported deployment execution |
| `invalid-framework-as-product.yaml` | Framework repo as product |

---

## Bootstrap plan input boundary (Phase 3+)

Phase 3 bootstrap planning consumes a minimal derived contract (`bootstrap-plan-input.schema.json`) containing:

- repo creation intent, local path, git intent
- scaffold strategy and commands
- baseline validation and approvals
- bootstrap fallback route
- deployment action boundary (`execution_allowed: false` in Phase 2)

The full greenfield schema is not duplicated in the bootstrap planner input.

---

## Gap IDs addressed

| Gap | Status in Phase 2 |
|-----|-------------------|
| GAP-004 — no canonical greenfield input contract | Addressed |
| Desired vs detected state ambiguity | Addressed via provenance + setup-state separation |
| Inconsistent single/multi-repo input models | Addressed — one schema |
| Incomplete architecture/deployment grooming | Addressed at planning/intent level |
| Normalized bootstrap prerequisites | Addressed via validation gate |
| Standard validation before bootstrap planning | Addressed |

**Not claimed complete:** GAP-001 (managed bootstrap execution), GAP-005 (capability detection).

---

## Limitations (Phase 2)

- No repository creation, cloning, or scaffold execution
- No package installation or version resolution from the internet
- No Git provider writes or MCP execution
- No cloud resource creation or deployment execution
- No CI workflow generation
- Managed bootstrap intent does not imply capability exists

---

## Recommended workflow

```text
User intent (text or YAML)
  → normalize-greenfield-project-spec.prompt.md
  → greenfield-project-spec.yaml
  → make ai-sdlc-validate-greenfield-spec
  → greenfield definition review
  → setup-state greenfield_spec_ref (on human confirm)
  → [Phase 3] bootstrap planning
  → [Phase 4/5] manual or managed bootstrap execution
```

After successful bootstrap, permanent maintenance uses:

- `/setup-existing-project refresh` for single-repo
- `/setup-existing-workspace refresh` for monorepo/multi-repo
