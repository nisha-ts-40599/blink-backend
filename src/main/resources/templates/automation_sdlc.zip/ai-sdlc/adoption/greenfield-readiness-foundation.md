# Moved: Project Delivery Readiness

This document moved to: [`project-delivery-readiness.md`](project-delivery-readiness.md)

The filename `greenfield-readiness-foundation.md` referred to an internal development phase name. Active documentation now uses capability-based naming.
