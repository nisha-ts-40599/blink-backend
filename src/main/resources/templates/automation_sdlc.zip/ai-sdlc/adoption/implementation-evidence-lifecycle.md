# Implementation Evidence Lifecycle

Generic framework guidance from pilot learnings — applies to any project using AI-SDLC.

## Repo topology

- **Workspace root** (where `.cursor/ai-sdlc/` lives) may **not** be a git root.
- Product code often lives in nested repos. Use:

```bash
make ai-sdlc-repo-status ROOT=<workspace-root>
```

- Report **untracked files separately** from tracked diffs to avoid false “no changes” confusion.

## Implementation evidence

Implementation is **not complete** from narrative summaries alone. Require one or more of:

- `implementation.repos[].files_changed`
- `implementation.repos[].local_commit`
- `git diff --stat` captured in `implementation-evidence.md`
- Live git inspection via repo topology tool

Register evidence with `implementation-evidence-capture.prompt.md`.

## PR lifecycle stages

| Stage | Meaning |
|-------|---------|
| `IMPLEMENTING` | Active coding; may have uncommitted changes |
| `COMMITTED_LOCAL` | Local commit recorded; may be unpushed |
| `PR_DRAFT_READY` | Clean tree; ready to open PR |
| `REVIEW_REQUESTED` | PR URL registered |
| `PR_REVIEWED` | PR review artifact present |
| `MERGE_READY` | Validation + QA-post + privacy review + rollback plan (Tier 3+) satisfied |
| `MERGED` | Human merged |
| `DEPLOY_READY` | Deploy gate + post-fix QA when required |
| `DEPLOYING` / `DEPLOYED` | Standard deployment lifecycle |
| `CUTOVER_READY` / `CUTOVER` | Phase 3 cutover planning/readiness (modernization/migration only) |
| `POST_MIGRATION_VALIDATION` | Phase 3 post-cutover validation before verified |

Legacy stages `PR_OPEN` and `APPROVED` remain supported.

## Pre-QA vs post-QA

| Gate | Purpose |
|------|---------|
| `G-QA-PRE` / legacy `g_qa` | Approves repro/test **plan** before implementation |
| `G-QA-POST` | Approves **post-fix** runtime validation before merge/deploy |

Pre-implementation approval must **never** substitute for post-fix validation.

## Validation status semantics

| Status | PR draft | Merge |
|--------|----------|-------|
| `passed` | OK | OK |
| `failed` | Block draft promotion | Block |
| `not_available` | OK (with note) | Block unless waived |
| `not_run` | OK | Block unless waived |
| `waived` | OK | OK if waiver approver recorded |
| `pending` | OK | Block |

Record in `implementation.validation.*` with command, evidence, reason, timestamp.

## Multi-repo evidence

For each affected repo, record in `implementation.repos[]`:

- `repo_id`, `path`, `branch`, `local_commit`, `pushed`, `pr_url`, `files_changed`

## Related prompts

- `repo-status-check.prompt.md`
- `implementation-evidence-capture.prompt.md`
- `pr-registration.prompt.md`
- `qa-validation.prompt.md` (post-fix)
- `merge-readiness.prompt.md`
- `rollback-plan.prompt.md`

## Rollback plan (Phase 1)

Tier 3+ merge readiness requires `artifacts.rollback_plan` unless `rollback_policy` disables enforcement.

Modernization/migration work (Phase 2) additionally requires modernization lane artifacts before technical plan; rollback touchpoints should be documented in `migration_strategy` and enforced at merge via Phase 1 `rollback_policy` for Tier 3+ modernization work types.

| Tier | Rollback at merge |
|------|-------------------|
| 1 | Not required (default) |
| 2 | Recommended (warn) |
| 3+ | Required (block) |

Payment/security/data-sensitive work uses `sensitive_enforcement: block` even below Tier 3.

See `adoption/rollback-policy-guide.md`.

## Related tools

```bash
make ai-sdlc-repo-status ROOT=<workspace-root>
make ai-sdlc-rollback-check ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```
