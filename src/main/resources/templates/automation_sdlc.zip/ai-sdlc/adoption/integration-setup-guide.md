# Tool integration setup (capability-oriented)

This guide describes how AI-SDLC discovers, records, and optionally wires **engineering and delivery tools** during workspace setup without assuming Jira, Confluence, GitHub, or Figma.

## Principles

- Ask by **capability** (ticket management, documentation, source control, design, test automation, test management, CI/CD, communication).
- Preserve the user's literal `provider_input`; normalize only when confident.
- Support `none`, `manual`, `defer`, and custom tool names.
- Store **non-secret** metadata under `.cursor/ai-sdlc/integrations/`.
- Keep secrets in `<framework-root>/.env.mcp` only; maintain `.env.mcp.example` with variable **names** only.
- Generate workspace `.cursor/mcp.json` via preview + `WRITE=1`; use `scripts/mcp-npx.sh`.

## Commands

```bash
make ai-sdlc-configure-integrations ROOT=<workspace-root>
make ai-sdlc-configure-integrations ROOT=<workspace-root> WRITE=1
```

Intake template: `ai-sdlc/templates/setup/integration-intake.template.yaml`

## Related guides

- [MCP configuration guide](mcp-configuration-guide.md)
- [Provider registry](provider-registry-guide.md)
- [Requirement storage guide](requirement-storage-guide.md)
- [Issue publication guide](issue-publication-guide.md)

Prompt include: `ai-sdlc/prompts/includes/integration-intake-setup.md`
