# Interactive Greenfield Workspace Setup

Provider-neutral, recommendation-driven setup for `/setup-new-workspace` and `/setup-new-project`.

## Requirement intake

| Source | Example |
|--------|---------|
| Pasted text | `Requirement:` block in chat |
| Workspace file | `requirements/product-requirements.md` |
| Issue tracker | `PROJECT-123` via authorised fetch; manual fallback if unavailable |
| YAML | Optional `project-initialisation-input.yaml` |

Recommendations stay **RECOMMENDED — NOT CONFIRMED** until a human confirms them. Accepting non-security defaults records planning guidance only; it does not confirm topology or executable stack decisions.

## Workspace control plane layout

The consuming workspace uses three boundaries:

| Boundary | Location | Role |
|----------|----------|------|
| Framework repository | Configured `framework_repo` (e.g. embedded tooling checkout) | Reusable AI-SDLC prompts, tools, schemas |
| Workspace control plane | `<workspace-root>/.cursor/` | Commands, overlay, intake, setup, reports, planned repo metadata |
| Product repositories | Sibling directories after approved bootstrap | Application source code |

Greenfield and existing flows use the same canonical control plane under `.cursor/ai-sdlc/` (`workspace-manifest.yaml`, `lifecycle-state.yaml`, `setup-state.yaml`). After the first validated implementation, finalize with `/finalize-greenfield-transition`; ongoing work uses `/setup-existing-workspace refresh`; new machines use `/setup-existing-workspace onboard`. See [workspace-lifecycle-unification.md](./workspace-lifecycle-unification.md).

Generated artifacts (never at workspace root):

```text
.cursor/
  commands/
  ai-sdlc/
    intake/requirements/          # normalized requirement snapshots
    intake/requirement-sources/   # source metadata (hash, issue key, gaps)
    setup/                        # session, init input, reports, scaffold records
    repos/                        # planned repository metadata only
    workflow-state/
    context/
    reports/
    roles/                        # reserved for future role-specific overlays
```

User-owned requirement files (e.g. `requirements/product-requirements.md`) stay in place; the framework records reference + hash and may copy a snapshot under `.cursor/ai-sdlc/intake/requirements/`.

Legacy root-level files (`project-initialisation-input.yaml`, `setup/setup-interactive-session.yaml`) are deprecated. Plan or migrate with:

```bash
make ai-sdlc-migrate-workspace-artifacts ROOT=<workspace>
make ai-sdlc-migrate-workspace-artifacts ROOT=<workspace> WRITE=1
```

Equivalent prompt operation: `/setup-new-workspace migrate-artifacts` (documented in setup prompts).

## Safety model

| Mode | Writes | Trigger |
|------|--------|---------|
| Discovery (default) | **None** | User runs setup prompt or `make ai-sdlc-greenfield-setup-discover` |
| Apply | `.cursor/ai-sdlc/**` metadata (setup, planned repos, handoff, **full overlay**) | Explicit confirmation + apply-readiness gate + `make ai-sdlc-greenfield-setup-apply` |
| Bootstrap | Typed managed actions or Cursor-assisted scaffold | G-BOOTSTRAP / G-BOOTSTRAP-EXEC and per-action confirmation |

Discovery and apply **do not** create product repository directories or run scaffold commands.

## Commands

```bash
# Read-only discovery (stdout JSON report; zero workspace writes)
make ai-sdlc-greenfield-setup-discover ROOT=<workspace> REQUIREMENT_TEXT="Product description..."

# Optional: persist resumable session during multi-turn chat (.cursor/ai-sdlc/setup/ and intake snapshots only)
make ai-sdlc-greenfield-setup-discover ROOT=<workspace> REQUIREMENT_FILE=requirements/product-requirements.md PERSIST_SESSION=1

# Apply (metadata under .cursor/ai-sdlc/ only; provenance gate always enforced)
make ai-sdlc-greenfield-setup-apply ROOT=<workspace> INPUT=.cursor/ai-sdlc/setup/project-initialisation-input.yaml ACCEPT_RECOMMENDED_DEFAULTS=1

make ai-sdlc-validate-project-init-input INPUT=.cursor/ai-sdlc/setup/project-initialisation-input.yaml
```

**Primary source rule:** use exactly one of `INPUT`, `REQUIREMENT_TEXT`, `REQUIREMENT_FILE`, `ISSUE_ID` per invocation (or `PROJECT_NAME` for legacy quick discover).

## Capability detection

- **Local tools:** Git, Node/npm/pnpm/yarn, Python/pip/uv, Java/Maven/Gradle, Flutter/Dart, Docker — via read-only `--version` probes; missing tools are recorded, not fatal.
- **Integrations:** Reads `.cursor/mcp.json` server **names** only; never emits env values or tokens. Status: `AVAILABLE`, `NOT_CONFIGURED`, `UNREACHABLE`, `NOT_REQUIRED`, `DEFERRED_BY_USER`.

## Recommendations

- **Repository structure:** single-repo, monorepo, or multi-repo from deployables, ownership, compliance, and user preference. Mobile + backend defaults to monorepo (`apps/mobile`, `services/api`, `packages/api-contracts`, …) unless separation triggers apply.
- **Technology stack:** evaluates Flutter, React Native, native mobile; backend options include FastAPI, Spring Boot, Node/TypeScript based on team skills and requirements — not scaffold availability alone.

## Bootstrap execution

1. **Managed (typed):** `create_directory`, `initialize_repository`, `configure_remote` (local), validation, handoff — see `managed-local-bootstrap-execution.md`.
2. **Cursor-assisted:** scaffold, dependencies, CI, initial commit — exact command shown; user must confirm; never sent through managed executor.
3. **Provider:** remote create/push/branch protection — separate confirmation; MCP only when probe status is `AVAILABLE`.

## Local-only fallback

When provider MCP is unavailable: local Git + scaffold + validation; remote steps deferred with manual instructions in `project-initialisation-report.md`.

## Readiness

After apply, `setup-result.readiness.planning_ready` means **permitted to enter planning** (`planning_ready_semantics: permitted_to_enter_planning`). It is not a claim that every planning role or topology decision is complete — that is `planning_prerequisites_complete`.

After scaffold: existing-project/workspace **refresh**, then `make ai-sdlc-validate-setup-readiness REQUIRE=delivery`. `delivery_ready` is set only by that authoritative process.

## Artifacts

| Path | Purpose |
|------|---------|
| `.cursor/ai-sdlc/setup/project-initialisation-input.yaml` | Normalized intake |
| `.cursor/ai-sdlc/setup/project-initialisation-report.yaml` | Machine report |
| `.cursor/ai-sdlc/setup/project-initialisation-report.md` | Human report |
| `.cursor/ai-sdlc/setup/scaffold-records/*.yaml` | Scaffold contracts |
| `.cursor/ai-sdlc/greenfield-project-spec.yaml` | Draft desired-state spec |

## Example: Flutter mobile + FastAPI + PostgreSQL (GitHub MCP, optional Figma/Confluence)

**Intake:** Android/iOS app, REST API, PostgreSQL; GitHub MCP configured; Figma deferred, Confluence skipped.

**Discovery report (abbreviated):**

- Repository: **monorepo** — `apps/mobile`, `services/api`, `packages/api-contracts`, `infrastructure`, `docs`.
- Stack: **Flutter** mobile, **FastAPI** backend, **PostgreSQL** database.
- Integrations: GitHub `AVAILABLE`; Figma `DEFERRED_BY_USER`; Confluence `NOT_REQUIRED` with manual placeholder path.
- Provider: remote create **deferred=false** but still requires **separate push/create confirmation**.
- Scaffold (display before run): `flutter create` under `apps/mobile`; `uv init` + FastAPI under `services/api`.
- Readiness after apply: `context_ready` possible; `delivery_ready` false until repos exist and refresh validates.

**Operator sequence:**

1. `/setup-new-workspace` discovery → questionnaire → `make ai-sdlc-greenfield-setup-discover`
2. User may record non-security recommended defaults as planning guidance (RECOMMENDED — NOT CONFIRMED) → `/setup-new-workspace apply` + `make ai-sdlc-greenfield-setup-apply`
3. Phase 0–1 grooming/plan → G-PLAN → `/generate-bootstrap-plan` → G-BOOTSTRAP
4. Managed: dirs + `git init` with G-BOOTSTRAP-EXEC; Cursor: scaffold commands after display/confirm
5. User confirms GitHub remote create/push separately
6. `/setup-existing-workspace refresh` → `make ai-sdlc-validate-setup-readiness REQUIRE=delivery`
