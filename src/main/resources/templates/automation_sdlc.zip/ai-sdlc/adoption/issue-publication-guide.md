# Issue publication guide

Publication to ticket systems uses **compact, level-specific** context — not the full workspace overlay.

| Level | Includes |
|-------|----------|
| Epic | Business problem, outcome, scope, exclusions, users, business AC, constraints, risks, source refs |
| Story / PBI | One functional slice, AC, dependencies, affected areas, constraints, parent Epic/Feature, requirement pointer |
| Task | Technical objective, target repo, boundary, dependencies, validation, security reqs, parent |
| Bug | Expected/actual, reproduction, severity, scope, parent Story |

Implementation: `ai-sdlc/tools/setup/integration/issue_publication.py`

Workflow-state should store `workflow_requirement_reference()` metadata linking to `.cursor/ai-sdlc/intake/requirements/` snapshots.
