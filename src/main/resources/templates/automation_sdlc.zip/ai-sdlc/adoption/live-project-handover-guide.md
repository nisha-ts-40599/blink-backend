# Live Project Handover Guide

**Audience:** A team taking the AI-SDLC framework into a live internal project for the first time.

**What this guide covers:** What you can use immediately, what to set up in week 1, what remains manual, how to run the first issue through the full workflow, and what the framework will do for your project once it is fully configured.

---

## What is ready today

The following components are fully operational and usable immediately with no additional setup:

> **New:** Context aggregator script (`tools/orchestration/build_context_bundle.py`) and stage router
> prompt (`prompts/stage-router.prompt.md`) are now available. These reduce the manual placeholder-fill
> burden from 8–12 items per prompt to 2–3. See "How to use the context aggregator" below.

| Component | What it does | Where it lives |
|-----------|-------------|----------------|
| 22 structured prompts | AI-assisted SDLC tasks from requirement to release | `ai-sdlc/prompts/` |
| 12-step Cursor workflow | Step-by-step guide for using prompts in daily work | `docs/operating-model/current-sdlc-flow.md` |
| Enterprise engineering guardrails | Coding standards for AI-generated code | `governance/enterprise-engineering-guardrails.md` |
| PR template | Standardised checklist for every PR | `.github/pull_request_template.md` |
| Work tier guide | How to classify work by risk and required governance | `ai-sdlc/work-tiers.md` |
| Approval gates | What G-PLAN, G-SEC, G-PR-MERGE, and G-DEPLOY mean | `governance/approval-gates.md` |
| Human-in-the-loop policy | What AI must not do; what humans always decide | `governance/human-in-the-loop-policy.md` |
| Conformance runner (local) | Validate schemas and policies locally | `make ai-sdlc-conformance-protected` |
| Prompt validation (local) | Check prompt placeholder catalog | `make ai-sdlc-prompt-check` |
| YAML lint (local) | Lint AI-SDLC configuration YAML | `make ai-sdlc-lint` |
| Agent model | 18 agent roles and how they map to prompts | `architecture/agent-model.md` |
| Global rules | Project-agnostic coding and governance rules | `rules/global-rule-index.md` |
| ACP handoff contracts | 13 agent-to-agent transition specifications | `acp/contracts/` |
| ADR store | Architectural decision records | `ai-sdlc/adr/` |

---

## What to set up in week 1

Complete these steps before running any issue through the workflow:

### Day 1–2: Trigger GitHub Actions
Open a draft PR to main. This fires the GitHub Actions workflow at least once, making the job names (`AI-SDLC Conformance`, `Secret Scan (Gitleaks)`, `Dependency Audit (pip-audit)`) visible in GitHub's branch protection settings.

### Day 2–3: Enable branch protection
Follow `adoption/branch-protection-setup.md`. Require at minimum:
- AI-SDLC Conformance *(required)*
- Secret Scan (Gitleaks) *(strongly recommended)*
- Dependency Audit (pip-audit) *(strongly recommended)*

### Day 1–3: Onboard your project
Run `prompts/setup-existing-project.prompt.md` with your repository details.
Engineering lead reviews and approves the generated `project-config.yaml` and `project-context.md`.
**Never commit AI-generated config files without engineering lead review.**

### Day 1–3: Set up GitHub read-only MCP (per engineer)
Follow `mcp/github-readonly-setup.md`. Each pilot engineer creates a fine-grained PAT and configures `.cursor/mcp.json`. This eliminates the need to manually paste issue content and PR diffs into prompts.

### Day 3–5: Brief the pilot team
Share this guide and `docs/operating-model/current-sdlc-flow.md` with every pilot engineer. Run a 30-minute walkthrough covering:
- The 12-step workflow
- Tier classification (Tier 1 vs. Tier 2 boundary rules)
- When G-PLAN is required and how to record it
- Engineering guardrails in the PR template
- What AI cannot do (never merges, never deploys, no autonomous decisions)

---

## What remains manual today

The following decisions and actions are always human-controlled. AI produces advisory outputs; humans decide and act.

| Decision / Action | Human responsible | AI may assist with |
|------------------|-----------------|--------------------|
| Requirement approval | Product owner or engineering lead | Structured draft; open questions list |
| Work tier confirmation | Engineering lead | Tier proposal with evidence |
| G-PLAN approval | Engineering lead | Technical plan for review |
| G-SEC approval | Security champion | Security assessment |
| Code review | Any peer reviewer | AI advisory review (not a substitute) |
| PR approval | At least 1 human reviewer | AI review comment (advisory) |
| Merge to main | Human (not automated) | All checks green; review complete |
| Production deployment | Authorized SRE / engineering lead | Release checklist; go/hold recommendation |
| Incident declaration | On-call engineer | Monitoring signal interpretation |
| Rollback decision | On-call SRE | Rollback conditions (never triggers) |
| All PII handling | Named data controller | Context-aware guidance only |
| All security waivers | Security champion | Triage analysis |

---

## How to onboard your project

1. **Run `setup-existing-project.prompt.md`**
   Fill placeholders: `{{REPOSITORY_URL}}`, `{{TECH_STACK}}`, `{{TEAM_SIZE}}`, `{{DEPLOYMENT_MODEL}}`.
   The prompt produces draft `project-config.yaml` and `project-context.md`.

2. **Engineering lead reviews both files**
   Check: ownership roles named, security model accurate, test conventions correct, approval roles assigned.

3. **Commit approved files**
   `project-context.md` goes in the repo root or `ai-sdlc/` directory.
   `project-config.yaml` goes in `ai-sdlc/` directory.

4. **Set a 90-day context freshness reminder**
   `project-context.md` must be reviewed every 90 days. Agents refuse to proceed if it is stale.

5. **Assign approval roles**
   Name the G-PLAN approver (engineering lead), G-SEC approver (security champion), and G-DEPLOY approver (SRE) in `project-config.yaml`.

---

## How to use the context aggregator

The context aggregator reduces manual prompt preparation. Instead of pasting 8–12 pieces of context,
run the script once and it pre-assembles everything it can from your workflow state and project files.

**Step 1 — Create a workflow state file** for your issue (fill manually using the schema at
`schemas/workflow/workflow-state.schema.json`). Example: `ai-sdlc/examples/workflow-state/patient-registration.workflow-state.yaml`.

**Step 2 — Run the aggregator:**

```bash
python ai-sdlc/tools/orchestration/build_context_bundle.py \
  --workflow-state ai-sdlc/workflow-state/YOUR-ISSUE.yaml \
  --project-context project-context.md \
  --project-config ai-sdlc/project-config.yaml \
  --target-agent "Backend Implementation Agent" \
  --target-prompt implement-step \
  --output /tmp/context-bundle.json
```

Or use the example:

```bash
make ai-sdlc-context-bundle-example
```

**Step 3 — Review the output.** The bundle shows: current stage, gate status, safe-to-proceed decision, missing items, and the exact next human action.

**Step 4 — Supply the remaining 2–3 manual fields** (typically `REPOSITORY_CONTEXT` and `CURRENT_STEP`) and invoke the recommended prompt.

**Step 5 — Use the stage router** (`prompts/stage-router.prompt.md`) at any point to get a routing recommendation from the current workflow state. Paste your workflow state YAML and project context as input.

---

## How to run the 12-step workflow

The full workflow is documented in `docs/operating-model/current-sdlc-flow.md`. Summary for first-time use:

| Step | Prompt | What the engineer does | What AI produces |
|------|--------|----------------------|-----------------|
| 1 | `clarify-requirement` | Paste raw requirement | Structured requirement; open questions |
| 2 | `classify-work` | Provide requirement + project context | Tier proposal with evidence |
| 3 | `impact-analysis` | Provide confirmed requirement + tier | Blast radius map; test targets |
| 4 | `technical-plan` | Provide impact + requirement | Ordered implementation plan |
| — | **G-PLAN gate** | Engineering lead approves plan | Written comment on issue |
| 5 | `create-spec` | Provide requirement + criteria | Technical specification |
| 6 | `create-issues` | Provide spec | Structured issue drafts |
| 7 | `implement-step` (×N) | Provide plan + step N + context | Step implementation |
| 8 | `generate-tests` | Provide diff + acceptance criteria | Test additions |
| 9 | `self-review` | Provide full diff | Self-review report |
| 10 | `pr-review` | Open PR + provide diff | AI review comment (advisory) |
| — | **G-PR-MERGE gate** | Human reviewer approves | Branch protection enforces |
| 11 | `release-verification` | After merge; provide CI results | Release checklist |
| — | **G-DEPLOY gate** | SRE executes deployment | |
| 12 | `monitoring-interpretation` | After deploy; provide signals | Go/hold recommendation |
| Post | `update-docs` / `changelog-generation` | After verification | Docs update; changelog |

**First-time tip:** Start with a single Tier 2 issue (a small, new feature with no external dependencies). This exercises all gates and produces a complete evidence trail. Reserve Tier 1 shortcuts and Tier 3+ rigor for later.

---

## How to use agents as prompt roles today

At Level 1, "agents" are prompt invocations, not running services. Think of each prompt as an instruction card for a specialist role:

- **Requirement Analyst role:** Run `clarify-requirement.prompt.md` — you are invoking the Analyst Agent.
- **Classifier role:** Run `classify-work.prompt.md` — you are invoking the Classifier Agent.
- **Planner role:** Run `technical-plan.prompt.md` — you are invoking the Planning Agent.
- **Coder role:** Run `implement-step.prompt.md` for each step — you are invoking the Coder Agent.
- **Test role:** Run `generate-tests.prompt.md` — you are invoking the Test Agent.
- **Reviewer role:** Run `pr-review.prompt.md` — you are invoking the PR Review Agent.

The roles are logically the same as in the future multi-agent architecture. The difference is that today you are the Orchestrator — you decide when to invoke each role and in what sequence.

---

## How the future Orchestrator will improve the process

Once the Minimum Viable Orchestrator (MVO) is operational (see `architecture/multi-agent-evolution-roadmap.md`), the workflow will improve in these specific ways:

| Today (manual) | With MVO (Level 2–3) |
|----------------|---------------------|
| Engineer fills 8–12 placeholders per prompt | Context aggregator auto-fills from project-context + MCP (2–3 fields remain) |
| Engineer decides which prompt to run next | Stage router prompt reads state file and recommends next action |
| G-PLAN requires engineer to remember to check | Gate checker script verifies G-PLAN record before implementation starts |
| PR diff is pasted manually | GitHub MCP reads PR diff directly |
| CVE alerts are noticed reactively | Dependabot alert fires trigger → Security Agent triage notification |
| Docs updates are often deferred | PR merged event triggers Docs Agent → draft update posted automatically |

The human decision points remain the same. The workflow coordination and context assembly is what improves.

---

## How to report gaps

When a prompt produces unreliable output, a placeholder is missing, or a governance rule is unclear:

1. **Open an issue** in this repository with label `ai-sdlc-gap`.
2. **Describe the gap:** which prompt or rule, what was expected, what was produced, what context was supplied.
3. **Check `prompts/prompt-placeholder-catalog.md`** — if a placeholder is missing, add it in a separate PR.
4. **Do not modify framework documents directly** unless you are the designated AI-SDLC framework maintainer for your organisation.

---

## How to update project-context.md

`project-context.md` should be updated:
- After every major release that changes architecture, tech stack, or conventions
- After every significant change to the deployment model
- After team ownership or approval role changes
- At the 90-day mandatory review cadence

To update: run `setup-existing-project.prompt.md` with your current state and compare the output to the existing `project-context.md`. Update the fields that have changed. Engineering lead approves before commit.

---

## How to avoid AI overengineering

AI-generated code has a well-known tendency to over-abstract, introduce unnecessary patterns, and propose solutions to problems that were not asked. The following practices prevent this:

1. **Invoke prompts step-by-step** — do not ask AI to implement multiple steps in one invocation.
2. **Apply `RULE-EQ-003` (Minimal Safe Change)** — the prompt enforces this, but you must also enforce it in review.
3. **Apply `RULE-EQ-007` (YAGNI)** — if the AI proposes a feature not in the acceptance criteria, reject it.
4. **Use the self-review checklist** — the 14-item guardrail checklist in `prompts/self-review.prompt.md` is designed to catch over-engineering.
5. **Review every diff before committing** — never auto-commit AI output; read every line.
6. **Use small, focused prompts** — a 200-line prompt with 15 requirements produces worse output than 5 focused prompts with 3 requirements each.

---

## How to preserve human approvals

Every gate in the framework exists because human accountability is legally, operationally, or governance-required. These must not be bypassed, even under delivery pressure:

- **G-PLAN** — Record the written approval comment URL in the workflow state file before implementation starts.
- **G-PR-MERGE** — Branch protection enforces this mechanically. Do not disable branch protection.
- **G-DEPLOY** — Never automate deployment. The SRE who executes deployment is accountable for the decision.
- **Tier overrides** — If you are considering classifying Tier 2 work as Tier 1 to avoid G-PLAN, read `work-tiers.md` §Tier 1 vs Tier 2 Boundary. If in doubt, classify up.

---

## First 2-week adoption plan

### Week 1 — Setup and first issue

| Day | Task |
|-----|------|
| 1 | Fork/clone repo; trigger GitHub Actions; file first PR to see job names |
| 2 | Configure branch protection with all three required status checks |
| 2 | Run `setup-existing-project.prompt.md`; engineering lead reviews config |
| 3 | Each pilot engineer configures GitHub read-only MCP |
| 3–4 | Brief pilot team on workflow, tiers, and gates |
| 4–5 | Select 1 Tier 2 issue from backlog; run through all 12 steps |
| 5 | G-PLAN is requested and recorded on the first issue |

### Week 2 — Validate and iterate

| Day | Task |
|-----|------|
| 6–7 | Complete implementation, tests, self-review, PR review for Week 1 issue |
| 7 | Human review + G-PR-MERGE; merge first AI-SDLC issue to main |
| 8 | Run release verification; request G-DEPLOY |
| 8–9 | Retrospective: collect prompt quality, gate adherence, context completeness findings |
| 9–10 | Update `project-context.md` with corrections from retro |
| 10 | Start second issue; report any gaps to AI-SDLC maintainer |

---

## Success metrics for Pilot week 1–2

| Metric | Target |
|--------|--------|
| GitHub Actions triggered and green | Yes |
| Branch protection active | Yes |
| At least 1 issue through full 12-step workflow | Yes |
| G-PLAN gate recorded with comment URL | Yes |
| PR template checklist completed | Yes |
| `project-context.md` reviewed and approved by engineering lead | Yes |
| Self-review output posted to issue | Yes |
| AI PR review comment posted | Yes |
| Zero autonomous actions taken by AI | Yes (non-negotiable) |
| Team can explain when G-PLAN is required | Yes |

---

## Not safe to use yet

Do not use the following until the specified prerequisites are met:

| Item | Do not use until |
|------|-----------------|
| Write MCP (Coder commits to branch) | Level 2: GitHub write scope reviewed by security champion |
| Automated PR creation | Level 2: human reviews every PR before it opens |
| Autonomous merge | Not planned — permanent human gate |
| Autonomous production deployment | Not planned — permanent human gate |
| ACP runtime / orchestrator service | Level 3: after MVO proven in pilot |
| Multi-agent orchestrator | Level 3: after ACP runtime stable |
| Figma MCP / design-to-spec | Level 2–3: after design-to-spec prompt is defined |
