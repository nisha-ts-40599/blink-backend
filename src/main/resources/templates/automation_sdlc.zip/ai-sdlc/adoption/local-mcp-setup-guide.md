# Local MCP Setup Guide — AI-SDLC Pilot

**Audience:** Each pilot developer, on their own machine.  
**Goal:** Configure Filesystem, GitHub, Jira, Confluence, and (optionally) S3 — one at a time, each verified before the next.  
**Primary issue tracker for this pilot:** Jira (Azure DevOps is not available for the current pilot — see optional appendix at the bottom if ADO is added later.)  
**Last updated:** 2026-06-18

> **Never commit `.cursor/mcp.json` or `.env.mcp`** — both are in `.gitignore`.  
> **Never share tokens** — each developer uses their own.  
> **One MCP at a time** — validate each before enabling the next.

---

## Before you start

### Prerequisites

```bash
# Node.js 18+ required (npx is used to launch MCP servers)
node --version   # must be >= 18.0.0

# Cursor IDE with MCP support enabled
# (Cursor Settings → Features → MCP → Enable)

# Workspace open in Cursor:
# <framework-repo-path>
```

### File locations

| File | Location | Committed? |
|------|---------|------------|
| MCP config template | `.cursor/mcp.example.json` | ✅ Yes — no secrets |
| Your live MCP config | `.cursor/mcp.json` | ❌ No — gitignored |
| Env vars template | `ai-sdlc/mcp/mcp-env.example` | ✅ Yes — no secrets |
| Your live env vars | `.env.mcp` (or shell profile) | ❌ No — gitignored |

### Create your local files

```bash
cd <framework-repo-path>

# MCP config (you will fill this in step by step below)
cp .cursor/mcp.example.json .cursor/mcp.json

# Env vars file (fill in as you create each token)
cp ai-sdlc/mcp/mcp-env.example .env.mcp
```

---

## Phase 1 — Filesystem MCP (no token needed)

**What it provides:** Source files, test files, dependencies, local plan docs.  
**Token needed:** None.  
**Risk:** Zero — local reads only.

### Step 1.1 — Verify it is already in `.cursor/mcp.json`

The `filesystem` server block should already be uncommented. Confirm:

```jsonc
"filesystem": {
  "command": "npx",
  "args": [
    "-y",
    "@modelcontextprotocol/server-filesystem",
    "${workspaceFolder}"
  ],
  "env": {}
}
```

`${workspaceFolder}` is automatically set by Cursor to the open project directory — no changes needed.

### Step 1.2 — Restart Cursor

After any edit to `.cursor/mcp.json`, restart Cursor completely (Quit → reopen). MCP servers are only loaded at startup.

### Step 1.3 — Read validation

In a **new Cursor chat**, type:

```
List the files and directories in the project root.
```

✅ **Pass:** Returns a directory listing of the automation_sdlc workspace.

```
Read the file ai-sdlc/workflow-state/TEMPLATE.yaml
```

✅ **Pass:** Returns YAML file contents.

### Step 1.4 — Write-block check

```
Create a new file at ai-sdlc/workflow-state/MCP-WRITE-TEST.yaml with content: write_test: true
```

✅ **Pass:** Cursor refuses or the file does not appear in the directory.  
❌ **Fail:** File is created on disk → the MCP server config is too permissive. Delete the file and check the `${workspaceFolder}` scope.

### Step 1.5 — Mark ready

- [ ] Filesystem MCP: read works ✅
- [ ] Write-block: confirmed ✅
- [ ] Date validated: ___________

---

## Phase 2 — GitHub MCP

**What it provides:** PR diffs, CI status, review comments, merged PR list, CI job statuses.  
**Token needed:** GitHub fine-grained personal access token (read-only).

### Step 2.1 — Create the token

1. Go to: `https://github.com/settings/tokens?type=beta`
2. Click **Generate new token (fine-grained)**
3. Set:
   - **Token name:** `cursor-ai-sdlc-pilot-read`
   - **Expiration:** 90 days (maximum recommended)
   - **Resource owner:** your user or the TalentServ org
   - **Repository access:** Only select repositories → add the repos you will work with

4. Under **Repository permissions**, set these to **Read-only** — nothing else:

   | Permission | Set to |
   |-----------|--------|
   | Contents | Read-only |
   | Issues | Read-only |
   | Pull requests | Read-only |
   | Actions | Read-only |
   | Metadata | Read-only (required) |

5. Leave **ALL** other permissions as **No access** — especially:
   - Administration → No access
   - Secrets → No access
   - Environments → No access
   - Webhooks → No access
   - Code → No access (for writing)

6. Click **Generate token** — copy it immediately (shown once only).

### Step 2.2 — Add to env

Edit `.env.mcp`:

```bash
GITHUB_PERSONAL_ACCESS_TOKEN=ghp_REPLACE_WITH_YOUR_TOKEN
```

Source it:

```bash
source .env.mcp
echo "GitHub token set: ${GITHUB_PERSONAL_ACCESS_TOKEN:0:10}..."
# Should print first 10 chars only — confirms var is set without revealing full token
```

### Step 2.3 — Confirm `.cursor/mcp.json` uses env var

The `github` block should read:

```jsonc
"github": {
  "command": "npx",
  "args": ["-y", "@modelcontextprotocol/server-github"],
  "env": {
    "GITHUB_PERSONAL_ACCESS_TOKEN": "${env:GITHUB_PERSONAL_ACCESS_TOKEN}"
  }
}
```

The `${env:GITHUB_PERSONAL_ACCESS_TOKEN}` syntax tells Cursor to read from the shell environment. You must source `.env.mcp` (or set it in your shell profile) before launching Cursor.

> **Alternative:** If `${env:...}` is not picking up your shell env, replace with the literal token value directly in `.cursor/mcp.json` — but treat that file as a secret and never commit it.

### Step 2.4 — Restart Cursor and read validate

In a new Cursor chat:

```
List the open pull requests in TalentServ/automation_sdlc.
```

✅ **Pass:** Returns a list of PRs (or "no open PRs" if there are none).

```
What is the status of the latest CI workflow run on the main branch in TalentServ/automation_sdlc?
```

✅ **Pass:** Returns job names and pass/fail statuses (or "no recent runs").

### Step 2.5 — Write-block safety test

```
Create a new GitHub issue in TalentServ/automation_sdlc titled "MCP write safety test".
```

✅ **Pass:** Error — *"Resource not accessible by personal access token"* or similar refusal.  
❌ **Fail:** A new issue appears on GitHub → **Revoke this PAT immediately.** Go to `https://github.com/settings/tokens`, find `cursor-ai-sdlc-pilot-read`, click **Revoke**. Regenerate with correct read-only scopes.

### Step 2.6 — Mark ready

- [ ] GitHub PAT created with read-only scopes ✅
- [ ] `GITHUB_PERSONAL_ACCESS_TOKEN` in `.env.mcp` ✅
- [ ] Read validation passes ✅
- [ ] Write-block confirmed ✅
- [ ] Rotation reminder set for 90 days: ___________

---

## Phase 3 — Jira + Confluence MCP (one token, two servers)

**What it provides:** Jira issues are the **primary source** for `REQUIREMENT`, `ACCEPTANCE_CRITERIA`, `ISSUE_COMMENTS`, `ISSUE_STATUS`, and `LINKED_ISSUES` in this pilot. Confluence provides `ARCHITECTURE_CONTEXT` and runbook references.  
**Token needed:** One Atlassian API token (covers both Jira and Confluence).  
**Note:** Azure DevOps is not available for the current pilot. Jira replaces it as the issue tracker. See the optional appendix at the bottom if ADO is added later.

> If your team does not use Jira or Confluence, skip this phase.

### Step 3.1 — Create the Atlassian API token

1. Go to: `https://id.atlassian.com/manage-profile/security/api-tokens`
2. Click **Create API token**
3. Label: `cursor-ai-sdlc-pilot`
4. Copy the token — shown once only.

**Scope note:** Atlassian API tokens do not have configurable scopes in the same way as GitHub PATs. The token inherits your account's project access. To limit exposure:
- Use your own account (not an admin account) — it only sees what you can see.
- If your org requires a service account, create one with read-only Jira/Confluence access.

### Step 3.2 — Add to env

Edit `.env.mcp`:

```bash
ATLASSIAN_API_TOKEN=REPLACE_WITH_YOUR_ATLASSIAN_TOKEN
ATLASSIAN_SITE_URL=https://YOUR_ORG.atlassian.net
ATLASSIAN_EMAIL=your.email@yourorg.com
```

Replace `YOUR_ORG` with your actual Atlassian organization name (visible in your Atlassian URL).  
Replace `your.email@yourorg.com` with the email address associated with your Atlassian account.

Source: `source .env.mcp`

### Step 3.3 — Enable Jira in `.cursor/mcp.json`

Find the commented Jira block and uncomment it:

```jsonc
"jira": {
  "command": "npx",
  "args": ["-y", "mcp-atlassian"],
  "env": {
    "ATLASSIAN_SITE_URL": "${env:ATLASSIAN_SITE_URL}",
    "ATLASSIAN_EMAIL":    "${env:ATLASSIAN_EMAIL}",
    "ATLASSIAN_API_TOKEN": "${env:ATLASSIAN_API_TOKEN}"
  }
}
```

> **Package name:** `mcp-atlassian` covers both Jira and Confluence in some implementations. Verify the correct package name is available (`npm show mcp-atlassian`) before assuming it is installed. If unavailable, check `@atlassian/mcp-jira` or the latest community package.

### Step 3.4 — Restart and validate Jira

```
Read Jira issue {YOUR-JIRA-KEY} including summary, description, acceptance criteria, comments,
status, assignee, sprint, labels, components, linked issues, and attachments if available.
Do not update the issue.
```

Replace `{YOUR-JIRA-KEY}` with a real Jira issue key from your project (e.g., `TS-1` or `PROJ-123`).

✅ **Pass:** Issue body, ACs, status, assignee, sprint, and comments returned.

```
List the open issues in the current sprint for Jira project {PROJ-KEY}.
```

✅ **Pass:** Sprint issue list returned.

### Step 3.5 — Jira write-block test

```
Create a Jira issue titled "MCP write safety test".
```

Expected result: The request must fail, be refused, or be denied by permission.

✅ **Pass:** Error — *"403 Forbidden"*, *"You do not have permission to create issues"*, or any clear refusal.  
❌ **Fail:** Issue created → **Revoke Atlassian token immediately** at `https://id.atlassian.com/manage-profile/security/api-tokens`. Delete the test issue. Create a new token with a read-only service account.

### Step 3.6 — Enable Confluence in `.cursor/mcp.json`

Uncomment the Confluence block (uses the same Atlassian env vars):

```jsonc
"confluence": {
  "command": "npx",
  "args": ["-y", "mcp-confluence"],
  "env": {
    "ATLASSIAN_SITE_URL":  "${env:ATLASSIAN_SITE_URL}",
    "ATLASSIAN_EMAIL":     "${env:ATLASSIAN_EMAIL}",
    "ATLASSIAN_API_TOKEN": "${env:ATLASSIAN_API_TOKEN}"
  }
}
```

> **Package name note:** Same as Jira — verify `mcp-confluence` exists (`npm show mcp-confluence`). Some distributions combine Jira and Confluence into one server.

### Step 3.7 — Restart and validate Confluence

```
Find Confluence pages in space {SPACE-KEY} related to the health platform API.
Summarize relevant architecture decisions and security constraints.
```

Replace `{SPACE-KEY}` with your Confluence space key (visible in the Confluence URL: `.../wiki/spaces/SPACEKEY`).

✅ **Pass:** Page summaries returned.

### Step 3.8 — Confluence write-block test

```
Create a Confluence page in space {SPACE-KEY} titled "MCP write safety test".
```

✅ **Pass:** Error — permission denied.  
❌ **Fail:** Page created → revoke Atlassian token immediately, delete the page, regenerate.

### Step 3.9 — Mark ready

- [ ] Atlassian API token created ✅
- [ ] All three Atlassian env vars set in `.env.mcp` ✅
- [ ] Jira read validation passes ✅
- [ ] Jira write-block confirmed ✅
- [ ] Confluence read validation passes ✅
- [ ] Confluence write-block confirmed ✅
- [ ] Rotation reminder set: ___________

---

## Phase 4 — AWS S3 (optional — artifact storage)

**What it provides:** Shared artifact storage for context bundles, technical plans, prompt outputs, pilot metrics.  
**Mode:** Controlled read/write to `projects/*` prefix only. No delete.  
**Token needed:** AWS IAM access key (least-privilege inline policy).

> Skip this phase if you do not need shared artifact storage in the current pilot sprint.  
> See `ai-sdlc/mcp/aws-s3-artifact-storage-setup.md` for full bucket setup and IAM policy JSON.

### Step 4.1 — Create the S3 bucket and IAM user

Follow the instructions in `ai-sdlc/mcp/aws-s3-artifact-storage-setup.md`:

```bash
# Quick verify — confirm bucket exists (requires existing AWS credentials with admin access):
aws s3api head-bucket --bucket talentserv-ai-sdlc-pilot-artifacts 2>&1
# Expected: HTTP 200 (no error) — bucket exists and you have access
```

If the bucket does not exist, the S3 setup guide has the full `aws s3api create-bucket` commands.

### Step 4.2 — Create the IAM user and access key

1. Go to: `https://console.aws.amazon.com/iam/home#/users`
2. Click **Add users**
3. Username: `talentserv-ai-sdlc-pilot`
4. Access type: **Programmatic access** (access key only — no console access)
5. Permissions: **Attach policies directly** → click **Create inline policy**
6. Paste the least-privilege policy from `aws-s3-artifact-storage-setup.md`:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AISDLCArtifactListBucket",
      "Effect": "Allow",
      "Action": ["s3:ListBucket"],
      "Resource": "arn:aws:s3:::talentserv-ai-sdlc-pilot-artifacts",
      "Condition": {
        "StringLike": { "s3:prefix": ["projects/*"] }
      }
    },
    {
      "Sid": "AISDLCArtifactReadWrite",
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:PutObject", "s3:GetObjectVersion"],
      "Resource": "arn:aws:s3:::talentserv-ai-sdlc-pilot-artifacts/projects/*"
    }
  ]
}
```

7. Click **Create user** → **Download .csv** (contains access key ID and secret — shown once).

### Step 4.3 — Add to env

Edit `.env.mcp`:

```bash
AWS_ACCESS_KEY_ID=YOUR_AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY=YOUR_AWS_SECRET_ACCESS_KEY
AWS_REGION=eu-west-1
AI_SDLC_S3_BUCKET=talentserv-ai-sdlc-pilot-artifacts
AI_SDLC_S3_PREFIX=projects/
```

Source: `source .env.mcp`

### Step 4.4 — Validate read access

```bash
# List the allowed prefix
aws s3 ls s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX --region $AWS_REGION
```

✅ **Pass:** Lists objects/directories or returns empty (no error).

### Step 4.5 — Validate write access (to allowed prefix)

```bash
echo "AI-SDLC write validation $(date -u)" | \
  aws s3 cp - s3://$AI_SDLC_S3_BUCKET/${AI_SDLC_S3_PREFIX}health-platform-api/pilot-metrics/write-test.txt
```

✅ **Pass:** `upload: - to s3://...` — write succeeds to the allowed prefix.

### Step 4.6 — Validate scope restriction (must fail)

```bash
aws s3 cp /dev/null s3://$AI_SDLC_S3_BUCKET/not-projects/test.txt 2>&1
```

✅ **Pass:** `An error occurred (AccessDenied)` — IAM policy correctly blocks writes outside `projects/*`.  
❌ **Fail:** Upload succeeds → IAM policy is too broad. Detach it, rewrite with the correct resource ARN, and re-test.

### Step 4.7 — Validate delete is blocked (must fail)

```bash
aws s3 rm s3://$AI_SDLC_S3_BUCKET/${AI_SDLC_S3_PREFIX}health-platform-api/pilot-metrics/write-test.txt 2>&1
```

✅ **Pass:** `An error occurred (AccessDenied)` — `s3:DeleteObject` is not in the policy.  
❌ **Fail:** Object deleted → add an explicit `Deny` for `s3:DeleteObject` to the IAM inline policy.

### Step 4.8 — Mark ready

- [ ] Bucket created with versioning + encryption + public access block ✅
- [ ] IAM user created with least-privilege inline policy ✅
- [ ] `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` in `.env.mcp` ✅
- [ ] Read validation passes ✅
- [ ] Write to allowed prefix passes ✅
- [ ] Scope restriction (write outside `projects/`) blocked ✅
- [ ] Delete blocked ✅
- [ ] No PHI/PII/secrets uploaded to bucket ✅
- [ ] Rotation reminder set for after pilot: ___________

---

## What must remain disabled in the current pilot

The following must remain commented out in `.cursor/mcp.json`:

| MCP | Status | Reason |
|-----|--------|--------|
| Azure DevOps | ⚠️ Not available | ADO is not used in the current pilot. See optional appendix below. |
| Slack | 🔜 Deferred | Requires write-block validation first; messaging MCPs need extra care |
| Microsoft Teams | 🔜 Deferred | Azure AD app registration required |
| Outlook | 🔜 Deferred | Same Azure AD app as Teams |
| MongoDB Atlas | 🔜 Deferred | Use only when DB schema context is needed; dev cluster only |
| Docker Hub | 🔜 Deferred | Configure only when CVE image triage is needed |
| Render | 🔜 Deferred | Configure only when post-deploy status reading is needed |
| Vercel | 🔜 Deferred | Configure only when post-deploy status reading is needed |
| Figma | 🔜 Deferred | Frontend phase only |

---

## Your final `.cursor/mcp.json` for Phases 1–3

After completing Phases 1–3, your active `.cursor/mcp.json` should contain exactly these uncommented servers. ADO stays commented out — it is not used in the current pilot.

```jsonc
{
  "servers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "${workspaceFolder}"],
      "env": {}
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${env:GITHUB_PERSONAL_ACCESS_TOKEN}"
      }
    },
    // azure-devops: NOT configured in current pilot (ADO not available)
    // Uncomment and configure if ADO is added later — see optional appendix below
    "jira": {
      "command": "npx",
      "args": ["-y", "mcp-atlassian"],
      "env": {
        "ATLASSIAN_SITE_URL": "${env:ATLASSIAN_SITE_URL}",
        "ATLASSIAN_EMAIL":    "${env:ATLASSIAN_EMAIL}",
        "ATLASSIAN_API_TOKEN": "${env:ATLASSIAN_API_TOKEN}"
      }
    },
    "confluence": {
      "command": "npx",
      "args": ["-y", "mcp-confluence"],
      "env": {
        "ATLASSIAN_SITE_URL":  "${env:ATLASSIAN_SITE_URL}",
        "ATLASSIAN_EMAIL":     "${env:ATLASSIAN_EMAIL}",
        "ATLASSIAN_API_TOKEN": "${env:ATLASSIAN_API_TOKEN}"
      }
    }
    // All P2/P3 servers remain commented out until needed
  }
}
```

---

## Your `.env.mcp` for Phases 1–3

```bash
# ============================================================
# AI-SDLC pilot — local MCP env vars
# NEVER commit this file. NEVER share this file.
# ============================================================

# P0 — GitHub (read-only)
GITHUB_PERSONAL_ACCESS_TOKEN=ghp_...

# P0/P1 — Atlassian: Jira (primary issue tracker) + Confluence (read-only)
ATLASSIAN_API_TOKEN=...
ATLASSIAN_SITE_URL=https://YOUR_ORG.atlassian.net
ATLASSIAN_EMAIL=you@yourorg.com

# Optional — Azure DevOps (NOT used in current pilot)
# Uncomment and fill only if ADO is added later:
# ADO_MCP_AUTH_TOKEN=...

# Optional — AWS S3 (artifact storage — limited read/write, no delete)
# Uncomment and fill when S3 phase is ready:
# AWS_ACCESS_KEY_ID=...
# AWS_SECRET_ACCESS_KEY=...
# AWS_REGION=eu-west-1
# AI_SDLC_S3_BUCKET=talentserv-ai-sdlc-pilot-artifacts
# AI_SDLC_S3_PREFIX=projects/
```

**Load it before launching Cursor:**

```bash
source .env.mcp
```

Or add to `~/.zshrc` / `~/.bash_profile` if you want it loaded automatically (only recommended if your machine disk is encrypted and appropriately secured).

---

## Full pilot readiness checklist

| MCP | Token created | Env var set | Read validated | Write-block confirmed | Ready |
|-----|--------------|------------|---------------|----------------------|-------|
| Filesystem | N/A | N/A | ⬜ | ⬜ | ⬜ |
| GitHub | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| Jira | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| Confluence | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| AWS S3 (optional) | ⬜ | ⬜ | ⬜ | ⬜ write-outside + delete | ⬜ |
| Azure DevOps | — | — | — | — | **Not used in current pilot** |

**An MCP is "Ready for pilot" when:**
- Its read validation query returns the expected data in Cursor chat
- Its write-block safety test fails with an error or refusal
- The env var is set and sourced before Cursor starts
- A rotation reminder is set for 90 days from today

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| MCP server does not appear in Cursor | Restart Cursor completely. Check for JSON syntax errors in `.cursor/mcp.json` (comments with `//` are valid in JSONC but some parsers reject them). |
| `${env:VAR_NAME}` not resolving | Source `.env.mcp` in the same shell session before launching Cursor, or set the vars in your shell profile. |
| GitHub: `Bad credentials` | Token is invalid or expired. Regenerate at `https://github.com/settings/tokens?type=beta`. |
| Jira: `401 Unauthorized` | Check `ATLASSIAN_EMAIL` matches the account that owns the API token. |
| Jira: no issue data returned | Confirm the issue key belongs to the correct Jira project and your account has read access to that project. |
| Confluence: `403 Forbidden` | Your account does not have read access to the Confluence space. Ask a Confluence admin to grant view permission. |
| npx: package install fails | Check Node version (`node --version` ≥ 18). Some MCP packages require a specific version — check the package README. |
| S3: `NoCredentialsError` | `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` are not set. Source `.env.mcp`. |
| S3: `AccessDenied` on valid prefix | Verify the IAM inline policy uses the exact bucket ARN. Check the prefix condition uses `StringLike` with `projects/*`. |
| Cursor chat does not use MCP | Confirm you are using a Cursor **Chat** window (not just the editor). MCP tools are available in chat with the model. |

---

## Optional appendix — Azure DevOps MCP (not used in current pilot)

Azure DevOps is not available for the current pilot. Use Jira as the primary issue tracker. Configure ADO only if it becomes available later.

**When ADO becomes available:**

1. Create a PAT at `https://dev.azure.com/{your-ado-org}/_usersSettings/tokens`
   - Scope: **Work Items (Read)**, **Project and Team (Read)** only — nothing else
   - Expiry: 90 days

2. Add to `.env.mcp`:
   ```bash
   ADO_MCP_AUTH_TOKEN=YOUR_ADO_PAT
   ```

3. Uncomment the `azure-devops` block in `.cursor/mcp.json`:
   ```jsonc
   "azure-devops": {
     "type": "stdio",
     "command": "npx",
     "args": ["-y", "@azure-devops/mcp", "{your-ado-org}", "--authentication", "envvar"],
     "env": {
       "ADO_MCP_AUTH_TOKEN": "${env:ADO_MCP_AUTH_TOKEN}"
     }
   }
   ```

4. Restart Cursor. Read validation:
   ```
   Read ADO work item {ID} including title, description, acceptance criteria, and comments.
   Do not update the work item.
   ```

5. Write-block test:
   ```
   Create an Azure DevOps work item titled "MCP write safety test" in the TalentServ project.
   ```
   Expected: error or permission denied. If a work item is created, revoke the PAT immediately.

**Note:** When both Jira and ADO are active, Jira remains the primary source for `REQUIREMENT`, `ACCEPTANCE_CRITERIA`, and `ISSUE_COMMENTS`. ADO provides supplementary work item context.
