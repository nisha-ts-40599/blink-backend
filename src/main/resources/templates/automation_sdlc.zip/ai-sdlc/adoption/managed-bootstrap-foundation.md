# Managed Bootstrap Foundation — Phase 5.1 Guide

> **Phase 5.1 implements the foundation and dry-run simulation layer only.**
> No real managed bootstrap execution is available in this phase.
> All actions remain preview/simulation mode. Real execution is Phase 5.2+.

---

## What Phase 5.1 does

Phase 5.1 establishes the governance runtime that will govern managed bootstrap execution in Phase 5.2+. It delivers:

- **Capability discovery** — read-only inspection of the local environment
- **Execution proposal generation** — deterministic, hash-bound, derived from the approved Phase 3 plan
- **G-BOOTSTRAP-EXEC approval validation** — a distinct approval gate binding exact proposal + action subset
- **Action policy classification** — every Phase 3 operation type mapped to a Phase 5.1 classification
- **Execution preview** — DRY RUN output showing what would happen
- **Simulation runtime** — non-authoritative simulation of action outcomes
- **Idempotency/retry/compensation policy evaluation** — machine-readable policy decisions
- **Audit event generation** — schema-valid append-only events

## What Phase 5.1 does not do

- **No real execution.** No project directories are created. No Git repositories are initialized. No remote repositories are created or contacted.
- **No authoritative completion evidence.** Simulation output cannot satisfy the Phase 4 completion requirement.
- **No readiness assertion.** No Phase 5.1 artifact can set `delivery_ready` or `existing_managed`.
- **No remote provider.** GitHub, GitLab, Azure DevOps, and Bitbucket adapters are not implemented.
- **No credentials.** No live credentials are used or stored.

---

## Capability versus authorization

These concepts are distinct. Understanding the separation is critical.

| Concept | Meaning | Phase 5.1 source |
|---------|---------|-----------------|
| **Capability** | Environment can *structurally support* an operation | `discover_local_capabilities()` |
| **Permission** | Environment has verified rights to perform the operation | Not verified in Phase 5.1 |
| **Action allowed by policy** | Operation type is on the managed preview allowlist | `action_policy.OPERATION_POLICY` |
| **Plan approval** | G-BOOTSTRAP gate — human reviewed and approved the plan content | `bootstrap-plan.schema.json approval.status` |
| **Managed execution approval** | G-BOOTSTRAP-EXEC gate — human approved this specific proposal and action subset | `approval_validation.validate_execution_approval()` |

**Capability ≠ permission ≠ policy allowance ≠ plan approval ≠ managed-execution approval.**

Capability discovery is **informational only**. It does not grant execution authorization.

---

## Plan approval versus G-BOOTSTRAP-EXEC

The Phase 3 plan approval (G-BOOTSTRAP gate) authorizes the *content* of the bootstrap plan — the operations to perform, their expected outputs, and the repository topology.

The G-BOOTSTRAP-EXEC approval (Phase 5 gate) is **separately required** and authorizes:
- This specific execution proposal (bound by proposal semantic hash)
- This specific subset of managed actions (bound by action ID list)
- This specific workspace root
- This specific adapter/provider selection

Plan approval alone does not permit simulation of managed actions. Both approvals are required.

---

## Proposal generation

An execution proposal is derived deterministically from:

```
approved bootstrap-plan.yaml
+ local capability profile
+ action policy version
+ selected execution mode
+ workspace root
→ execution proposal (hash-bound)
```

Every plan action appears exactly once in the proposal. No action is silently omitted.

The proposal semantic hash changes if any governance-relevant input changes (plan, capability profile, workspace, policy version, action classification).

---

## Action classifications

Every Phase 3 operation type maps to exactly one Phase 5.1 classification:

| Classification | Meaning |
|----------------|---------|
| `managed_preview` | Can be previewed/simulated in Phase 5.1; real execution in Phase 5.2 |
| `manual` | Human must perform; system generates instructions and fallback |
| `deferred` | Requires Phase 5.2+ provider implementation |
| `blocked` | Structurally prohibited (destructive safety class or prohibited operation) |
| `unsupported` | Unknown operation type; treated as manual |

**Managed preview operations (9):** `verify_tool_version`, `verify_workspace_path`, `create_directory`, `initialize_repository`, `configure_remote`, `leave_empty_repository`, `run_validation`, `verify_repository`, `handoff_to_existing_setup`

**Manual operations (3):** `manual_scaffold`, `create_remote_repository`, `push_initial_branch`

**Deferred operations (5):** `clone_repository`, `run_scaffold_command`, `clone_template_repository`, `install_dependencies`, `create_initial_commit`

---

## Preview

```bash
make ai-sdlc-managed-preview PROPOSAL=path/to/proposal.json PLAN=path/to/plan.json
```

Preview output:
- Contains `DRY RUN — NO ACTIONS WILL BE EXECUTED` banner
- Shows every action with classification, adapter, safety class, side effects, and expected outcomes
- Makes no changes to the workspace
- Produces no completion evidence

---

## Simulation

```bash
make ai-sdlc-managed-simulate \
  PROPOSAL=path/to/proposal.json \
  PLAN=path/to/plan.json \
  APPROVAL=path/to/approval.json
```

Simulation:
- Validates G-BOOTSTRAP-EXEC approval before running
- Produces `would_complete`, `would_skip_idempotent`, `would_require_manual_action`, `would_block`, `would_fail`, or `would_be_deferred` outcomes per action
- Every result contains `simulation: true`, `authoritative_execution_evidence: false`
- Cannot be used as Phase 4 completion evidence
- Cannot grant readiness

---

## Why simulation is not evidence

Simulated action results are structurally separated from authoritative completion evidence:

1. Schema: `authoritative_execution_evidence` is a `const: false` in `managed-bootstrap-action-result.schema.json`
2. Runtime: `assemble_completion_preview()` marks output `simulation_preview: true`
3. Validation: `validate_completion_for_persistence()` rejects any artifact with `simulation_preview: true`
4. Test: `test_simulated_completion_rejected` confirms even a fully-successful simulation cannot be persisted

---

## Manual and mixed-mode handling

Manual and deferred actions are **always preserved** in proposals and previews. The proposal carries `manual_fallback` for every action, ensuring human operators have clear instructions regardless of classification.

A mixed managed/manual execution plan:
- Groups actions by `ownership: managed | manual | deferred`
- Applies G-BOOTSTRAP-EXEC only to the managed subset
- Preserves manual actions for human attestation via the existing Phase 4 completion flow

---

## Idempotency

Idempotency keys are derived deterministically from:

```
plan_action_id + proposal_hash + adapter_id + target_identity + policy_version
```

The key is a 64-character lowercase SHA-256 hex string. Same inputs always produce the same key. The key changes if any input changes, making reruns safe to track.

Phase 5.1 evaluates idempotency strategies only — no real target checks are performed.

---

## Retry and compensation policy

Phase 5.1 evaluates retry and compensation policies without executing them.

**Retry rules:**
- Maximum 2 retry attempts for retryable failures
- Approval mismatch: non-retryable
- Permission denied: non-retryable until evidence changes
- Target conflict: manual review required

**Compensation prohibited for:**
- Destructive operations
- Remote deletion
- Force push
- Deletion of user-authored files

---

## Setup-state execution references

Phase 5.1 produces optional execution pointers (`current_proposal`, `current_run`) that can be stored under `bootstrap.execution` in setup-state. These are **informational only**:

- They do not grant approval
- They do not grant completion
- They do not advance readiness
- They do not satisfy the Phase 4 existing-* refresh requirement

The existing-* refresh remains mandatory regardless of simulation results.

---

## Existing-* refresh requirement

Phase 4 existing-* refresh validation is **not replaced or bypassed** by Phase 5.1. After any real managed execution (Phase 5.2+), the existing-* refresh must still be run to produce authoritative completion evidence.

---

## Phase 5.2 boundary

Phase 5.2 will enable real managed execution for `managed_preview`-classified actions on the local provider. This will require:

- Real implementation of `LocalFilesystemAdapter.execute_action()` and `LocalGitAdapter.execute_action()`
- Binary presence verification during capability discovery
- A second, execution-specific G-BOOTSTRAP-EXEC approval (not a simulation approval)
- Full execution evidence compatible with Phase 4 completion
- Setup-state schema extension for `bootstrap.execution` and `gates.g_bootstrap_exec`
