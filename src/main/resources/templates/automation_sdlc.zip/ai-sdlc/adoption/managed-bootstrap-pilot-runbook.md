# Managed Bootstrap — Controlled Pilot Runbook

Compact operator guide for **limited local pilots** on Phase 5 managed bootstrap.

Managed execution **persists completion evidence** via the production Phase 4 completion adapter. Phase 4 reconciliation and existing refresh remain the **only** authority for `delivery_ready`.

## Before you start

Confirm exclusions (no remote ops, no scaffolding, no package install, single-host only):

```text
.cursor/ai-sdlc/bootstrap-executions/   ← run artifacts
.cursor/ai-sdlc/setup-state.yaml        ← non-authoritative pointers
```

## Pilot A — New local repository (managed mutations)

### 1. Plan and gates (unchanged)

```bash
make ai-sdlc-generate-bootstrap-plan WRITE=1 ROOT=<workspace>
make ai-sdlc-approve-gate GATE=G-BOOTSTRAP ROOT=<workspace>
```

### 2. Phase 5.1 — proposal (no mutations)

```bash
make ai-sdlc-managed-capability-discovery ROOT=<workspace>
make ai-sdlc-managed-proposal PLAN=<plan.yaml> ROOT=<workspace>
make ai-sdlc-managed-proposal-validate PROPOSAL=<proposal.yaml> PLAN=<plan.yaml> ROOT=<workspace>
make ai-sdlc-managed-preview PROPOSAL=<proposal.yaml> PLAN=<plan.yaml> ROOT=<workspace>
```

### 3. G-BOOTSTRAP-EXEC approval

Create external approval binding plan hash, proposal hash/revision, approved action IDs, workspace root. Validate:

```bash
make ai-sdlc-managed-approval-validate \
  PROPOSAL=<proposal.yaml> APPROVAL=<approval.yaml> PLAN=<plan.yaml> ROOT=<workspace>
```

### 4. Execute (mutations)

Dry-run first:

```bash
make ai-sdlc-managed-execute ROOT=<workspace> PLAN=<plan> PROPOSAL=<proposal> APPROVAL=<approval>
```

Mutate:

```bash
make ai-sdlc-managed-execute ROOT=<workspace> PLAN=<plan> PROPOSAL=<proposal> APPROVAL=<approval> WRITE=1
```

**Success:** `execution-run.yaml` status `completed`; action results under `action-results/`.  
**Blocked:** inspect JSON findings; do not retry with same approval if consumed.

### 5. Completion handoff (current limitation)

Production path does **not** yet write validated `managed-bootstrap-completion.yaml`.  
For pilot readiness use **manual bootstrap completion** reporting, or wait for Phase 5 final closure adapter.

### 6. Phase 4 refresh (manual completion path)

```bash
make ai-sdlc-existing-refresh ROOT=<workspace> WRITE=1
make ai-sdlc-validate-setup-readiness ROOT=<workspace> REQUIRE=delivery
```

## Pilot C — Interrupted run recovery

```bash
# Read-only status
python ai-sdlc/tools/setup/managed_bootstrap/execute_managed_bootstrap.py \
  --mode status --root <workspace> --run-id <run-id>

# Acquire lease
python ai-sdlc/tools/setup/managed_bootstrap/execute_managed_bootstrap.py \
  --mode acquire-lease --root <workspace> --run-id <run-id> --owner-id <you>

# Resume
python ai-sdlc/tools/setup/managed_bootstrap/execute_managed_bootstrap.py \
  --mode resume --root <workspace> --plan <plan> --proposal <proposal> --approval <approval> \
  --run-id <run-id> --lease-id <lease-id> --owner-id <you> --write

# Release lease
python ai-sdlc/tools/setup/managed_bootstrap/execute_managed_bootstrap.py \
  --mode release-lease --root <workspace> --run-id <run-id> \
  --lease-id <lease-id> --owner-id <you>
```

**Takeover (expired lease only):**

```bash
python ai-sdlc/tools/setup/managed_bootstrap/execute_managed_bootstrap.py \
  --mode takeover --takeover --rationale "prior operator unavailable" \
  --root <workspace> --run-id <run-id> --owner-id <new-owner>
```

**Manual recovery (unknown outcome / drift):**

```bash
python ai-sdlc/tools/setup/managed_bootstrap/execute_managed_bootstrap.py \
  --mode mark-manual-recovery --root <workspace> --run-id <run-id> \
  --rationale "describe conflict"
```

## Common blocked outputs

| Finding | Meaning | Recovery |
|---------|---------|----------|
| `APPROVAL_ALREADY_CLAIMED` | Approval used by another run | Inspect original run; do not replay |
| `GIT_BOUNDARY_CONFLICT` | Target inside parent repo | Relocate target or use manual bootstrap |
| `GIT_STATE_CONFLICT` | Remote mismatch | Fix remote manually or update plan |
| `PATH_OUTSIDE_ALLOWED_ROOT` | Symlink/path escape | Remove symlink; restore workspace |
| `LEASE_NOT_HELD` | Resume without valid lease | Acquire or takeover lease |
| `DRIFT_CONFLICT` | Target changed since interruption | Manual recovery |
| `EXECUTION_MANUAL_RECOVERY_REQUIRED` | Unknown action outcome | Manual recovery; no auto-retry |
| `COMPLETION_VALIDATION_FAILED` | Phase 4 handoff blocked | Expected today for managed; use manual completion path |

## What never to do

- Second run with same G-BOOTSTRAP-EXEC approval
- `git push`, `fetch`, `clone`, or provider API calls
- Set `delivery_ready` directly in setup-state
- Resume without lease on a partially completed run
- Takeover while lease is still active

## References

- `ai-sdlc/adoption/managed-local-bootstrap-execution.md`
- `ai-sdlc/adoption/managed-bootstrap-recovery.md`
- `docs/operating-model/pilot-readiness-assessment.md`
