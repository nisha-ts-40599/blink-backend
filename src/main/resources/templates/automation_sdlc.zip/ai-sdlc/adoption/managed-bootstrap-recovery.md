# Managed Bootstrap Recovery — Operator Guide

Phase 5.3 governs same-run recovery for interrupted managed local bootstrap execution.

## Recovery lifecycle

```text
interrupted run detected
→ resume eligibility validation
→ lease acquisition (required for resume)
→ approval / claim / use / snapshot binding checks
→ drift assessment
→ completed-action re-verification
→ bounded retry or manual recovery
→ same-run continuation
→ completion candidate (Phase 4 validation only)
```

## Phase boundaries

| Phase | Responsibility |
|-------|----------------|
| 5.2 | Governed forward local execution |
| 5.3 | Same-run recovery, lease, resume, drift, retry, conservative compensation |
| Deferred | Remote/provider execution, scaffold, push, commit, deployment |

## When to use recovery

Use recovery when a run exists with status `running`, `partially_completed`, or `failed` and you need to continue without creating a new run or replaying approval.

## Recovery workflow

```text
1. Inspect status (read-only)
   execute_managed_bootstrap.py --mode status --root <workspace> --run-id <run-id>

2. Acquire lease
   execute_managed_bootstrap.py --mode acquire-lease --root <workspace> --run-id <run-id> --owner-id <you>

3. Resume with lease
   execute_managed_bootstrap.py --mode resume --root <workspace> --plan ... --proposal ... --approval ... \
     --run-id <run-id> --lease-id <lease-id> --owner-id <you> --write

4. Release lease when done
   execute_managed_bootstrap.py --mode release-lease --root <workspace> --run-id <run-id> \
     --lease-id <lease-id> --owner-id <you>
```

## Takeover (explicit only)

When a prior operator's lease is stale but work must continue:

```text
execute_managed_bootstrap.py --mode takeover --takeover --rationale "operator unavailable" \
  --root <workspace> --run-id <run-id> --owner-id <new-owner>
```

## Manual recovery

When drift, unknown outcomes, or conflicting state block resume:

```text
execute_managed_bootstrap.py --mode mark-manual-recovery --root <workspace> --run-id <run-id> \
  --action-id <optional> --rationale "describe conflict"
```

## Lease coordination (single-host)

Lease transitions use a **local file transition lock** (`run-lease.transition.lock`) scoped to each run directory. This coordination is **single-host and local only** — it is not distributed locking and does not make multi-host concurrent execution safe.

If a transition lock persists unexpectedly after a crash or killed process, do **not** delete it while another operator or process may still be executing the same run. Confirm no active managed execution holds the run, then remove `run-lease.transition.lock` manually and retry the lease operation.

## What recovery never does

- Create a new run ID
- Regenerate approval claim
- Replay consumed approval
- Broaden approved actions
- Set `delivery_ready`

## Completion

After successful continuation, Phase 4 completion validation remains the readiness authority.
