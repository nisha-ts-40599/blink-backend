# Managed Local Bootstrap Execution (Phase 5.2)

Phase 5.2 implements **approved local forward-only managed execution** for greenfield bootstrap. It is distinct from Phase 5.1 preview/simulation.

## Phase boundaries

| Phase | Capability |
|-------|------------|
| **5.1** | Capability discovery, proposal, preview, simulation — **non-authoritative** |
| **5.2** | G-BOOTSTRAP-EXEC gated local execution, authoritative action evidence, completion candidate |
| **5.3** | Recovery, resume, lease, drift, retry hardening, conservative compensation — see [`managed-bootstrap-recovery.md`](managed-bootstrap-recovery.md) |

## Managed allowlist (Phase 5.2)

| Operation | Adapter | Mutation |
|-----------|---------|----------|
| `verify_tool_version` | local-filesystem-v1 | No |
| `verify_workspace_path` | local-filesystem-v1 | No |
| `create_directory` | local-filesystem-v1 | Yes |
| `initialize_repository` | local-git-v1 | Yes |
| `configure_remote` | local-git-v1 | Yes (local config only) |
| `leave_empty_repository` | local-filesystem-v1 | No |
| `run_validation` | validation registry | No |
| `verify_repository` | local-git-v1 | No |
| `handoff_to_existing_setup` | handoff-v1 | No |
| `initialize_control_checkout` | workspace-control-v1 | Yes |
| `write_workspace_manifest` / `validate_workspace_manifest` | workspace-control-v1 | Write / No |
| `write_product_workspace_pointer` / `validate_product_workspace_pointer` | workspace-control-v1 | Write / No |
| `update_manifest_actual_state` / `commit_control_*` | workspace-control-v1 | Yes |
| `create_control_repository` | workspace-control-v1 | Provider (manual classification; G-BOOTSTRAP) |

**Still manual or deferred:** product remote push, scaffolding, dependency installation, initial product commit (unless explicitly approved), cloud/provider operations beyond control-repo stub.

## Workspace-control bootstrap actions

Greenfield specs may define `control_plane.mode` (`separate-repository` | `embedded-single-repo`). Bootstrap plan generation inserts control-plane actions into `shared_prerequisites` (not product dependency graphs). Remote actions set `prohibited_in_phase_3: true` — they cannot run during plan generation or pre-G-BOOTSTRAP phases. Evidence accumulates in `.cursor/ai-sdlc/scaffold-records/workspace-control-bootstrap-evidence.yaml`.


Managed execution requires independent **G-BOOTSTRAP-EXEC** approval binding:

- `plan_content_hash`
- `approved_proposal_hash`
- `proposal_revision` (mandatory)
- `approved_action_ids`
- `workspace_root`
- `policy_version`

G-PLAN and G-BOOTSTRAP do **not** grant execution permission.

## Transaction boundary

1. Validate plan, proposal, and G-BOOTSTRAP-EXEC approval
2. Atomically publish execution run (`created`)
3. Atomically claim approval (`claimed`)
4. Transition `validated` → `running`
5. First target mutation → approval `consumed`
6. Execute remaining approved actions
7. Generate completion candidate → Phase 4 validation via production adapter

Cross-filesystem atomicity is **not** claimed. Run directory publication uses temp-sibling rename where supported.

## Stage eligibility

Stage routing recognizes `MANAGED_BOOTSTRAP_EXECUTION` and `MANAGED_BOOTSTRAP_COMPLETION` for managed bootstrap work items.

## Phase 4 handoff

After managed execution completes:

```text
completion-candidate.yaml
→ phase4_completion_adapter (production)
→ managed-bootstrap-completion.yaml
→ write_completion_artifact / existing refresh (operator)
→ delivery_ready (Phase 4 authority only)
```

Production persistence is validated in `make ai-sdlc-phase5-final-closure-test`.

## CLI

```bash
# Validate only (no mutations)
make ai-sdlc-managed-execute ROOT=<path> PLAN=<plan> PROPOSAL=<proposal> APPROVAL=<approval>

# Execute (mutations)
make ai-sdlc-managed-execute ROOT=<path> PLAN=<plan> PROPOSAL=<proposal> APPROVAL=<approval> WRITE=1

# Preview (JSON proposal file)
make ai-sdlc-managed-preview ROOT=<path> PLAN=<plan> PROPOSAL=<proposal.json>

# Operator status (read-only)
make ai-sdlc-bootstrap-operator-status ROOT=<path> ISSUE=<issue>

# Publish completion candidate (Phase 5 — does not set delivery_ready)
make ai-sdlc-publish-bootstrap-completion ROOT=<path> RUN_ID=<run-id> WRITE=1

# Phase 4 reconciliation (delivery readiness authority)
make ai-sdlc-reconcile-bootstrap-completion ROOT=<path> WRITE=1

# Legacy status CLI
python ai-sdlc/tools/setup/managed_bootstrap/execute_managed_bootstrap.py --mode status --root <path> --run-id <id>
```

## H11 operator command spine (managed local route)

| Step | Command |
|------|---------|
| Plan | `/generate-bootstrap-plan` |
| Approve design | `make ai-sdlc-approve-gate GATE=G-BOOTSTRAP` |
| Proposal | `make ai-sdlc-managed-proposal` |
| Approve execution | `make ai-sdlc-managed-approval-validate` + G-BOOTSTRAP-EXEC |
| Preview | `/preview-managed-bootstrap` |
| Execute | `/execute-managed-bootstrap` |
| Status | `/bootstrap-operator-status` |
| Publish candidate | `/publish-bootstrap-completion` |
| Reconcile (Phase 4) | `/reconcile-bootstrap-completion` |

Manual bootstrap uses `/generate-manual-bootstrap` after G-BOOTSTRAP only — G-BOOTSTRAP-EXEC is not required.

**Cursor-assisted scaffold** (dependency install, CI templates, initial commit) is outside the managed allowlist. Interactive setup documents the display → confirm → execute pattern in [`interactive-greenfield-setup.md`](interactive-greenfield-setup.md).

## Network enforcement

```yaml
network_enforcement: command_policy_only
```

Network-capable Git subcommands (`fetch`, `pull`, `push`, `clone`, etc.) are rejected by central command policy. No OS-level network sandbox is claimed.

## Operator guidance

| Situation | Action |
|-----------|--------|
| Approval already claimed | Inspect `bootstrap-executions/<run-id>/` status; do not create a second run |
| Partial run | Review action evidence; complete remaining actions manually if mixed |
| Verification failure | Do not treat as completion; investigate target state |
| Conflicting target state | Fail closed; manual recovery required |
| After managed completion | **Mandatory** existing-* refresh before `delivery_ready` |

## Artifact layout

```text
bootstrap-executions/<run-id>/
  execution-run.yaml
  approval-claim.yaml
  approval-consumption.yaml
  action-results/<action-id>.yaml
  audit-events.jsonl
  completion-candidate.yaml
  managed-bootstrap-completion.yaml
```
