# Manual Bootstrap Reconciliation (Phase 4)

Phase 4 formalizes the transition from desired state through planned bootstrap, approved manual instructions, reported completion, detected repository state, and existing-* reconciliation.

## Core principle

> Manual completion evidence records what a person reports. Existing-* refresh establishes what the framework detects.

Completion evidence **never** grants `context_ready` or `delivery_ready` by itself.

## State layers

| Layer | Source |
|-------|--------|
| **Desired** | `greenfield-project-spec.yaml` |
| **Planned** | Approved `bootstrap-plan.yaml` |
| **Reported** | `manual-bootstrap-completion.yaml` |
| **Detected** | Existing-* refresh (filesystem/Git discovery with explicit provenance) |
| **Reconciled** | `bootstrap-reconciliation-result.yaml` |

## Recording manual completion

1. Complete manual bootstrap actions from the approved instruction package.
2. Fill structured completion evidence using `manual-bootstrap-completion.template.yaml`.
3. Store under append-only package path:

```text
.cursor/ai-sdlc/setup/bootstrap/<plan-id>/completions/<completion-id>/
├── manual-bootstrap-completion.yaml
└── completion-metadata.json
```

4. Validate:

```bash
make ai-sdlc-validate-bootstrap-completion COMPLETION=<path> PLAN=<path> STRICT=1
```

Completion must bind to exact `plan_id`, `plan_revision`, plan semantic hash, and instruction hash.

## Reconciliation via existing-* refresh

Permanent owner: `/setup-existing-project refresh` or `/setup-existing-workspace refresh`.

```bash
make ai-sdlc-compare-bootstrap-state ROOT=<root> PLAN=<path> SPEC=<path> COMPLETION=<path> WRITE=1
make ai-sdlc-generate-bootstrap-verification-report RECONCILIATION=<path> SETUP_STATE=<path> OUTPUT=<path>
make ai-sdlc-validate-setup-readiness ROOT=<root> REQUIRE=delivery
```

## Discrepancy classifications

`matched`, `missing`, `unexpected`, `deviated`, `conflicting`, `not_verifiable`, `reported_only`, `detected_only`, `blocked`, `needs_human_review`.

Blocking discrepancies prevent delivery readiness.

## Setup-state authority model

`setup-state.yaml` tracks authoritative pointers:

```yaml
bootstrap:
  current_plan:
    plan_id: ...
    plan_hash: ...
  plan_history: [...]
  completion:
    current_completion_id: ...
  reconciliation:
    last_result_id: ...
  verification:
    existing_refresh_required: true
```

Legacy `bootstrap_plan_ref` is migrated via `migrate_legacy_bootstrap_refs()`.

## Supersession and history

- Semantic plan hash binds approved content; supersession is lifecycle bookkeeping.
- Superseded plans reject new completion evidence.
- Replacement plans require new plan ID, revision, hash, and approval.
- Historical artifacts remain append-only.

## Lifecycle transitions

Machine-enforced via `validate_setup_transition()`:

```text
manual_execution_complete_unverified → verification_required → existing_managed
```

Forbidden: skipping refresh, granting readiness from completion, re-entering greenfield from `existing_managed` without reset.

## Recovery from partial bootstrap

1. Record accurate completion evidence (including failures/deviations).
2. Run existing-* refresh to detect actual state.
3. Review verification report and resolve blocking discrepancies.
4. Obtain deviation approval where required.
5. Re-run readiness validation.

## Phase 4B governance (High-finding closure)

### Detected state is independently observed

Setup-state values (`default_branch`, `scaffold_status`, `baseline_validation_status`) are **configured or historical** — they are never copied into detected output. The filesystem detector (`detected_state_common.py`) labels each field with a classification:

`detected`, `reported`, `configured`, `expected`, `inferred`, `not_verifiable`.

`not_verifiable` does **not** mean success — it means Phase 4 cannot independently confirm the fact without execution or network access.

### Filesystem-only capability limits

Phase 4 detection may safely observe path existence, `.git` directory presence, scaffold marker files, and (read-only) `.git/HEAD` / `.git/config` parsing. It does **not** verify remotes over the network, dependency correctness, build/test success, or cloud resources.

### Reconciliation authority

Reconciliation results expose derived `authority.readiness_eligible` — not a caller assertion. Production readiness requires:

- validated completion evidence;
- detected state with `trust_level: independently_observed`;
- current plan and completion binding;
- zero blocking reconciliation items.

Fixture or caller-supplied detected state may be used in tests but cannot grant production readiness.

### Completion persistence boundary

`write_completion_artifact()` invokes canonical semantic validation before any directory creation. Invalid completion cannot be persisted via direct library calls.

### Secret scanning

Completion secret scanning remains heuristic — treat findings as advisory/blocking per policy, not cryptographic assurance.

### Phase 5

Richer provider-backed detection may be added under explicit capability and security controls.

## Phase 5 compatibility

Managed execution will produce completion evidence using the same schema and reconciliation model.
