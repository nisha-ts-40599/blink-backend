# Manual Greenfield Bootstrap (Phase 3)

Planning and instruction generation for greenfield repository bootstrap — **no execution**.

Related: [`greenfield-project-specification.md`](greenfield-project-specification.md), [`project-delivery-readiness.md`](project-delivery-readiness.md)

## Purpose

Phase 3 converts a validated `greenfield-project-spec` into:

```text
.cursor/ai-sdlc/setup/bootstrap/<plan-id>/
├── bootstrap-plan.yaml          # canonical machine contract
├── bootstrap-plan.md            # human plan review
├── manual-bootstrap-instructions.md
├── manual-bootstrap-completion.md
└── package-metadata.json
```

## Artifact flow

```text
greenfield-project-spec.yaml
  → validate_greenfield_spec
  → generate_bootstrap_plan
  → bootstrap-plan.yaml
  → validate_bootstrap_plan
  → G-BOOTSTRAP plan approval
  → generate_manual_bootstrap_instructions --write   # final only when approved
  → manual-bootstrap-instructions.md
  → user executes externally
  → existing-* refresh
  → setup-readiness validation
```

## Approval and preview modes

| Mode | CLI | When allowed | Output |
|------|-----|--------------|--------|
| **Preview** | `--preview` (stdout) or `--preview-output <path>` | Any plan that fails `validate_final_instruction_eligibility()` | Banner: `PREVIEW ONLY — DO NOT EXECUTE` |
| **Final write** | `--write --output <path>` | Passes all checks in `validate_final_instruction_eligibility()` | Approved instruction file (no preview banner) |

Preview and final modes share **one canonical eligibility evaluator** — partial approval states always render as preview even when some approval metadata is present.

Final instruction writing **requires G-BOOTSTRAP approval** recorded in the plan. Unapproved plans cannot use `--write`; preview is non-executable.

Superseded plans cannot generate new final packages (`PLAN_SUPERSEDED`).

## Structured operations vs rendered commands

`bootstrap-plan.yaml` stores **structured operations** (`operation.type`, `operation.category`, `parameters`) as the canonical intent. Shell commands appear only in the derived instruction pack, except approved scaffold commands preserved as `preserved_scaffold_command`.

## Planned, reported, detected

| Layer | Source | Runtime-validated in Phase 3? |
|-------|--------|:-----------------------------:|
| Planned | greenfield spec + bootstrap plan | Yes (planner + validator) |
| Reported | manual-bootstrap-completion.md (user evidence) | **Artifact model only** — no parser yet |
| Detected | existing-* refresh + setup-readiness validator | Phase 1/2 tools (not full comparison engine) |

Manual completion never grants `delivery_ready`. Complete planned/reported/detected comparison is deferred to Phase 4.

## Plan immutability

- Draft plans may be regenerated before approval.
- After approval, set `immutable_after_approval: true` and record `approval.approved_plan_hash`.
- Spec changes require a new `plan_revision` — do not edit approved plans.
- A new revision **does not inherit** a prior revision's approval hash.

## Plan supersession (lifecycle bookkeeping)

Supersession fields (`status`, `supersedes_plan_id`, `superseded_by_plan_id`) are **lifecycle bookkeeping**, not part of the semantic plan content hash. This is intentional:

- The **semantic hash** binds approved plan **content** (actions, order, handoff, repositories).
- **Approval metadata is retained** on superseded files for audit history.
- A superseded on-disk plan may therefore show both historical approval fields and `status: superseded`.
- **Final instruction packages cannot be generated** from superseded plans (`PLAN_SUPERSEDED`).
- Rendered output for superseded plans uses **`HISTORICAL PLAN — DO NOT EXECUTE`**, not a preview banner.
- A replacement plan requires a **new plan ID**, **new plan revision**, **new semantic hash**, and **new G-BOOTSTRAP approval**.

Phase 4 should move authoritative “current plan” ownership to **append-only plan artifacts** plus setup-state / current-plan pointers rather than in-place mutation of approved YAML.

Preview and final rendering both derive eligibility from the same canonical evaluator: `validate_final_instruction_eligibility()` (via `is_plan_approved_for_manual_execution()`).

## Semantic hash chain

**Compatibility note:** Phase 1/2 greenfield spec hashes remain `sha256-prefix16` (16 hex chars). Phase 3 bootstrap plans use **full SHA-256** (64 hex chars) for governance comparisons.

Plan semantic hash excludes volatile fields: `plan_id`, `generated_at`, `status`, approval metadata, supersession bookkeeping, and the stored hash itself.

```text
spec content_hash (prefix16) → plan source_spec_hash → plan content_hash (full sha256) → instruction hash (full sha256)
```

`content_hash_display` (optional 16-char prefix) may be shown in human review output.

Setup-state stores references and hashes only.

## Output boundaries

Writes are confined to an explicitly approved root (default conceptually `.cursor/ai-sdlc/setup/bootstrap/` under the workspace). Path traversal and writes outside the allowed root are rejected (`OUTPUT_PATH_OUTSIDE_ALLOWED_ROOT`).

Dry-run (no `--write`) creates **no files**.

## Lifecycle

```text
plan_ready → approval_required → instruction_pack_generated → manual_action_required
→ manual_execution_in_progress → manual_execution_complete_unverified → existing-* refresh
```

`instruction_pack_generated` is a setup-state lifecycle value distinguishing plan approval from manual execution.

## Commands

```bash
# Plan generation (dry-run default)
make ai-sdlc-generate-bootstrap-plan SPEC=<spec>
make ai-sdlc-generate-bootstrap-plan SPEC=<spec> OUTPUT_DIR=<dir> WRITE=1

# Validation
make ai-sdlc-validate-bootstrap-plan PLAN=<plan> SPEC=<spec>

# Preview instructions (unapproved OK)
python ai-sdlc/tools/setup/generate_manual_bootstrap_instructions.py --plan <plan> --preview

# Final instructions (requires approval)
make ai-sdlc-generate-manual-bootstrap PLAN=<plan> OUTPUT=<path> WRITE=1
```

## Limitations

- No repository creation, Git writes, scaffold execution, or deployment by the framework
- No MCP or network access required
- Managed bootstrap execution deferred to Phase 4–5
- Provider-neutral — no invented clone URLs or provider CLI assumptions
- Manual completion evidence template is supported; **runtime validation** of completion evidence is Phase 4
- Semantic lifecycle transition enforcement beyond schema enums is Phase 4
