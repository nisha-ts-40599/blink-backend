# MCP configuration guide

## Wrapper

All generated MCP servers should invoke:

```text
<framework-root>/scripts/mcp-npx.sh
```

The wrapper:

1. Resolves `FRAMEWORK_ROOT` from `scripts/` location.
2. Resolves `WORKSPACE_ROOT` (parent of framework checkout, or `AI_SDLC_WORKSPACE_ROOT`).
3. Loads secrets from `AI_SDLC_MCP_ENV_FILE`, then `<framework-root>/.env.mcp`, then legacy `<workspace-root>/.env.mcp`.
4. Exports `AI_SDLC_FRAMEWORK_ROOT` and `AI_SDLC_WORKSPACE_ROOT`.
5. Resolves Node via `AI_SDLC_NODE_BIN`, `AI_SDLC_NODE_HOME`, or `command -v node`.
6. Runs `npm exec` from the workspace root.
7. Does **not** log full argv (set `AI_SDLC_MCP_WRAPPER_LOG=1` for redacted invocation metadata only).

## Generated mcp.json

- Uses `${env:VARIABLE_NAME}` for secrets (Cursor env interpolation).
- Derives absolute paths to the wrapper from detected framework root.
- Merges with existing servers; preserves unmanaged entries by default.
- Writes `.cursor/mcp.json.bak` before overwrite when `WRITE=1`.

Machine-specific `mcp.json` is normally **not** committed to the workspace control repository.

## Environment example

`make ai-sdlc-configure-integrations ROOT=... WRITE=1` updates `<framework-root>/.env.mcp.example` but **never** overwrites `.env.mcp`.
