# MCP Integration Readiness Matrix

**Framework:** AI-SDLC / DeliveryMind AI Pilot  
**Last updated:** 2026-06-18  
**Scope:** Read-only MCPs by default. AWS S3 is the only integration with controlled write access — limited to a dedicated pilot bucket/prefix for AI-SDLC artifact storage. No autonomous deployment, messaging, or data mutation.

> See `ai-sdlc/mcp/mcp-security-guidelines.md` for security controls, token handling, and data sensitivity rules.  
> See `ai-sdlc/adoption/mcp-validation-checklist.md` for per-MCP read/write-block validation queries.  
> See `ai-sdlc/mcp/mcp-env.example` for required environment variables.

---

## Readiness matrix

| MCP | Purpose in AI-SDLC | Initial mode | Auth method | Required env vars | Data it can provide | Prompts helped | Write risk | Pilot status |
|-----|-------------------|--------------|-------------|-------------------|---------------------|----------------|------------|--------------|
| **Filesystem** | Read project source files, configs, migrations, test files | Read-only | None (workspace path only) | None | `REPOSITORY_CONTEXT`, `RELEVANT_FILES`, `EXISTING_TESTS`, `DEPENDENCY_MANIFEST`, `CURRENT_STEP` (plan doc) | implement-step, self-review, generate-tests, impact-analysis | None — local only | ✅ Active |
| **GitHub** | Read PRs, CI status, issues, merged PR list | Read-only | Fine-grained PAT | `GITHUB_PERSONAL_ACCESS_TOKEN` | `PR_CONTEXT`, `DIFF_CONTENT`, `REVIEW_COMMENTS`, `RECENT_CI_STATUS`, `RECENT_CHANGES`, `DEPLOYMENT_SUMMARY`, `MERGED_PRS` | pr-review, self-review, stage-router, release-verification, cve-triage | PAT must have no write scopes | ✅ Active |
| **Jira** | Read issues, ACs, comments, epics, linked issues — **primary issue tracker for this pilot** | Read-only | API token (read scope) | `ATLASSIAN_API_TOKEN`, `ATLASSIAN_SITE_URL`, `ATLASSIAN_EMAIL` | `REQUIREMENT`, `ACCEPTANCE_CRITERIA`, `ISSUE_COMMENTS`, `ISSUE_STATUS`, `LINKED_ISSUES` | clarify-requirement, classify-work, impact-analysis, bug-triage | Token scope must be read-only | ✅ Active (P0 for current pilot) |
| **Azure DevOps** | Read work items, acceptance criteria, comments, sprint status | Read-only | PAT (read-only) | `ADO_MCP_AUTH_TOKEN` | `REQUIREMENT`, `ACCEPTANCE_CRITERIA`, `ISSUE_COMMENTS`, `BUG_REPORT` | clarify-requirement, classify-work, impact-analysis, bug-triage | PAT must have read-only work item scope | ⚠️ Not available in current pilot — alternative to Jira |
| **AWS S3** | Artifact storage: context bundles, prompt outputs, technical plans, impact analysis, release readiness, pilot metrics | Controlled read/write to dedicated pilot bucket/prefix only | IAM user/role with least-privilege inline policy | `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_REGION`, `AI_SDLC_S3_BUCKET`, `AI_SDLC_S3_PREFIX` | `AVAILABLE_ARTIFACTS`, `TECHNICAL_PLAN`, `IMPACT_ANALYSIS`, `RELEASE_PLAN`, `DEPLOYMENT_CHECKLIST`, `RUNBOOK`, `PILOT_METRICS`, `CONTEXT_BUNDLE_ARCHIVE` | impact-analysis, technical-plan, implement-step, pr-review, release-verification, runbook-draft, monitoring-interpretation | Artifact overwrite; accidental sensitive data upload; retention gaps — no delete permission in pilot | 📋 Ready to configure |
| **Confluence** | Read architecture docs, ADRs, runbooks, design decisions | Read-only | API token (read scope) | `ATLASSIAN_API_TOKEN`, `ATLASSIAN_SITE_URL`, `ATLASSIAN_EMAIL` | `ARCHITECTURE_CONTEXT`, `EXISTING_RUNBOOK`, `TECHNICAL_PLAN_REFERENCE` | technical-plan, impact-analysis, runbook-draft | Token scope must be read-only | 📋 Ready to configure |
| **Slack** | Search messages for work item context and team decisions | Read-only | Bot token (read scopes) | `SLACK_BOT_TOKEN`, `SLACK_TEAM_ID` | `HUMAN_NOTES` supplement (manually confirmed), stakeholder discussion context | clarify-requirement (supplement), bug-triage | Must not send messages during pilot | 📋 Ready to configure |
| **Microsoft Teams** | Search messages/meeting notes for work item decisions | Read-only | Azure AD app token | `MICROSOFT_TENANT_ID`, `MICROSOFT_CLIENT_ID`, `MICROSOFT_CLIENT_SECRET` | `HUMAN_NOTES` supplement (manually confirmed), approval discussion evidence | clarify-requirement (supplement) | Must not send messages during pilot | 📋 Ready to configure |
| **Outlook / M365 Mail** | Search mail threads for approval or clarification evidence | Read-only | Azure AD app token (mail.read) | `MICROSOFT_TENANT_ID`, `MICROSOFT_CLIENT_ID`, `MICROSOFT_CLIENT_SECRET` | `HUMAN_NOTES` supplement (manually confirmed) | clarify-requirement (supplement) | Must not send email during pilot | 📋 Ready to configure |
| **MongoDB Atlas** | Read collection structure, schema, and index info | Read-only | Atlas API key (read-only) | `MONGODB_URI`, `MONGODB_ATLAS_PROJECT_ID` | `ARCHITECTURE_CONTEXT` supplement (DB schema), `REPOSITORY_CONTEXT` (data model) | technical-plan, impact-analysis | Must not mutate data or create indexes | 📋 Ready to configure |
| **Docker Hub** | Read image tags, repository list, build metadata | Read-only | Personal access token (read-only) | `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN` | `DEPENDENCY_MANIFEST` supplement (base image tags), `DEPLOYMENT_SUMMARY` supplement | cve-triage, release-verification | Must not delete or push images | 📋 Ready to configure |
| **Render** | Read service status, latest deployment info | Read-only | Render API key (read-only) | `RENDER_API_KEY` | `DEPLOYMENT_SUMMARY`, `MONITORING_SIGNALS` supplement (deploy logs) | release-verification, monitoring-interpretation | Must not trigger deploy or restart | 📋 Ready to configure |
| **Vercel** | Read project deployments, environment config names | Read-only | Vercel token (read-only) | `VERCEL_TOKEN` | `DEPLOYMENT_SUMMARY`, `RECENT_CI_STATUS` supplement | release-verification, monitoring-interpretation | Must not trigger deployment or change env vars | 📋 Ready to configure |
| **Figma** | Read design specs, component names, screen flows | Read-only | Personal access token | `FIGMA_ACCESS_TOKEN` | `ARCHITECTURE_CONTEXT` supplement (UI context for frontend), impact surface | implement-step (frontend), impact-analysis | Design write operations must fail | 🗓️ Planned (frontend phase) |
| **Observability (Datadog/Grafana)** | Read live error rates, latency, alert state | Read-only | Read-only API key | Platform-specific | `MONITORING_SIGNALS`, `STACK_TRACE` | monitoring-interpretation, release-verification | Alert mutations must not occur | 🗓️ Planned (post-deploy phase) |
| **Security Scanner (Snyk/CodeQL)** | Read CVE findings, SAST results | Read-only | Read-only API key | Platform-specific | `AUDIT_OUTPUT`, CVE findings | cve-triage, pr-review (security supplement) | No suppression/dismiss during pilot | 🗓️ Planned (security phase) |

---

## Priority tiers

### P0 — Active now (current pilot configuration)

| MCP | Why P0 |
|-----|--------|
| Filesystem | Core context — all local file reads, zero auth required |
| GitHub | PR diff, CI status — highest-ROI for code review prompts |
| Jira | **Primary issue tracker for this pilot** — requirement intake, ACs, comments, linked issues |

> **Azure DevOps:** Not available in the current pilot. ADO is documented as an alternative for when it becomes available. See the optional appendix in `local-mcp-setup-guide.md`.

### P1 — Configure next in expanded pilot

| MCP | Why P1 | When to add |
|-----|--------|-------------|
| Confluence | Architecture context, runbook reference — reduces ARCHITECTURE_CONTEXT manual paste | When ADRs and architecture docs are in Confluence |
| AWS S3 | Artifact storage for context bundles, prompt outputs, plans — enables shared team artifact access and pilot metric collection | After core flow validated; requires IAM policy and dedicated pilot bucket |
| Slack | Team decisions and context for PHI/security discussions | After core flow validated |

### P2 — Configure in second expansion

| MCP | Why P2 | When to add |
|-----|--------|-------------|
| Microsoft Teams | Approval discussion evidence for audit trail | When team uses Teams for decision-making |
| Outlook | Approval email threads for governance evidence | When approvals come via email |
| MongoDB Atlas | DB schema context for impact analysis | When adding or changing data models |
| Docker Hub | Base image CVE triage | When container CVE triage is needed |
| Render / Vercel | Deployment status in release-verification | When verifying deployment post-merge |

### P3 — Deferred to later phases

| MCP | Reason for deferral |
|-----|---------------------|
| Figma | Frontend phase only — not needed for backend/API work |
| Observability | Production monitoring — requires PHI data review before enabling |
| Security Scanner | Requires scanner integration decision first |

---

## Classification key

| Symbol | Meaning |
|--------|---------|
| ✅ Active | Configured in `.cursor/mcp.json`, validated in Cursor chat |
| 📋 Ready to configure | Config template available; env vars documented; no blockers |
| ⚠️ Not available | Not used in the current pilot; keep commented out |
| 🗓️ Planned | Design documented; config template not yet written |
| ⛔ Blocked | Security review, data sensitivity, or governance decision required first |
| 🚫 Not needed | Not applicable to current pilot scope |

---

## Non-negotiable pilot rules

1. **Read-only in all MCPs during pilot except AWS S3** — S3 allows controlled read/write to the dedicated pilot bucket/prefix only; no delete permission; no access outside `AI_SDLC_S3_PREFIX`
2. **Write-block safety test required before using any MCP for real work** — see `mcp-validation-checklist.md`
3. **Human gates (G-PLAN, G-SEC, G-PR-MERGE, G-DEPLOY) are never populated from any MCP** — always workflow-state only
4. **APPROVAL_RECORDS is never auto-populated from messaging MCPs** — even if Slack/Teams show an approval message
5. **Production databases (MongoDB Atlas) must not be connected during early pilot** — use dev/staging only
6. **Production deployment services (Render, Vercel) must be read-only** — no deploy triggers
7. **Messaging MCPs (Slack, Teams, Outlook) must not send messages** — read context only, and all imported content must be manually confirmed before use
