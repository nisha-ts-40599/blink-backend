# MCP Setup Checklist

Step-by-step checklist for configuring each MCP server with Cursor AI-SDLC.
Configure MCPs in the sequence shown — GitHub read first, others when ready.

> **Full setup guides:** See `ai-sdlc/mcp/` for detailed per-integration documentation.
> `.cursor/mcp.json` is **local-only** — never commit it to the repository.
> Use `.cursor/mcp.example.json` (committed) as the template.

---

## GitHub read-only MCP — configure now

This is the highest-ROI MCP. Once active, Cursor auto-fills `{{REPOSITORY_CONTEXT}}`,
`{{PR_CONTEXT}}`, and CI status instead of requiring manual paste.

### Required PAT permissions

Create a **fine-grained personal access token** at
`https://github.com/settings/tokens?type=beta` with **read-only** permissions:

| Permission | Why |
|-----------|-----|
| Contents | Read files and repo structure |
| Issues | Read issue bodies and comments |
| Pull requests | Read PR diffs and review comments |
| Actions | Read workflow run status |
| Metadata | Required by all fine-grained PATs |

**Do NOT grant:** write permissions, administration, secrets, environments, or webhooks.

### Configuration checklist

- [ ] Generate fine-grained PAT (read-only, expires in 90 days, scoped to specific repos)
- [ ] Copy `.cursor/mcp.example.json` to `.cursor/mcp.json` (local only — in `.gitignore`)
- [ ] Replace `REPLACE_WITH_YOUR_GITHUB_PAT` in `.cursor/mcp.json` with your PAT
- [ ] Restart Cursor to pick up the MCP config change
- [ ] In Cursor chat, ask: *"List the open issues in {your-repo}"* — should return issue list
- [ ] In Cursor chat, ask: *"Read the file app/main.py"* — should return file contents
- [ ] Run the write-block safety test (see below)

### Write-block safety test

Before using MCP for any AI-SDLC work, confirm it is read-only:

```
In Cursor, ask: "Create a new issue in {repo} titled 'MCP write test'"
```

Expected result: error or refusal — the PAT has no write permission. If a new issue appears on
GitHub, your PAT has too many permissions. Revoke it immediately and regenerate read-only.

### Prompts that improve most with GitHub read MCP

| Prompt | What becomes automatic |
|--------|----------------------|
| `clarify-requirement` | Issue body + comments |
| `impact-analysis` | Directory structure, relevant source files |
| `implement-step` | Relevant source files, existing patterns |
| `self-review` | Branch diff |
| `pr-review` | Full PR diff + existing comments |
| `stage-router` | CI job statuses |
| `release-verification` | CI results, merged PR list |

### Rotate the PAT

Set a reminder to rotate your PAT at the expiry date. PATs should expire in 90 days maximum.
Do not use tokens with no expiry.

---

## Jira read-only MCP — configure when ready

Use when: your team tracks requirements and tickets in Jira and wants to auto-load issue context.

### What it improves

- `clarify-requirement`: reads Jira ticket body, acceptance criteria, and comments automatically
- `classify-work`: reads ticket type and labels
- `impact-analysis`: reads linked tickets and epics

### Configuration checklist

- [ ] Generate Jira API token at `https://id.atlassian.com/manage-profile/security/api-tokens`
- [ ] Confirm the MCP server package is available (e.g., `@atlassian/mcp-server-jira` or equivalent)
- [ ] Add Jira server config to `.cursor/mcp.json` (local only)
- [ ] Test: ask Cursor *"What is the description of ticket {PROJ-123}?"*
- [ ] Confirm read-only: ask Cursor *"Update the description of ticket {PROJ-123}"* — should fail

### Security note

Jira API tokens have broad read access by default. Scope to specific projects if your Jira instance supports it.

---

## Figma read-only MCP — configure when frontend work begins

Use when: your team designs in Figma and developers need to reference designs while implementing frontend features.

### What it improves

- `impact-analysis`: understands UI surface from design specs
- `implement-step` (frontend): reads component properties and layout from Figma

### Configuration checklist

- [ ] Generate Figma personal access token at `https://www.figma.com/developers/api#access-tokens`
- [ ] Add Figma server config to `.cursor/mcp.json` (local only)
- [ ] Test: ask Cursor *"Describe the components on the patient registration screen in Figma file {FILE-ID}"*
- [ ] Confirm read-only: design write operations should fail

---

## Confluence / docs MCP — configure when architecture docs are in Confluence

Use when: ADRs, architecture docs, runbooks, and requirements live in Confluence.

### What it improves

- `technical-plan`: reads relevant architecture decisions and existing system docs
- `runbook-draft`: reads existing runbooks as references
- `impact-analysis`: reads system architecture from Confluence docs

### Configuration checklist

- [ ] Confirm Confluence MCP server is available for your Confluence instance (Cloud or Server)
- [ ] Generate API token with read-only scope
- [ ] Add Confluence server config to `.cursor/mcp.json` (local only)
- [ ] Test: ask Cursor *"Summarise the architecture doc at {space}/{page}"*

---

## Observability MCP — configure before monitoring-interpretation is used in production

Use when: post-deploy monitoring interpretation will be run against live metric data.

### What it improves

- `monitoring-interpretation`: reads live error rates, latency, and alert states automatically
- `release-verification`: reads current CI/CD pipeline status and deployment metrics

### Configuration checklist

- [ ] Identify observability platform (Datadog, Grafana, Prometheus, Splunk, etc.)
- [ ] Confirm an MCP server exists for your platform
- [ ] Generate read-only API key scoped to the relevant service/dashboard
- [ ] Add observability server config to `.cursor/mcp.json` (local only)
- [ ] Test: ask Cursor *"What is the current error rate for service {name}?"*
- [ ] Confirm no write access: alert creation/modification should fail

### Data sensitivity note

Observability data can include request bodies, user identifiers, or PII in logs. Confirm with your
security team that the AI model context window is acceptable for your data classification before
enabling this MCP for services handling sensitive data.

---

## Security scanner MCP — configure when CVE triage is integrated with scanner output

Use when: `cve-triage.prompt.md` and PR security review should read scanner output directly.

### What it improves

- `cve-triage`: reads Dependabot, Snyk, or CodeQL findings directly instead of manual paste
- `pr-review`: reads SAST/SCA findings for the PR branch

### Configuration checklist

- [ ] Identify security scanner (GitHub Advanced Security / CodeQL, Snyk, Trivy, etc.)
- [ ] Confirm an MCP server or API integration exists
- [ ] Generate read-only API key
- [ ] Add scanner server config to `.cursor/mcp.json` (local only)
- [ ] Test: ask Cursor *"What are the critical vulnerabilities in repo {name}?"*

---

## MCP activation sequence (recommended)

```
Phase 1 — Configure now:
  ✅ GitHub read-only MCP

Phase 2 — Configure when starting Jira-tracked work:
  📋 Jira read-only MCP

Phase 3 — Configure when frontend development begins:
  🎨 Figma read-only MCP

Phase 4 — Configure when architecture docs are in Confluence:
  📚 Confluence read-only MCP

Phase 5 — Configure when production monitoring interpretation is needed:
  📊 Observability read-only MCP

Phase 6 — Configure when automated CVE/SAST triage is needed:
  🔒 Security scanner read-only MCP

Phase 7 — Deferred (requires explicit governance decision):
  ✏️  Branch-scoped write MCP (not yet in scope)
```

---

## Local-only reminder

`.cursor/mcp.json` is listed in `.gitignore` and must never be committed. It contains your personal
access tokens. Use `.cursor/mcp.example.json` (committed, PAT-free) as the template.

If you accidentally commit a token, rotate it immediately and follow your incident process.
