# MCP Validation Checklist

**Purpose:** For each MCP server, provide the exact Cursor chat queries to (A) confirm read access works and (B) confirm write actions are blocked. Run these before using any MCP for real AI-SDLC work.

**Rule:** Do not use an MCP for AI-SDLC prompts until both tests pass — read succeeds, write fails.

> See `ai-sdlc/adoption/mcp-integration-readiness.md` for priority tiers (P0/P1/P2/P3).  
> See `ai-sdlc/mcp/mcp-config-notes.md` for setup instructions.

---

## How to record validation results

After testing each MCP, update `ai-sdlc/adoption/mcp-integration-readiness.md` — change `📋 Ready to configure` to `✅ Active` and add a note with the date and tester.

---

## Filesystem MCP (P0 — validate first)

### A. Read validation

```
List the files and directories in the project root.
```
Expected: directory listing of the workspace.

```
Read the file ai-sdlc/workflow-state/TEMPLATE.yaml
```
Expected: YAML file contents returned by Cursor.

### B. Write-block test

```
Create a new file at ai-sdlc/workflow-state/MCP-WRITE-TEST.yaml with content: write_test: true
```
Expected: Cursor should refuse or the file must NOT appear on disk.  
If the file is created: this indicates the MCP server or filesystem permissions are too broad. Delete the file and review the config.

### C. AI-SDLC placeholders it can populate

| Placeholder | How |
|-------------|-----|
| `{{REPOSITORY_CONTEXT}}` | Ask Cursor to list or read relevant source files |
| `{{RELEVANT_FILES}}` | Ask Cursor to read specific file paths |
| `{{EXISTING_TESTS}}` | Ask Cursor to read test files in the test directory |
| `{{DEPENDENCY_MANIFEST}}` | Ask Cursor to read requirements.txt or package.json |
| `{{CURRENT_STEP}}` | Ask Cursor to read the plan_doc artifact and list steps |

---

## GitHub MCP (P0)

### A. Read validation

```
List the open pull requests in {org}/{repo}.
```
Expected: list of open PRs with titles.

```
What is the CI status of the latest run on branch main in {org}/{repo}?
```
Expected: job names and pass/fail statuses.

```
Read the diff for GitHub PR #1 in {org}/{repo}.
```
Expected: unified diff of changed files.

### B. Write-block test

```
Create a new GitHub issue in {org}/{repo} titled "MCP write safety test".
```
Expected: error or refusal — PAT has no write permissions.  
If an issue appears: revoke the PAT immediately and regenerate with read-only scopes only.

### C. AI-SDLC placeholders it can populate

| Placeholder | Cursor query pattern |
|-------------|---------------------|
| `{{PR_CONTEXT}}` | Read PR #{number} including title, description, and review comments |
| `{{DIFF_CONTENT}}` | Read the diff for PR #{number} |
| `{{REVIEW_COMMENTS}}` | List all reviewer comments on PR #{number} |
| `{{RECENT_CI_STATUS}}` | CI status of latest run on branch {branch} |
| `{{RECENT_CHANGES}}` | PRs merged to main since {date} |
| `{{DEPLOYMENT_SUMMARY}}` | Read the GitHub release for tag {tag} |

---

## Jira MCP (P0 — primary issue tracker)

> Jira is the **primary issue tracker** for the current pilot. Azure DevOps is not available. Run this validation before starting any pilot work.

### A. Read validation

```
Read Jira issue {ISSUE-KEY} including summary, description, acceptance criteria, comments,
status, assignee, sprint, labels, components, linked issues, and attachments if available.
Do not update the issue.
```
Replace `{ISSUE-KEY}` with a real Jira issue key (e.g., `TS-1`, `PROJ-42`).  
Expected: full issue body, acceptance criteria, status, assignee, sprint, and comments returned.

```
List the issues in Jira project {PROJ-KEY} that are in the current sprint.
```
Expected: sprint issue list returned.

### B. Write-block test

```
Create a Jira issue titled "MCP write safety test".
```
Expected result: The request must fail, be refused, or be denied by permission.  
If an issue is created: **revoke the Atlassian API token immediately** at `https://id.atlassian.com/manage-profile/security/api-tokens`. Delete the test issue. Regenerate with a read-only service account.

### C. AI-SDLC placeholders it can populate

| Placeholder | Cursor query pattern |
|-------------|---------------------|
| `{{REQUIREMENT}}` | Read Jira issue {KEY} including summary and description |
| `{{ACCEPTANCE_CRITERIA}}` | Read the acceptance criteria field from Jira issue {KEY} |
| `{{ISSUE_COMMENTS}}` | List all comments on Jira issue {KEY} |
| `{{ISSUE_STATUS}}` | Read the status, sprint, and assignee fields of Jira issue {KEY} |
| `{{LINKED_ISSUES}}` | Read the linked issues for Jira issue {KEY} |
| `{{BUG_REPORT}}` | Read Jira issue {KEY} including description, repro steps, and all comments |

---

## Azure DevOps MCP (⚠️ not used in current pilot — alternative to Jira)

> **Azure DevOps is not available for the current pilot.** Keep the ADO server block commented out in `.cursor/mcp.json`. Run this section only if ADO becomes available and Jira is not the primary tracker.

### A. Read validation (when available)

```
Read Azure DevOps work item {WORK-ITEM-ID} including title, description,
acceptance criteria, comments, state, assigned sprint, and linked PRs.
Do not update the work item.
```
Expected: full work item body returned.

### B. Write-block test (when available)

```
Create an Azure DevOps work item titled "MCP write safety test" in project {ADO-PROJECT}.
```
Expected: error or permission denied.  
If a work item is created: revoke the ADO PAT immediately and regenerate with read-only scope.

### C. AI-SDLC placeholders it can populate (same as Jira)

| Placeholder | Cursor query pattern |
|-------------|---------------------|
| `{{REQUIREMENT}}` | Read work item {ID} including title, description, and body |
| `{{ACCEPTANCE_CRITERIA}}` | Read the acceptance criteria field from work item {ID} |
| `{{ISSUE_COMMENTS}}` | List all comments on work item {ID} |
| `{{BUG_REPORT}}` | Read work item {ID} including repro steps and all comments |

---

## Confluence MCP (P1)

### A. Read validation

```
Find Confluence pages in space {SPACE-KEY} related to patient registration
or the health platform API. Summarize relevant architecture and security constraints.
```
Expected: page summaries returned.

```
Read the Confluence page titled "Health Platform API Architecture Overview"
in space {SPACE-KEY}.
```
Expected: page content returned.

### B. Write-block test

```
Create a Confluence page in space {SPACE-KEY} titled "MCP write safety test".
```
Expected: error or permission denied.  
If a page is created: revoke the Atlassian token.

### C. AI-SDLC placeholders it can populate

| Placeholder | Cursor query pattern |
|-------------|---------------------|
| `{{ARCHITECTURE_CONTEXT}}` | Read architecture pages from Confluence space {KEY} |
| `{{EXISTING_RUNBOOK}}` | Find runbook pages related to {service} in Confluence |
| `{{TECHNICAL_PLAN_REFERENCE}}` | Read ADR or design decision pages from Confluence |

---

## Slack MCP (P1)

### A. Read validation

```
Search Slack for messages mentioning {WORK-ITEM-ID} in the past 14 days.
Include the channel names and message summaries.
```
Expected: relevant message summaries.

```
List the most recent 10 messages in the #pilot-team channel.
```
Expected: message list (no send action).

### B. Write-block test

```
Send a message to the #pilot-team Slack channel saying "MCP write safety test".
```
Expected: error or refusal — bot token must not have `chat:write` scope.  
If a message is sent: revoke the Slack bot token immediately.

### C. AI-SDLC placeholders it can populate

| Placeholder | Cursor query / notes |
|-------------|----------------------|
| `{{HUMAN_NOTES}}` supplement | Search for stakeholder discussions — must be manually confirmed before use |

**Important:** Slack content must always be manually reviewed and confirmed before it is used as a prompt input. It must never be treated as an approval record.

---

## Microsoft Teams MCP (P2)

### A. Read validation

```
Search Microsoft Teams messages mentioning {WORK-ITEM-ID} in the past 7 days.
Include channel and thread context.
```
Expected: message summaries.

```
Search Teams meeting notes from the last sprint review for decisions about {FEATURE-AREA}.
```
Expected: summary of relevant discussion.

### B. Write-block test

```
Send a Microsoft Teams message in the #pilot channel saying "MCP write safety test".
```
Expected: error or refusal — Graph API must not have ChannelMessage.Send.  
If a message is sent: revoke the Azure AD app permissions immediately.

### C. AI-SDLC placeholders it can populate

| Placeholder | Notes |
|-------------|-------|
| `{{HUMAN_NOTES}}` supplement | Team decision context — must be manually confirmed |

---

## Outlook / Microsoft Mail MCP (P2)

### A. Read validation

```
Search Outlook email for messages with subject or body containing {WORK-ITEM-ID}.
Summarize any approval or requirement-related messages.
```
Expected: email summaries.

```
Find emails from the last 30 days related to patient registration requirements.
```
Expected: relevant email summaries.

### B. Write-block test

```
Send an email with subject "MCP write safety test" to test@example.com.
```
Expected: error or refusal — Mail.Read scope must not allow sending.  
If an email is sent: revoke Azure AD app permissions immediately.

### C. AI-SDLC placeholders it can populate

| Placeholder | Notes |
|-------------|-------|
| `{{HUMAN_NOTES}}` supplement | Approval email evidence — must be manually confirmed; not a substitute for workflow-state gate records |

---

## MongoDB Atlas MCP (P2)

### A. Read validation

```
List the database names and collections available in the Atlas project {PROJECT-ID}.
```
Expected: list of database names and collection names.

```
Describe the schema (field names and types) of the patients collection
in the health-platform-api-dev database.
```
Expected: field list (no data values).

### B. Write-block test

```
Insert a document {"test": true} into the patients collection in the dev database.
```
Expected: error or permission denied.  
If a document is inserted: revoke the Atlas API key immediately and delete the test document.

```
Drop the collection called mcp_test_collection in the dev database.
```
Expected: error — must fail.

### C. AI-SDLC placeholders it can populate

| Placeholder | Cursor query pattern |
|-------------|---------------------|
| `{{ARCHITECTURE_CONTEXT}}` supplement | Describe the database schema for impact analysis |
| `{{REPOSITORY_CONTEXT}}` supplement | List collections and index structure for data model context |

**Important:** Never connect the production Atlas cluster during pilot. Use dev or staging only.

---

## Docker Hub MCP (P2)

### A. Read validation

```
List the repositories in Docker Hub namespace {DOCKERHUB_USERNAME}.
Include the latest tag and image size for each.
```
Expected: repository list with tags.

```
List the available tags for the image {DOCKERHUB_USERNAME}/{IMAGE-NAME}.
Include the digest and push date for the latest 5 tags.
```
Expected: tag list.

### B. Write-block test

```
Delete the latest tag from the image {DOCKERHUB_USERNAME}/{IMAGE-NAME} on Docker Hub.
```
Expected: error or permission denied.  
If a tag is deleted: revoke the Docker Hub token immediately.

```
Push an image to Docker Hub repository {DOCKERHUB_USERNAME}/mcp-write-test.
```
Expected: error — must fail.

### C. AI-SDLC placeholders it can populate

| Placeholder | Cursor query pattern |
|-------------|---------------------|
| `{{DEPENDENCY_MANIFEST}}` supplement | List base image tags for CVE triage |
| `{{DEPLOYMENT_SUMMARY}}` supplement | Read latest image metadata for release notes |

---

## Render MCP (P2)

### A. Read validation

```
List the Render services connected to the GitHub repository {org}/{repo}.
Include the service name, environment, and latest deployment status.
```
Expected: service list with deployment status.

```
What is the latest deployment status for the {SERVICE-NAME} service on Render?
Include the deploy date, status, and any error messages.
```
Expected: deployment status summary.

### B. Write-block test

```
Restart the {SERVICE-NAME} service on Render.
```
Expected: error or permission denied.  
If the service is restarted: revoke the Render API key immediately.

```
Trigger a manual deploy of {SERVICE-NAME} on Render using the latest commit.
```
Expected: error — must fail.

### C. AI-SDLC placeholders it can populate

| Placeholder | Cursor query pattern |
|-------------|---------------------|
| `{{DEPLOYMENT_SUMMARY}}` | Service status and latest deployment info |
| `{{MONITORING_SIGNALS}}` supplement | Recent deploy logs and error output |

---

## Vercel MCP (P2)

### A. Read validation

```
List the Vercel projects associated with GitHub repository {org}/{repo}.
Include the latest deployment URL and status for each project.
```
Expected: project list with deployment status.

```
What is the latest deployment for Vercel project {PROJECT-NAME}?
Include the deployment URL, status, and commit message.
```
Expected: deployment summary.

### B. Write-block test

```
Trigger a new deployment for Vercel project {PROJECT-NAME} from the main branch.
```
Expected: error or permission denied.  
If a deployment is triggered: revoke the Vercel token immediately.

```
Update the environment variable API_URL in Vercel project {PROJECT-NAME}.
```
Expected: error — must fail.

### C. AI-SDLC placeholders it can populate

| Placeholder | Cursor query pattern |
|-------------|---------------------|
| `{{DEPLOYMENT_SUMMARY}}` | Latest deployment URL and status |
| `{{RECENT_CI_STATUS}}` supplement | Vercel build status |

---

## Figma MCP (P3 — deferred)

### A. Read validation (when configured)

```
Describe the components on the patient registration screen in Figma file {FILE-ID}.
Include component names, layout hints, and any annotations.
```
Expected: component summary.

### B. Write-block test

```
Create a new frame titled "MCP write safety test" in Figma file {FILE-ID}.
```
Expected: error or permission denied.

### C. AI-SDLC placeholders it can populate

| Placeholder | Cursor query pattern |
|-------------|---------------------|
| `{{ARCHITECTURE_CONTEXT}}` supplement | UI surface summary for frontend impact analysis |

---

## AWS S3 Artifact Storage (P1)

> S3 is the only integration in the AI-SDLC pilot that allows **controlled writes** — limited to a dedicated pilot bucket and prefix. Unlike other MCPs, the goal is to confirm write works to the correct path AND fails everywhere else. No delete permission in pilot.
>
> See `ai-sdlc/mcp/aws-s3-artifact-storage-setup.md` for full setup, IAM policy, and bucket configuration.

### A. Read validation

```bash
# List objects under the allowed prefix
aws s3 ls s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX --region $AWS_REGION
```
Expected: directory listing or README.txt.

```bash
# Read a specific artifact
aws s3 cp s3://$AI_SDLC_S3_BUCKET/${AI_SDLC_S3_PREFIX}health-platform-api/pilot-metrics/write-test.txt -
```
Expected: file contents returned.

### B. Write validation (controlled — allowed to succeed)

```bash
# Upload a test artifact to the allowed prefix
echo "AI-SDLC write validation $(date -u)" | \
  aws s3 cp - s3://$AI_SDLC_S3_BUCKET/${AI_SDLC_S3_PREFIX}health-platform-api/pilot-metrics/write-test.txt
```
Expected: `upload: - to s3://...` — this write **should succeed**.

### C. Scope restriction test (must fail)

```bash
# Attempt write OUTSIDE the allowed prefix
aws s3 cp /dev/null s3://$AI_SDLC_S3_BUCKET/not-projects/test.txt 2>&1
```
Expected: `An error occurred (AccessDenied)` — IAM policy only allows writes under `projects/*`.

If the write outside prefix succeeds: the IAM policy is too broad. Revoke the key, tighten the policy, and regenerate.

### D. Delete restriction test (must fail)

```bash
# Attempt to delete an object
aws s3 rm s3://$AI_SDLC_S3_BUCKET/${AI_SDLC_S3_PREFIX}health-platform-api/pilot-metrics/write-test.txt 2>&1
```
Expected: `An error occurred (AccessDenied)` — `s3:DeleteObject` must not be in the IAM policy.

If delete succeeds: add an explicit `Deny` for `s3:DeleteObject` to the IAM inline policy and re-run.

### E. PHI/PII/secrets check

Before using S3 for any real artifact:

- [ ] Confirm the file being uploaded contains **no PHI, PII, secrets, or credentials**
- [ ] Confirm the bucket has **SSE-S3 or SSE-KMS encryption enabled**
- [ ] Confirm **public access is fully blocked**
- [ ] Confirm **versioning is enabled**

```bash
aws s3api get-bucket-versioning --bucket $AI_SDLC_S3_BUCKET
aws s3api get-bucket-encryption --bucket $AI_SDLC_S3_BUCKET
aws s3api get-public-access-block --bucket $AI_SDLC_S3_BUCKET
```

### F. AI-SDLC placeholders it can populate

| Placeholder | Source |
|-------------|--------|
| `{{AVAILABLE_ARTIFACTS}}` | List objects in S3 project prefix to discover stored artifacts |
| `{{TECHNICAL_PLAN}}` | Read from `technical-plans/` prefix |
| `{{IMPACT_ANALYSIS}}` | Read from `impact-analysis/` prefix |
| `{{RELEASE_PLAN}}` | Read from `release-readiness/` prefix |
| `{{DEPLOYMENT_CHECKLIST}}` | Read from `release-readiness/` prefix |
| `{{RUNBOOK}}` | Read from — Filesystem MCP primary; S3 for shared/published runbooks |
| `{{PILOT_METRICS}}` | Read from `pilot-metrics/` prefix |
| `{{CONTEXT_BUNDLE_ARCHIVE}}` | Read from `context-bundles/` prefix |

---

## What to do if a write-block test succeeds (write action NOT blocked)

1. **Stop.** Do not use this MCP for any AI-SDLC work.
2. **Undo the write action** if possible (delete created item, restore original state).
3. **Revoke the token immediately** — do not wait.
4. **Regenerate with correct read-only scope** — follow setup notes in `mcp-config-notes.md`.
5. **Re-run both read and write tests** before resuming.
6. **Record the incident** — note the date, which MCP, what write action succeeded, and what was done to fix it.

---

## Validation record template

When you complete validation for an MCP, add a row to this table:

| MCP | Validated by | Date | Read test | Write-block test | Notes |
|-----|-------------|------|-----------|-----------------|-------|
| Filesystem | — | — | ⬜ | ⬜ | |
| GitHub | — | — | ⬜ | ⬜ | |
| Jira | — | — | ⬜ | ⬜ | **P0 — validate first** |
| Confluence | — | — | ⬜ | ⬜ | |
| AWS S3 | — | — | ⬜ | ⬜ write-outside-prefix + delete | |
| Slack | — | — | ⬜ | ⬜ | |
| Azure DevOps | — | — | N/A | N/A | **Not used in current pilot** |
| Teams | — | — | ⬜ | ⬜ | |
| Outlook | — | — | ⬜ | ⬜ | |
| MongoDB Atlas | — | — | ⬜ | ⬜ | |
| Docker Hub | — | — | ⬜ | ⬜ | |
| Render | — | — | ⬜ | ⬜ | |
| Vercel | — | — | ⬜ | ⬜ | |
