# Modernization Examples (Generic)

Consulting-ready examples for classify-work and requirement grooming. **Not** tied to any client product.

## Legacy stack migration

- **Requirement:** Migrate monolithic PHP application to Java/Spring over multiple releases.
- **Classification:** `work_type: modernization`, `work_subtype: legacy_stack_migration`, tier floor **3**.
- **Strategy:** Strangler fig around highest-risk modules first; parallel API validation.

## Framework upgrade

- **Requirement:** Upgrade major framework version in place with regression suite expansion.
- **Classification:** `work_type: modernization`, `work_subtype: framework_upgrade`, tier **2–3** by blast radius.
- **Strategy:** Phased migration with feature flags; no rewrite unless gate review approves.

## On-prem to cloud

- **Requirement:** Replatform production workloads from data center to managed cloud.
- **Classification:** `work_type: cloud_infra`, `work_subtype: on_prem_to_cloud`, tier floor **3–4**.
- **Conditional artifact:** `cloud_readiness_assessment`.

## Database migration

- **Requirement:** Move production OLTP database to new engine with reconciliation.
- **Classification:** `work_type: data_migration`, `work_subtype: database_migration`, tier floor **4** when production data involved.
- **Conditional artifact:** `data_migration_plan`.

## UI modernization only

- **Requirement:** Replace legacy UI shell; backend APIs unchanged.
- **Classification:** `work_type: modernization`, `work_subtype: ui_modernization`, tier **2–3** by user impact.
- **Strategy:** Compatibility contract preserves API/UI workflows; regression baseline for critical flows.

## Monolith to microservices (discouraged by default)

- **Classification:** `work_subtype: monolith_to_microservices`, tier floor **4**.
- **Required justification:** Why modular monolith or strangler is insufficient.
- **Conditional artifacts:** `service_decomposition_plan`, `capability_map`.

## Normal bug (lane off)

- **Requirement:** Fix incorrect validation message on registration form.
- **Classification:** `work_type: bug`, `modernization.enabled: false`.
- **Flow:** CLASSIFIED → SPEC_DRAFTED → PLAN_DRAFTED (no modernization stages).

## Profile disabled

- **Config:** `modernization_profile.enabled: false`
- **Classification:** `work_type: modernization` without `modernization.enabled: true`
- **Flow:** Standard bug/feature path — lane off unless explicit workflow override.

## Explicit workflow override

- **Config:** `modernization_profile.enabled: false`
- **Workflow-state:** `modernization.enabled: true`
- **Flow:** Modernization lane activates despite profile disable.
