# Modernization Lane Guide (Phase 2)

Modernization is part of the **same AI-SDLC backbone**, not a separate SDLC. The lane activates only when classification or workflow-state indicates modernization/migration work.

## When the lane activates

**Precedence (highest first):**

1. `modernization.enabled: true` in workflow-state — **always** activates the lane, even when `modernization_profile.enabled: false`.
2. Otherwise, when `modernization_profile.enabled: true` (default), `work_type` in `modernization`, `migration`, `cloud_infra`, `data_migration`, or `platform` activates the lane.
3. When `modernization_profile.enabled: false`, work_type alone does **not** activate the lane.

Normal **bug** and **feature** work does **not** enter this lane.

## Specification / SPEC_DRAFTED

The modernization path **intentionally bypasses** `SPEC_DRAFTED` and `create-spec.prompt.md`. Modernization lane artifacts (assessment through gate review) serve as **specification-equivalent** planning inputs before technical plan.

Teams may optionally produce `specification.md` and register `artifacts.spec_doc` for traceability, but orchestration does not require it on the modernization path.

## Lane stages (after impact analysis, before technical plan)

1. **MODERNIZATION_ASSESSMENT** — `modernization-assessment.prompt.md`
2. **MODERNIZATION_DISCOVERY** — `current-state-discovery.prompt.md`
3. **TARGET_ARCHITECTURE** — `target-architecture.prompt.md`
4. **MIGRATION_STRATEGY** — `migration-strategy.prompt.md`, then compatibility/regression sub-prompts; when complete, router recommends `modernization-gate-review.prompt.md` (human advances stage to `MODERNIZATION_GATE_REVIEW`)
5. **MODERNIZATION_GATE_REVIEW** — `modernization-gate-review.prompt.md`

Then the workflow returns to **technical plan** (`PLAN_DRAFTED`).

## Default strategy posture

Prefer, in order:

- Strangler fig
- Phased migration
- Parallel run / validation
- Modular monolith first
- Replatform

Microservices and full rewrite require **explicit justification** in target architecture and gate review.

## Configuration

See `project-config.template.yaml` sections:

- `work_types.supported`
- `modernization_profile`
- `modernization_required_artifacts`

## Rollback (Phase 1)

Phase 1 rollback support remains active. Modernization work should record rollback touchpoints in migration strategy; merge-readiness still enforces `rollback_plan` per `rollback_policy`.

## Phase 3 — cutover and post-migration validation

Phase 3 adds optional production cutover stages after deploy readiness for cutover-required work:

`DEPLOY_READY → CUTOVER_READY → CUTOVER → DEPLOYED → POST_MIGRATION_VALIDATION → VERIFIED`

See [cutover-readiness-guide.md](cutover-readiness-guide.md) and [post-migration-validation-guide.md](post-migration-validation-guide.md). Normal bug/feature deploy paths are unchanged.

## Commands

```bash
make ai-sdlc-stage-router ROOT=<workspace> ISSUE=<ID>
make ai-sdlc-validate-artifacts ROOT=<workspace> ISSUE=<ID>
```
