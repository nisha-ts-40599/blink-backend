# Monolith Decomposition SDLC Guide

Decomposition work uses the modernization lane when scope exceeds a normal feature.

## Activation

`work_subtype: monolith_to_microservices` or explicit decomposition in requirement with `modernization.enabled: true`.

## Default posture

**Modular monolith first.** Extract boundaries only when:

- Clear data ownership exists
- Strangler path is defined
- Regression baseline covers extracted capability

Microservices require explicit justification in target architecture (why not modular monolith).

## Conditional artifacts

- `service_decomposition_plan`
- `capability_map`

## Lane flow

Impact analysis → assessment → discovery (dependency map) → target architecture → migration strategy → gate review → technical plan.

## Discouraged patterns

From `modernization_profile.discouraged_strategies`:

- Shared database microservices without data ownership
- Big-bang rewrite without parallel validation

## Rollback

Reuse Phase 1 rollback plan at merge readiness; document service-level rollback touchpoints in migration strategy.

## Phase 3

Service cutover and post-migration validation are Phase 3 extension points.
