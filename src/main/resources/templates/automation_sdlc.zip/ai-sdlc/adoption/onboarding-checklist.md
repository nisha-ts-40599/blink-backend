# Onboarding Checklist

Use this checklist before running AI-SDLC in a project repository.

## Project Configuration

- [ ] Copy `ai-sdlc/project-config.template.yaml` to `project-config.yaml`.
- [ ] Fill project, domain, architecture, and technology fields.
- [ ] Define branching and deployment strategy.
- [ ] Map `approval_rules.roles` to real groups/users.
- [ ] Validate tier policy alignment with `ai-sdlc/work-tiers.md`.

## Repository Setup

- [ ] Add `ai-sdlc/` folder to repository (or reference from platform repo).
- [ ] Ensure teams can access workflows, templates, prompts, and governance docs.
- [ ] Confirm runtime prerequisites (`python3`, virtual env).
- [ ] Confirm make targets run (`make ai-sdlc-install`).

## CI Setup

- [ ] Select CI templates from `ai-sdlc/ci/`.
- [ ] Add conformance job template for your CI system.
- [ ] Configure `dev` vs `protected` branch profile behavior.
- [ ] Persist conformance JSON and JUnit artifacts in CI.
- [ ] Gate protected branches on strict conformance success.

## Issue Tracker Mapping

- [ ] Map requirement/spec/plan/test artifacts to issue fields.
- [ ] Define issue labels for tier, risk, and workflow state.
- [ ] Add link conventions between issue, PR, and docs.

## Documentation Mapping

- [ ] Map specification template to docs platform structure.
- [ ] Define ADR location and naming convention.
- [ ] Define release and post-release verification document owners.

## Approval Roles and Human Gates

- [ ] Confirm approver roles: engineering lead, security, release/platform, product.
- [ ] Document which gate IDs apply to each tier and action type.
- [ ] Verify merge and production deploy remain human-gated.

## Security Scanner Mapping

- [ ] Map SAST, SCA, secrets scan, and (if used) DAST tools.
- [ ] Ensure scanner outputs are persisted in CI artifacts.
- [ ] Define failure thresholds and exception process.

## Runtime Mode

- [ ] Start in assisted mode (mock adapters and local runtime for demo/pilot).
- [ ] Enable policy traces (`--trace-policies`) for pilot runs.
- [ ] Enable metrics (`--metrics`) and archive `runtime-data` for review.

## Final Readiness

- [ ] Run conformance in dev profile successfully.
- [ ] Run runtime demo workflow end-to-end.
- [ ] Conduct stakeholder demo and sign-off.
- [ ] Start first real requirement with explicit human approval plan.

