# AI-SDLC Operator Guide

Canonical operator entry point: **`/sdlc-run ISSUE`**.

Framework identity: **4.0.0** · channel **stable** · **`stable: true`**.

This guide documents the full requirement lifecycle from intake through closure. Prompts are **advisory**; guards, gates, and Make/CLI validators are **authoritative**. Conversational text never authorizes mutation. Bootstrap authorization is separate from implementation authorization. Confirmation does not execute — one human confirmation authorizes one bounded action. Quarantine overrides authorization. Product writes require a separately confirmed `IMPLEMENTATION_SLICE`.

---

## Before you start

| Check | Command | Read-only |
| --- | --- | --- |
| Install Python deps | `make ai-sdlc-install` | mutating (venv) |
| Install OPA (protected profile) | `make ai-sdlc-install-opa` | mutating (binary) |
| Operational health | `make ai-sdlc-health-report ROOT=<workspace>` | read-only |
| Release integrity | `make ai-sdlc-release-verify` | read-only |

Workspace bootstrap: `/setup-new-workspace` or `/setup-existing-workspace` (or project variants). See [`operator-quick-start.md`](operator-quick-start.md).

---

## Lifecycle stages

Each row: operator command, required state, expected output, authoritative guard/gate, common BLOCKED codes, repair/resume, mutating vs read-only, human confirmation, persisted evidence.

### 1. Requirement intake

| Field | Value |
| --- | --- |
| **Operator command** | `make ai-sdlc-groom-prep ISSUE=<id>` then `/clarify-requirement` or `/sdlc-run ISSUE` |
| **Required state** | Workspace `context_ready`; issue id known |
| **Expected output** | Grooming bundle; draft requirement artifact path |
| **Guard / gate** | Stage eligibility preflight; optional issue tracker fetch |
| **Common BLOCKED** | `MISSING_PREREQUISITE`, `GATE_DENIAL` (if prior issue incomplete) |
| **Repair / resume** | `/sdlc-run ISSUE EXECUTE=0 MODE=diagnostic` → `/sdlc-resume ISSUE` |
| **Mutating** | groom-prep may write bundle files; `/sdlc-run` default read-only |
| **Human confirmation** | No (intake) |
| **Evidence** | requirement draft, lifecycle-events.jsonl |

### 2. Grooming and clarification

| Field | Value |
| --- | --- |
| **Operator command** | `/clarify-requirement`, `/stakeholder-pack`, `/requirement-revision` |
| **Required state** | `REQUIREMENT` or grooming stage; requirement draft exists |
| **Expected output** | Updated requirement doc; open questions resolved or escalated |
| **Guard / gate** | Artifact validators; grooming completeness checks |
| **Common BLOCKED** | `MISSING_PREREQUISITE`, `STALE_ARTIFACT` |
| **Repair / resume** | Refresh artifacts → `make ai-sdlc-validate-artifacts ISSUE=<id>` → `/sdlc-resume ISSUE` |
| **Mutating** | Prompt may propose edits; persistence via explicit write tools only |
| **Human confirmation** | Stakeholder decisions recorded in requirement doc |
| **Evidence** | requirement.md, grooming notes |

### 3. Definition of Ready (DoR)

| Field | Value |
| --- | --- |
| **Operator command** | `/definition-of-ready` then `make ai-sdlc-approve-gate ISSUE=<id> GATE=G-GROOM` |
| **Required state** | Requirement complete; acceptance criteria testable |
| **Expected output** | DoR checklist pass; G-GROOM approved in workflow state |
| **Guard / gate** | **G-GROOM**; DoR validator |
| **Common BLOCKED** | `GATE_DENIAL`, `MISSING_PREREQUISITE` |
| **Repair / resume** | Complete missing DoR items → re-run approve-gate → `/sdlc-resume ISSUE` |
| **Mutating** | approve-gate mutates workflow state |
| **Human confirmation** | **Yes** — groom approver per role registry |
| **Evidence** | gates.g_groom, dor checklist artifact |

### 4. Impact analysis

| Field | Value |
| --- | --- |
| **Operator command** | `/classify-work` then `/impact-analysis` (Tier 2+) |
| **Required state** | G-GROOM approved; `work_tier` assigned |
| **Expected output** | `impact.md`; `current_stage` remains `CLASSIFIED` (not IMPACT_ANALYZED) |
| **Guard / gate** | Tier rules in `work-tiers.md`; stage transition validator |
| **Common BLOCKED** | `MISSING_PREREQUISITE`, `GATE_DENIAL` |
| **Repair / resume** | `make ai-sdlc-validate-artifacts ISSUE=<id>` → `/sdlc-run ISSUE` |
| **Mutating** | Classification may update workflow state via Make init/update |
| **Human confirmation** | Tier override requires documented rationale |
| **Evidence** | impact.md, work_tier in workflow-state |

### 5. Technical plan

| Field | Value |
| --- | --- |
| **Operator command** | `/create-spec` → `/technical-plan` → `make ai-sdlc-validate-pre-spec ISSUE=<id>` |
| **Required state** | Spec drafted; Tier 2+ requires impact doc |
| **Expected output** | spec.md, plan.md; stage `PLAN_DRAFTED` |
| **Guard / gate** | Pre-spec validator; artifact lineage |
| **Common BLOCKED** | `MISSING_PREREQUISITE`, `STALE_ARTIFACT`, `EXECUTION_PLAN_DRIFT` |
| **Repair / resume** | Fix artifacts → validate → `/sdlc-resume ISSUE` |
| **Mutating** | Plan artifacts via controlled writers |
| **Human confirmation** | Plan review comments (non-authorizing) |
| **Evidence** | spec.md, plan.md, artifacts registry |

### 6. Approvals

| Field | Value |
| --- | --- |
| **Operator command** | `make ai-sdlc-approve-gate ISSUE=<id> GATE=G-PLAN` (Tier 2+); security/deploy gates as tier requires |
| **Required state** | `PLAN_DRAFTED`; required artifacts present |
| **Expected output** | Gate approved; stage may advance to `PLAN_APPROVED` |
| **Guard / gate** | **G-PLAN** (Tier 2+), **G-SEC**, **G-DEPLOY** per tier_defaults |
| **Common BLOCKED** | `GATE_DENIAL`, role/SoD violations |
| **Repair / resume** | `make ai-sdlc-check-gates ISSUE=<id>` → approve with valid approver → `/sdlc-resume ISSUE` |
| **Mutating** | approve-gate mutates workflow state |
| **Human confirmation** | **Yes** — one gate decision per invocation |
| **Evidence** | gates.*, approval evidence URLs |

### 7. Execution planning

| Field | Value |
| --- | --- |
| **Operator command** | `/execution-plan`; `make ai-sdlc-confirm-handoff ROOT=<ws> ISSUE=<id> HANDOFF=<path>` |
| **Required state** | `PLAN_APPROVED`; gates satisfied for implement-ready |
| **Expected output** | Execution plan binding; handoff proposal (not consumed) |
| **Guard / gate** | Guided handoff enforcement; execution plan schema |
| **Common BLOCKED** | `HANDOFF_ENFORCEMENT_REQUIRED`, `STALE_HANDOFF`, `EXECUTION_PLAN_DRIFT` |
| **Repair / resume** | Registry repair for `STALE_HANDOFF` → new handoff → `make ai-sdlc-confirm-handoff` |
| **Mutating** | Handoff propose writes governance/handoffs |
| **Human confirmation** | Plan review; handoff confirm is separate step |
| **Evidence** | handoff YAML, plan hash binding |

### 8. Implementation authorization

| Field | Value |
| --- | --- |
| **Operator command** | `make ai-sdlc-authorize-implementation ISSUE=<id>` after handoff confirm |
| **Required state** | Valid handoff consumed; bootstrap complete if greenfield |
| **Expected output** | `IMPLEMENTATION_AUTHORIZED` token (distinct from bootstrap auth) |
| **Guard / gate** | Authorization guard; quarantine check |
| **Common BLOCKED** | `MISSING_AUTHORIZATION`, `MUTATION_DENIAL`, quarantine active |
| **Repair / resume** | Complete handoff confirm → re-authorize → `/sdlc-resume ISSUE` |
| **Mutating** | Authorization record in workflow state |
| **Human confirmation** | **Yes** — explicit implementation authorization |
| **Evidence** | authorization tokens, handoff consumption audit |

### 9. Bounded implementation slice

| Field | Value |
| --- | --- |
| **Operator command** | `/implement` with confirmed **`IMPLEMENTATION_SLICE`**; product writes via mutation guard |
| **Required state** | `IMPLEMENTATION_AUTHORIZED`; valid slice scope |
| **Expected output** | Local commits within slice boundary; stage `IMPLEMENTING` |
| **Guard / gate** | **product_mutation_guard**; slice envelope |
| **Common BLOCKED** | `MUTATION_DENIAL`, `MISSING_AUTHORIZATION`, `CONCURRENT_EXECUTION_BLOCKED` |
| **Repair / resume** | `/sdlc-run ISSUE EXECUTE=0 MODE=diagnostic` → re-authorize slice → resume implement |
| **Mutating** | **Yes** — product source writes |
| **Human confirmation** | **Yes** — one slice per confirmation |
| **Evidence** | mutation audit log, implementation package |

### 10. Test / build / security validation

| Field | Value |
| --- | --- |
| **Operator command** | `make ai-sdlc-sync-validation-status ISSUE=<id>`; CI; `/self-review` |
| **Required state** | Implementation slice complete or checkpoint |
| **Expected output** | Build/test/security evidence artifacts |
| **Guard / gate** | CI tier enforcement; security scan gates |
| **Common BLOCKED** | `MISSING_PREREQUISITE`, `GATE_DENIAL` (G-SEC) |
| **Repair / resume** | Fix failures → re-run validation → `/sdlc-run ISSUE` |
| **Mutating** | Test runs may write reports only |
| **Human confirmation** | Security waiver via formal gate if needed |
| **Evidence** | test reports, scan outputs, QA artifacts |

### 11. PR evidence

| Field | Value |
| --- | --- |
| **Operator command** | `/create-pr` → `make ai-sdlc-register-pr ISSUE=<id>` |
| **Required state** | `PR_DRAFT_READY` or equivalent |
| **Expected output** | PR URL registered in workflow state |
| **Guard / gate** | PR registration validator |
| **Common BLOCKED** | `MISSING_PREREQUISITE`, `PR_EVIDENCE_MISSING` |
| **Repair / resume** | Register PR → validate → `/sdlc-resume ISSUE` |
| **Mutating** | register-pr updates workflow state |
| **Human confirmation** | PR creation human-driven; registration is operator action |
| **Evidence** | pr_url, review artifacts |

### 12. Merge reconciliation

| Field | Value |
| --- | --- |
| **Operator command** | `/merge-readiness` → `make ai-sdlc-approve-gate GATE=G-PR-MERGE` |
| **Required state** | Review complete; CI green; Tier 3+ rollback plan if required |
| **Expected output** | Merge-ready gate; human performs merge |
| **Guard / gate** | **G-PR-MERGE**; rollback policy (Tier 3+) |
| **Common BLOCKED** | `GATE_DENIAL`, `MISSING_PREREQUISITE` |
| **Repair / resume** | Address review → re-approve → human merge |
| **Mutating** | Gate approval only; merge remains human |
| **Human confirmation** | **Yes** — merge approver + human git merge |
| **Evidence** | merge gate record, CI links |

### 13. Closure eligibility

| Field | Value |
| --- | --- |
| **Operator command** | `/deploy-readiness` or `/verified` per topology; `make ai-sdlc-check-gates ISSUE=<id>` |
| **Required state** | Deploy/verify gates satisfied for tier |
| **Expected output** | All required gates approved; no blocking reasons |
| **Guard / gate** | Closure eligibility assessor |
| **Common BLOCKED** | `GATE_DENIAL`, `MISSING_PREREQUISITE`, `RELEASE_INTEGRITY_FAILURE` |
| **Repair / resume** | Complete deploy evidence → journey repair → resume |
| **Mutating** | Evidence registration may update state |
| **Human confirmation** | Deploy/promotion human per policy |
| **Evidence** | deploy evidence, verification checklist |

### 14. Closure report

| Field | Value |
| --- | --- |
| **Operator command** | `/closure-report` → `make ai-sdlc-generate-closure-report ISSUE=<id>` |
| **Required state** | `VERIFIED` or terminal-ready stage |
| **Expected output** | Closure report artifact; issue marked complete |
| **Guard / gate** | Closure validator; audit linkage |
| **Common BLOCKED** | `MISSING_PREREQUISITE`, `NON_RETRYABLE_FAILURE` |
| **Repair / resume** | Complete missing evidence → `/sdlc-resume ISSUE` |
| **Mutating** | generate-closure-report updates workflow state |
| **Human confirmation** | Optional sign-off per project policy |
| **Evidence** | closure report, final lifecycle-events.jsonl |

### 15. Resume / recovery

| Field | Value |
| --- | --- |
| **Operator command** | `/sdlc-resume ISSUE` or `/sdlc-run ISSUE MODE=diagnostic` |
| **Required state** | Any non-terminal stage |
| **Expected output** | Exactly one next command; no replay of completed work |
| **Guard / gate** | journey_recovery registry; lock registry |
| **Common BLOCKED** | `TRANSACTION_INTERRUPTED`, `STALE_LOCK`, `STALE_HANDOFF` |
| **Repair / resume** | `/sdlc-run ISSUE EXECUTE=0 MODE=diagnostic` then `/sdlc-resume ISSUE` |
| **Mutating** | Resume routing read-only; repair may update recovery metadata |
| **Human confirmation** | Reauthorization if auth expired |
| **Evidence** | recovery-attempts.jsonl, repair audit |

### 16. Amendments and reauthorization

| Field | Value |
| --- | --- |
| **Operator command** | `/requirement-revision` → invalidate stale auth → new handoff → re-authorize |
| **Required state** | Prior authorization may be invalidated by artifact change |
| **Expected output** | Updated requirement/plan; new gates if tier changed |
| **Guard / gate** | STALE_ARTIFACT detection; plan-hash mismatch guards |
| **Common BLOCKED** | `STALE_ARTIFACT`, `EXECUTION_PLAN_DRIFT`, `MISSING_AUTHORIZATION` |
| **Repair / resume** | Full re-groom or re-plan path → new approvals → new slice auth |
| **Mutating** | Amendment artifacts; may revoke prior authorization |
| **Human confirmation** | **Yes** — reapproval and new IMPLEMENTATION_SLICE |
| **Evidence** | amendment log, superseded handoffs |

---

## Daily operator loop

1. `/sdlc-run ISSUE` — get exactly one next command.
2. Execute that command (or human step it designates).
3. `make ai-sdlc-health-report ROOT=<workspace>` — weekly or after incidents.
4. On BLOCKED: note reason code → [`reason-code-runbook.md`](reason-code-runbook.md) → [`recovery-runbook.md`](recovery-runbook.md).

---

## Related documents

| Document | Purpose |
| --- | --- |
| [`operator-quick-start.md`](operator-quick-start.md) | First-time 10–15 min path |
| [`reason-code-runbook.md`](reason-code-runbook.md) | Canonical BLOCKED codes |
| [`recovery-runbook.md`](recovery-runbook.md) | Interruption procedures |
| [`pilot-plan.md`](pilot-plan.md) | Controlled internal pilot |
| [`../../docs/operating-model/current-sdlc-flow.md`](../../docs/operating-model/current-sdlc-flow.md) | Implemented flow reference |
