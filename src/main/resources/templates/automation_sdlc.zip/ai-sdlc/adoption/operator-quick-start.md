# Operator Quick-Start (10–15 minutes)

Framework: **4.0.0** · **stable** · **`stable: true`**.

Primary entry point after setup: **`/sdlc-run ISSUE`**.

---

## 1. Install and verify (2 min)

```bash
make ai-sdlc-install
make ai-sdlc-install-opa          # required for protected conformance profile
make ai-sdlc-release-verify       # read-only integrity check
make ai-sdlc-health-report ROOT=<workspace>   # read-only health report
```

Does **not** install OPA automatically — run `make ai-sdlc-install-opa` separately.

---

## 2. Bootstrap workspace (3 min)

**New workspace:**

```text
/setup-new-workspace
# provide one explicit product source (pasted text, file, issue, or name + description)
# review the discovery plan
/setup-new-workspace apply
```

Recommended after apply (authoritative NextAction): `/configure-stakeholders`

Authoritative new-workspace journey:

```text
/setup-new-workspace
# provide one explicit product source
# review
/setup-new-workspace apply
/configure-stakeholders
/plan-product-scope
/confirm-product-scope
/sdlc-start <confirmed-work-item-id>
/sdlc-next <issue>
```

The product/workspace requirement is captured in discovery and planned into an
internal backlog. `/sdlc-start` starts a **confirmed** story, not the whole BRD.
New text is not a new ticket. New scope is a new item. Same scope is a revision.

Issue identity and requirement source are separate. A local issue ID
does not imply an external tracker body. If the local issue has no body, Blink SDLC
asks whether to reuse the canonical setup requirement or provide another source.

Do not infer product identity from the folder name, git name, previous chats, or `/tmp`.

**Existing workspace:** `/setup-existing-workspace refresh` or `/setup-existing-project refresh`

Then exactly one of:

- `/configure-stakeholders` when the roster changed, is missing, or has not been reviewed
- `/confirm-stakeholders` when the current roster is unchanged and you attest it remains current

Then:

- `/plan-product-scope refresh` when the requirement source changed
- `/confirm-product-scope` when a proposal exists
- `/sdlc-start` or `/sdlc-next` when product scope is current

If the requirement source did not change and product scope remains current, do not
force decomposition. External trackers can be synchronized later with `/sync-product-scope`.
Internal product scope remains canonical even when `provider = manual/read_only`.

Do not hand-edit YAML.

Confirm overlay exists at `.cursor/ai-sdlc/` with `project-config.yaml` and `project-context.md`.

Canonical role IDs, purpose, `required_by_stage`, and applicability are projected from
`ai-sdlc/registry/role-catalog.yaml`. Do not maintain a second role table.
`/assign-role` is an advanced/debug alias of `/configure-stakeholders`.

---

## 3. Configure project (2 min)

Edit overlay `project-config.yaml`:

- `project_id`, repositories, approval roles
- CI tier expectations
- Pilot flags only if participating in internal pilot (`features.sdlc_run_execution.enabled`)

Validate:

```bash
make ai-sdlc-schema-check
make ai-sdlc-validate-overlay ROOT=<workspace>
```

See [`project-config-guide.md`](project-config-guide.md).

---

## 4. First issue — `/sdlc-run ISSUE` (3 min)

```bash
make ai-sdlc-groom-prep ISSUE=DEMO-1
/sdlc-run DEMO-1
```

Default `/sdlc-run` is **read-only** (`EXECUTE=0`). It returns exactly **one** copy command. It does not mutate state or authorize product writes.

Answer grooming via `/clarify-requirement` when prompted. Record stakeholder answers in the requirement artifact — conversational approval does not persist gates.

---

## 5. Record approvals (2 min)

When DoR is ready:

```bash
make ai-sdlc-approve-gate ISSUE=DEMO-1 GATE=G-GROOM APPROVER=<role-email> DECISION=approved EVIDENCE_REF=<url>
```

Tier 2+ plan approval:

```bash
make ai-sdlc-approve-gate ISSUE=DEMO-1 GATE=G-PLAN APPROVER=<lead> DECISION=approved EVIDENCE_REF=<url>
```

One gate decision per command. Check status:

```bash
make ai-sdlc-check-gates ISSUE=DEMO-1
/sdlc-status DEMO-1 MODE=diagnostic
```

---

## 6. Authorize a bounded implementation slice (2 min)

After execution plan handoff is **confirmed** (handoffs propose; confirmation consumes):

```bash
make ai-sdlc-authorize-implementation ISSUE=DEMO-1
```

Then implement only within the confirmed **`IMPLEMENTATION_SLICE`**. Product writes without valid authorization are blocked (`MUTATION_DENIAL`).

Bootstrap authorization (`G-BOOTSTRAP`) is **separate** from implementation authorization.

---

## 7. Resume after interruption (1 min)

```bash
/sdlc-resume ISSUE
# or
/sdlc-run ISSUE MODE=diagnostic
```

If BLOCKED, read the reason code and run the registry repair command first:

```bash
/sdlc-run DEMO-1 EXECUTE=0 MODE=diagnostic
/sdlc-resume DEMO-1
```

Completed work is never replayed on resume.

---

## 8. Inspect health and export audit (1 min)

```bash
make ai-sdlc-health-report ROOT=<workspace>
make ai-sdlc-audit-export ROOT=<workspace> ISSUE=DEMO-1
```

---

## 9. Common blocked states

| Symptom | Likely code | Safe next step |
| --- | --- | --- |
| Missing artifact | `MISSING_PREREQUISITE` | `make ai-sdlc-validate-artifacts ISSUE=<id>` |
| Gate not approved | `GATE_DENIAL` | `make ai-sdlc-check-gates` → approve-gate |
| Stale plan | `STALE_HANDOFF` | `/sdlc-run ISSUE EXECUTE=0 MODE=diagnostic` → new handoff |
| Lock held | `CONCURRENT_EXECUTION_BLOCKED` | `python ai-sdlc/tools/orchestration/lock_registry.py --root . --inspect` |
| Interrupted write | `TRANSACTION_INTERRUPTED` | diagnostic → `/sdlc-resume ISSUE` |

Full catalog: [`reason-code-runbook.md`](reason-code-runbook.md) · procedures: [`recovery-runbook.md`](recovery-runbook.md).

**Do not** delete workflow state files or hand-edit authoritative YAML as recovery.

---

## 10. When to stop and escalate

Stop immediately and notify pilot owner if:

- Unauthorized product mutation occurred
- Evidence integrity failure or role bypass suspected
- Same completed step replayed on resume

Pause and review if repeated false BLOCKED states or operator confusion persists.

See [`pilot-rollback-triggers.md`](pilot-rollback-triggers.md).

---

## Next reading

- Full lifecycle: [`operator-guide.md`](operator-guide.md)
- Pilot participation: [`pilot-plan.md`](pilot-plan.md) + [`pilot-readiness-checklist.md`](pilot-readiness-checklist.md)
