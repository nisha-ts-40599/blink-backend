# Operator role catalog (generated)

Projected from `ai-sdlc/registry/role-catalog.yaml`.
Legacy aliases are omitted from current role IDs.

## Core delivery roles

| role_id | display_name | required_by_stage | applicability | gates |
|---|---|---|---|---|
| `backend_developer` | Backend Developer | IMPLEMENTATION | required | — |
| `business_analyst` | Business Analyst | REQUIREMENT_GROOMING | required | — |
| `frontend_developer` | Frontend Developer | IMPLEMENTATION | required | — |
| `product_owner` | Product Owner | REQUIREMENT_GROOMING | required | G-GROOM, G-BOOTSTRAP |
| `qa_engineer` | QA Engineer | QA_DESIGN | required | G-QA-POST |
| `qa_lead` | QA Lead | QA_DESIGN | required | G-QA-PRE, G-QA-POST |
| `tech_lead` | Tech Lead | PLANNING | required | G-PLAN, G-QA-PRE, G-PR-MERGE, G-BOOTSTRAP, G-CLASS |

## Context-dependent review roles

| role_id | display_name | required_by_stage | applicability | gates |
|---|---|---|---|---|
| `dba` | DBA | PLANNING | conditional when: database_schema_changed, migration_required, storage_model_changed, query_index_or_performance_risk, retention_or_data_lifecycle_changed, backup_or_recovery_impact | — |
| `platform_architect` | System / Platform Architect | PLANNING | conditional when: architecture_boundary_changed, new_component_or_service, cross_repository_architecture_impact, new_platform_dependency, technology_or_platform_change, material_nfr_impact | — |
| `ux_designer` | UX Designer | REQUIREMENT_GROOMING | conditional when: ui_ux_behavior_changed, user_journey_changed, interaction_or_wireframe_impact | — |

## Governance approval roles

| role_id | display_name | required_by_stage | applicability | gates |
|---|---|---|---|---|
| `compliance_approver` | Compliance Approver | DELIVERY_READINESS | conditional when: regulatory_or_privacy_review_required, privacy_sensitive_change, jurisdictional_obligation, policy_requires_compliance_gate | — |
| `designated_reviewer` | Designated Reviewer | REVIEW | conditional when: pr_workflow_applicable, independent_reviewer_required | G-PR-MERGE |
| `release_approver` | Release Approver | RELEASE | required | G-REL-PROD, G-REL-STG, G-DEPLOY |
| `security_champion` | Security Champion | SECURITY_REVIEW | conditional when: authentication_or_authorization, secrets, trust_boundaries, sensitive_data, security_sensitive_change, elevated_tier, explicit_security_policy_applicability | G-SEC |
| `sre` | SRE | RELEASE | conditional when: infrastructure, runtime, deployment, observability, reliability, production_configuration_impact | G-DEPLOY, G-BOOTSTRAP-EXEC |

## Legacy aliases

Documented only for backward read. Do not use as current role IDs.

| alias | notes |
|---|---|
| `platform_owner` | Ambiguous; do not auto-map |
