# Pilot Success Metrics

Framework: **4.0.0** · **`stable: true`**.

Metrics use existing audit, lifecycle-events, recovery-attempts, lock-events, migration, performance, and operational-health evidence where possible. **Pilot 1 baselines are observational** unless noted.

Do not claim productivity improvement without measured evidence from this pilot.

---

## Collection sources

| Source | Location / command |
| --- | --- |
| Workflow lifecycle | `.cursor/ai-sdlc/workflow-state/<ISSUE>/lifecycle-events.jsonl` |
| Recovery attempts | `history/recovery-attempts.jsonl` |
| Lock events | lock-events.jsonl |
| Operational health | `make ai-sdlc-health-report ROOT=<ws>` JSON |
| Performance | `ai-sdlc/tests/results/performance-*.json` |
| Release integrity | `make ai-sdlc-release-verify` |
| Audit bundle | `make ai-sdlc-audit-export ISSUE=<id>` |
| Dry-run | `pilot-dry-run-report.json` |

---

## Core metrics

| Metric | Definition | Pilot 1 target | Type |
| --- | --- | --- | --- |
| Requirements entering pilot | Count of issues with groom-prep + init | Track all | Observational |
| Workflows reaching DoR | G-GROOM approved | ≥ 80% of entered | Observational |
| Workflows completing without manual state repair | Closed without ad-hoc YAML edits | ≥ 70% | Target range |
| Blocked-state frequency by reason code | BLOCKED count / stage transitions | Decreasing week-over-week | Observational |
| Time between stages (avg/median) | lifecycle-events timestamps | Establish baseline | Observational |
| Retry/resume count | recovery-attempts entries per issue | < 3 median | Target range |
| Stale-lock incidence | lock-recover events | < 2 per week | Target range |
| Authorization rejection count | MUTATION_DENIAL / MISSING_AUTHORIZATION | Track; expect near zero after training | Observational |
| Handoff mismatch incidence | STALE_HANDOFF / EXECUTION_PLAN_DRIFT | < 1 per issue avg | Target range |
| Failed/rolled-back migrations | migration audit failures | 0 unplanned | Hard target |
| Performance warnings/failures | performance tier results | 0 cert failures | Hard target |
| Release-integrity failures | release-verify failures | 0 | Hard target |
| Human review findings | PR review comments attributed to framework gaps | Track qualitatively | Observational |
| Escaped defects (framework execution) | Defects caused by guard bypass or bad routing | 0 | Hard target |
| Operator time saved | Compare pilot issue time vs historical | **Not claimed Pilot 1** | Deferred |
| Operator satisfaction/clarity | Short survey (1–5) after week 2 and week 6 | ≥ 4 avg clarity | Observational |

---

## Weekly reporting template

```text
Week N — Pilot metrics
- Issues active: 
- DoR reached: 
- Completed clean: 
- Top BLOCKED codes: 
- Recovery/repair count: 
- Stale locks: 
- Cert tier: PASS/FAIL
- Operator feedback notes:
```

---

## Mid-pilot checkpoint (week 3)

Review metrics against target ranges. Pause pilot if any **Pause for review** trigger in [`pilot-rollback-triggers.md`](pilot-rollback-triggers.md) fires.

---

## Final pilot review (week 6)

Deliver:

1. Metrics summary table (actual vs target)
2. Reason-code trend analysis
3. Documentation gaps found
4. Recommendation: continue / extend scope / halt

No automatic promotion to a stable tag based on metrics alone.
