# Controlled Internal Pilot Plan

Framework: **4.0.0** · channel **stable** · **`stable: true`**.

This pilot validates operator documentation, recovery paths, and measurable workflow outcomes **before** any stable promotion claim. Pilot success does **not** trigger automatic tagging or production promotion.

---

## Pilot summary

| Parameter | Value |
| --- | --- |
| **Duration** | ~6 weeks |
| **Scope** | Tier 1 and Tier 2 work only |
| **Projects** | Internal repositories only |
| **Exclusions** | Production-critical emergency fixes; unreviewed destructive migration |
| **Merge / deploy** | Human merge and deployment retained |
| **Product writes** | Only through existing mutation guards and confirmed slices |

---

## Tier eligibility (from `work-tiers.md`)

### Tier 1 — pilot eligible

Low risk, localized changes: copy/tooltip fixes, internal ergonomics, documentation typos, non-production fixtures. Optional peer review; no mandatory G-PLAN.

### Tier 2 — pilot eligible

Standard product change within a single boundary: API fields, isolated bug fixes, flag-gated features, contract-preserving refactors. Requires engineering lead approval and **G-PLAN** at plan approval stage.

### Not in initial pilot scope

**Tier 3+** (cross-cutting, security-sensitive, rollback-mandatory merge), **Tier 4** (platform/critical), production migration/cutover lanes, and emergency production hotfixes.

---

## Entry criteria

Complete [`pilot-readiness-checklist.md`](pilot-readiness-checklist.md) before first live issue:

- Repository onboarded with validated overlay
- Role registry complete in project-config
- Required CI tier configured and green locally
- `make ai-sdlc-release-verify` green
- `make ai-sdlc-health-report ROOT=<ws>` green
- Backup/rollback path documented where migration applies
- Operator completed [`operator-quick-start.md`](operator-quick-start.md)
- Named **Pilot Owner** and **Technical Reviewer** assigned

---

## Operating principles

1. **`/sdlc-run ISSUE`** is the daily entry point.
2. Prompts advise; guards and gates authorize.
3. One confirmation → one bounded action.
4. Weekly **Certification** tier run (pre-tag mandatory if tagging is ever considered).
5. No automatic release from pilot metrics alone.

---

## Pilot roles and responsibilities

Canonical framework roles only — no new runtime roles for pilot documentation.

### Pilot Owner

- **Canonical mapping:** `engineering_lead` / program owner
- **Responsibilities:** pilot scope, entry sign-off, weekly metrics review, stop/pause declarations
- **May approve:** pilot entry, scope exceptions within Tier 1/2, pause/resume after review
- **May not authorize:** product mutations, gate bypass, implementation slices
- **Escalation:** Framework Maintainer for framework defects; Security Reviewer for boundary issues
- **Evidence owned:** pilot readiness checklist, weekly metrics, incident records

### Operator / Engineer

- **Canonical mapping:** implementer
- **Responsibilities:** daily `/sdlc-run`, grooming, artifact production, repair/resume per runbook
- **May approve:** none (gates require designated approvers)
- **May not authorize:** gates, implementation authorization, merge/deploy
- **Escalation:** Pilot Owner when blocked twice on same reason code
- **Evidence owned:** lifecycle-events, operator session notes

### Technical Reviewer

- **Canonical mapping:** `engineering_lead` or delegate
- **Responsibilities:** plan/spec review, G-PLAN and merge gate approvals, slice scope validation
- **May approve:** G-PLAN, G-PR-MERGE per SoD rules
- **May not authorize:** implementation mutations directly
- **Escalation:** Security Reviewer for elevated-risk findings
- **Evidence owned:** review comments, gate approval records

### Product / Business Approver

- **Canonical mapping:** `product_owner`
- **Responsibilities:** requirement acceptance, DoR business criteria, prioritization
- **May approve:** G-GROOM business sign-off where configured
- **May not authorize:** technical implementation or merge
- **Escalation:** Pilot Owner for scope disputes
- **Evidence owned:** requirement doc, stakeholder decisions

### Security / Governance Reviewer

- **Canonical mapping:** `security_champion`
- **Responsibilities:** Tier 2+ security gate review, stop-trigger assessment, audit sampling
- **May approve:** G-SEC and security waivers per policy
- **May not authorize:** bypassing mutation guards
- **Escalation:** Framework Maintainer for evidence integrity failures
- **Evidence owned:** security scan review, stop/pause declarations

### Framework Maintainer

- **Canonical mapping:** platform / framework maintainer
- **Responsibilities:** framework defects, release-verify failures, baseline updates, documentation gaps
- **May approve:** pilot restart after framework corrective action
- **May not authorize:** product changes in pilot workspaces
- **Escalation:** executive sponsor for pilot halt
- **Evidence owned:** release/certification results, framework issue tracker

---

## Operating cadence

| Cadence | Activity |
| --- | --- |
| **Kickoff** | Complete readiness checklist; assign roles; run dry-run |
| **Daily** | Operator captures BLOCKED codes, repair paths, audit exports for active issues |
| **Weekly** | Health review (`make ai-sdlc-health-report`); reason-code trend review |
| **Weekly** | **Certification tier** run (pre-tag mandatory if tagging considered) |
| **Weekly** | Metrics update per [`pilot-metrics.md`](pilot-metrics.md) |
| **On incident** | Stop/pause assessment within 48h |
| **Mid-pilot (week 3)** | Checkpoint against metrics and rollback triggers |
| **Final (week 6)** | Pilot review report; no automatic tagging |

---

## Artifacts

| Document | Purpose |
| --- | --- |
| [`operator-guide.md`](operator-guide.md) | Full lifecycle |
| [`operator-quick-start.md`](operator-quick-start.md) | Onboarding |
| [`reason-code-runbook.md`](reason-code-runbook.md) | BLOCKED codes |
| [`recovery-runbook.md`](recovery-runbook.md) | Interruption procedures |
| [`pilot-readiness-checklist.md`](pilot-readiness-checklist.md) | Go/no-go |
| [`pilot-metrics.md`](pilot-metrics.md) | Success measures |
| [`pilot-rollback-triggers.md`](pilot-rollback-triggers.md) | Stop/pause rules |

Dry-run evidence: `ai-sdlc/tests/results/pilot-dry-run-report.json`.

The dry-run exercises lightweight readiness checks (release-verify, tier-manifest presence, migration rollback on neutral fixtures). **Full** Release and Certification aggregates (`make ai-sdlc-release-test`, `make ai-sdlc-certification-test`) are validated separately on a clean tree before pilot kickoff — not inside the dry-run harness.

---

## Out of scope for Pilot 1

- Declaring framework stable or marking it GA-ready
- Customer workspace overlay changes
- New orchestration or authorization semantics
- Autonomous merge/deploy
