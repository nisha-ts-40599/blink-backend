# Pilot Readiness Checklist

Use before the first live pilot issue. Framework: **4.0.0** · **`stable: true`**.

---

## Repository and workspace

- [ ] Repository onboarded to AI-SDLC overlay (`.cursor/ai-sdlc/`)
- [ ] `project-config.yaml` validated (`make ai-sdlc-validate-overlay ROOT=<workspace>`)
- [ ] `project-context.md` present and current
- [ ] Workspace topology documented (single-repo / monorepo / multi-repo)
- [ ] Internal project only (no customer production-critical path)

---

## Roles and governance

- [ ] Role registry complete in project-config (`approval_rules.roles`)
- [ ] Separation-of-duties mappings reviewed
- [ ] Named **Pilot Owner** assigned
- [ ] Named **Technical Reviewer** assigned
- [ ] Product and security approvers identified for Tier 2 gates

---

## CI and conformance

- [ ] Required CI tier configured per project policy
- [ ] `make ai-sdlc-fast-test` green on operator machine
- [ ] `make ai-sdlc-release-verify` green
- [ ] OPA installed if using protected profile (`make ai-sdlc-install-opa`)

---

## Operational health

- [ ] `make ai-sdlc-health-report ROOT=<workspace>` green or documented waivers
- [ ] Audit export path tested (`make ai-sdlc-audit-export ROOT=<workspace> ISSUE=<id>`)
- [ ] Lock inspect/recover understood by operator

---

## Migration (if applicable)

- [ ] `make ai-sdlc-migrate-workspace MODE=ASSESS ROOT=<ws> TARGET=4.0.0` run
- [ ] Backup path documented
- [ ] Rollback procedure reviewed ([`recovery-runbook.md`](recovery-runbook.md))
- [ ] No unreviewed destructive migration planned for Pilot 1

---

## Operator readiness

- [ ] Operator completed [`operator-quick-start.md`](operator-quick-start.md) (~15 min)
- [ ] Operator read [`operator-guide.md`](operator-guide.md) lifecycle summary
- [ ] [`reason-code-runbook.md`](reason-code-runbook.md) bookmarked
- [ ] Pilot limited to **Tier 1 and Tier 2** per [`pilot-plan.md`](pilot-plan.md)

---

## Pilot dry-run

- [ ] `make ai-sdlc-pilot-dry-run` executed
- [ ] Dry-run report reviewed (`ai-sdlc/tests/results/pilot-dry-run-report.json`)
- [ ] No unresolved critical issues

---

## Weekly ongoing (during pilot)

- [ ] Certification tier run scheduled (weekly, pre-tag mandatory)
- [ ] Reason-code review scheduled
- [ ] Metrics capture per [`pilot-metrics.md`](pilot-metrics.md)

---

## Sign-off

| Role | Name | Date | Signature |
| --- | --- | --- | --- |
| Pilot Owner | | | |
| Framework Maintainer | | | |
| Operator | | | |

Pilot may start only when all mandatory items above are checked or explicitly waived with evidence.
