# Pilot Rollback and Stop Triggers

Framework: **4.0.0** · **`stable: true`**.

---

## Immediate stop (halt pilot work)

Stop all pilot issues immediately. Preserve evidence. Do not delete state files.

| Trigger | Detection | Who declares stop |
| --- | --- | --- |
| Unauthorized product mutation | mutation audit without IMPLEMENTATION_AUTHORIZED | Operator or Pilot Owner |
| Lost or corrupted authoritative evidence | schema validation failure; missing audit chain | Framework Maintainer |
| Repeated replay of completed work on resume | lifecycle-events show duplicate completion | Operator |
| Role/gate bypass | approve-gate without valid role; SoD violation | Security/Governance Reviewer |
| Handoff consumed incorrectly | implement without consumed handoff | Technical Reviewer |
| Implementation without valid authorization | MUTATION_DENIAL ignored; writes proceed | Pilot Owner |
| Rollback cannot restore expected state | migration rollback failure | Framework Maintainer |
| Security boundary violation | path traversal, symlink escape events | Security/Governance Reviewer |
| Evidence integrity failure | release-verify or audit linkage failure | Framework Maintainer |

**Evidence preservation:** export audit bundles for all active issues; capture operational health and git SHA; file incident record.

**Restart approval:** Pilot Owner + Framework Maintainer + Security/Governance Reviewer sign-off after root-cause and corrective action.

---

## Pause for review (pilot may continue after fix)

| Trigger | Threshold | Review owner |
| --- | --- | --- |
| Repeated stale-lock incidents | > 2 per week same workspace | Pilot Owner |
| Repeated manual state repair | > 2 issues requiring non-standard repair | Framework Maintainer |
| Performance failure beyond threshold | Certification performance tier fail | Framework Maintainer |
| Genericity/project-isolation defect | Customer-specific path in framework output | Framework Maintainer |
| Excessive false BLOCKED states | > 30% transitions BLOCKED without valid cause | Pilot Owner |
| Significant operator confusion | Survey clarity < 3 or repeated escalations | Pilot Owner |
| CI tier instability | > 2 flaky cert failures same week | Framework Maintainer |

**Evidence preservation:** weekly metrics snapshot; reason-code log; failing CI artifacts.

**Restart approval:** Pilot Owner documents corrective action; Framework Maintainer ack for framework defects.

---

## Declaration process

1. Declarer notifies pilot channel with reason code and issue ids.
2. Freeze new `IMPLEMENTATION_SLICE` authorizations.
3. Run read-only diagnostics on all active issues.
4. Export audit evidence.
5. Schedule incident review within 48 hours.

---

## Unsafe responses (never use)

- Deleting workflow-state or handoff files
- Manually editing gates/authorization in YAML
- Disabling mutation guards or quarantine for convenience
- Force-pushing or hard-resetting shared branches to hide errors
- Marking framework stable or GA-ready to meet schedule

---

## Related documents

- [`recovery-runbook.md`](recovery-runbook.md)
- [`reason-code-runbook.md`](reason-code-runbook.md)
- [`pilot-plan.md`](pilot-plan.md)
