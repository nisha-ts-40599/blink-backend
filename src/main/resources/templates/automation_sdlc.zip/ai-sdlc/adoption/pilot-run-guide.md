# AI-SDLC Pilot Run Guide

**Purpose:** Step-by-step instructions to run one real work item through the AI-SDLC workflow — from MCP validation through technical plan and first implementation step.

**Prerequisites:**
- `make ai-sdlc-install` completed
- `.cursor/mcp.json` configured with active Filesystem, GitHub, and Jira MCP tokens (Azure DevOps is not used in the current pilot)
- A real Jira issue selected for the pilot
- `.cursor/ai-sdlc/project-context.md` and `.cursor/ai-sdlc/project-config.yaml` filled in for the target project
  (legacy fallback: `ai-sdlc/project-context.md`, `ai-sdlc/project-config.yaml`)

---

## Lifecycle branches — which path applies?

Most pilot work follows the **standard bug/feature path**. Optional layers activate only when classification and project policy require them. See [`README.md`](README.md#lifecycle-branches-phase-13) for the full summary.

| Path | When it applies | Extra guides |
|------|-----------------|--------------|
| **Standard bug/feature** | Default Tier 1–2 work | This guide |
| **Tier 3+ rollback-sensitive** | Tier 3+ or sensitive `work_type` | [`rollback-policy-guide.md`](rollback-policy-guide.md) |
| **Modernization / migration** | `work_type` or `modernization.enabled` activates the lane | [`modernization-lane-guide.md`](modernization-lane-guide.md) |
| **Cutover-active modernization** | `cutover.required: true` or cutover policy matches | [`cutover-readiness-guide.md`](cutover-readiness-guide.md), [`post-migration-validation-guide.md`](post-migration-validation-guide.md), [`production-migration-gates-guide.md`](production-migration-gates-guide.md) |

**Pilot recommendation:** Start with a **Tier 2 standard feature** (not Tier 3+, not modernization/cutover) unless your pilot scope explicitly includes those policies.

**Verify routing and artifacts** with the example workspaces (generic fixtures):

```bash
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/rollback-tier3 ISSUE=GEN-3
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/modernization-lane ISSUE=MOD-1
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/cutover-modernization ISSUE=CUT-1
```

Use `make ai-sdlc-validate-artifacts ROOT=<path> ISSUE=<id>` to confirm artifact completeness matches stage-router recommendations.

---

## Pilot command discipline

Use these commands as the **canonical** routing and validation sources at every stage transition:

| Command | When to run |
|---------|-------------|
| `make ai-sdlc-stage-router ROOT=<workspace> ISSUE=<id>` | **Start of every session** and after each major workflow-state update |
| `make ai-sdlc-validate-artifacts ROOT=<workspace> ISSUE=<id>` | Before advancing stage; confirms artifact completeness for suggested next stage |
| `make ai-sdlc-validate-pre-spec ROOT=<workspace> ISSUE=<id>` | Before `technical-plan.prompt.md`; validates requirement/classification/impact/spec/review readiness |
| `make ai-sdlc-rollback-check ROOT=<workspace> ISSUE=<id>` | Tier 3+ or rollback-sensitive work before merge readiness |
| `make ai-sdlc-validate-transition WORKFLOW_STATE=... SET_STAGE=...` | Optional explicit transition check (uses same artifact matrix as router) |

**Do not rely only on prompt-based routing** (`stage-router.prompt.md`). If the prompt disagrees with Make output, **trust the Make output**.

**Gate approvals:** Never mark a gate `approved: true` without a named approver and a reference URL (comment, PR, or evidence link). Use `gate-approval-capture.prompt.md` or `update_workflow_state.py --add-approval` with `GATE=approver:url`.

**MCP Phase 0 (mandatory before live pilot):**

- Verify read-only access to Filesystem, Jira, and GitHub MCP.
- Run the **write-block safety tests** in Phase 0 below — Jira/GitHub write attempts must fail.
- Do not allow unattended tracker or Git write operations during the pilot.

### Stop / pause triggers

Pause the pilot immediately if any of the following occur:

| Trigger | Action |
|---------|--------|
| Gate approved without evidence (missing approver or reference URL) | Stop; fix workflow-state; re-run stage-router |
| MCP write safety failure (issue/PR created by MCP test) | Revoke token; stop until MCP is read-only |
| Repeated router vs human disagreement on next step | Escalate to lead; clarify SOP before continuing |
| Workflow-state not maintained after major steps | Pause until state is current |
| Framework drift in product repo (`ai-sdlc-guard-framework-clean` fails) | Stop product work; file framework gap report |
| Team bypasses tier/gate requirements | Pause; retrain on approval gates and work tiers |

---

## Enterprise adoption pilot

Use this section when running a **controlled enterprise adoption pilot** with the command spine (`command-spine-playbook.md`). For a single-team technical pilot, follow the steps above.

### Pilot selection criteria

Choose one issue that is real but low risk, completable in one cycle, easy to roll back, and not dependent on deployment automation or external API integrations unless reviewers are available.

### Required roles

| Role | Responsibility |
| --- | --- |
| Requester / product owner | Confirms requirement, priority, acceptance expectations |
| Engineering lead | Confirms implementation approach and plan readiness |
| Implementer | Performs work and records artifacts through commands |
| PR reviewer / maintainer | Reviews PR and confirms merge approval validity |
| Security reviewer (when required) | Confirms G-SEC evidence |
| Pilot observer / scribe | Records usability gaps, evidence gaps, confusion |
| Deployment / release owner (optional) | Advises on deployment boundaries only — no deployment automation |

### Framework vs product workspace separation

- **Product workspace:** real issue work, code changes, PR, review evidence, workflow-state
- **Framework repo:** generic guides, templates, gap logs — no real client URLs or issue IDs in framework docs

### Gap log and retrospective

During the pilot, use [`templates/pilot-gap-log-template.md`](templates/pilot-gap-log-template.md). Severity: `blocker`, `high`, `medium`, `low`. Types: `docs`, `command_ux`, `validation`, `workflow`, `training`, `policy`.

After completion, use [`templates/pilot-retrospective-template.md`](templates/pilot-retrospective-template.md).

### Enterprise pilot success criteria

- One real low-risk issue reaches closure report generation
- State-changing commands were dry-run before `WRITE=1`
- Human approvals recorded with reviewable evidence
- PR registration, PR approval, and merge closure remained distinct
- Merge closure was not treated as deployment readiness
- Gap log entries are specific enough to drive documentation improvements

### Authority boundaries (internal production candidate)

Do **not** conflate these steps:

| Step | Meaning | Does NOT mean |
|------|---------|---------------|
| `ai-sdlc-register-pr` | Records candidate metadata | PR is merged; URL is required |
| G-PR-MERGE approval | Human authorizes merge | Code is on main |
| `ai-sdlc-close-merge` | Records verified merge reconciliation | Issue is closed |
| Bootstrap completion candidate (Phase 5) | Managed bootstrap run complete | Delivery readiness (Phase 4) |
| AI implementation review | Automated advisory review | Developer attestation |

Local candidates: use `LOCAL_UNPUSHED_CANDIDATE` without a PR URL when the provider is unavailable — the framework does not push branches by default.

See [`governance/internal-production-candidate/README.md`](../governance/internal-production-candidate/README.md).

### Escalation

Pause immediately if: gate approved without evidence; MCP write safety failure; repeated router vs human disagreement; framework drift guard fails; team bypasses tier/gate requirements.

See also: [`enterprise-rollout.md`](enterprise-rollout.md), [`command-spine-playbook.md`](command-spine-playbook.md), [`docs/operating-model/pilot-readiness-assessment.md`](../../docs/operating-model/pilot-readiness-assessment.md).

---

## Pre-development readiness before technical-plan

Before running `technical-plan.prompt.md`, confirm the requirement-to-spec bundle is ready:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<issue-id>
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<issue-id>
make ai-sdlc-validate-pre-spec ROOT=<workspace-root> ISSUE=<issue-id>
```

Minimum handoff expectations:

- `requirement_doc` is present and DoR-ready.
- `classification_record` is present.
- `work_tier` and `work_type` are set.
- `impact_doc` is present for Tier 2+.
- `spec_doc` uses the adaptive shape matching the work type.
- `spec_review_record` is expected for Tier 2+.
- For Tier 3+ or security/data-sensitive work, missing `spec_review_record` blocks technical-plan handoff.
- Tier 2 `WARN` / `CONDITIONAL` from `validate-pre-spec` may proceed only with explicit human acceptance.

Adaptive spec shape guidance:

- Use the **bug-fix** shape for bugs; do not convert defects into features.
- Use the **feature/enhancement** shape for product capability changes.
- Use the **spike/investigation** shape when technical planning should wait for a decision.
- Map `FR-xxx` requirements to `AC-xxx` acceptance criteria.
- Keep implementation design and step ordering in `technical-plan.prompt.md`.

First pilot guidance: use a **Tier 2 standard feature**. Avoid production bugs, spikes,
modernization, cutover, and Tier 4 work as the first pilot. Capture grooming and
spec-review friction as pilot feedback.

---

## Phase 0 — MCP validation (run in Cursor chat before anything else)

Confirm MCP servers are reading real data. Open a Cursor chat and run each query below. These are read-only tests.

> **Note:** Azure DevOps (ADO) is not available in the current pilot. Jira is the primary issue tracker. If ADO becomes available later, refer to the optional appendix in `local-mcp-setup-guide.md`.

### 0.1 Filesystem MCP

```
List the files and directories in the project root.
```

Expected: directory listing of your project repo.

```
Read the file app/main.py (or your project's main entry point).
```

Expected: file contents returned by Cursor.

**Status to record:**
- [ ] Filesystem MCP: ✅ working / ❌ not working
- Notes: ___________

### 0.2 Jira MCP

```
Read Jira issue {YOUR-JIRA-KEY} including summary, description, acceptance criteria, comments,
status, assignee, sprint, labels, components, linked issues, and attachments if available.
Do not update the issue.
```

Replace `{YOUR-JIRA-KEY}` with a real issue key from your Jira project (e.g., `TS-1` or `PROJ-42`).

Expected: issue body, acceptance criteria, status, assignee, sprint, and comments returned.

```
List the open issues in the current sprint for Jira project {YOUR-JIRA-PROJECT-KEY}.
```

Expected: sprint issue list returned.

**Write-block safety test:**
```
Create a Jira issue titled "MCP write safety test".
```

Expected result: The request must fail, be refused, or be denied by permission.  
If a Jira issue is created → **Revoke your Atlassian API token immediately** at `https://id.atlassian.com/manage-profile/security/api-tokens`. Delete the test issue. Regenerate with a read-only service account.

**Status to record:**
- [ ] Jira read MCP: ✅ working / ❌ not working
- [ ] Write safety: ✅ blocked (correct) / ❌ created issue (STOP — revoke token)
- Notes: ___________

### 0.3 GitHub MCP

```
List the open pull requests in repository {YOUR-GITHUB-ORG}/{YOUR-REPO}.
```

```
Read the CI workflow run status for the latest commit on the main branch of {YOUR-GITHUB-ORG}/{YOUR-REPO}.
```

**Write-block safety test:**
```
Create a new issue in {YOUR-GITHUB-ORG}/{YOUR-REPO} titled "MCP write safety test".
```

Expected: error or refusal.

**Status to record:**
- [ ] GitHub read MCP: ✅ working / ❌ not working
- [ ] Write safety: ✅ blocked (correct) / ❌ wrote item (STOP — revoke token)
- Notes: ___________

### 0.4 MCP validation summary before proceeding

All three must pass before starting the pilot:

| MCP | Status | Write blocked? |
|-----|--------|---------------|
| Filesystem | ✅/❌ | N/A (read-only by design) |
| Jira | ✅/❌ | ✅/❌ |
| GitHub | ✅/❌ | ✅/❌ |

> **Azure DevOps:** Not used in the current pilot. Leave the ADO block commented out in `.cursor/mcp.json`.

**Do not proceed if any MCP is failing or if write safety is not confirmed.**

---

## Phase 1 — Select your work item and create the workflow-state file

### 1.1 Select the work item

Choose a **Tier 2 feature** from the current sprint. Ideal candidate:
- A new API endpoint, a new service feature, or a well-scoped backend change
- Not too large (implementable in 3–5 steps)
- Not a security-critical system change (keep Tier 2 for the pilot — avoid Tier 3+)
- No external integrations required

Record:
- **Issue ID:** ___________
- **Title:** ___________
- **Source:** Jira / GitHub
- **URL:** ___________

### 1.2 Create the workflow-state file

**Preferred (workspace overlay):**

```bash
mkdir -p .cursor/ai-sdlc/workflow-state/{YOUR-ISSUE-ID}
cp ai-sdlc/workflow-state/TEMPLATE.yaml .cursor/ai-sdlc/workflow-state/{YOUR-ISSUE-ID}/{YOUR-ISSUE-ID}.yaml
```

**Legacy fallback** (framework repo or embedded `ai-sdlc/`):

```bash
cp ai-sdlc/workflow-state/TEMPLATE.yaml ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml
```

Fill in the top fields:
```yaml
issue_id: "YOUR-ISSUE-ID"            # e.g. "TS-42" (Jira) or "org/repo#42" (GitHub)
issue_url: "https://YOUR_ORG.atlassian.net/browse/YOUR-ISSUE-ID"  # Jira issue URL
title: "Your feature title"
work_tier: null          # filled in at Phase 2 step 2
current_stage: "REQUIREMENT"
updated_at: "2026-06-18T09:00:00Z"  # current ISO8601 timestamp
```

Leave all gates, artifacts, and agent_outputs as null/false initially.

### 1.3 Validate the new file

```bash
# Lint YAML structure (add file to yamllint scope first, or validate manually)
python -c "import yaml; yaml.safe_load(open('ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml'))" && echo "YAML valid"

# Check gates
python ai-sdlc/tools/orchestration/check_gates.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml

# Validate transition to CLASSIFIED (first allowed transition)
python ai-sdlc/tools/orchestration/validate_transition.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --target-state CLASSIFIED
```

Expected gate check: `Safe to advance: YES` (no gates required at REQUIREMENT stage).
Expected transition check: `Valid transition: YES`.

---

## Phase 2 — Context prefill, context bundle, and stage router

### 2.0 Run the context prefill report (new — do this first)

Before generating the context bundle, run the prefill report to see exactly what to fetch in Cursor and get pre-built MCP queries for your specific issue ID.

```bash
python ai-sdlc/tools/orchestration/context_prefill.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --target-prompt clarify-requirement \
  --emit-template /tmp/{YOUR-ISSUE-ID}-prefill-input.json
```

This prints:
- Which fields are **auto-filled** by script — nothing to do
- Which fields are **MCP-readable** — with the exact Cursor query for your issue ID
- Which fields are **developer-required** — must provide manually
- Which fields are **human gates** — require explicit approval, never auto-filled

The `--emit-template` flag produces a blank JSON file for you to fill with values from Cursor.

**In Cursor chat, run the suggested Jira queries:**
```
Read Jira issue {YOUR-ISSUE-ID} including summary, description, acceptance criteria,
comments, status, assignee, sprint, labels, components, linked issues, and attachments if available.
Do not update the issue.
```
```
Read the acceptance criteria and any linked issues for Jira issue {YOUR-ISSUE-ID}.
```

Paste the results into your `/tmp/{YOUR-ISSUE-ID}-prefill-input.json` template.

**Import and validate (optional — provides a structured prefill-context.json):**
```bash
python ai-sdlc/tools/orchestration/context_prefill.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --target-prompt clarify-requirement \
  --import /tmp/{YOUR-ISSUE-ID}-prefill-input.json \
  --output /tmp/{YOUR-ISSUE-ID}-prefill-context.json
```

Expected output: `Ready to run prompt: YES — all inputs are present`

### 2.1 Generate context bundle

```bash
python ai-sdlc/tools/orchestration/build_context_bundle.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --project-context ai-sdlc/project-context.md \
  --project-config ai-sdlc/project-config.yaml \
  --target-agent "Requirement Analyst Agent" \
  --target-prompt clarify-requirement \
  --output /tmp/{YOUR-ISSUE-ID}-context.json
```

Review the output. The script now prints:
- `safe_to_proceed` — `yes`, `no`, or `conditional`
- `Guardrails: found — ai-sdlc/governance/enterprise-engineering-guardrails.md` — confirms auto-detection worked
- **Placeholder Coverage Report** — filtered to `clarify-requirement`:
  - `AUTO-FILLED BY SCRIPT`: PROJECT_CONTEXT, WORKFLOW_STATE, ENGINEERING_GUARDRAILS
  - `MCP-READABLE — ask Cursor explicitly`: REQUIREMENT, ACCEPTANCE_CRITERIA (with Cursor query shown)
  - `MANUAL DEVELOPER INPUT REQUIRED`: any fields with no MCP source
  - `HUMAN GATE — never auto-filled`: relevant approval gates
- Note `missing_context` items and `sensitive_data_flags`

The coverage report tells you exactly what to read in Cursor before starting the prompt session.

### 2.2 Run stage router (in Cursor chat)

Open a new Cursor chat. Paste:
1. The content of your `ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml`
2. The content of `ai-sdlc/project-context.md`
3. The content of `ai-sdlc/project-config.yaml`

Then run the prompt:
```
Use ai-sdlc/prompts/stage-router.prompt.md with:
{{WORKFLOW_STATE}} = <paste workflow state YAML>
{{PROJECT_CONTEXT}} = <paste project-context.md>
{{PROJECT_CONFIG}} = <paste project-config.yaml>
```

**Expected output:**
- Current stage: REQUIREMENT
- Safe to proceed: YES
- Next agent: Requirement Analyst Agent
- Next prompt: clarify-requirement.prompt.md
- Required placeholders: {{REQUIREMENT}}, {{PROJECT_CONTEXT}}
- Exact human action: Run clarify-requirement.prompt.md with the work item body as {{REQUIREMENT}}

Record the stage router output for the pilot report.

---

## Phase 3 — Requirement clarification (Cursor chat with Jira MCP)

### 3.0 Grooming prep (terminal)

Before opening Cursor chat, run grooming prep from the repo root:

```bash
make ai-sdlc-groom-prep ISSUE={YOUR-ISSUE-ID}
```

This runs `context_prefill.py` and `build_context_bundle.py` and writes
`/tmp/{YOUR-ISSUE-ID}-clarify-requirement-context.json`. It does **not** call Jira.

**BA/PO input:** Share [`ba-po-requirement-grooming-guide.md`](ba-po-requirement-grooming-guide.md)
with stakeholders so Jira issues contain testable acceptance criteria before grooming.

### 3.1 Run clarify-requirement.prompt.md

Open a new Cursor chat. With Jira MCP active, Cursor can read the issue body directly.

```
Read Jira issue {YOUR-ISSUE-ID} including summary, description, acceptance criteria,
comments, status, assignee, sprint, labels, components, linked issues, and attachments if available.
Do not update the issue.
Use its description and acceptance criteria as {{REQUIREMENT}}.
Also read ai-sdlc/project-context.md as {{PROJECT_CONTEXT}}.
Now run ai-sdlc/prompts/clarify-requirement.prompt.md.
```

If Jira MCP is not returning the full body yet, paste it manually:
```
Use ai-sdlc/prompts/clarify-requirement.prompt.md with:
{{REQUIREMENT}} = <paste the Jira issue description>
{{PROJECT_CONTEXT}} = <paste project-context.md>
```

**Expected output:**
- Structured requirement following `templates/requirement-template.md`
- Requirement type identified (Bug, Enhancement, New feature, etc.)
- List of open questions that need resolution
- Draft acceptance criteria and suggested test cases by category
- Privacy/copyright review and Definition of Ready checklist
- Grooming decision (ready for classify-work, needs clarification, etc.)

Set `{{REQUIREMENT_TYPE}}` when known (from Jira issue type or labels). For bugs, also supply
sanitized `{{REPRODUCTION_STEPS}}`, `{{CURRENT_BEHAVIOR}}`, and `{{EXPECTED_BEHAVIOR}}` when available.

**Human action:**
1. Take each open question to the product owner or requester
2. Resolve every blocking question
3. Save output to `.cursor/ai-sdlc/workflow-state/<ISSUE>/requirement.md` (lite or full template per SOP)
4. Extract grooming state and validate DoR:

```bash
make ai-sdlc-extract-grooming-state ROOT=<ROOT> ISSUE=<ISSUE> WRITE=1
make ai-sdlc-validate-requirement-dor ROOT=<ROOT> ISSUE=<ISSUE> WRITE=1
```

5. Run `/requirement-grooming-status <ISSUE>` — continue stakeholder pack / revision / sign-off / G-GROOM approval (`make ai-sdlc-approve-gate ... GATE=G-GROOM ...`) as directed
6. Capture grooming metrics — copy `templates/grooming-metrics-template.yaml` to
   `workflow-state/<ISSUE>/grooming-metrics.yaml`
7. Phase 0 exit → Phase 1 entry: `/classify-work <ISSUE>` **only** when DoR is ready and G-GROOM is approved when required

**One-line bugs:** Run clarify-requirement with read-only code inspection (`{{REPOSITORY_CONTEXT}}`
or Filesystem MCP) before escalating to stakeholders. The groomed output should include a
code-informed repro plan, findings classification, and stakeholder clarification pack.
**Do not proceed to classify-work** until DoR validator passes.

See **Requirement grooming by type** (below) for type-specific expectations.

**Developer SOP:** [`requirement-grooming-sop.md`](requirement-grooming-sop.md) ·
**BA/PO guide:** [`ba-po-requirement-grooming-guide.md`](ba-po-requirement-grooming-guide.md) ·
**Review checklist:** [`requirement-grooming-review-checklist.md`](requirement-grooming-review-checklist.md) ·
**Examples:** [`examples/requirements/`](../examples/requirements/) (bug, enhancement, feature, migration, QA, platform, docs)

Use **lite template** for Tier 1 / docs / simple bugs; **full template** otherwise.
See [`../templates/requirement-template-lite.md`](../templates/requirement-template-lite.md).

### 3.2 Update workflow state

```bash
# Add requirement artifact reference
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --add-artifact "requirement_doc=ai-sdlc/workflow-state/{YOUR-ISSUE-ID}/requirement.md" \
  --write

# Update analyst summary
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --add-agent-output "analyst_summary=<one-line summary of what was clarified>" \
  --write
```

---

## Phase 4 — Work classification

### 4.1 Run classify-work.prompt.md

Open a new Cursor chat:

```
Use ai-sdlc/prompts/classify-work.prompt.md with:
{{REQUIREMENT}} = <paste clarified requirement from Phase 3>
{{PROJECT_CONTEXT}} = <paste project-context.md>
```

**Expected output:** Tier 1–4 recommendation with explicit justification.

**Human action:**
1. Review the AI recommendation
2. Confirm or override (document reason if overriding)
3. Add the tier label to the Jira issue

### 4.2 Update workflow state

```bash
# Validate transition to CLASSIFIED
python ai-sdlc/tools/orchestration/validate_transition.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --target-state CLASSIFIED

# Update stage and tier
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --set-current-stage CLASSIFIED \
  --write

# Edit the YAML directly to set work_tier and gates.g_plan.required
# (update_workflow_state.py does not expose work_tier update — this is intentional:
#  tier changes are manually reviewed; use your editor)
```

After manually setting `work_tier` and `gates.g_plan.required`, verify:
```bash
python ai-sdlc/tools/orchestration/check_gates.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml
```

---

## Requirement grooming by type

**SOP:** [`requirement-grooming-sop.md`](requirement-grooming-sop.md) · **Checklist:**
[`requirement-grooming-review-checklist.md`](requirement-grooming-review-checklist.md)

`clarify-requirement.prompt.md` adapts grooming to the requirement type. Set
`{{REQUIREMENT_TYPE}}` when known.

| Template | When to use |
|----------|-------------|
| [`requirement-template-lite.md`](../templates/requirement-template-lite.md) | Tier 1, docs/tooling, simple bugs (~10 min) |
| [`requirement-template.md`](../templates/requirement-template.md) | Tier 2+, production, security, migration |

Examples: [`../examples/requirements/`](../examples/requirements/)

| Type | Key grooming focus | Repo inspection | Typical next step |
|------|-------------------|-----------------|-------------------|
| **Bug** | Repro steps, observed vs expected, severity; one-liners incomplete — run read-only code analysis first; tag findings; DoR blocked until runtime/PO gaps closed | Read-only via Filesystem MCP if allowed | DoR validator → classify-work; impact-analysis if high severity |
| **Enhancement** | Current vs proposed behavior, regression, backward compatibility | Optional read-only | classify-work |
| **New feature** | MVP scope, integrations, rollout/rollback | Recommended read-only | classify-work → impact-analysis (Tier 2+) |
| **New product** | Vision, personas, MVP, auth/compliance | Discovery only | setup-new-project/workspace, then classify-work |
| **Modernization/migration** | Source/target, cutover, rollback, equivalence criteria | Required read-only | impact-analysis before technical-plan |
| **QA/test automation** | SUT, environments, CI gates, flake handling | Read test layout | classify-work |
| **Cloud/devops/platform** | IaC scope, secrets, blast radius, approvals | Read infra files if present | classify-work (often Tier 3+) |
| **Documentation/process/tooling** | Audience, outcome, maintenance owner | Optional | classify-work (often Tier 1–2) |

### Public-reference and data-safety rules

All grooming and downstream prompts follow [`public-reference-and-data-safety.md`](../governance/public-reference-and-data-safety.md):

- Public sources inform **patterns and standards only** — no proprietary or copyrighted copy
- Customer/production data must be **sanitized or excluded**
- Repo inspection during grooming is **read-only**
- Public research findings are **not invented** — use placeholders until a human verifies sources
- Assumptions from public data must be labeled **assumption**

### Requirement grooming by persona

| Lens | Validates |
|------|-----------|
| **BA** | Business goal, scope, non-goals, testable AC, stakeholder gaps |
| **QA** | Testability, repro/env gaps, edge/regression tests, DoR from QA view |
| **Domain** | Product fit, domain constraints, domain questions (no invented rules) |
| **Security/Data** | Classification, auth, compliance, tier escalation when applicable |

Persona lenses run **inside clarify-requirement** — not as separate autonomous agents.

---

## Phase 5 — Impact analysis and technical planning (Tier 2+)

### 5.1 Run impact-analysis.prompt.md

Open a new Cursor chat. With Filesystem MCP, Cursor can read the repo structure directly.

```
Read the directory structure of the project using filesystem MCP.
Read the relevant source files for this feature area.
Then use ai-sdlc/prompts/impact-analysis.prompt.md with:
{{REQUIREMENT}} = <clarified requirement>
{{PROJECT_CONTEXT}} = <project-context.md>
{{TECH_STACK}} = <tech stack from project-config.yaml>
```

**Expected output:** Affected components, DB/API surface, migration risk, test scope, rollback approach.

**Human action:** Verify the component list against actual codebase. Add anything the AI missed.

### 5.2 Run technical-plan.prompt.md

Open a new Cursor chat:

```
Read ai-sdlc/project-context.md and ai-sdlc/project-config.yaml.
Then use ai-sdlc/prompts/technical-plan.prompt.md with:
{{REQUIREMENT}} = <clarified requirement with resolved questions>
{{PROJECT_CONTEXT}} = <project-context.md>
{{SECURITY_MODEL}} = <security section from project-context.md>
{{APPROVAL_RULES}} = <approval_roles from project-config.yaml>
```

**Expected output:** Ordered implementation steps (typically 4–6), DB migration plan, risk notes, rollback plan.

**Human action:**
1. Review every step — are they ordered correctly? Is the DB migration step first?
2. Save to `ai-sdlc/workflow-state/{YOUR-ISSUE-ID}/technical-plan.md`
3. Post the plan as a comment on the Jira issue and request G-PLAN approval

### 5.3 Update workflow state

```bash
# Add plan artifact
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --add-artifact "plan_doc=ai-sdlc/workflow-state/{YOUR-ISSUE-ID}/technical-plan.md" \
  --write

# Advance stage to PLAN_DRAFTED
python ai-sdlc/tools/orchestration/validate_transition.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --target-state PLAN_DRAFTED

python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --set-current-stage PLAN_DRAFTED \
  --write
```

---

## Phase 6 — G-PLAN approval (human gate)

**This is always a human step. Do not proceed without it.**

**H9:** Prefer `make ai-sdlc-approve-gate GATE=G-PLAN DECISION=approved WRITE=1` so G-PLAN binds specification, technical plan, and test/QA strategy versions/hashes. Artifact files alone do not prove approval. Tier 2+ requires reviewed pre-development documents and AC verification coverage.

The engineering lead (named in `project-config.yaml` under `approval_roles.g_plan`) reviews the technical plan and posts an explicit approval comment on the Jira issue or GitHub PR:

```
G-PLAN approved. Plan reviewed — steps look correct. Migration first, endpoint last.
— [Name], [Date]
```

After the approval is recorded, update the workflow state:

```bash
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --add-approval "G-PLAN=approver-name@domain.com:https://YOUR_ORG.atlassian.net/browse/{ID}#comment-{N}" \
  --write
```

Verify gates are now satisfied:

```bash
python ai-sdlc/tools/orchestration/check_gates.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --target-state IMPLEMENTING
```

Expected: `Safe to advance: YES` — G-PLAN: satisfied.

```bash
python ai-sdlc/tools/orchestration/validate_transition.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --target-state IMPLEMENTING
```

Expected: `Valid transition: YES`.

```bash
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --set-current-stage PLAN_APPROVED \
  --write
```

---

## Phase 7 — Context bundle refresh + first implementation step

### 7.1 Regenerate context bundle

```bash
python ai-sdlc/tools/orchestration/build_context_bundle.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --project-context ai-sdlc/project-context.md \
  --project-config ai-sdlc/project-config.yaml \
  --target-agent "Backend Implementation Agent" \
  --target-prompt implement-step \
  --output /tmp/{YOUR-ISSUE-ID}-impl-context.json
```

Expected: `Safe to proceed: YES` with G-PLAN gate confirmed.
If `safe_to_proceed = NO`, read the blocker and resolve it before continuing.

### 7.2 Run implement-step.prompt.md for Step 1 only

Open a new Cursor chat. With Filesystem MCP, Cursor reads relevant source files directly.

```
Read the relevant source files for this feature using filesystem MCP.
Then use ai-sdlc/prompts/implement-step.prompt.md with:
{{CURRENT_STEP}} = Step 1: <paste Step 1 from the technical plan>
{{REPOSITORY_CONTEXT}} = <read from filesystem MCP — relevant source files>
{{PROJECT_CONTEXT}} = <project-context.md>
{{ENGINEERING_GUARDRAILS}} = <ai-sdlc/governance/enterprise-engineering-guardrails.md>
```

**Expected output:**
- Code for Step 1 only (model, migration, or first component)
- Notes on PHI/security handling if applicable
- Verification command to run locally

**Developer action:**
1. Review every line of generated code — you are accountable for it
2. Verify any security/PHI handling is correct
3. Apply code to your feature branch
4. Run tests locally
5. Do not proceed to Step 2 until Step 1 is verified

### 7.3 Update workflow state

```bash
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/{YOUR-ISSUE-ID}.yaml \
  --set-current-stage IMPLEMENTING \
  --write
```

---

## Phase 8 — Pilot metrics capture

After completing through Step 7, record these metrics:

| Metric | Value |
|--------|-------|
| Jira issue ID | |
| Total time: issue → clarified requirement (mins) | |
| Total time: clarified requirement → G-PLAN approved (mins) | |
| Total time: context bundle preparation before MCP (mins) | |
| Total time: context bundle preparation with MCP (mins) | |
| Manual context items provided (count) | |
| MCP-auto-filled context items (count) | |
| Open questions found by clarify-requirement | |
| Affected components identified by impact-analysis | |
| Implementation steps in technical plan | |
| Workflow-state updates made (count) | |
| Gate violations detected by check_gates.py | |
| Invalid transitions caught by validate_transition.py | |
| PHI/PII/sensitivity flags raised by context bundle | |
| Developer confidence: "AI output was usable as-is" (1–5) | |
| Developer confidence: "Plan was accurate to the actual codebase" (1–5) | |
| Blockers encountered (describe) | |

---

## Pilot validation report template

Fill in after completing all phases:

```
AI-SDLC Pilot Validation Report
================================
Date: 
Jira issue: 
Developer: 
Project: 

MCP validation:
  Filesystem: PASS / FAIL
  Jira: PASS / FAIL
  GitHub: PASS / FAIL
  Azure DevOps: NOT USED IN CURRENT PILOT
  Write safety: CONFIRMED / ISSUE (describe)

Workflow-state file: ai-sdlc/workflow-state/{ISSUE-ID}.yaml
  Created: YES/NO
  Gate check on PLAN_APPROVED: PASS / FAIL
  Transition PLAN_APPROVED → IMPLEMENTING: VALID / INVALID

Context bundle:
  safe_to_proceed: YES / NO / CONDITIONAL
  Missing context items: (count and list)
  Sensitive data flags: (list or NONE)

Stage router:
  Next prompt recommended: clarify-requirement
  Routing was: CORRECT / INCORRECT (describe)

Prompts run:
  clarify-requirement: YES / NO — open questions found: (count)
  classify-work: YES / NO — tier: (1/2/3/4)
  impact-analysis: YES / NO — components identified: (count)
  technical-plan: YES / NO — steps: (count)
  implement-step (Step 1): YES / NO

Gates recorded:
  G-PLAN: YES / NO — approver: 
  G-PR-MERGE: not yet
  G-DEPLOY: not yet

Metrics:
  Context prep time before MCP: (mins)
  Context prep time with MCP: (mins)
  Manual items: (count)
  MCP items: (count)

Framework/doc fixes needed:
  (list any gaps, confusion, missing steps, or incorrect guidance)

Overall pilot result: SUCCESS / PARTIAL / BLOCKED
Recommendation for scaling: YES / YES WITH FIXES / NO
```

---

## Common blockers and fixes

| Blocker | Fix |
|---------|-----|
| `safe_to_proceed = NO — G-PLAN required but not recorded` | Get approval, then run `update_workflow_state.py --add-approval` |
| `project-context.md is stale` | Update `project-context.md` and set `**Last reviewed:**` to today |
| Jira MCP returns issue body but not acceptance criteria | Acceptance criteria may be in a custom field — paste it manually or check the Jira field name in the MCP response |
| Filesystem MCP returns wrong repo files | Confirm `${workspaceFolder}` in `.vscode/mcp.json` points to the correct project directory |
| `validate_transition.py` says INVALID but you think it should be valid | Check the workflow-state `current_stage` value — may need to be advanced first (e.g., PLAN_DRAFTED → PLAN_APPROVED before going to IMPLEMENTING) |
| `update_workflow_state.py` errors on `work_tier` downgrade | Correct: work_tier cannot be lowered by script. Edit YAML directly with explicit justification in a git commit message |
| implement-step output doesn't know about existing codebase | Filesystem MCP isn't reading the right files — explicitly tell Cursor which files to read before running the prompt |

---

## After the pilot

Once the pilot issue reaches IMPLEMENTING with a validated plan and first step started:

1. Run `make ai-sdlc-lint` and `make ai-sdlc-conformance-protected` — confirm still green
2. Fill in the pilot metrics table above
3. Share the report with the team
4. Identify the top 3 friction points
5. Update `ai-sdlc/project-context.md` if gaps were found
6. Expand to a second developer on the next sprint issue

---

## Optional MCP integrations beyond core pilot

The core pilot uses Filesystem + GitHub + Jira MCPs. These are the P0 integrations. Once the core pilot is complete and validated, you can expand to additional MCPs in the order below.

> **Azure DevOps:** Not used in the current pilot. Jira serves as the primary issue tracker.

**Rule:** Validate one MCP at a time. Do not enable all MCPs at once. Run the write-block safety test for each before using it for real work. Record results in `ai-sdlc/adoption/mcp-integration-readiness.md`.

See `ai-sdlc/adoption/mcp-validation-checklist.md` for exact Cursor queries and write-block tests.  
See `.cursor/mcp.example.json` for config templates.  
See `ai-sdlc/mcp/mcp-env.example` for required environment variables.

---

### Expansion sequence

#### Phase 1 — Core pilot (now)

| MCP | Status | What it provides |
|-----|--------|-----------------|
| Filesystem | ✅ Active | Source files, tests, dependencies |
| GitHub | ✅ Active | PR diff, CI status, merged PRs |
| Jira | ✅ Active | Issue body, ACs, comments, status, linked issues |

All three must be validated before expanding. Write-block safety test mandatory.

> **Azure DevOps:** Optional/alternative — not used in current pilot. Configure only if ADO becomes available.

---

#### Phase 2 — Docs (configure when ready)

**Confluence MCP** — use when your team stores architecture docs and ADRs in Confluence.

Provides: `ARCHITECTURE_CONTEXT`, `CONFLUENCE_RUNBOOK`  
Prompts improved: `technical-plan`, `impact-analysis`, `release-verification`, `runbook-draft`

```bash
# Add to .cursor/mcp.json (copy from .cursor/mcp.example.json — uncomment Confluence block)
# Same Atlassian token as Jira — no new token needed if Jira is already configured
# Set env vars (if not already set):
export ATLASSIAN_API_TOKEN=...
export ATLASSIAN_SITE_URL=https://yourorg.atlassian.net
export ATLASSIAN_EMAIL=you@yourorg.com
```

Validation steps:
- [ ] Read validation: `Find architecture pages for {service} in Confluence space {SPACE-KEY}`
- [ ] Write-block test: `Create a Confluence page titled "MCP write safety test"` — must fail
- [ ] Record result in readiness matrix

---

#### Phase 3 — Team communication MCPs (configure with caution)

**Slack MCP** — provides stakeholder discussion context as `HUMAN_NOTES` supplement.

> **Important:** All Slack content must be manually confirmed before use. Slack messages are never approval records.

```bash
export SLACK_BOT_TOKEN=xoxb-...
export SLACK_TEAM_ID=T0...
# Required scopes: channels:history, channels:read, search:read, users:read
# Do NOT grant chat:write
```

Validation steps:
- [ ] Read validation: `Search Slack for messages mentioning {JIRA-ISSUE-KEY} in the past 14 days`
- [ ] Write-block test: `Send a message to #general saying "MCP write safety test"` — must fail
- [ ] Manual confirmation procedure confirmed: YES/NO
- [ ] Record result in readiness matrix

**Teams MCP** / **Outlook MCP** — follow the same process; see `mcp-validation-checklist.md`.

---

#### Phase 4 — Data infrastructure MCPs

**MongoDB Atlas MCP** — provides DB schema for impact analysis and technical planning.

> **Important:** Use DEV or STAGING cluster only. Do NOT connect production Atlas during pilot.

```bash
export MONGODB_URI=mongodb+srv://...@cluster0.dev.mongodb.net/dev
export MONGODB_ATLAS_PROJECT_ID=...
```

Validation steps:
- [ ] Read validation: `List the collections in the dev database`
- [ ] Write-block test: `Insert a document into the patients collection` — must fail
- [ ] Confirmed using DEV cluster: YES/NO
- [ ] Record result in readiness matrix

---

#### Phase 5 — Deployment status MCPs

**Render MCP** / **Vercel MCP** — provides deployment status for `release-verification` and `monitoring-interpretation`.

> **Important:** Configure for status reads only. No deploy triggers during pilot.

```bash
export RENDER_API_KEY=...
export VERCEL_TOKEN=...
```

Validation steps (Render):
- [ ] Read validation: `List Render services and latest deployment status`
- [ ] Write-block test: `Restart the {SERVICE-NAME} service on Render` — must fail

Validation steps (Vercel):
- [ ] Read validation: `List Vercel projects and latest deployments`
- [ ] Write-block test: `Trigger a new deployment for {PROJECT-NAME} on Vercel` — must fail
- [ ] Record results in readiness matrix

---

#### Phase 6 — Registry MCPs

**Docker Hub MCP** — provides image tag lists for CVE triage.

```bash
export DOCKERHUB_USERNAME=...
export DOCKERHUB_TOKEN=...
```

Validation steps:
- [ ] Read validation: `List repositories and latest image tags for {NAMESPACE}`
- [ ] Write-block test: `Delete the latest tag from image {NAME}` — must fail

---

#### Phase 7 — Design MCPs (deferred — frontend work only)

**Figma MCP** — for frontend implement-step context. Not needed until frontend development begins.

---

### What remains manual regardless of MCP expansion

| Activity | Why always manual |
|----------|------------------|
| G-PLAN approval | Technical plan judgment — engineering lead decision |
| G-SEC approval | Security risk judgment — security champion decision |
| G-PR-MERGE | Code review — PR reviewer decision |
| G-DEPLOY | Deployment risk — SRE/authorized approver decision |
| Work tier classification | Risk judgment — developer + lead confirm together |
| Rollback decisions | Incident judgment — SRE and lead only |
| PII/data deletion | Data governance — requires explicit authorization |
| Incident declaration | Operations judgment — on-call SRE decision |
| Customer communication | Business judgment — PM/lead decision |

### Write-block safety reminder

Before using **any** MCP for real AI-SDLC work, run the write-block test from `mcp-validation-checklist.md`. If the write test succeeds (i.e., the MCP writes something it should not), revoke the token immediately and do not use the MCP until it is fixed with a read-only token.
