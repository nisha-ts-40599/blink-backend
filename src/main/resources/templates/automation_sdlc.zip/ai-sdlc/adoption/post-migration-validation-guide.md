# Post-Migration Validation Guide (Phase 3)

Post-migration validation is required before `VERIFIED` / `COMPLETE` for cutover-active modernization and migration work.

## When validation applies

- Work with `cutover.required: true` (or policy-matched cutover work)
- `post_migration_validation_policy.enabled: true` in project-config
- Stage `DEPLOYED` or `POST_MIGRATION_VALIDATION`

Standard bug/feature deploys skip this stage.

## Required checks (configurable)

Default `post_migration_validation_policy.required_checks`:

- `functional_smoke`
- `regression_baseline`
- `data_reconciliation`
- `integration_health`
- `monitoring_health`
- `rollback_window_review`

## Artifacts and gates

| Stage | Requirement |
|-------|-------------|
| Enter `POST_MIGRATION_VALIDATION` | Cutover execution evidence (`cutover.executed` or `deployment_evidence`) |
| Enter `VERIFIED` | `post_migration_validation` artifact + `g_post_migration` approved |

## Prompt

Use `post-migration-validation.prompt.md` with `post-migration-validation-template.md`.

## Safety

- Record sanitized validation evidence only.
- Rollback recommendations require human decision — never auto-execute rollback.

## Example

```bash
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/cutover-modernization ISSUE=CUT-1-POST
```

Expected: next prompt `post-migration-validation.prompt.md`.
