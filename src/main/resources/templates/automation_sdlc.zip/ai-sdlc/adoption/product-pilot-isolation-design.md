# AI-SDLC Product Pilot Isolation Design

Product-neutral framework design for an isolated, reversible product pilot. AITA-specific
values appear only as **inspection findings**; pilot configuration belongs in the future
`.cursor/ai-sdlc-pilot/` workspace on the product repository.

## Strategy

```text
fresh pilot issue
+ dedicated product branch
+ dedicated workflow-state directory (.cursor/ai-sdlc-pilot/workflow-state/)
+ explicit pilot manifest (pilot-manifest.yaml)
+ pinned framework commit SHA
+ no automatic provider/deployment actions
```

Do **not** reuse `prospective-existing-pilot-01` or `iacadware-aita-analytics-phase-01` as the
primary pilot. Optional read-only comparison is permitted; migration is not.

## Framework revision pinning

```yaml
pilot_framework:
  repository: automation_sdlc
  branch: feature/enterprise-dev-qa-pipeline
  commit: 8ef0c7e503a6b43d072eae2002e6d782cf57e374
  phase: PHASE_3C_COMPLETE
```

Framework updates during the pilot require explicit manifest revision change, change log,
impact assessment, and readiness re-validation.

## Product candidate inspection (read-only, 2026-07-19)

| Field | Value |
|-------|-------|
| Workspace | `/Users/talentserv/Projects/TalentServ/aita-dashboard` |
| Mode | **Single repository, frontend only** (workspace folder + embedded product repo) |
| Product repo | `acadware_aita_dashboard` @ `acadware_aita_dashboard/` |
| Default branch | `main` |
| Current branch | `feature/aita-analytics-phase-01-am` (dirty: generated manifest) |
| Provider remote | `git@bitbucket.org:rohitjnaik/acadware_aita_dashboard.git` |
| Operational overlay | `.cursor/ai-sdlc/` present — **do not modify** |
| Pilot overlay | `.cursor/ai-sdlc-pilot/` — **not present** (expected) |
| Operational workflow issues | DOR-1, EGT-CLI-1, GS-TEST-1, LOCAL-E7488BA3, function-enhancements-02, functional-enhancements-03, iacadware-aita-analytics-phase-01, prospective-existing-pilot-01 |
| Build | `npm run build` (Vite) |
| Test | `npm test` / `vitest run --passWithNoTests` |
| Lint | `npm run lint` |
| CI | None detected in product repo |
| Deployment | Manual static hosting (`dist/`) — simulated/nonproduction only |
| Secrets | No production credentials required for dashboard POC |

**Recommended pilot scope:** frontend-only, single repo — smallest meaningful scope that still
exercises intake → slices → FINAL_PRE_PR_READY.

**Recommended fresh issue type:** additive dashboard widget or filter enhancement (3–5 slices,
12–30 tasks, STANDARD or ROBUST lane, low production risk). Avoid auth, payments, migrations,
or issues already partially implemented on active feature branches.

## Workspace isolation

```text
.cursor/
├── ai-sdlc/                    # operational — unchanged
└── ai-sdlc-pilot/
    ├── pilot-manifest.yaml
    ├── framework/              # reference or generated install from pinned SHA
    ├── config/
    │   ├── project-config.yaml
    │   └── project-context.md
    ├── workflow-state/
    ├── evidence/
    ├── artifacts/
    └── audit/
```

Runtime path resolution:

- Default pilot root: `.cursor/ai-sdlc-pilot`
- Override: `AI_SDLC_PILOT_ROOT=/absolute/path`
- Operational overlay remains `.cursor/ai-sdlc` (framework convention)

**Strong isolation (recommended for AITA):** dedicated git worktree — prepared command only:

```bash
AITA_ROOT="/Users/talentserv/Projects/TalentServ/aita-dashboard/acadware_aita_dashboard"
PILOT_WT="/Users/talentserv/Projects/TalentServ/aita-dashboard-pilot-worktree"
ISSUE_ID="AITA-AI-SDLC-PILOT-01"
git -C "$AITA_ROOT" worktree add "$PILOT_WT" -b "pilot/ai-sdlc-e2e-${ISSUE_ID}" main
```

Do **not** execute without explicit authorization.

## Pilot manifest

Schema: `ai-sdlc/schemas/pilot/product-pilot-manifest.schema.json`

Example template: `ai-sdlc/examples/disposable-fixtures/product-pilot-isolation-01/pilot-manifest.template.yaml`

## Installation process (future authorized step)

1. Validate framework checkout at pinned commit
2. Validate product worktree on pilot branch
3. Install/reference framework commands under pilot root
4. Copy/adapt `project-config.example.yaml` → pilot config
5. Write `pilot-manifest.yaml` with pinned SHA
6. Create empty `workflow-state/` root
7. Run `validate_product_pilot_readiness.py`
8. Verify operational `.cursor/ai-sdlc/` unchanged

## Feature configuration

Enabled: `pilot.enabled`, `structured_decisions`, `sdlc_run_execution` (max 1 action).

Disabled: autonomous execution, provider write, deployment write, repository mutation via
/sdlc-run, automatic human approval.

## Pilot stages

| Stage | Scope | Provider writes |
|-------|-------|-----------------|
| **A** | Intake → FINAL_PRE_PR_READY | Disabled |
| **B** | Provider PR → QA → merge → optional nonprod deploy → closure | Explicit authorization only |

## Human checkpoints

| ID | Purpose | Required role |
|----|---------|---------------|
| P0 | Pilot readiness approval | Engineering lead |
| P1 | Classification and lane approval | Engineering lead + product owner |
| P2 | Technical plan and slice approval | Engineering lead |
| P3 | First slice retrospective | Engineering lead |
| P4 | Pre-PR readiness review | Engineering lead + security champion (if tier 3) |
| P5 | Provider PR authorization | Engineering lead |
| P6 | Merge authorization | Engineering lead |
| P7 | Pilot closure and framework assessment | Engineering lead + framework owner |

Use `/sdlc-answer` where supported. Do not automate approvals.

## Stop conditions

Stop immediately on: protected branch checkout, workflow root outside pilot overlay, framework
revision drift, unauthorized provider/deployment write, unobservable candidate binding, integrity
failure, unrecoverable transaction, UNKNOWN routing, multiple authoritative commands, automated
human approval, missing test baseline, secrets in workflow artifacts.

## Rollback and cleanup

1. Delete pilot worktree
2. Delete local pilot branch (when approved)
3. Archive `workflow-state/` and `evidence/` under pilot root
4. Preserve metrics and review report
5. Remove pilot command installation
6. Leave operational overlay and framework branch unchanged

## Framework tooling

| Component | Path |
|-----------|------|
| Manifest schema | `ai-sdlc/schemas/pilot/product-pilot-manifest.schema.json` |
| Metrics schema | `ai-sdlc/schemas/pilot/product-pilot-metrics.schema.json` |
| Readiness result schema | `ai-sdlc/schemas/pilot/pilot-readiness-result.schema.json` |
| Isolation guard | `ai-sdlc/tools/orchestration/pilot_isolation_guard.py` |
| Readiness validator | `ai-sdlc/tools/orchestration/validate_product_pilot_readiness.py` |
| Metrics collector | `ai-sdlc/tools/orchestration/pilot_metrics_collector.py` |
| Review template | `ai-sdlc/adoption/templates/product-pilot-review-template.md` |
| Disposable fixture | `ai-sdlc/examples/disposable-fixtures/product-pilot-isolation-01/` |

## Optional AITA workflow comparison (read-only)

Compare `prospective-existing-pilot-01` or `iacadware-aita-analytics-phase-01` against the fresh
pilot for: operator prompt count, routing corrections, evidence gaps, recaptures, review cycles.
Mark historical values as **inferred** unless directly measured in the new pilot.

## Exact next authorized action

After human P0 approval: create isolated product worktree and pilot overlay, initialize fresh
workflow `AITA-AI-SDLC-PILOT-01`, run readiness validator, begin **Stage A** only.
