# Production Migration Gates Guide (Phase 3)

Optional production migration gates for cutover-active modernization/migration work.

## Gates

| Gate key | Label | When required |
|----------|-------|---------------|
| `g_cutover` | G-CUTOVER | Before entering `CUTOVER` |
| `g_rollback` | G-ROLLBACK | Before entering `CUTOVER` |
| `g_prod_migration` | G-PROD-MIGRATION | Tier 4, customer-facing, data migration, or security/identity impact |
| `g_post_migration` | G-POST-MIGRATION | Before `VERIFIED` from `POST_MIGRATION_VALIDATION` |

## Not required for normal work

Bug, feature, and standard deploy flows do **not** require Phase 3 gates.

## Human approval only

- Gates must have `approved: true`, `approver`, and `comment_url` or `pr_url` evidence.
- Prompts must **not** auto-approve gates without explicit human evidence.
- Use `production-migration-approval.prompt.md` to document go/no-go decisions.

## Project config

```yaml
production_migration_gates:
  g_cutover:
    approver_roles: [engineering_lead, qa_owner, ops_owner]
  g_rollback:
    approver_roles: [engineering_lead, ops_owner]
  g_prod_migration:
    approver_roles: [engineering_lead, ops_owner, security_owner, data_owner]
  g_post_migration:
    approver_roles: [qa_owner, engineering_lead, ops_owner]
```

## Router visibility

Stage router JSON includes `missing_cutover_gates` and `cutover_policy_source` for cutover-active work.

See [approval-gates.md](../governance/approval-gates.md) for the full gate registry.
