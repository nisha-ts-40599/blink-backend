# Project Configuration Guide

This guide explains how to fill `ai-sdlc/project-config.template.yaml`.

See `ai-sdlc/adoption/project-type-profiles.md` for profile-specific priorities.

## Workspace-local context (preferred)

Project and workspace configs live in the **workspace overlay**, not in the reusable framework repo:

```text
.cursor/ai-sdlc/
├── workspace-config.yaml      # multi-repo map (or lightweight single-repo)
├── workspace-context.md
├── project-config.yaml        # this guide applies here
├── project-context.md
├── repos/<repo-id>/project-config.yaml
├── repos/<repo-id>/project-context.md
├── workflow-state/<ISSUE-ID>/
└── context-loading.md
```

| Workspace type | Overlay location |
|----------------|------------------|
| **Single-repo** | `.cursor/ai-sdlc/` inside the product repo |
| **Multi-repo** | `.cursor/ai-sdlc/` at workspace/control repo root |

Legacy fallback paths (`ai-sdlc/project-config.yaml`, `ai-sdlc/projects/<repo-id>/`) remain supported.

## Setup lifecycle (discovery, apply, refresh, reset)

Run setup prompts to generate or maintain the overlay:

| Situation | Mode |
|-----------|------|
| First-time setup (no overlay) | discovery → **apply** |
| Overlay exists, workspace/repos changed | **refresh** — do not delete `.cursor/ai-sdlc/**` |
| Explicit recreate | **reset** — archives to `.cursor/ai-sdlc.archive/<timestamp>/` first |

Refresh preserves human-owned fields (approval rules, tracker config, notes) and never overwrites workflow-state issue artifacts automatically. See setup prompt **Refresh merge policy** sections for details.

**Future backlog:** `make ai-sdlc-refresh-overlay ROOT=<workspace-root>` may automate refresh discovery later.

Run setup prompts (`setup-existing-project`, `setup-existing-workspace`, etc.) to generate the overlay.

**Version control:** commit sanitized configs and context; gitignore secrets, tokens, raw PII captures.
See `templates/context-loading-template.md` for load order and safety rules.

## `context_loading` (optional block)

When using the overlay, populate `context_loading` in `project-config.yaml` with paths under
`.cursor/ai-sdlc/`. Tools (`build_context_bundle.py`, `context_paths.py`) prefer overlay files automatically.

## `schema_version`

- Set to the template version, for example `1.0`.
- Update only when your team intentionally adopts a new config schema.
- Validated by `ai-sdlc/schemas/project/project-config.schema.json` (requires `schema_version` only; other fields optional).

## `context_freshness_days`

- Maximum age in days before `project-context.md` should be reviewed.
- Recommended default: `90`.
- Align with `last_reviewed` in `project-context.md`.

## `project`

- `name`: human-readable project name.
- `identifier`: stable key used in tracker or internal systems.
- `description`: short one-paragraph scope statement.

## `domain`

- `business_domain`: business area (payments, identity, etc.).
- `bounded_contexts`: meaningful subdomains; list only real ownership boundaries.

## `architecture`

- `style`: current architecture model (modular monolith, microservices).
- `diagram_uri`: link to living architecture diagram.
- `key_integrations`: external/internal systems and interface type.
- `contracts` (optional): API, event, and shared-package contract references for impact analysis.

## `technology`

- `frontend_stack`, `backend_stack`: language/framework/runtime.
- `database`: primary data store (string or object with `engine`, `version`, `migration_tool`).
- `secondary_datastores`, `messaging`: optional but explicit if used.
- `cloud_provider`, `infrastructure_as_code`: infra baseline.
- `runtimes` (optional): array of `{ name, version }` for explicit runtime pins.

## `tooling`

- `source_control`: git host, default branch, repo URLs.
- `issue_tracker`: system + project key + base URL.
- `documentation_platform`: space/root location.
- `cicd`: system and key pipelines.
- `commands` (optional): exact install/build/lint/test/dev commands for agents and CI.
- `validation_commands` (optional): health/conformance commands (e.g. `make ai-sdlc-conformance-protected`).
- `quality_tools` (optional): lint and format tool names.
- `test_frameworks`: unit/integration/e2e stack.
- `security_scanners`: SAST/DAST/SCA/secrets tools.
- `observability`: metrics/logs/traces backends; optional `dashboards`, `alerts`, `slos`.

## `engineering_practices`

- `branching_strategy`: trunk-based or variant.
- `deployment_strategy`: rolling/canary/blue-green.
- `feature_flags_provider`: if feature flags are used.
- `environments`: list dev/stage/prod with automation mode.

## `security_model`

- `data_classification`: highest data sensitivity level.
- `pii_processing`: none/limited/extensive.
- `regulatory_context`: explicit regulatory obligations.
- `secrets_management`: secret store reference.
- `agent_network_policy`: network constraints for agents/MCP.
- `auth` (optional): `scheme`, `roles`, `tenant_model` summary for security-sensitive projects.

## `definition_of_done`

- `criteria`: baseline completion criteria; keep objective.
- `reference_doc_uri`: link to deeper organizational DoD if available.

## `approval_rules`

- `roles`: map to real approver groups (not placeholders in final).
- `tier_approvals`: who must approve each tier.
- `merge_to_default_branch_requires`: branch protection controls.
- `production_deploy_requires`: mandatory controls for prod releases.

## `work_tiers`

- `default_tier_when_unclassified`: recommended conservative default is `2`.
- `mapping_notes`: explain local tier interpretation differences if any.

## `rollback_policy` (Phase 1)

Tier- and work-type-aware rollback plan requirements enforced at **merge readiness**.

- `enabled`: master switch (default `true`).
- `required_by_tier`: semantic levels (`optional`, `recommended`, `required`, `required_with_approval`).
- `enforcement`: per-tier modes — `off`, `warn`, `block` (Tier 3+ default: `block`).
- `required_for_work_types`: e.g. `payment`, `security`, `production_bugfix`.
- `sensitive_enforcement`: applies when `risk_profile` flags payment/PII/data sensitivity below Tier 3.

See `adoption/rollback-policy-guide.md`.

## `work_types`, `modernization_profile`, `modernization_required_artifacts` (Phase 2)

Modernization is part of the standard SDLC, not a separate process. These keys configure when the modernization lane activates and which artifacts are enforced.

- `work_types.supported`: classification vocabulary (bug, feature, modernization, migration, etc.).
- `modernization_profile.enabled`: master switch for the lane (default `true`; lane still requires matching `work_type` or `modernization.enabled` in workflow-state).
- `modernization_profile.default_strategy_preference`: strangler fig, phased migration, parallel run, modular monolith first.
- `modernization_profile.discouraged_strategies`: big-bang rewrite, cutover without rollback, shared DB microservices.
- `modernization_required_artifacts`: per-phase and conditional artifact requirements before technical plan.

**Lane activation precedence:** `modernization.enabled: true` in workflow-state overrides `modernization_profile.enabled: false`. When profile is disabled, work_type alone does not activate the lane.

See `adoption/modernization-lane-guide.md` and `adoption/modernization-examples.md`.

## `cutover_policy`, `post_migration_validation_policy`, `production_migration_gates` (Phase 3)

Optional production cutover and post-migration validation for modernization/migration work only:

- `cutover_policy.enabled`: master switch (default `true`; activates when work type/subtype and `required_when` flags match, or `cutover.required: true` in workflow-state).
- `cutover_policy.required_for_work_types` / `required_for_subtypes`: work that may require cutover planning.
- `cutover_policy.required_when`: risk flags (`production_environment`, `customer_facing`, `data_migration`, etc.) in workflow-state `risk_profile` or `cutover` block.
- `cutover_policy.enforcement`: tier-based `off` / `warn` / `block` (Tier 3+ blocks by default).
- `post_migration_validation_policy.required_checks`: validation categories before `VERIFIED`.
- `production_migration_gates`: approver roles for `g_cutover`, `g_rollback`, `g_prod_migration`, `g_post_migration`.

Normal bug/feature deploy flows ignore Phase 3 config. See `adoption/cutover-readiness-guide.md`.

## `audit_and_compliance`

- `require_audit_log_for`: minimum auditable event categories.
- `retention_days`: retention policy aligned to compliance obligations.

## `extensions` (optional)

- `project_type`: profile hint — `application`, `monorepo`, `qa-automation`, `platform`, `migration`, `tooling`.
- `rules`: domain-specific enforcement rules (see healthcare example in `examples/project-config/`).

## Workspace configuration

For multi-repo setups, use `ai-sdlc/templates/workspace-config-template.yaml` at
**`.cursor/ai-sdlc/workspace-config.yaml`**. Validated by `ai-sdlc/schemas/workspace/workspace-config.schema.json`.

Key optional workspace sections:
- `api_version_matrix`, `cross_repo_smoke_tests`, `artifacts`, `known_unknowns`
- `shared_configuration`, `event_contracts`, `cross_repo_ci`, `coordination`, `monorepo_packages`

Example: `ai-sdlc/examples/workspaces/multi-repo/.cursor/ai-sdlc/`

## Practical fill-in tips

- Prefer explicit values over "TBD".
- Use canonical team group IDs for approval roles.
- Keep all links resolvable and owned.
- Re-review this config every quarter or major platform change.
- Keep `project-config.yaml` and `project-context.md` aligned (commands, roles, tiers).

## Validation

```bash
make ai-sdlc-conformance-protected
```

Config schema fixtures: `dev-schema-project-config` and `dev-schema-workspace-config` in the conformance test matrix.
