# Project Delivery Readiness

> Establishes setup lifecycle state, readiness separation, migration inference,
> one-time greenfield guards, and requirement-entry rules.
> **Managed bootstrap execution** is documented in [`managed-local-bootstrap-execution.md`](managed-local-bootstrap-execution.md).

---

## One-time greenfield lifecycle

| Phase | Command | When |
|-------|---------|------|
| First-time greenfield | `/setup-new-project` or `/setup-new-workspace` (discovery → apply) | No overlay yet |
| After setup complete | `/setup-existing-project refresh` or `/setup-existing-workspace refresh` | Ongoing maintenance |
| Legacy / brownfield | `/setup-existing-*` | Adopting existing repos |

After greenfield setup completes, **do not** rerun `/setup-new-project` or `/setup-new-workspace` for routine maintenance. The setup prompts redirect to existing-* refresh when lifecycle is `existing_managed`.

---

## Readiness model

Two dimensions tracked in `.cursor/ai-sdlc/setup-state.yaml`:

```yaml
setup_readiness:
  context_ready: false   # overlay structurally valid
  delivery_ready: false  # repos present + Git/baseline rules satisfied
```

| Readiness | Meaning |
|-----------|---------|
| `context_ready` | Required overlay files exist; strict validation passes; roster and issue tracking configured or explicitly manual |
| `delivery_ready` | Requires `context_ready`; all required repos on disk; Git valid or approved no-Git; baseline known; no planned-only required repos |

**Rule:** `delivery_ready: true` requires `context_ready: true`.

Validate:

```bash
make ai-sdlc-validate-setup-readiness ROOT=<root>
make ai-sdlc-validate-setup-readiness ROOT=<root> REQUIRE=delivery
make ai-sdlc-validate-setup-readiness ROOT=<root> FORMAT=json
```

For requirement grooming entry, prefer non-blocking context assessment:

```bash
make ai-sdlc-validate-setup-readiness ROOT=<root> REQUIRE=context
```

---

## Migration for existing overlays

Projects that predates setup-state support are **not** marked as historical greenfield-complete.

Inference rules:

- `lifecycle.state`: `existing_managed`
- `lifecycle.bootstrap_origin`: `legacy_or_preexisting`
- `lifecycle.one_time_greenfield_complete`: `false`

Persist explicitly (optional):

```bash
make ai-sdlc-validate-setup-readiness ROOT=<root> WRITE_MIGRATION=1
```

---

## Requirement entry and implementation gates

**Canonical rule:**

```text
Requirement clarification and grooming require context readiness.
Implementation requires delivery readiness.
```

| Activity | `context_ready` | `delivery_ready` |
|----------|:---------------:|:----------------:|
| `/sdlc-start`, groom-prep, `/clarify-requirement` | Required | Not required |
| `/classify-work`, planning prompts | Required | Not required |
| `/implement-step` and later implementation stages | Required | Required |

When an overlay exists and `delivery_ready=false`, requirement grooming and clarification proceed normally. Stage eligibility blocks **implementation** until delivery readiness is established.

**Exceptions for setup/bootstrap work items:**

- Issue classified as setup/bootstrap work (`work_type`: `setup`, `bootstrap`, `greenfield_setup`, …)
- Workflow already in progress (`requirement_doc` present)
- Test fixtures with `setup_readiness_opt_out: true`

---

## G-BOOTSTRAP gate

Represented in setup-state for greenfield bootstrap planning. **Not required** for migrated existing-managed projects unless unresolved blockers exist. Distinct from **G-BOOTSTRAP-EXEC** (managed execution approval).

---

## Limitations

Not implemented in managed bootstrap (local-only scope):

- Remote repository creation / deletion
- Git provider network operations (push, fetch, clone)
- Scaffold command execution
- Package installation
- Cloud resource creation
- MCP capability execution for bootstrap mutations

---

## Related artifacts

- Schema: `ai-sdlc/schemas/setup/setup-state.schema.json`
- Template: `ai-sdlc/templates/setup/setup-state.template.yaml`
- Tool: `ai-sdlc/tools/setup/validate_setup_readiness.py`
- Operator flow: [`docs/operating-model/current-sdlc-flow.md`](../../docs/operating-model/current-sdlc-flow.md)
- Readiness map: [`docs/operating-model/lifecycle-and-readiness-map.md`](../../docs/operating-model/lifecycle-and-readiness-map.md)
