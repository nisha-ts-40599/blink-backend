# AI-SDLC Project Type Profiles

Use these profiles to choose which configuration sections to prioritize when adopting
AI-SDLC. All profiles use the same core files:

- `ai-sdlc/project-config.yaml` (single-repo or per-repo in multi-repo)
- `ai-sdlc/project-context.md`
- `ai-sdlc/workspace-config.yaml` + `workspace-context.md` (multi-repo only)

Set `extensions.project_type` in `project-config.yaml` to match the profile when helpful.

Validate configs after changes:

```bash
make ai-sdlc-conformance-protected
```

---

## Single-repo application

**When to use:** One git repository delivering one deployable application or service.

**Required config sections:**
- `project`, `domain`, `technology`, `tooling.source_control`, `tooling.issue_tracker`
- `tooling.commands` (at minimum install, build, lint, test_unit)
- `security_model`, `approval_rules`, `work_tiers`, `definition_of_done`

**Recommended optional sections:**
- `architecture.contracts`, `security_model.auth`, `tooling.observability`
- Context sections: Technical Debt, Known Risks, Data Model Summary, Coding Standards

**Common risks:**
- Missing exact CI commands leads to weak implement-step and PR review output
- Stale `last_reviewed` in project-context blocks stage-router at later stages

**Suggested validation commands:**
```bash
make ai-sdlc-conformance-protected
# project-specific:
make test   # or npm test, pytest, etc.
```

---

## Multi-repo application

**When to use:** Frontend, backend, database, and/or infra live in separate repositories.

**Required config sections:**
- Workspace: `repositories`, `cross_repo_dependencies`, `deployment_order`, `approval_rules`
- Per-repo: `project-config.yaml` + `project-context.md` for each affected repo

**Recommended optional sections:**
- `shared_configuration`, `api_contracts`, `event_contracts`, `cross_repo_ci`, `coordination`
- Workspace context: merge/deploy readiness rules (Section 11)

**Common risks:**
- Cross-repo changes treated as single-repo Tier 1
- Missing deployment order causes unsafe merge sequencing

**Suggested validation commands:**
```bash
make ai-sdlc-conformance-protected
# run CI validation in each affected repo before merge
```

---

## Monorepo

**When to use:** Multiple packages/services in one git repository (e.g. `apps/`, `packages/`).

**Required config sections:**
- Same as single-repo application
- Context Section 4 (Repository and Module Map) must list package boundaries

**Recommended optional sections:**
- `extensions.project_type: monorepo`
- `architecture.contracts` between internal packages
- Workspace optional: `monorepo_packages` if using workspace-config for Cursor multi-root

**Common risks:**
- Agents treat entire repo as one module and miss package boundaries
- Tier classification ignores cross-package contract changes

**Suggested validation commands:**
```bash
make ai-sdlc-conformance-protected
# package-scoped lint/test commands documented in tooling.commands
```

---

## QA / test automation project

**When to use:** Dedicated test harness, E2E framework, or automation repo (not primary app code).

**Required config sections:**
- `extensions.project_type: qa-automation`
- `tooling.commands` for test execution (unit, integration, e2e)
- `tooling.test_frameworks` with explicit e2e tooling
- Context: test data strategy, environments under test

**Recommended optional sections:**
- `architecture.contracts` linking to systems under test
- Observability baseline for test failure triage

**Common risks:**
- Classified as Tier 1 when tests gate production releases (often Tier 2+)
- Missing target environment definitions in context

**Suggested validation commands:**
```bash
make ai-sdlc-conformance-protected
# e.g. npm run test:e2e, pytest tests/e2e/
```

---

## Cloud / DevOps / platform project

**When to use:** Infrastructure, IaC, CI platform, or shared platform tooling repositories.

**Required config sections:**
- `technology.infrastructure_as_code`, `engineering_practices.deployment_strategy`
- `security_model` with elevated classification expectations
- Context: Rollback & Incident Procedures, ownership of shared platforms

**Recommended optional sections:**
- `architecture.key_integrations` for cloud APIs and identity
- `tooling.observability` for platform health signals
- Tier 3+ examples for IAM, network, and production infra changes

**Common risks:**
- Under-tiering infra changes (most production infra is Tier 3–4)
- Missing rollback/`terraform plan` review conventions

**Suggested validation commands:**
```bash
make ai-sdlc-conformance-protected
# e.g. terraform validate, helm lint, kubectl dry-run
```

---

## Modernization / migration project

**When to use:** Strangler migrations, re-platforming, legacy replacement, or dual-run programs.

**Required config sections:**
- Context: Known Risks, Technical Debt, Rollback & Incident Procedures
- `architecture.contracts` for old vs new system boundaries
- Explicit tier examples for parallel-run and cutover phases

**Recommended optional sections:**
- `extensions.project_type: migration`
- `extensions.rules` for migration-specific enforcement
- Work tier mapping notes describing cutover vs steady-state rules

**Common risks:**
- Agents propose big-bang changes without phased migration plan
- Missing rollback for dual-write/dual-read periods

**Suggested validation commands:**
```bash
make ai-sdlc-conformance-protected
# migration-specific smoke/compat tests documented in tooling.commands
```

---

## Tooling / framework repository

**When to use:** Shared SDLC framework, internal CLI, policy engine, or developer tooling (like this repo).

**Required config sections:**
- `tooling.validation_commands` (framework conformance or package tests)
- `definition_of_done` aligned with repo-specific quality gates
- Context: Manual vs Automated Boundaries (what agents must never auto-change)

**Recommended optional sections:**
- `extensions.project_type: tooling`
- Low or no deployment sections; merge-to-main as release model

**Common risks:**
- Applying application-tier deployment gates to non-deployable repos
- Skipping conformance validation on governance/schema changes

**Suggested validation commands:**
```bash
make ai-sdlc-lint
make ai-sdlc-prompt-check
make ai-sdlc-conformance-protected
```

---

## Profile selection quick reference

| Profile | `extensions.project_type` | Workspace config? |
|---------|---------------------------|-------------------|
| Single-repo application | `application` | No |
| Multi-repo application | `application` | Yes |
| Monorepo | `monorepo` | Optional |
| QA / test automation | `qa-automation` | Optional |
| Cloud / platform | `platform` | Optional |
| Modernization / migration | `migration` | Often yes |
| Tooling / framework | `tooling` | Optional |

See also: `ai-sdlc/adoption/project-config-guide.md`, `ai-sdlc/project-config.template.yaml`.

---

## Requirement grooming by profile

Use `clarify-requirement.prompt.md` with `{{REQUIREMENT_TYPE}}` aligned to the work:

| Profile | Typical requirement types | Grooming notes |
|---------|--------------------------|----------------|
| Single-repo / multi-repo application | Bug, Enhancement, New feature | Standard template; repo read-only inspection for bugs and enhancements |
| Monorepo | Same as application | Include impacted package paths in §13 |
| QA / test automation | QA/test automation | Focus on SUT, CI gates, flake policy; see QA profile section |
| Cloud / platform | Cloud/devops/platform | Escalate tier for prod infra, IAM, secrets |
| Modernization / migration | Modernization/migration | Require impact-analysis before plan; document rollback |
| Tooling / framework | Documentation/process/tooling, Enhancement | Often Tier 1–2 unless CI/security behavior changes |

Groomed output: `ai-sdlc/workflow-state/{ISSUE-ID}/requirement.md`

- **Lite template** (`requirement-template-lite.md`) — Tier 1, docs/tooling, simple bugs
- **Full template** (`requirement-template.md`) — Tier 2+, production, security, migration

**SOP:** `ai-sdlc/adoption/requirement-grooming-sop.md` · **Examples:** `ai-sdlc/examples/requirements/`

Persona lenses (BA, QA, Domain, Security/Data) run inside `clarify-requirement` — not separate agents.

Follow `ai-sdlc/governance/public-reference-and-data-safety.md` for all public references and data handling.
