# AI-SDLC Prompt Input Source Map

**Purpose:** Developer-facing quick reference — for every prompt placeholder, this doc tells you where the value comes from, whether it is auto-filled, how to read it via MCP, whether you must supply it manually, and whether it is a human gate.

**How to use:** Before running any prompt, check this doc to know exactly what to prepare.

---

## Input types — quick reference

| Input type | Source | Auto-populated? | Manual fallback |
| ---------- | ------ | --------------- | --------------- |
| Project context | `.cursor/ai-sdlc/project-context.md` | Yes (context bundle / groom-prep) | Paste project context |
| Workspace context | `.cursor/ai-sdlc/workspace-context.md` | Partial (when overlay present) | Paste workspace summary |
| Repo context | Filesystem MCP / repo tree | No | Paste relevant file excerpts |
| Issue details | Tracker MCP / tracker UI / groom-prep | No | Paste issue body + metadata |
| Issue tracker config | `issue_tracking` in project-config or workspace-config | Partial (detection only) | Set `provider: manual` or configure provider |
| Normalized issue metadata | Tracker MCP / groom-prep / pasted | Partial | Paste; see `architecture/normalized-issue-model.md` |
| Acceptance criteria | Tracker MCP or groomed `requirement.md` | Partial | Paste AC list |
| Workflow state | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/` | Yes (context bundle) | Paste workflow-state YAML |
| Approvals | workflow-state → `gates` | Partial (records only) | Record via `update_workflow_state.py --add-approval` |
| Available artifacts | workflow-state → `artifacts` | Yes (paths from bundle) | List artifact paths manually |
| CI results | GitHub CI MCP or dashboard | No | Paste job statuses; mark **missing evidence** if unknown |
| PR context | GitHub MCP or local diff | No | Paste PR description + diff summary |
| Validation results | CI MCP / local test output / QA evidence | No | Paste results; mark **missing evidence** if unknown |
| Release context | changelog, merged PRs, release notes | No | Paste release summary |
| Monitoring signals | observability tools / Render / Vercel MCP | No | Paste alerts/metrics; mark **missing evidence** if unknown |
| Audit output | `make ai-sdlc-audit` or CI security job | No | Paste raw audit output |
| Deployment evidence | GitHub release / deployment MCP | No | Paste deploy summary |
| Human notes | engineer free text | No | Paste ad-hoc context for stage-router |

**Rules:**

- Config and static context values are usually auto-populated through overlay + context bundle.
- Live operational evidence is usually MCP-assisted or manual paste.
- Issue tracker provider is detected from config (`make ai-sdlc-resolve-issue-tracker`) — no API calls.
- Default tracker mode is `read_only`; writes require explicit human approval.
- Approvals remain human-owned — no AI prompt may invent gate records.
- If evidence is missing, say **missing evidence**; do not infer or fabricate.

**Developer grooming:** [`developer-grooming-quick-guide.md`](developer-grooming-quick-guide.md)

---

## Legend

| Classification | Meaning |
|----------------|---------|
| **Auto — script** | `build_context_bundle.py` fills this automatically from local files. No developer action needed. |
| **MCP-readable** | Cursor can read this value via MCP in chat. You must ask Cursor explicitly. The context bundle script does NOT fetch this automatically. Values can be pasted into a prefill-input JSON and imported with `context_prefill.py --import`. |
| **Manual input** | You must type or paste this value. No MCP or script can provide it today. |
| **Human gate** | This value is a human approval decision. It must never be auto-filled. Recorded with `update_workflow_state.py --add-approval`. |

## Context prefill workflow (reducing copy-paste)

Use `context_prefill.py` to reduce the effort of supplying MCP-readable values:

```bash
# Step 1: See what to fetch and get exact Cursor queries
make TARGET_PROMPT=clarify-requirement ai-sdlc-prefill-report
# or:
python ai-sdlc/tools/orchestration/context_prefill.py \
  --workflow-state ai-sdlc/workflow-state/PROJ-1234.yaml \
  --target-prompt clarify-requirement \
  --emit-template /tmp/PROJ-1234-prefill-input.json  # blank template

# Step 2: Open Cursor, run the suggested MCP queries, paste results into the template

# Step 3: Import and validate
python ai-sdlc/tools/orchestration/context_prefill.py \
  --workflow-state ai-sdlc/workflow-state/PROJ-1234.yaml \
  --target-prompt clarify-requirement \
  --import /tmp/PROJ-1234-prefill-input.json \
  --output /tmp/PROJ-1234-prefill-context.json

# Step 4: Run build_context_bundle.py as normal — use prefill-context.json content
#         when the prompt asks for REQUIREMENT, ACCEPTANCE_CRITERIA, etc.
```

## Grooming prep workflow (enterprise pilot)

Single Make target combines prefill report + context bundle for clarify-requirement:

```bash
make ai-sdlc-groom-prep ISSUE=YOUR-ISSUE
# Optional: TARGET_PROMPT=clarify-requirement (default)
```

Outputs `/tmp/{ISSUE}-clarify-requirement-context.json`. Does **not** call external tracker APIs.

Resolve configured tracker (read-only):

```bash
make ai-sdlc-resolve-issue-tracker ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

After saving groomed `requirement.md`:

```bash
make ai-sdlc-extract-grooming-state ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
make ai-sdlc-validate-requirement-dor ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
# then /requirement-grooming-status <ISSUE-ID> — do not run classify-work until DoR ready and G-GROOM approved
```

Capture pilot metrics manually using `templates/grooming-metrics-template.yaml`.

Optional structured sidecar (not enforced): `schemas/requirements/groomed-requirement.schema.json`

**BA/PO guide:** [`ba-po-requirement-grooming-guide.md`](ba-po-requirement-grooming-guide.md)

Safety rules for `context_prefill.py --import`:
- Issue ID in prefill input must match workflow state — fails closed if mismatched
- Gate fields (G_PLAN, G_SEC, G_PR_MERGE, G_DEPLOY) are rejected by both schema and runtime
- Empty values are rejected
- No file is modified — import only produces a readable output JSON
- Source, timestamp, and fetched_by are recorded for every imported value

---

## What the context bundle auto-fills (9 fields)

`build_context_bundle.py` reads **four local files** and produces a JSON bundle. It makes **no API calls**.

| Placeholder | Source | Notes |
|-------------|--------|-------|
| `{{PROJECT_CONTEXT}}` | `project-context.md` (full text) | Loaded as a text blob — all sections included |
| `{{PROJECT_CONFIG}}` | `project-config.yaml` (structured) | tech_stack, approval_roles, sensitivity fields extracted |
| `{{WORKFLOW_STATE}}` | `workflow-state.yaml` (raw YAML) | Also provides issue_id, current_stage, work_tier |
| `{{APPROVAL_RECORDS}}` | `workflow-state.yaml` → `gates` section | All G-PLAN / G-SEC / G-PR-MERGE / G-DEPLOY records |
| `{{CURRENT_BLOCKERS}}` | `workflow-state.yaml` → `blocked_reasons` | Empty array if no blockers |
| `{{TECH_STACK}}` | `project-config.yaml` → `tech_stack` | Structured object |
| `{{APPROVAL_RULES}}` | `project-config.yaml` → `approval_roles` | Role-to-gate mapping |
| `{{ENGINEERING_GUARDRAILS}}` | `ai-sdlc/governance/enterprise-engineering-guardrails.md` | **Auto-detected from repo root.** Path is included in `engineering_guardrails_ref`; read content via Filesystem MCP in Cursor chat. |
| `{{SECURITY_MODEL}}` | Embedded in `project-context.md` text | **Partial** — not extracted as a separate field |

**Important:** The context bundle does not fetch `{{REQUIREMENT}}`, source files, PR diffs, CI status, or any live data. These must come from MCP or manual input.

### Requirement grooming — clarify-requirement placeholders

| Placeholder | Source | Notes |
|-------------|--------|-------|
| `{{REQUIREMENT}}` | Tracker MCP or paste | Issue body + AC |
| `{{REQUIREMENT_TYPE}}` | Manual or infer from issue type/labels | See [requirement-grooming-sop.md](requirement-grooming-sop.md) |
| `{{REPRODUCTION_STEPS}}` | Tracker MCP / manual / sanitized logs | Bugs only |
| `{{CURRENT_BEHAVIOR}}` | Tracker MCP / manual / repo context | Enhancements and bugs |
| `{{EXPECTED_BEHAVIOR}}` | Tracker MCP / manual / PO input | Enhancements and bugs |
| `{{EDGE_CASES}}` | Manual | Optional prefill |
| `{{TEST_EXPECTATIONS}}` | Manual / QA input | Optional prefill |
| `{{PUBLIC_REFERENCE_NOTES}}` | Manual — pattern summaries only | See [public-reference-and-data-safety.md](../governance/public-reference-and-data-safety.md) |
| `{{REPOSITORY_CONTEXT}}` | Filesystem MCP (read-only) | Bugs/enhancements when repo inspection allowed |

**Templates:** [lite](../templates/requirement-template-lite.md) (Tier 1) · [full](../templates/requirement-template.md) (Tier 2+) ·
**Examples:** [examples/requirements/](../examples/requirements/) ·
**SOP:** [requirement-grooming-sop.md](requirement-grooming-sop.md)

---

## MCP-readable fields — ask Cursor explicitly

For each field below, the example query shows what to type in a Cursor chat session when the relevant MCP server is active.

| Placeholder | MCP server | Example Cursor chat query |
|-------------|------------|--------------------------|
| `{{REQUIREMENT}}` | **Jira MCP** | `Read Jira issue {ISSUE-KEY} including summary, description, acceptance criteria, comments, status, assignee, sprint, labels, components, linked issues, and attachments if available. Do not update the issue.` |
| `{{ACCEPTANCE_CRITERIA}}` | **Jira MCP** | `Read the acceptance criteria field from Jira issue {ISSUE-KEY}.` |
| `{{ISSUE_COMMENTS}}` | **Jira MCP** | `List all comments on Jira issue {ISSUE-KEY}.` |
| `{{ISSUE_STATUS}}` | **Jira MCP** | `Read the status, assignee, sprint, and labels of Jira issue {ISSUE-KEY}.` |
| `{{LINKED_ISSUES}}` | **Jira MCP** | `Read the linked issues for Jira issue {ISSUE-KEY}.` |
| `{{REPOSITORY_CONTEXT}}` | Filesystem MCP | `Read the files app/services/auth.py and app/models/user.py.` |
| `{{EXISTING_TESTS}}` | Filesystem MCP | `List the files in tests/unit/services/ and read tests/unit/services/test_auth.py.` |
| `{{DIFF_CONTENT}}` | GitHub MCP | `Read the diff for PR #88 in repo org/project.` |
| `{{REVIEW_COMMENTS}}` | GitHub MCP | `List all reviewer comments on PR #88.` |
| `{{RECENT_CI_STATUS}}` | GitHub MCP | `What is the status of the latest CI run on branch feature/{ISSUE-KEY}?` |
| `{{RECENT_CHANGES}}` | GitHub MCP | `List the PRs merged to main since 2026-06-01.` |
| `{{MERGED_PRS}}` | GitHub MCP | `List all PRs merged in milestone v2.5.0.` |
| `{{DEPENDENCY_MANIFEST}}` | Filesystem MCP | `Read requirements.txt (or package.json).` |
| `{{IMPLEMENTATION_PRS}}` | GitHub MCP | `Read the PR descriptions for PR #81 and PR #82.` |
| `{{ENGINEERING_GUARDRAILS}}` | Filesystem MCP | `Read ai-sdlc/governance/enterprise-engineering-guardrails.md.` |
| `{{ARCHITECTURE_CONTEXT}}` | Filesystem MCP | `Read ai-sdlc/project-context.md, sections Architecture and Service Map.` |
| `{{BUG_REPORT}}` | **Jira MCP** / GitHub MCP | `Read Jira issue {ISSUE-KEY} including description, repro steps, and all comments.` |
| `{{DEPLOYMENT_SUMMARY}}` | GitHub MCP / Render MCP / Vercel MCP | `Read the release tag or latest deployment for v2.4.1.` |

---

## MCP source mapping — all placeholders × all MCP servers

This table shows which MCP server can provide each placeholder, including the expanded P1/P2 servers (Jira, Confluence, Slack, Teams, Outlook, MongoDB, Docker Hub, Render, Vercel). Use this as a lookup when deciding which MCPs are worth enabling for your prompt workflow.

**Human gate rule:** G-PLAN, G-SEC, G-PR-MERGE, and G-DEPLOY are **never auto-filled by any MCP**. They are always recorded manually via `update_workflow_state.py --add-approval` after a named human posts an explicit approval. MCP content (e.g., an approval message found in Slack) must be manually confirmed and is never treated as a gate record.

| Placeholder | Primary MCP source | Alternative MCP source | Auto-script source | Manual fallback | Human gate? |
|-------------|-------------------|------------------------|--------------------|-----------------|-------------|
| `{{PROJECT_CONTEXT}}` | — | Filesystem MCP (read project-context.md) | ✅ build_context_bundle.py | Write project-context.md | No |
| `{{PROJECT_CONFIG}}` | — | Filesystem MCP (read project-config.yaml) | ✅ build_context_bundle.py | Write project-config.yaml | No |
| `{{WORKFLOW_STATE}}` | — | — | ✅ build_context_bundle.py | Edit YAML directly | No |
| `{{ENGINEERING_GUARDRAILS}}` | — | Filesystem MCP (read guardrails.md) | ✅ build_context_bundle.py | Read file manually | No |
| `{{APPROVAL_RECORDS}}` | — | — | ✅ workflow-state.yaml gates | update_workflow_state.py | **Human gate** |
| `{{REQUIREMENT}}` | **Jira MCP** | GitHub Issues MCP / ADO MCP (alternative) | — | Paste issue description | No |
| `{{ACCEPTANCE_CRITERIA}}` | **Jira MCP** | ADO MCP (alternative) | — | Paste AC field | No |
| `{{ISSUE_COMMENTS}}` | **Jira MCP** | GitHub Issues MCP / ADO MCP (alternative) | — | Paste comment thread | No |
| `{{ISSUE_STATUS}}` | **Jira MCP** | ADO MCP (alternative) | — | Check Jira manually | No |
| `{{LINKED_ISSUES}}` | **Jira MCP** | ADO MCP (alternative) | — | Check Jira manually | No |
| `{{BUG_REPORT}}` | **Jira MCP** | GitHub Issues MCP / ADO MCP (alternative) | — | Paste bug description | No |
| `{{REPOSITORY_CONTEXT}}` | Filesystem MCP | GitHub MCP (repo tree) | — | Manual file review | No |
| `{{RELEVANT_FILES}}` | Filesystem MCP | — | — | Developer selects files | No |
| `{{EXISTING_TESTS}}` | Filesystem MCP | — | — | Navigate test directory | No |
| `{{DEPENDENCY_MANIFEST}}` | Filesystem MCP | Docker Hub MCP (image tags supplement) | — | Read requirements.txt | No |
| `{{PR_CONTEXT}}` | GitHub MCP | — | — | Paste PR description | No |
| `{{DIFF_CONTENT}}` | GitHub MCP | Filesystem MCP (local diff) | — | `git diff` output | No |
| `{{REVIEW_COMMENTS}}` | GitHub MCP | — | — | Paste reviewer comments | No |
| `{{RECENT_CI_STATUS}}` | GitHub MCP | Vercel MCP | — | Check CI dashboard manually | No |
| `{{RECENT_CHANGES}}` | GitHub MCP | — | — | Check changelog manually | No |
| `{{MERGED_PRS}}` | GitHub MCP | — | — | Read changelog manually | No |
| `{{DEPLOYMENT_SUMMARY}}` | GitHub MCP (release) | Render MCP / Vercel MCP | — | Check deployment dashboard | No |
| `{{ARCHITECTURE_CONTEXT}}` | Filesystem MCP | Confluence MCP / MongoDB Atlas MCP (schema) | ✅ Embedded in project-context.md | Add architecture section to project-context.md | No |
| `{{EXISTING_RUNBOOK}}` | Filesystem MCP | Confluence MCP | — | Locate runbook manually | No |
| `{{HUMAN_NOTES}}` | — | Slack MCP supplement (manually confirmed) / Teams MCP supplement / Outlook MCP supplement | — | Developer writes context note | No |
| `{{MONITORING_SIGNALS}}` | — | Render MCP logs supplement / Vercel MCP logs supplement | — | Paste from observability tool | No |
| `{{AVAILABLE_ARTIFACTS}}` | AWS S3 (list prefix) | Filesystem MCP (local artifacts) | ✅ workflow-state.yaml artifact paths | Check workflow-state manually | No |
| `{{TECHNICAL_PLAN}}` | AWS S3 (`technical-plans/` prefix) | Filesystem MCP (local plan doc) | — | Read plan_doc artifact path | No |
| `{{IMPACT_ANALYSIS}}` | AWS S3 (`impact-analysis/` prefix) | Filesystem MCP (local output) | — | Read impact analysis output manually | No |
| `{{RELEASE_PLAN}}` | AWS S3 (`release-readiness/` prefix) | Filesystem MCP | — | Assemble from changelog + plan | No |
| `{{DEPLOYMENT_CHECKLIST}}` | AWS S3 (`release-readiness/` prefix) | Filesystem MCP | — | Prepare from release plan | No |
| `{{RUNBOOK}}` | Filesystem MCP | AWS S3 (`projects/.../` prefix) / Confluence MCP | — | Locate runbook file manually | No |
| `{{PILOT_METRICS}}` | AWS S3 (`pilot-metrics/` prefix) | Filesystem MCP (local report) | — | Record manually from pilot run | No |
| `{{CONTEXT_BUNDLE_ARCHIVE}}` | AWS S3 (`context-bundles/` prefix) | Filesystem MCP (local bundle) | — | Run build_context_bundle.py | No |
| `{{CURRENT_STEP}}` | Filesystem MCP (plan doc) | AWS S3 (`technical-plans/` prefix) | — | Developer selects step | No |
| `{{STACK_TRACE}}` | — | — | — | Paste from APM / logs | No |
| `{{AUDIT_OUTPUT}}` | — | — | — | `make ai-sdlc-audit` output | No |
| `{{G_PLAN}}` | — | — | — | Named human approval | **✅ Human gate** |
| `{{G_SEC}}` | — | — | — | Named human approval | **✅ Human gate** |
| `{{G_PR_MERGE}}` | — | — | — | Named human approval (PR merge) | **✅ Human gate** |
| `{{G_DEPLOY}}` | — | — | — | Named human approval (deploy) | **✅ Human gate** |

### Messaging MCP notes (Slack, Teams, Outlook)

These MCPs can surface stakeholder discussion, decision context, and approval evidence in Cursor chat. Rules for using them:

- Content read from messaging MCPs **must be manually confirmed** before being used as a prompt input.
- A Slack/Teams/email message showing an approval is **not a substitute** for a `workflow-state.yaml` gate record.
- Human gate records must always be set via `update_workflow_state.py --add-approval` referencing the explicit approver name and the comment/email URL.
- Use messaging MCPs only to **supplement context**, not to auto-populate approval records.

### Deployment MCP notes (Render, Vercel)

- Use only for reading deployment status and logs — never to trigger deploys.
- Deployment status from Render/Vercel supplements `{{DEPLOYMENT_SUMMARY}}` and `{{MONITORING_SIGNALS}}` but does not replace human SRE verification.
- G-DEPLOY gate remains human-only regardless of what deployment MCPs report.

---

## Always-manual fields — developer must supply

| Placeholder | Prompt(s) using it | Why it is manual | How to get it |
|-------------|-------------------|-----------------|---------------|
| `{{CURRENT_STEP}}` | implement-step | Developer selects which step from the technical plan to implement now | Read `plan_doc` artifact and select the step number |
| `{{STACK_TRACE}}` | bug-triage | Comes from APM/logs — no observability MCP yet | Copy from Grafana, Datadog, CloudWatch, or Sentry |
| `{{MONITORING_SIGNALS}}` | monitoring-interpretation, bug-triage | No observability MCP configured | Paste alert body / metric summary from your observability tool |
| `{{AUDIT_OUTPUT}}` | cve-triage | Raw pip-audit / npm audit / trivy output | Run `make ai-sdlc-audit` locally and paste the output |
| `{{VALIDATION_RESULTS}}` | release-verification | Human QA/tester must produce these | QA run results, smoke test pass/fail evidence |
| `{{RELEASE_VERSION}}` | changelog-generation | Versioning is a human engineering decision | Engineering lead decides the version number |
| `{{RELEASE_CONTEXT}}` | release-verification | What is in this release, risk level, environment | Assembled from changelog + technical plan by developer |
| `{{RUNBOOK_SUBJECT}}` | runbook-draft | Human defines the scope of the runbook | State the feature/service/incident type clearly |
| `{{PROJECT_INTENT}}` | setup-new-project, setup-new-workspace | New project only — no code exists yet | Write a one-paragraph description of what the project does |
| `{{HUMAN_NOTES}}` | stage-router | By design — ad-hoc context the tools did not capture | Add any context that is not in workflow-state or project files |

---

## Human gates — never auto-filled

Human gates are approval decisions made by named humans. They are recorded **after** the human posts an explicit approval comment in the configured issue tracker, GitHub, or another tracked communication channel.

| Gate | When required | Approver (per project-config.yaml) | How to record |
|------|--------------|-----------------------------------|---------------|
| G-PLAN | Required for Tier 2+ before implementation begins | Engineering lead | `python ai-sdlc/tools/orchestration/update_workflow_state.py --add-approval "G-PLAN=name@domain.com:https://dev.azure.com/...#comment-N" --write` |
| G-SEC | Required for Tier 3+ or security-triggering changes | Security champion | Same as above with G-SEC |
| G-PR-MERGE | Always required before merge | PR approver | Recorded when PR is approved and merged in GitHub/ADO |
| G-DEPLOY | Required before production deployment | SRE / authorized approver | Recorded after explicit deployment approval |

To check gate status:
```bash
python ai-sdlc/tools/orchestration/check_gates.py \
  --workflow-state ai-sdlc/workflow-state/YOUR-ISSUE-ID.yaml
```

---

## Prompt-by-prompt cheat sheet

| Prompt | Auto-filled | MCP-readable | Must supply manually | Gate |
|--------|-------------|--------------|---------------------|------|
| stage-router | PROJECT_CONTEXT, WORKFLOW_STATE, APPROVAL_RECORDS, CURRENT_BLOCKERS, PROJECT_CONFIG | RECENT_CI_STATUS (GitHub) | AVAILABLE_ARTIFACTS content, HUMAN_NOTES | None — advisory |
| clarify-requirement | PROJECT_CONTEXT | REQUIREMENT (tracker MCP), REQUIREMENT_TYPE, REPOSITORY_CONTEXT, REPRODUCTION_STEPS, CURRENT_BEHAVIOR, EXPECTED_BEHAVIOR (tracker MCP/manual) | REQUIREMENT if no tracker MCP | Human resolves open questions; see [requirement-grooming-sop.md](requirement-grooming-sop.md) |
| classify-work | PROJECT_CONTEXT | REQUIREMENT (tracker MCP) | REQUIREMENT if no tracker MCP | Human confirms tier |
| create-spec | PROJECT_CONTEXT, TECH_STACK | REQUIREMENT, ACCEPTANCE_CRITERIA (tracker MCP) | ACCEPTANCE_CRITERIA if no tracker MCP | Human approves spec |
| create-issues | PROJECT_CONTEXT | REQUIREMENT (tracker MCP) | SPEC from create-spec output | Human creates in tracker |
| impact-analysis | PROJECT_CONTEXT, TECH_STACK | REQUIREMENT (tracker MCP), source files (Filesystem) | REPOSITORY_CONTEXT file selection | Human verifies component list |
| technical-plan | PROJECT_CONTEXT, APPROVAL_RULES, SECURITY_MODEL | REQUIREMENT (tracker MCP) | REQUIREMENT if no tracker MCP | **G-PLAN required before implementing** |
| implement-step | PROJECT_CONTEXT, TECH_STACK | REPOSITORY_CONTEXT, plan_doc (Filesystem) | CURRENT_STEP, ENGINEERING_GUARDRAILS | G-PLAN must already be recorded |
| generate-tests | PROJECT_CONTEXT, TECH_STACK | EXISTING_TESTS, source files (Filesystem) | REPOSITORY_CONTEXT, EXISTING_TESTS | Human reviews test output |
| self-review | PROJECT_CONTEXT | DIFF_CONTENT (GitHub / Filesystem) | DIFF_CONTENT if no MCP | Human reviews AI feedback |
| pr-review | PROJECT_CONTEXT, APPROVAL_RULES | DIFF_CONTENT, REVIEW_COMMENTS (GitHub) | DIFF_CONTENT if no GitHub MCP | **Human approves; G-PR-MERGE gate** |
| fix-review-comments | PROJECT_CONTEXT | REVIEW_COMMENTS (GitHub) | REVIEW_COMMENTS if no MCP | Re-review required after fixes |
| update-docs | PROJECT_CONTEXT | IMPLEMENTATION_PRS (GitHub) | IMPLEMENTATION_PRS if no GitHub MCP | Human approves docs PR |
| release-verification | PROJECT_CONTEXT, WORKFLOW_STATE, APPROVAL_RULES | RELEASE_CONTEXT (GitHub / tracker MCP) | VALIDATION_RESULTS, RELEASE_CONTEXT | **G-DEPLOY — human executes deployment** |
| bug-triage | PROJECT_CONTEXT | BUG_REPORT (tracker MCP / GitHub MCP), RECENT_CHANGES (GitHub) | STACK_TRACE, MONITORING_SIGNALS | Human confirms root cause |
| cve-triage | PROJECT_CONTEXT, TECH_STACK | DEPENDENCY_MANIFEST (Filesystem) | AUDIT_OUTPUT — paste CI output | Engineering lead reviews |
| changelog-generation | PROJECT_CONTEXT | MERGED_PRS (GitHub) | RELEASE_VERSION, MERGED_PRS if no MCP | PM/lead approves before publishing |
| runbook-draft | PROJECT_CONTEXT, ARCHITECTURE_CONTEXT | IMPLEMENTATION_PRS, PREVIOUS_INCIDENTS (GitHub / tracker MCP) | RUNBOOK_SUBJECT, MONITORING_SETUP | SRE reviews before publishing |
| monitoring-interpretation | PROJECT_CONTEXT | DEPLOYMENT_SUMMARY (GitHub / Render / Vercel) | MONITORING_SIGNALS, STACK_TRACE, LOG_EXCERPTS | SRE decides: incident / continue / rollback |
| setup-existing-project | None initially | Full repo (Filesystem MCP) | PROJECT_CONTEXT if none exists yet | Human confirms config before committing |
| setup-new-project | None initially | None (greenfield) | PROJECT_INTENT, TECH_STACK, APPROVAL_RULES | Human confirms proposed files |
| setup-existing-workspace | None initially | All repos (Filesystem MCP) | WORKSPACE_CONTEXT, APPROVAL_RULES | Human confirms workspace config |
| setup-new-workspace | None initially | None (greenfield) | PROJECT_INTENT, REPOSITORY_MAP, TECH_STACK | Human confirms workspace before creating |

---

## Placeholder coverage report in the context bundle

The script now prints a **placeholder coverage report** to stdout for every run. This report is also embedded in the JSON bundle under `placeholder_coverage`.

The report is filtered to the `--target-prompt` you pass. Example for `implement-step`:

```
PLACEHOLDER COVERAGE REPORT
Target prompt: implement-step

AUTO-FILLED BY SCRIPT:
  {{ PROJECT_CONTEXT }}
  {{ WORKFLOW_STATE }}
  {{ ENGINEERING_GUARDRAILS }}
    Cursor: Read ai-sdlc/governance/enterprise-engineering-guardrails.md

MCP-READABLE — ask Cursor explicitly:
  {{ REPOSITORY_CONTEXT }}
    Cursor: Read the repository structure and relevant files for <feature/module>.
    Action: Identify which source files are relevant and read them via Filesystem MCP

MANUAL DEVELOPER INPUT REQUIRED:
  {{ CURRENT_STEP }}
    Source: Technical plan artifact — developer selects the step to implement now
    Action: Read the technical plan and specify which step number to implement

HUMAN GATE — never auto-filled:
  {{ G_PLAN }}
    Action: Record only after engineering lead posts explicit approval comment.
```

Use this output to know exactly what to prepare in Cursor before running the prompt.

---

## Common session prep checklist

Before running a prompt session, verify:

- [ ] `build_context_bundle.py` has been run for the current workflow-state file
- [ ] `safe_to_proceed = YES` in the bundle output (or understand the blocker)
- [ ] MCP is active in Cursor for the servers you need (configured tracker MCP, GitHub, Filesystem)
- [ ] You have read the relevant issue via tracker MCP when configured (provides REQUIREMENT)
- [ ] If running implement-step: G-PLAN has been recorded in workflow-state
- [ ] If running release-verification: G-PLAN has been recorded
- [ ] If running pr-review: you have the PR diff available (GitHub MCP or manual)

---

## What will not be auto-filled — by design

These values should never be auto-populated, regardless of future tooling:

- Human approval records (G-PLAN, G-SEC, G-PR-MERGE, G-DEPLOY)
- Production deployment decisions
- Rollback decisions
- Security exploit severity judgments
- QA/acceptance test evidence
- Customer communication content
- Data deletion or anonymisation decisions
