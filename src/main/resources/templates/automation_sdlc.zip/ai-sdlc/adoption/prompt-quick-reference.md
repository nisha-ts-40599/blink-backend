# AI-SDLC Prompt Quick Reference

Curated daily-use guide for **commonly used** commands and prompts. It does **not** list the complete prompt inventory (55 operational prompts).

**Complete reference:** [`docs/operating-model/ai-sdlc-command-and-prompt-reference.md`](../../docs/operating-model/ai-sdlc-command-and-prompt-reference.md)

> **First time?** Start with [`quick-start.md`](quick-start.md) and [`first-feature-walkthrough.md`](first-feature-walkthrough.md).
> **Not sure which prompt to run?** Use `make ai-sdlc-stage-router` — it reads workflow state and recommends the next authorized step.

---

## Commonly used prompts

| When you need to… | Prompt / command | Key inputs | Output | Human action |
|---|---|---|---|---|
| Start grooming | `/sdlc-start` or `make ai-sdlc-sdlc-start-prep` | Issue ID or description (`INPUT_FILE=`) | workflow-state, context | Run `/clarify-requirement` when authorized |
| Set up an **existing project** | `/setup-existing-project` | Repo inspection | overlay drafts | Review and commit |
| Set up a **new project** | `/setup-new-project` | Project intent | overlay drafts | Complete setup refresh |
| **Clarify a requirement** | `/clarify-requirement` | groom-prep bundle | `requirement.md` | Resolve open questions |
| **Classify work** | `/classify-work` | requirement | `classification.md` | Confirm tier |
| **Analyse impact** (Tier 2+) | `/impact-analysis` | classification | `impact-analysis.md` | Verify blast radius |
| **Create specification** | `/create-spec` | requirement | `specification.md` | Review before planning |
| **Technical plan** | `/technical-plan` | spec, impact | `technical-plan.md` | **G-PLAN** (Tier 2+) |
| **Implement a plan step** | `/implement-step` | approved plan | step summary | Review code; preflight required |
| **Generate tests** | `/generate-tests` | plan, code | tests | Review coverage |
| **Self-review** | `/self-review` | branch diff | findings | Fix must-fix items |
| **AI PR review** | `/pr-review` | PR diff | review report | Resolve must-fix |
| **Merge readiness** | `/merge-readiness` | QA + review evidence | checklist | **G-PR-MERGE**; human merges |
| **Release verification** | `/release-verification` | merge evidence | release report | **G-DEPLOY**; human deploys |
| **Route next step** | `make ai-sdlc-stage-router` | workflow-state | recommendation | Follow authorized command only |
| **Authorize prompt** | `make ai-sdlc-validate-stage` | EXPECTED_STAGE | eligible true/false | Stop if blocked |

For grooming, bootstrap, modernization, and managed-bootstrap commands see the [command reference](../../docs/operating-model/ai-sdlc-command-and-prompt-reference.md).

---

## Recommended sequences

### Starting a feature

```
make ai-sdlc-stage-router     → confirm safe next step
/clarify-requirement          → requirement.md
/classify-work                → tier confirmation
/impact-analysis              → Tier 2+
/create-spec → /technical-plan → G-PLAN
```

### Development loop (per plan step)

```
/implement-step → /generate-tests → /self-review → PR lane
```

### PR and release

```
/pr-review → /merge-readiness → (human merge) → /release-verification
```

---

## Which prompts benefit from GitHub MCP

When GitHub read-only MCP is configured:

| Prompt | What MCP provides |
|--------|------------------|
| `clarify-requirement` | Issue body + comments |
| `classify-work` | Labels, similar issues |
| `pr-review` | PR diff and review threads |

See [`mcp/github-readonly-setup.md`](../mcp/github-readonly-setup.md).

---

## Placeholder quick map

| Placeholder | Typical source |
|-------------|----------------|
| `{{PROJECT_CONTEXT}}` | `.cursor/ai-sdlc/project-context.md` |
| `{{REQUIREMENT}}` | Issue body or `requirement.md` |
| `{{WORKFLOW_STATE}}` | `.cursor/ai-sdlc/workflow-state/<ISSUE>/<ISSUE>.yaml` |
| `{{ENGINEERING_GUARDRAILS}}` | `governance/enterprise-engineering-guardrails.md` |

Full map: [`prompt-input-source-map.md`](prompt-input-source-map.md).
