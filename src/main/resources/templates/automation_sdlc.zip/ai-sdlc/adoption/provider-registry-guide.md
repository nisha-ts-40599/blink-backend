# Provider registry guide

Adaptive aliases are implemented in `ai-sdlc/tools/setup/integration/provider_registry.py`.

Examples:

| User input (examples) | Normalized ID | Capability |
|----------------------|---------------|------------|
| ado, azure boards | azure-devops | ticket_management |
| bitbucket cloud | bitbucket-cloud | source_control |
| jira | jira | ticket_management |
| github (ambiguous) | — | clarification required |
| github issues | github-issues | ticket_management |
| confluence | confluence | documentation_knowledge |
| figma | figma | design_collaboration |
| playwright | playwright | test_automation (MCP not required) |

Unknown names → `custom` with `CUSTOM_UNSUPPORTED` configuration status; setup continues.

Adapter status values: `AVAILABLE`, `GENERATABLE`, `EXTERNAL`, `NOT_AVAILABLE`, `NOT_REQUIRED`.
