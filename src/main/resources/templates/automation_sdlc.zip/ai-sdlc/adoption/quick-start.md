# AI-SDLC Quick Start

Get running in under 30 minutes.

> **New to AI-SDLC?** Read this file first, then open `adoption/prompt-quick-reference.md` and
> `adoption/first-feature-walkthrough.md`. You do not need to read every document before starting.
>
> **Full lifecycle navigation:** See [`adoption/README.md`](README.md) for the recommended reading order (quick start → tiers/gates → rollback → modernization → cutover → pilot) and lifecycle branch summary.
>
> **Joining SDLC grooming?** See [`adoption/developer-grooming-quick-guide.md`](developer-grooming-quick-guide.md) and [`adoption/prompt-input-source-map.md`](prompt-input-source-map.md).
>
> **Enterprise rollout command spine:** See [`adoption/command-spine-playbook.md`](command-spine-playbook.md) and [`adoption/enterprise-rollout.md`](enterprise-rollout.md). Phase B commands are the recommended enterprise-safe workflow for issue initialization, artifact registration, gate approval, PR registration, merge closure, and closure reporting.

> **Internal production candidate:** See [`governance/internal-production-candidate/README.md`](../governance/internal-production-candidate/README.md) for H1–H13 baseline, authority boundaries, and release validation (`make ai-sdlc-release-candidate-test`).

---

## Recommended current workflow

For every issue you work on, follow this sequence:

```
1. Ensure `.cursor/ai-sdlc/project-context.md` and `project-config.yaml` are up to date
   (fallback: `ai-sdlc/project-context.md`, `ai-sdlc/project-config.yaml`)
2. Create `.cursor/ai-sdlc/workflow-state/{ISSUE-ID}/{ISSUE-ID}.yaml` for the issue
3. Run build_context_bundle.py to assemble context automatically
4. Run `make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>` to get the recommended next action (**canonical** — prefer over prompt-based routing)
5. Run `make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>` when checking artifact completeness before advancing
6. Before technical-plan, run `make ai-sdlc-validate-pre-spec ROOT=<workspace-root> ISSUE=<ISSUE-ID>`
7. Follow the recommended prompt with the pre-assembled context
8. Update workflow-state.yaml after each major step (stage change, gate approval, spec review)
9. Repeat from step 3 at the start of each session
```

**Quick commands:**

```bash
# Grooming prep for an issue (prefill report + context bundle; prefers .cursor/ai-sdlc overlay)
make ai-sdlc-groom-prep ISSUE=YOUR-ISSUE
# Embedded framework in a multi-repo workspace (run from automation_sdlc/):
make ai-sdlc-groom-prep ROOT=.. ISSUE=YOUR-ISSUE

# Validate groomed requirement before classify-work
python ai-sdlc/tools/orchestration/validate_requirement_dor.py \
  --requirement .cursor/ai-sdlc/workflow-state/YOUR-ISSUE/requirement.md

# Assemble context bundle (overlay resolved automatically when present)
python ai-sdlc/tools/orchestration/build_context_bundle.py \
  --workflow-state .cursor/ai-sdlc/workflow-state/YOUR-ISSUE/YOUR-ISSUE.yaml \
  --project-context .cursor/ai-sdlc/project-context.md \
  --project-config .cursor/ai-sdlc/project-config.yaml \
  --target-agent "Backend Implementation Agent" \
  --target-prompt implement-step \
  --output /tmp/context.json

# Or use the example target to verify the script works:
make ai-sdlc-context-bundle-example

# Recommend next prompt (read-only; never executes workflow actions):
make ai-sdlc-stage-router ROOT=. ISSUE=YOUR-ISSUE

# Check artifact completeness for current stage (PASS / WARN / FAIL):
make ai-sdlc-validate-artifacts ROOT=. ISSUE=YOUR-ISSUE

# Register local PR candidate without provider URL (omit PR_URL):
make ai-sdlc-register-pr ROOT=. ISSUE=YOUR-ISSUE REPO_ID=app SOURCE_BRANCH=feature/x \
  TARGET_BRANCH=main COMMIT_SHA=<sha> WRITE=1

# Check requirement/spec bundle readiness before technical-plan:
make ai-sdlc-validate-pre-spec ROOT=. ISSUE=YOUR-ISSUE
```

**Make vs slash commands vs prompt files:**

- Use **Make commands** for deterministic checks (guard, tracker resolution, stage-router, validate-artifacts, validate-pre-spec, groom-prep, install-cursor-commands).
- Use **Cursor slash commands** for AI-SDLC phase prompts (type `/` in chat — wrappers in `<workspace-root>/.cursor/commands/`).
- Use **full prompt file paths** only for framework maintenance or debugging (`automation_sdlc/ai-sdlc/prompts/`).

Canonical prompts live in the framework repo; slash commands must be installed into the consuming workspace root:

```bash
make ai-sdlc-install-cursor-commands ROOT=<workspace-root>
make ai-sdlc-install-cursor-commands ROOT=..
```

| Phase | Cursor command | Canonical prompt |
|------|----------------|------------------|
| Clarify requirement | `/clarify-requirement` | `ai-sdlc/prompts/clarify-requirement.prompt.md` |
| Technical plan | `/technical-plan` | `ai-sdlc/prompts/technical-plan.prompt.md` |
| Implementation | `/implement-step` | `ai-sdlc/prompts/implement-step.prompt.md` |
| PR review | `/pr-review` | `ai-sdlc/prompts/pr-review.prompt.md` |

Helper commands: `/sdlc-start`, `/sdlc-next`, `/sdlc-after-prompt` — see [`developer-grooming-quick-guide.md`](developer-grooming-quick-guide.md).

**Setup prompts — discovery, apply, refresh, reset:**

| Lifecycle | Flow |
|-----------|------|
| First-time setup | discovery → apply |
| Existing configured workspace | discovery → refresh |
| Workspace changed | refresh — do not delete `.cursor/ai-sdlc/**` |
| Destructive recreate | reset only — archive first |

- **Discovery** (default): inspect and propose — no writes.
- **Apply**: create missing overlay (`confirm setup`, `/setup-existing-workspace apply`, etc.).
- **Refresh**: update/reconcile existing overlay (`refresh setup`, `/setup-existing-workspace refresh`).
- If setup only proposes files, use apply for first-time setup or refresh when overlay already exists.

| Setup | Slash command |
|------|----------------|
| Existing workspace | `/setup-existing-workspace` |
| New workspace | `/setup-new-workspace` |
| Existing project | `/setup-existing-project` |
| New project | `/setup-new-project` |

Phase 1 greenfield readiness (`context_ready` / `delivery_ready`, migration inference): see [`project-delivery-readiness.md`](project-delivery-readiness.md). Validate with `make ai-sdlc-validate-setup-readiness ROOT=<root> REQUIRE=delivery`.

Phase 2 greenfield specification (canonical desired-state contract before bootstrap planning): see [`greenfield-project-specification.md`](greenfield-project-specification.md). Validate with `make ai-sdlc-validate-greenfield-spec SPEC=<path-to-spec.yaml>`.

**Interactive setup (discovery + recommendations):** see [`interactive-greenfield-setup.md`](interactive-greenfield-setup.md). Discover with `make ai-sdlc-greenfield-setup-discover ROOT=<root> PROJECT_NAME="..." DESCRIPTION="..."` (no file writes).

Phase 3 manual bootstrap planning (plan + instruction pack, no execution): see [`manual-greenfield-bootstrap.md`](manual-greenfield-bootstrap.md).

**Manual bootstrap is the operational greenfield execution path.** Human operators execute bootstrap steps externally; the framework records completion via reconciliation and `existing-*` refresh.

Phase 5.1 managed bootstrap supports **preview and simulation only**:
- capability discovery;
- execution proposal generation;
- approval validation (`G-BOOTSTRAP-EXEC` validation — not permission for real execution);
- preview;
- simulation.

Phase 5.1 does **not** execute repository, Git, scaffold, dependency, or provider actions. It cannot produce authoritative completion evidence. All managed preview/simulation output is labelled `DRY RUN / SIMULATION — NO ACTIONS EXECUTED` and `NONAUTHORITATIVE — NOT COMPLETION EVIDENCE`.

After G-PLAN, when `delivery_ready=false`, run `make ai-sdlc-stage-router` — the router returns an explicit route (`ROUTE_TO_GREENFIELD_BOOTSTRAP`, `ROUTE_TO_EXISTING_REFRESH`, or `ROUTE_TO_SETUP_REMEDIATION`) with `next_command`. Do not infer the bootstrap path manually.

After greenfield setup completes, use `/setup-existing-project refresh` or `/setup-existing-workspace refresh` — not `/setup-new-*` again.

**Enterprise-pilot grooming flow:**

```text
/sdlc-start <ISSUE>
→ /clarify-requirement <ISSUE>
→ make ai-sdlc-extract-grooming-state ROOT=<ROOT> ISSUE=<ISSUE> WRITE=1
→ /requirement-grooming-status <ISSUE>
→ /grooming-stakeholder-pack <ISSUE>   (if DoR not ready)
→ /grooming-revision <ISSUE>           (after stakeholder answers)
→ /grooming-sign-off-capture <ISSUE>   (when DoR ready)
→ make ai-sdlc-approve-gate ROOT=<ROOT> ISSUE=<ISSUE> GATE=G-GROOM APPROVER="<Full Name>:<email>" DECISION=approved EVIDENCE_REF=".cursor/ai-sdlc/workflow-state/<ISSUE>/grooming-signoff-summary.md" WRITE=1   (G-GROOM — human gate only)
── Phase 0 exit / Phase 1 entry ───────────────────────────────
→ /classify-work <ISSUE>               (Phase 1 — only after DoR ready + G-GROOM approved)
```

**One-line bugs:** Run clarify-requirement with **read-only code inspection** before asking
stakeholders. Output should include a code-informed repro plan and stakeholder clarification
pack. **Do not proceed to classify-work** until DoR validator passes and G-GROOM is approved when required.

---

### Context readiness and delivery readiness

AI-SDLC distinguishes two readiness levels. Understanding them prevents confusion when setup
blocks are reported.

#### context_ready

`context_ready` means the AI-SDLC workspace has enough valid context to begin grooming,
clarification, classification, and planning.

Typical requirements:

- setup lifecycle recognized (workspace-config, project-config present and valid)
- workspace/project identity available
- overlay valid
- context bundle resolvable

**A repository is not required for `context_ready`.** Brand-new product ideas may begin
Phase 0 grooming before any code infrastructure exists.

#### delivery_ready

`delivery_ready` means the repository and workspace prerequisites required for implementation
have been independently validated.

Typical requirements:

- repository present and detected
- overlay independently validated
- required bootstrap/reconciliation complete (if greenfield bootstrap ran)
- no blocking setup findings
- implementation prerequisites satisfied

**A repository is required for `delivery_ready`.** Run `implement-step` only when delivery_ready is true.

#### Readiness check commands

```bash
# Check both readiness levels
make ai-sdlc-validate-setup-readiness ROOT=<workspace-root> FORMAT=json

# Strict implementation-prerequisite check
make ai-sdlc-validate-setup-readiness ROOT=<workspace-root> REQUIRE=delivery
```

#### Activity matrix

| Activity | context_ready required | delivery_ready required |
|----------|-----------------------|------------------------|
| Grooming | Yes | No |
| Requirement clarification | Yes | No |
| Classification | Yes | No |
| Impact analysis | Yes | No |
| Technical planning | Yes | No |
| Bootstrap planning | Yes | No |
| implement-step | Yes | **Yes** |
| Automated tests | Yes | **Yes** |
| PR registration | Yes | **Yes** |
| Merge readiness | Yes | **Yes** |

If `delivery_ready` is false when you run `implement-step`, the validator will explain which
prerequisites are missing and what to do next.

See `docs/operating-model/lifecycle-and-readiness-map.md` for the complete readiness model,
greenfield bootstrap placement, and approval gate reference.

---

### Framework protection (product vs framework development)

**Default: product SDLC execution mode.** When `automation_sdlc` is embedded in a product workspace:

| Allowed | Blocked during product SDLC |
|---------|----------------------------|
| `.cursor/ai-sdlc/**` (overlay: config, workflow state, issue artifacts) | Framework repo files (`ai-sdlc/prompts/`, `tools/`, `schemas/`, etc.) |
| Approved product repo changes during approved implementation steps | Ad-hoc patches to framework code during product delivery |

**Check for framework drift** before product workflow steps (see [`adoption/framework-guard-checkpoints.md`](framework-guard-checkpoints.md)):

```bash
# Embedded framework — run from framework repo directory
cd <framework-repo>
make ai-sdlc-guard-framework-clean ROOT=..

# Standalone framework repo
make ai-sdlc-guard-framework-clean
```

`make ai-sdlc-groom-prep` runs this guard automatically in product mode (skipped when `FRAMEWORK_DEV=1`).

**Framework development mode** (maintainers only):

```bash
FRAMEWORK_DEV=1 make ai-sdlc-guard-framework-clean
```

If a workflow discovers a framework limitation, **report a framework gap** — do not patch framework files during product delivery. See `ai-sdlc/governance/framework-protection-rule.md` for the gap report format and **Git operations rule**.

**Git write operations** (`git add`, `git commit`, `git push`, branch checkout/switch, merge, rebase, reset, clean, tags, remote writes) are **blocked by default** during product SDLC unless the user explicitly requests them — regardless of shell, IDE Git UI, MCP, or automation. Report suggested commands instead of executing them. Push always requires separate approval.

**Key docs to open alongside this guide:**
- [`adoption/README.md`](README.md) — **full lifecycle reading order and branch summary**
- [`adoption/rollback-policy-guide.md`](rollback-policy-guide.md) — Tier 3+ rollback planning (Phase 1)
- [`adoption/modernization-lane-guide.md`](modernization-lane-guide.md) — modernization lane (Phase 2)
- [`adoption/cutover-readiness-guide.md`](cutover-readiness-guide.md) — cutover readiness (Phase 3)
- [`adoption/post-migration-validation-guide.md`](post-migration-validation-guide.md) — post-cutover validation (Phase 3)
- [`adoption/production-migration-gates-guide.md`](production-migration-gates-guide.md) — production migration gates (Phase 3)
- [`adoption/requirement-grooming-sop.md`](requirement-grooming-sop.md) — **start here for requirement clarification**
- [`adoption/ba-po-requirement-grooming-guide.md`](ba-po-requirement-grooming-guide.md) — for BA/PO input and review
- [`adoption/requirement-grooming-review-checklist.md`](requirement-grooming-review-checklist.md) — post-clarify review
- [`templates/requirement-template-lite.md`](../templates/requirement-template-lite.md) — Tier 1 / simple work (~10 min)
- [`templates/requirement-template.md`](../templates/requirement-template.md) — Tier 2+ / full grooming
- [`templates/grooming-metrics-template.yaml`](../templates/grooming-metrics-template.yaml) — pilot metrics capture
- [`examples/requirements/`](../examples/requirements/) — sanitized grooming examples (bug, enhancement, feature, migration, QA, platform, docs)
- [`tools/orchestration/validate_requirement_dor.py`](../tools/orchestration/validate_requirement_dor.py) — DoR validator
- [`schemas/requirements/groomed-requirement.schema.json`](../schemas/requirements/groomed-requirement.schema.json) — optional structured sidecar (not enforced)
- [`governance/public-reference-and-data-safety.md`](../governance/public-reference-and-data-safety.md)
- [`governance/framework-protection-rule.md`](../governance/framework-protection-rule.md)
- [`adoption/framework-guard-checkpoints.md`](framework-guard-checkpoints.md)
- [`adoption/prompt-quick-reference.md`](prompt-quick-reference.md) — which prompt to run, when, with what inputs
- [`adoption/first-feature-walkthrough.md`](first-feature-walkthrough.md) — end-to-end example using the patient-registration scenario
- [`orchestration/context-aggregator.md`](../orchestration/context-aggregator.md) — how context assembly works
- [`prompts/stage-router.prompt.md`](../prompts/stage-router.prompt.md) — routing recommendation prompt
- [`mcp/github-readonly-setup.md`](../mcp/github-readonly-setup.md) — reduce manual context copy-paste

---

## What this framework is for

- AI-assisted requirement clarification and work classification
- Governed technical planning with human approval gates
- Structured PR review and merge readiness analysis
- Conformance checking to validate schema and policy integrity in CI

## What this framework is NOT for

- Autonomous merging or deployment
- Runtime orchestration of real SDLC steps
- Replacement for human judgment on architecture, security, or production changes

---

## Step 1 — Create 2 setup files

These are the only files you need before running any prompt.

### `ai-sdlc/project-config.yaml`

Machine-readable project identity. Drives CI and governance tooling.

```bash
# Generate from the existing template, or run the setup prompt:
# Slash commands (discovery mode by default):
#   /setup-existing-project   /setup-new-project
# Apply mode: /setup-existing-project apply  or reply "confirm setup"
# Full paths: ai-sdlc/prompts/setup-existing-project.prompt.md (existing repo)
#             ai-sdlc/prompts/setup-new-project.prompt.md     (new repo)
cp ai-sdlc/project-config.template.yaml ai-sdlc/project-config.yaml
# Fill in: project name, stack, CI commands, approval roles, work tiers
```

### `ai-sdlc/project-context.md`

Human-readable context injected into every prompt as `{{PROJECT_CONTEXT}}`.
It tells the AI what this project is, how it works, and what rules apply.

```bash
# Use ai-sdlc/templates/project-context-template.md as the base
# Or let the setup prompt generate a filled version from repo inspection
```

**Both files should be committed on a feature branch and peer-reviewed before merging.**

---

## Step 2 — Run the daily prompts

Open a Cursor chat. Paste your `project-context.md` as context. Then use these prompts:

| # | Prompt file | When to use | Time |
|---|-------------|-------------|------|
| 1 | `prompts/clarify-requirement.prompt.md` | Every new requirement before any planning | 10 min |
| 2 | `prompts/classify-work.prompt.md` | After clarification; determines rigor required | 5 min |
| 3 | `prompts/impact-analysis.prompt.md` | Tier 2+ after classification, before spec | 10–20 min |
| 4 | `prompts/create-spec.prompt.md` | Produce adaptive bug/feature/spike specification | 10–20 min |
| 5 | `prompts/technical-plan.prompt.md` | After spec review and pre-spec validation | 20–30 min |
| 6 | `prompts/pr-review.prompt.md` | Before requesting human review on any PR | 15 min |

### Minimal usage pattern

```
New requirement arrives
  → clarify-requirement (fill {{REQUIREMENT}} + {{PROJECT_CONTEXT}}; optional {{REQUIREMENT_TYPE}})
  → save groomed output to workflow-state/{ISSUE-ID}/requirement.md
  → classify-work       (fill {{REQUIREMENT}} + {{PROJECT_CONTEXT}})
  → impact-analysis     (Tier 2+)
  → create-spec         (adaptive bug-fix / feature-enhancement / spike-investigation shape)
  → record spec_review_record (expected Tier 2+)
  → validate-pre-spec   (PASS, or explicit Tier 2 conditional acceptance)
  → technical-plan
  → implement
  → pr-review           (fill {{PR_CONTEXT}} + {{PROJECT_CONTEXT}})
  → human reviews and merges
```

### Requirement grooming by type

**SOP:** [`requirement-grooming-sop.md`](requirement-grooming-sop.md) · **Review checklist:**
[`requirement-grooming-review-checklist.md`](requirement-grooming-review-checklist.md)

`clarify-requirement.prompt.md` applies **BA, QA, Domain, and Security/Data review lenses**
in one pass (prompt personas — not separate agents). Output uses:

- **Lite template** — Tier 1, docs/tooling, simple bugs: [`requirement-template-lite.md`](../templates/requirement-template-lite.md)
- **Full template** — Tier 2+, production, security, migration: [`requirement-template.md`](../templates/requirement-template.md)

Examples: [`examples/requirements/`](../examples/requirements/)

Set `{{REQUIREMENT_TYPE}}` when known:

| Type | Grooming emphasis |
|------|-------------------|
| Bug | Treat one-liners as incomplete; run read-only code analysis first; repro + regression tests; DoR blocked until runtime/PO gaps closed |
| Enhancement | Current feature behavior, compatibility, regression scope |
| New feature / product | MVP scope, integrations, non-goals; product setup prompts if greenfield |
| Modernization/migration | Source/target, rollback, equivalence; impact-analysis before plan |
| QA/test automation | SUT, CI integration, flake handling, coverage gates |
| Cloud/devops/platform | IaC, secrets, blast radius; expect higher tier |

### Requirement grooming by persona

| Lens | Validates |
|------|-----------|
| **BA** | Business clarity, scope, non-goals, testable AC |
| **QA** | Testability, edge/regression cases, DoR from QA view |
| **Domain** | Product/domain fit; domain questions (no invented rules) |
| **Security/Data** | Privacy, auth, compliance, tier escalation when applicable |

**Data safety:** Follow `ai-sdlc/governance/public-reference-and-data-safety.md` — public
references are pattern summaries only; no PII, secrets, or proprietary copy in artifacts.

---

## Step 3 — Wire CI conformance

Copy the appropriate template from `ai-sdlc/ci/`:

```bash
# GitHub Actions
cp ai-sdlc/ci/ai-sdlc-conformance-job.github-actions.yml \
   .github/workflows/ai-sdlc-conformance.yml

# GitLab CI
# Copy ai-sdlc/ci/ai-sdlc-conformance-job.gitlab-ci.yml into your .gitlab-ci.yml

# Azure DevOps
# Copy ai-sdlc/ci/ai-sdlc-conformance-job.azure-pipelines.yml
```

Test locally:

```bash
make ai-sdlc-install               # Python venv + conformance runner dependencies
make ai-sdlc-install-opa           # OPA binary (protected conformance profile)
make ai-sdlc-conformance           # dev profile     → schema checks pass; OPA tests skipped
make ai-sdlc-conformance-protected # protected profile → OPA required; all policy checks run
```

> **Prerequisites (two separate steps):**
> - **`make ai-sdlc-install`** — creates `.venv-ai-sdlc/` and installs Python dependencies from `ai-sdlc/tools/conformance-runner/requirements.txt`. Does **not** install OPA.
> - **`make ai-sdlc-install-opa`** — downloads the OPA binary to `ai-sdlc/tools/bin/opa` via `ai-sdlc/tools/install-opa.sh`. Required for `make ai-sdlc-conformance-protected`. Supported on **macOS and Linux** (including **WSL2**). Native Windows is unsupported.
>
> Verify OPA after install: `ai-sdlc/tools/bin/opa version`
>
> Run `make ai-sdlc-install` once when you first clone the repo, and again after any `requirements.txt` change. Run `make ai-sdlc-install-opa` once per machine (or when `OPA_VERSION` changes).

---

## The 3 rules

```
1. AI recommends — humans approve.
   Tier 2+: engineering lead approves the plan (G-PLAN gate).
   All merges: human clicks merge. No exceptions.

2. Merge and deploy stay manual.
   AI produces merge readiness analysis. Human merges.
   AI produces deployment readiness analysis. SRE deploys.

3. The runtime orchestrator is reference/demo only.
   ai-sdlc/runtime/ has mock adapters and noop step executors.
   It does not produce governance records.
   Do not run it in CI or against production systems.
```

---

## First pilot (recommended)

Choose a Tier 2 standard feature from your real backlog. Avoid production bugs,
spikes, modernization, cutover, and Tier 4 work as the first pilot.

Use `make ai-sdlc-stage-router` as the canonical next-step source. Run the full
pre-development sequence before implementation:

```
1. clarify-requirement      → confirm scope and acceptance criteria
2. validate DoR             → confirm requirement is ready for planning
3. classify-work            → confirm Tier 2; add label to issue
4. impact-analysis          → Tier 2+ impact before spec
5. create-spec              → adaptive bug/feature/spike specification
6. spec_review_record       → record lightweight spec review evidence
7. validate-pre-spec        → make ai-sdlc-validate-pre-spec ROOT=<workspace-root> ISSUE=<issue-id>
8. technical-plan           → engineering lead approves (G-PLAN)
```

**Measure:** Did the clarification prompt reduce back-and-forth on requirements?
Did the plan prompt produce an ordered list you actually followed?

If yes to both — the framework is working. Expand to a second feature.

---

## Multi-repo workspace (do this after single-repo is working)

Once single-repo setup is solid, add workspace context for cross-repo planning:

```bash
# Generate workspace config and context:
# Use ai-sdlc/prompts/setup-existing-workspace.prompt.md

# The two workspace files:
# ai-sdlc/workspace-config.yaml  — machine-readable workspace topology
# ai-sdlc/workspace-context.md   — human-readable context for cross-repo prompts
```

**Cross-repo prompt usage in Cursor:**

```
Planning chat:   load workspace-context.md + each affected repo's project-context.md
                 run clarify-requirement + classify-work + technical-plan

Implementation:  separate chat per repo
                 load ONLY that repo's project-context.md + approved plan excerpt

Review chat:     load ONLY that repo's project-context.md + the PR diff
```

**Do not mix planning and implementation in the same chat.**
**Do not load workspace-context into an implementation chat.**

---

## Stage-boundary principle

Every AI-SDLC prompt owns exactly one SDLC responsibility:

```text
Each prompt owns one SDLC responsibility.
It may consume prior-stage evidence but must not perform later-stage work.
When complete, it returns control to the stage router.
```

**Why this matters:** When you say "Fix this bug", "Deploy this", or "Implement this feature",
you are stating the desired *outcome*. The active workflow state — artifacts, gate approvals,
readiness — determines what the current prompt is *permitted* to do. Imperative wording does
not select the workflow stage or bypass required gates.

**Example:** You ask `/clarify-requirement` "Fix the checkout bug."
Correct behaviour:
- captures "fix checkout bug" as the requirement intent;
- structures the requirement to DoR standard;
- runs DoR validation;
- hands off to the stage router;
- **stops** — it does not edit checkout code or create commits.

Every prompt contains a `## Stage Boundary` section declaring its stage, responsibility,
prohibited downstream work, and handoff. Validation:

```bash
make ai-sdlc-prompt-boundary-test
```

Further reading: `docs/operating-model/prompt-stage-boundary-model.md`

---

## Where to go from here

| Goal | Document |
|------|---------|
| Full daily workflow (all steps) | [`docs/operating-model/current-sdlc-flow.md`](../../docs/operating-model/current-sdlc-flow.md) |
| Week-by-week rollout plan | `ai-sdlc/adoption/first-week-rollout-plan.md` |
| Work tier definitions | `ai-sdlc/work-tiers.md` |
| Approval gate catalog | `ai-sdlc/governance/approval-gates.md` |
| What not to automate | `ai-sdlc/adoption/when-not-to-use-ai-automation.md` |
| Self-adoption examples (this repo) | `ai-sdlc/examples/self-adoption/` |
| Conformance test details | `ai-sdlc/tests/README.md` |
| Stage-boundary model | `docs/operating-model/prompt-stage-boundary-model.md` |
| Prompt responsibility matrix | `docs/operating-model/prompt-responsibility-matrix.md` |
| Stage handoff contract | `docs/operating-model/stage-handoff-contract.md` |
