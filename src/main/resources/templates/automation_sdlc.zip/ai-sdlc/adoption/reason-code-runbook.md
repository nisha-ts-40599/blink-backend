# Operator Reason-Code Runbook

Generated from `ai-sdlc/registry/journey-recovery-registry.yaml` and
`ai-sdlc/registry/gate-registry.yaml`. Do not edit reason mappings manually.

Framework: **4.0.0** (`stable`, `stable: true`)

## How to use

1. Run `/sdlc-status ISSUE MODE=diagnostic` or inspect operational health report.
2. Normalize the reported code through journey recovery (aliases map automatically).
3. Follow **Repair** first (read-only where possible), then **Resume**.

## Canonical recovery codes

| Code | Category | Retryable | Repair | Resume | Evidence |
| --- | --- | --- | --- | --- | --- |
| `MISSING_PREREQUISITE` | prerequisite | yes | `/sdlc-run {issue_id} EXECUTE=0 MODE=diagnostic` | `/sdlc-run {issue_id} EXECUTE=1 ACTION={action_id}` | workflow-state, lifecycle-events.jsonl, operational health report |
| `STALE_ARTIFACT` | artifact | yes | `/sdlc-recapture-implementation-package {issue_id}` | `/sdlc-run {issue_id} ACTION=REGISTER_IMPLEMENTATION_PACKAGE ` | artifact registry, implementation package hashes |
| `STALE_HANDOFF` | handoff | yes | `/sdlc-run {issue_id} ACTION={action_id}` | `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1` | governance/handoffs, execution plan binding |
| `MISSING_AUTHORIZATION` | authorization | yes | `/sdlc-run {issue_id} ACTION={repair_action_id}` | `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1` | workflow-state authorization tokens |
| `GATE_DENIAL` | gate | yes | `make ai-sdlc-approve-gate ROOT={root} ISSUE={issue_id} GATE=` | `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1` | workflow-state gates, gate approval evidence |
| `MUTATION_DENIAL` | mutation | no | `/sdlc-run {issue_id} EXECUTE=0 MODE=diagnostic` | `/sdlc-status {issue_id} MODE=diagnostic` | mutation audit events, product_mutation_guard output |
| `EXECUTION_PLAN_DRIFT` | handoff | yes | `/sdlc-run {issue_id} ACTION={action_id}` | `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1` | governance/handoffs, execution plan binding |
| `PARTIAL_BOOTSTRAP` | bootstrap | yes | `/sdlc-run {issue_id} ACTION=BOOTSTRAP_EXECUTE EXECUTE=1` | `/sdlc-run {issue_id} ACTION=BOOTSTRAP_EXECUTE EXECUTE=1` | workflow-state, lifecycle-events.jsonl, operational health report |
| `PARTIAL_IMPLEMENTATION_SLICE` | implementation | yes | `/sdlc-run {issue_id} ACTION=IMPLEMENTATION_PREP` | `/sdlc-run {issue_id} ACTION=IMPLEMENTATION_SLICE EXECUTE=1` | workflow-state, lifecycle-events.jsonl, operational health report |
| `RETRY_EXHAUSTED` | retry | no | `/sdlc-status {issue_id} MODE=diagnostic` | `/sdlc-run {issue_id} EXECUTE=0 MODE=diagnostic` | workflow-state, lifecycle-events.jsonl, operational health report |
| `QA_FAILED` | qa | yes | `/sdlc-triage-defects {issue_id}` | `/sdlc-run {issue_id} ACTION=QA_RECORD_EVIDENCE EXECUTE=1` | QA evidence artifacts |
| `QA_EVIDENCE_MISSING` | qa | yes | `/sdlc-run {issue_id} ACTION=QA_RECORD_EVIDENCE` | `/sdlc-run {issue_id} ACTION=QA_RECORD_EVIDENCE EXECUTE=1` | QA evidence artifacts |
| `PR_EVIDENCE_INCOMPLETE` | pr | yes | `/sdlc-run {issue_id} ACTION=REGISTER_PR` | `/sdlc-run {issue_id} ACTION=REGISTER_PR EXECUTE=1` | PR registration artifacts |
| `PR_NOT_READY` | pr | yes | `/sdlc-run {issue_id} ACTION=REGISTER_PR` | `/sdlc-run {issue_id} ACTION=ASSESS_PR_READINESS` | PR registration artifacts |
| `RELEASE_READINESS_FAILED` | release | yes | `/sdlc-run {issue_id} ACTION=ASSESS_RELEASE_READINESS` | `/sdlc-run {issue_id} ACTION=ASSESS_RELEASE_READINESS` | release readiness report |
| `DEPLOYMENT_SIMULATION_FAILED` | deployment | yes | `/sdlc-run {issue_id} ACTION=DEPLOYMENT_SIMULATE` | `/sdlc-run {issue_id} ACTION=DEPLOYMENT_SIMULATE EXECUTE=1` | deployment simulation evidence |
| `POST_DEPLOY_VERIFICATION_FAILED` | deployment | yes | `/sdlc-run {issue_id} ACTION=POST_DEPLOY_VERIFY` | `/sdlc-run {issue_id} ACTION=POST_DEPLOY_VERIFY EXECUTE=1` | deployment simulation evidence |
| `ROLLBACK_EVIDENCE_REQUIRED` | deployment | yes | `/sdlc-run {issue_id} ACTION=DEPLOYMENT_SIMULATE` | `/sdlc-run {issue_id} ACTION=POST_DEPLOY_VERIFY EXECUTE=1` | deployment simulation evidence |
| `TRANSACTION_INTERRUPTED` | transaction | yes | `make ai-sdlc-workflow-recovery ROOT={root} ISSUE={issue_id}` | `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1` | workflow-transaction.json, lifecycle-events.jsonl |
| `DUPLICATE_SUBMISSION` | idempotency | no | `/sdlc-status {issue_id}` | `/sdlc-run {issue_id}` | workflow-state, lifecycle-events.jsonl, operational health report |
| `CONCURRENT_EXECUTION_BLOCKED` | concurrency | yes | `/sdlc-status {issue_id}` | `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1` | lock-events.jsonl, lock_registry inspect |
| `POSTCONDITION_FAILED` | execution | yes | `/sdlc-run {issue_id} EXECUTE=0 MODE=diagnostic` | `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1` | workflow-state, lifecycle-events.jsonl, operational health report |
| `NON_RETRYABLE_FAILURE` | terminal | no | `/sdlc-status {issue_id} MODE=diagnostic` | `/sdlc-run {issue_id} EXECUTE=0 MODE=diagnostic` | workflow-state, lifecycle-events.jsonl, operational health report |

## Detailed entries

### `MISSING_PREREQUISITE`

- **Category:** prerequisite
- **Meaning:** Required artifact, gate, or handoff not satisfied.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `IMPLEMENTATION_NOT_AUTHORIZED, BOOTSTRAP_NOT_AUTHORIZED, G_PLAN_NOT_APPROVED, CONSUMED_HANDOFF_NOT_FOUND, PREREQUISITE_MISSING`
- **Repair command:** `/sdlc-run {issue_id} EXECUTE=0 MODE=diagnostic`
- **Resume command:** `/sdlc-run {issue_id} EXECUTE=1 ACTION={action_id}`
- **Evidence to inspect:** workflow-state, lifecycle-events.jsonl, operational health report
- **Escalation:** Retry per policy; escalate to operator if max retries exceeded.

### `STALE_ARTIFACT`

- **Category:** artifact
- **Meaning:** Bound artifact hash/revision no longer matches authorization.
- **Retryable:** yes
- **Requires new handoff:** yes
- **Likely cause:** see compatibility aliases: `AUTHORIZATION_REVISION_MISMATCH, ARTIFACT_HASH_MISMATCH, PACKAGE_BINDING_STALE`
- **Repair command:** `/sdlc-recapture-implementation-package {issue_id}`
- **Resume command:** `/sdlc-run {issue_id} ACTION=REGISTER_IMPLEMENTATION_PACKAGE EXECUTE=1`
- **Evidence to inspect:** artifact registry, implementation package hashes
- **Escalation:** Retry per policy; escalate to engineering_lead if max retries exceeded.

### `STALE_HANDOFF`

- **Category:** handoff
- **Meaning:** Handoff plan expired, superseded, or drifted.
- **Retryable:** yes
- **Requires new handoff:** yes
- **Likely cause:** see compatibility aliases: `HANDOFF_STALE, HANDOFF_REVISION_MISMATCH, EXECUTION_PLAN_DRIFT`
- **Repair command:** `/sdlc-run {issue_id} ACTION={action_id}`
- **Resume command:** `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1`
- **Evidence to inspect:** governance/handoffs, execution plan binding
- **Escalation:** Retry per policy; escalate to operator if max retries exceeded.

### `MISSING_AUTHORIZATION`

- **Category:** authorization
- **Meaning:** Bootstrap or implementation authorization not recorded.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `BOOTSTRAP_NOT_AUTHORIZED, IMPLEMENTATION_NOT_AUTHORIZED, GATE_AUTHORIZATION_BLOCKED`
- **Repair command:** `/sdlc-run {issue_id} ACTION={repair_action_id}`
- **Resume command:** `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1`
- **Evidence to inspect:** workflow-state authorization tokens
- **Escalation:** Retry per policy; escalate to engineering_lead if max retries exceeded.

### `GATE_DENIAL`

- **Category:** gate
- **Meaning:** Human gate approval missing or rejected.
- **Retryable:** yes
- **Requires new handoff:** yes
- **Likely cause:** see compatibility aliases: `QA_GATE_DENIED, MERGE_GATE_DENIED, RELEASE_GATE_DENIED, HUMAN_APPROVAL_REQUIRED`
- **Repair command:** `make ai-sdlc-approve-gate ROOT={root} ISSUE={issue_id} GATE={gate} WRITE=1`
- **Resume command:** `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1`
- **Evidence to inspect:** workflow-state gates, gate approval evidence
- **Escalation:** Retry per policy; escalate to gate_approver if max retries exceeded.

### `MUTATION_DENIAL`

- **Category:** mutation
- **Meaning:** Product mutation blocked by guard or policy.
- **Retryable:** no
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `REPOSITORY_MUTATION_BLOCKED, PROVIDER_WRITE_BLOCKED, COMMAND_INJECTION_BLOCKED, DESTRUCTIVE_BLOCKED`
- **Repair command:** `/sdlc-run {issue_id} EXECUTE=0 MODE=diagnostic`
- **Resume command:** `/sdlc-status {issue_id} MODE=diagnostic`
- **Evidence to inspect:** mutation audit events, product_mutation_guard output
- **Escalation:** Escalate to operator when repair commands fail twice.

### `EXECUTION_PLAN_DRIFT`

- **Category:** handoff
- **Meaning:** Requested action differs from confirmed handoff plan.
- **Retryable:** yes
- **Requires new handoff:** yes
- **Likely cause:** see compatibility aliases: `ACTION_CHANGED_DURING_PREFLIGHT, PLAN_HASH_MISMATCH`
- **Repair command:** `/sdlc-run {issue_id} ACTION={action_id}`
- **Resume command:** `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1`
- **Evidence to inspect:** governance/handoffs, execution plan binding
- **Escalation:** Retry per policy; escalate to operator if max retries exceeded.

### `PARTIAL_BOOTSTRAP`

- **Category:** bootstrap
- **Meaning:** Canonical bootstrap recovery reason.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `BOOTSTRAP_PARTIAL, BOOTSTRAP_RESUME_REQUIRED`
- **Repair command:** `/sdlc-run {issue_id} ACTION=BOOTSTRAP_EXECUTE EXECUTE=1`
- **Resume command:** `/sdlc-run {issue_id} ACTION=BOOTSTRAP_EXECUTE EXECUTE=1`
- **Evidence to inspect:** workflow-state, lifecycle-events.jsonl, operational health report
- **Escalation:** Retry per policy; escalate to bootstrap_operator if max retries exceeded.

### `PARTIAL_IMPLEMENTATION_SLICE`

- **Category:** implementation
- **Meaning:** Canonical implementation recovery reason.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `IMPLEMENTATION_SLICE_INCOMPLETE, IMPLEMENTATION_PREP_INCOMPLETE, retry_budget_exhausted`
- **Repair command:** `/sdlc-run {issue_id} ACTION=IMPLEMENTATION_PREP`
- **Resume command:** `/sdlc-run {issue_id} ACTION=IMPLEMENTATION_SLICE EXECUTE=1`
- **Evidence to inspect:** workflow-state, lifecycle-events.jsonl, operational health report
- **Escalation:** Retry per policy; escalate to implementation_operator if max retries exceeded.

### `RETRY_EXHAUSTED`

- **Category:** retry
- **Meaning:** Canonical retry recovery reason.
- **Retryable:** no
- **Requires new handoff:** yes
- **Likely cause:** see compatibility aliases: `none`
- **Repair command:** `/sdlc-status {issue_id} MODE=diagnostic`
- **Resume command:** `/sdlc-run {issue_id} EXECUTE=0 MODE=diagnostic`
- **Evidence to inspect:** workflow-state, lifecycle-events.jsonl, operational health report
- **Escalation:** Escalate to engineering_lead when repair commands fail twice.

### `QA_FAILED`

- **Category:** qa
- **Meaning:** Canonical qa recovery reason.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `none`
- **Repair command:** `/sdlc-triage-defects {issue_id}`
- **Resume command:** `/sdlc-run {issue_id} ACTION=QA_RECORD_EVIDENCE EXECUTE=1`
- **Evidence to inspect:** QA evidence artifacts
- **Escalation:** Retry per policy; escalate to qa_lead if max retries exceeded.

### `QA_EVIDENCE_MISSING`

- **Category:** qa
- **Meaning:** Canonical qa recovery reason.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `none`
- **Repair command:** `/sdlc-run {issue_id} ACTION=QA_RECORD_EVIDENCE`
- **Resume command:** `/sdlc-run {issue_id} ACTION=QA_RECORD_EVIDENCE EXECUTE=1`
- **Evidence to inspect:** QA evidence artifacts
- **Escalation:** Retry per policy; escalate to qa_lead if max retries exceeded.

### `PR_EVIDENCE_INCOMPLETE`

- **Category:** pr
- **Meaning:** Canonical pr recovery reason.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `none`
- **Repair command:** `/sdlc-run {issue_id} ACTION=REGISTER_PR`
- **Resume command:** `/sdlc-run {issue_id} ACTION=REGISTER_PR EXECUTE=1`
- **Evidence to inspect:** PR registration artifacts
- **Escalation:** Retry per policy; escalate to operator if max retries exceeded.

### `PR_NOT_READY`

- **Category:** pr
- **Meaning:** Canonical pr recovery reason.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `none`
- **Repair command:** `/sdlc-run {issue_id} ACTION=REGISTER_PR`
- **Resume command:** `/sdlc-run {issue_id} ACTION=ASSESS_PR_READINESS`
- **Evidence to inspect:** PR registration artifacts
- **Escalation:** Retry per policy; escalate to operator if max retries exceeded.

### `RELEASE_READINESS_FAILED`

- **Category:** release
- **Meaning:** Canonical release recovery reason.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `none`
- **Repair command:** `/sdlc-run {issue_id} ACTION=ASSESS_RELEASE_READINESS`
- **Resume command:** `/sdlc-run {issue_id} ACTION=ASSESS_RELEASE_READINESS`
- **Evidence to inspect:** release readiness report
- **Escalation:** Retry per policy; escalate to release_approver if max retries exceeded.

### `DEPLOYMENT_SIMULATION_FAILED`

- **Category:** deployment
- **Meaning:** Canonical deployment recovery reason.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `none`
- **Repair command:** `/sdlc-run {issue_id} ACTION=DEPLOYMENT_SIMULATE`
- **Resume command:** `/sdlc-run {issue_id} ACTION=DEPLOYMENT_SIMULATE EXECUTE=1`
- **Evidence to inspect:** deployment simulation evidence
- **Escalation:** Retry per policy; escalate to platform_owner if max retries exceeded.

### `POST_DEPLOY_VERIFICATION_FAILED`

- **Category:** deployment
- **Meaning:** Canonical deployment recovery reason.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `none`
- **Repair command:** `/sdlc-run {issue_id} ACTION=POST_DEPLOY_VERIFY`
- **Resume command:** `/sdlc-run {issue_id} ACTION=POST_DEPLOY_VERIFY EXECUTE=1`
- **Evidence to inspect:** deployment simulation evidence
- **Escalation:** Retry per policy; escalate to platform_owner if max retries exceeded.

### `ROLLBACK_EVIDENCE_REQUIRED`

- **Category:** deployment
- **Meaning:** Canonical deployment recovery reason.
- **Retryable:** yes
- **Requires new handoff:** yes
- **Likely cause:** see compatibility aliases: `none`
- **Repair command:** `/sdlc-run {issue_id} ACTION=DEPLOYMENT_SIMULATE`
- **Resume command:** `/sdlc-run {issue_id} ACTION=POST_DEPLOY_VERIFY EXECUTE=1`
- **Evidence to inspect:** deployment simulation evidence
- **Escalation:** Retry per policy; escalate to platform_owner if max retries exceeded.

### `TRANSACTION_INTERRUPTED`

- **Category:** transaction
- **Meaning:** Workflow transaction incomplete; recovery required.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `STATE_REVISION_CONFLICT, REVISION_CONFLICT, STALE_WORKFLOW_REVISION, PARTIAL_FAILURE`
- **Repair command:** `make ai-sdlc-workflow-recovery ROOT={root} ISSUE={issue_id}`
- **Resume command:** `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1`
- **Evidence to inspect:** workflow-transaction.json, lifecycle-events.jsonl
- **Escalation:** Retry per policy; escalate to operator if max retries exceeded.

### `DUPLICATE_SUBMISSION`

- **Category:** idempotency
- **Meaning:** Canonical idempotency recovery reason.
- **Retryable:** no
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `IDEMPOTENCY_CONFLICT, DUPLICATE_HANDOFF`
- **Repair command:** `/sdlc-status {issue_id}`
- **Resume command:** `/sdlc-run {issue_id}`
- **Evidence to inspect:** workflow-state, lifecycle-events.jsonl, operational health report
- **Escalation:** Escalate to operator when repair commands fail twice.

### `CONCURRENT_EXECUTION_BLOCKED`

- **Category:** concurrency
- **Meaning:** Lock or lease prevents concurrent execution.
- **Retryable:** yes
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `CONCURRENT_HANDOFF_CONSUMPTION, CONCURRENT_ARTIFACT_AMENDMENT, LOCK_CONFLICT, LEASE_CONFLICT, CONCURRENT_WORKFLOW_WRITE`
- **Repair command:** `/sdlc-status {issue_id}`
- **Resume command:** `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1`
- **Evidence to inspect:** lock-events.jsonl, lock_registry inspect
- **Escalation:** Retry per policy; escalate to operator if max retries exceeded.

### `POSTCONDITION_FAILED`

- **Category:** execution
- **Meaning:** Canonical execution recovery reason.
- **Retryable:** yes
- **Requires new handoff:** yes
- **Likely cause:** see compatibility aliases: `EXECUTION_POSTCONDITION_FAILED`
- **Repair command:** `/sdlc-run {issue_id} EXECUTE=0 MODE=diagnostic`
- **Resume command:** `/sdlc-run {issue_id} ACTION={action_id} EXECUTE=1`
- **Evidence to inspect:** workflow-state, lifecycle-events.jsonl, operational health report
- **Escalation:** Retry per policy; escalate to operator if max retries exceeded.

### `NON_RETRYABLE_FAILURE`

- **Category:** terminal
- **Meaning:** Canonical terminal recovery reason.
- **Retryable:** no
- **Requires new handoff:** no
- **Likely cause:** see compatibility aliases: `POLICY_BLOCKED, UNSUPPORTED, HANDLER_MISSING`
- **Repair command:** `/sdlc-status {issue_id} MODE=diagnostic`
- **Resume command:** `/sdlc-run {issue_id} EXECUTE=0 MODE=diagnostic`
- **Evidence to inspect:** workflow-state, lifecycle-events.jsonl, operational health report
- **Escalation:** Escalate to engineering_lead when repair commands fail twice.

## Gate policy reason codes (informational)

- `BOOTSTRAP_PLAN_EXISTS` — Bootstrap plan artifact exists (POLICY_INFORMATIONAL)
- `CLASSIFICATION_CONDITIONAL` — Conditional routing from classification (POLICY_INFORMATIONAL)
- `DEPLOYMENT_IN_SCOPE` — Production or staged deployment is in scope (POLICY_INFORMATIONAL)
- `DEPLOYMENT_OUT_OF_SCOPE` — Deployment is not in scope for this work item (POLICY_INFORMATIONAL)
- `GATE_EXPLICITLY_NOT_REQUIRED` — Gate explicitly marked not required in workflow state (POLICY_INFORMATIONAL)
- `GATE_EXPLICITLY_REQUIRED` — Gate explicitly marked required in workflow state (POLICY_INFORMATIONAL)
- `MANAGED_BOOTSTRAP_EXECUTION` — Managed bootstrap execution selected (POLICY_INFORMATIONAL)
- `PR_WORKFLOW_APPLICABLE` — Pull-request workflow applies (POLICY_INFORMATIONAL)
- `PR_WORKFLOW_NOT_APPLICABLE` — Pull-request workflow not in scope (POLICY_INFORMATIONAL)
- `REPOSITORY_MISSING` — Target repository missing (greenfield bootstrap) (POLICY_INFORMATIONAL)
- `RUNTIME_QA_REQUIRED` — Runtime visual QA validation required (POLICY_INFORMATIONAL)
- `SECURITY_SENSITIVE` — Security-sensitive change profile (POLICY_INFORMATIONAL)
- `STAGE_THRESHOLD` — Gate enforced at or past lifecycle stage threshold (POLICY_INFORMATIONAL)
- `WORK_TIER_1_G_PLAN_NOT_REQUIRED` — Tier 1 does not require G-PLAN by default (POLICY_INFORMATIONAL)
- `WORK_TIER_2_REQUIRES_G_PLAN` — Tier 2 requires G-PLAN (POLICY_INFORMATIONAL)
- `WORK_TIER_3_REQUIRES_G_SEC` — Tier 3+ requires G-SEC at implementation (POLICY_INFORMATIONAL)
- `WORK_TIER_REQUIRES_GATE` — Gate required for work tier (POLICY_INFORMATIONAL)

## Reason-code authority classification

Operator-actionable codes are the 22 canonical journey-recovery entries below. Compatibility aliases and routing codes normalize to these via `journey_recovery.py`. Gate-registry codes are policy-informational only.

| Classification | Count |
| --- | --- |
| OPERATOR_ACTIONABLE | 23 |
| INTERNAL_ONLY (catalogued) | 53 |
| POLICY_INFORMATIONAL | 17 |
