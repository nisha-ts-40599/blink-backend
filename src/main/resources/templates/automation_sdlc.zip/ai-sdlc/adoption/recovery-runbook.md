# Recovery and Interruption Runbook

Framework: **4.0.0** · **stable** · **`stable: true`**.

Authoritative repair uses Make/CLI commands and journey recovery — **never** delete state files or manually edit authoritative YAML.

Primary diagnostic: `/sdlc-run ISSUE MODE=diagnostic` or `/sdlc-status ISSUE MODE=diagnostic`.

---

## General procedure

1. **Detect** — note reason code from BLOCKED output or operational health report.
2. **Inspect read-only** — `make ai-sdlc-health-report ROOT=<ws>`, lock registry inspect, audit export.
3. **Repair** — use the registry `default_repair_command` for the reason code (see reason-code runbook).
4. **Resume** — `/sdlc-resume ISSUE` or `/sdlc-run ISSUE`.
5. **Verify** — confirm no replay of completed steps; check lifecycle-events.jsonl.

---

## Process interruption

| Field | Value |
| --- | --- |
| **Detection** | Operator session ended mid-command; next `/sdlc-run` shows BLOCKED or unexpected stage |
| **Inspect** | `make ai-sdlc-health-report ROOT=<ws>`; workflow-state current_stage; lifecycle-events.jsonl tail |
| **Repair** | `/sdlc-run ISSUE EXECUTE=0 MODE=diagnostic` |
| **Reapproval** | Only if authorization or gates expired |
| **Evidence preserved** | lifecycle-events, workflow-state, transaction log |
| **Unsafe shortcuts** | Re-running implement without checking auth; skipping diagnostic |

---

## TRANSACTION_INTERRUPTED

| Field | Value |
| --- | --- |
| **Detection** | Reason code `TRANSACTION_INTERRUPTED` |
| **Inspect** | `workflow-transaction.json`; recovery-attempts.jsonl |
| **Repair** | `make ai-sdlc-workflow-recovery ROOT=<ws> ISSUE=<id>` |
| **Resume** | `/sdlc-resume ISSUE` |
| **Reapproval** | If transaction was authorization or slice commit |
| **Evidence** | transaction log, repair audit |
| **Unsafe** | Manual transaction file deletion |

---

## Partial bootstrap

| Field | Value |
| --- | --- |
| **Detection** | setup-state `bootstrap_incomplete`; missing repo |
| **Inspect** | `make ai-sdlc-validate-setup-readiness ROOT=<ws>`; bootstrap plan path |
| **Repair** | `make ai-sdlc-managed-proposal` / resume managed bootstrap per setup guide |
| **Reapproval** | **G-BOOTSTRAP** if plan changed |
| **Evidence** | setup-state.yaml, bootstrap-plan.yaml |
| **Unsafe** | Creating repos outside managed bootstrap workflow |

---

## Partial implementation slice

| Field | Value |
| --- | --- |
| **Detection** | Slice incomplete; `MUTATION_DENIAL` or stage stuck in IMPLEMENTING |
| **Inspect** | mutation audit log; implementation package hash |
| **Repair** | Complete or explicitly abandon slice via diagnostic repair path |
| **Reapproval** | **Yes** — new `IMPLEMENTATION_SLICE` confirmation |
| **Evidence** | mutation events, slice envelope |
| **Unsafe** | Continuing product writes without reauthorization |

---

## Stale lock

| Field | Value |
| --- | --- |
| **Detection** | `CONCURRENT_EXECUTION_BLOCKED`; lock age exceeds policy |
| **Inspect** | `python ai-sdlc/tools/orchestration/lock_registry.py --root . --inspect` |
| **Repair** | `python ai-sdlc/tools/orchestration/lock_registry.py --root . --recover-stale --lock-path <path> --dry-run` then `--write` if assessment passes |
| **Reapproval** | No if lock only; yes if interrupted authorized write |
| **Evidence** | lock-events.jsonl |
| **Unsafe** | Deleting lock files manually |

---

## Abandoned lock

| Field | Value |
| --- | --- |
| **Detection** | Lock holder process gone; lock-inspect shows orphan |
| **Inspect** | lock metadata, holder pid/lease |
| **Repair** | lock-recover after dry-run assessment |
| **Reapproval** | Per interrupted action type |
| **Evidence** | lock recovery audit |
| **Unsafe** | Force unlock without dry-run |

---

## Stale handoff

| Field | Value |
| --- | --- |
| **Detection** | `STALE_HANDOFF`, `EXECUTION_PLAN_DRIFT`, `HANDOFF_PLAN_DRIFT` |
| **Inspect** | governance/handoffs; plan hash in workflow state |
| **Repair** | `/sdlc-run ISSUE EXECUTE=0 MODE=diagnostic` → new handoff → `make ai-sdlc-confirm-handoff` |
| **Reapproval** | **Yes** — new handoff confirmation |
| **Evidence** | superseded handoff records |
| **Unsafe** | Implementing against unconsumed handoff |

---

## Amended requirement after authorization

| Field | Value |
| --- | --- |
| **Detection** | `STALE_ARTIFACT` after requirement/plan edit |
| **Inspect** | artifact digests vs authorization binding |
| **Repair** | `/requirement-revision` → re-groom/re-plan → new gates |
| **Reapproval** | **Yes** — full reauthorization path |
| **Evidence** | amendment log, revoked auth tokens |
| **Unsafe** | Keeping old IMPLEMENTATION_AUTHORIZED after plan change |

---

## Plan-hash mismatch

| Field | Value |
| --- | --- |
| **Detection** | `EXECUTION_PLAN_DRIFT`, `STALE_ARTIFACT` |
| **Inspect** | execution plan binding vs current plan.md hash |
| **Repair** | Regenerate execution plan; new handoff |
| **Reapproval** | **Yes** |
| **Evidence** | plan hash audit |
| **Unsafe** | Forcing implement with mismatched hash |

---

## Artifact-digest mismatch

| Field | Value |
| --- | --- |
| **Detection** | `STALE_ARTIFACT`, validation failures on artifact registry |
| **Inspect** | `make ai-sdlc-validate-artifacts ISSUE=<id>` |
| **Repair** | Refresh or revert artifact; `/sdlc-run ISSUE EXECUTE=0 MODE=diagnostic` |
| **Reapproval** | If artifact bound to authorization |
| **Evidence** | artifact registry entries |
| **Unsafe** | Editing artifact registry manually |

---

## Expired approval / waiver

| Field | Value |
| --- | --- |
| **Detection** | `GATE_DENIAL`; waiver TTL exceeded |
| **Inspect** | `make ai-sdlc-check-gates ISSUE=<id>` |
| **Repair** | New approve-gate or formal waiver per policy |
| **Reapproval** | **Yes** |
| **Evidence** | gate evidence with timestamps |
| **Unsafe** | Bypassing gate CLI |

---

## Failed migration

| Field | Value |
| --- | --- |
| **Detection** | workspace migration test failure; migration report errors |
| **Inspect** | `make ai-sdlc-migrate-workspace MODE=ASSESS ROOT=<ws> TARGET=4.0.0`; migration audit |
| **Repair** | `make ai-sdlc-rollback-workspace ROOT=<ws> BACKUP=<archive> DRY_RUN=1` when backup exists |
| **Reapproval** | **Yes** before re-attempt |
| **Evidence** | backup manifest, migration log |
| **Unsafe** | Running WRITE migration without backup |

---

## Rollback

| Field | Value |
| --- | --- |
| **Detection** | Operator or health report indicates inconsistent post-migration state |
| **Inspect** | backup path; rollback eligibility in migration report |
| **Repair** | `make ai-sdlc-rollback-workspace ROOT=<ws> BACKUP=<archive> WRITE=1` |
| **Reapproval** | Pilot owner + framework maintainer for workspace rollback |
| **Evidence** | rollback audit trail |
| **Unsafe** | git reset --hard on shared branches without evidence |

---

## Corrupted or missing workflow state

| Field | Value |
| --- | --- |
| **Detection** | Schema validation errors; load_workflow_state failure |
| **Inspect** | `make ai-sdlc-schema-check`; validate workflow-state YAML |
| **Repair** | `/sdlc-run ISSUE EXECUTE=0 MODE=diagnostic`; restore from audit export if available |
| **Reapproval** | Per stage being reconstructed |
| **Evidence** | audit export, lifecycle-events |
| **Unsafe** | Deleting and recreating state from memory |

---

## Release-integrity failure

| Field | Value |
| --- | --- |
| **Detection** | `RELEASE_INTEGRITY_FAILURE`; release-verify red |
| **Inspect** | `make ai-sdlc-release-verify` report |
| **Repair** | Restore framework tree to known good commit; re-run verify |
| **Reapproval** | Framework maintainer |
| **Evidence** | release verify JSON, checksum manifest |
| **Unsafe** | Disabling verify checks in pilot |

---

## Performance threshold failure

| Field | Value |
| --- | --- |
| **Detection** | performance tier test failure; CERT/PERF warnings |
| **Inspect** | `make ai-sdlc-performance-test` results |
| **Repair** | Investigate regression; update baselines only via controlled WRITE=1 process |
| **Reapproval** | Framework maintainer for baseline changes |
| **Evidence** | performance JSON artifacts |
| **Unsafe** | Ignoring certification performance gate |

---

## Escalation

Escalate to **Pilot Owner** and **Framework Maintainer** when repair fails twice, evidence is ambiguous, or any immediate-stop trigger in [`pilot-rollback-triggers.md`](pilot-rollback-triggers.md) applies.

Reason code lookup: [`reason-code-runbook.md`](reason-code-runbook.md).
