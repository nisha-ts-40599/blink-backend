# Requirement Grooming — Review Checklist

Use this checklist after running `clarify-requirement.prompt.md` and before saving
`requirement.md` or proceeding to `classify-work`.

**Full SOP:** [`requirement-grooming-sop.md`](requirement-grooming-sop.md)

---

## 1. Inputs and template

- [ ] Correct Jira issue / requirement text used
- [ ] `project-context.md` is current (`last_reviewed` not stale)
- [ ] Requirement type is correct (or inference documented)
- [ ] **Lite template** used for Tier 1 / docs / simple bugs; **full template** for Tier 2+ / production / security / migration / platform

## 2. Persona review summary

- [ ] **BA review:** business goal, scope, non-goals, and AC are clear
- [ ] **QA review:** AC are testable; test expectations and edge/regression risks noted
- [ ] **Domain review:** fits product model; domain questions captured (not invented)
- [ ] **Security/Data review:** completed if auth, data, infra, or compliance involved

## 2A. Code-informed bug checks (bugs in existing products)

- [ ] Agent performed **read-only code inspection** where repo access was available
- [ ] Findings tagged: Confirmed from code / Likely from code / Needs runtime verification / Needs PO/QA confirmation
- [ ] Likely causes labeled as **hypotheses**, not confirmed root cause
- [ ] Text flow diagram present (`UI → API → … → UI display`)
- [ ] Code-informed repro steps include UI path and API-level path where relevant
- [ ] Runtime verification checklist populated or marked pending
- [ ] Before/after API/UI captures requested (sanitized — no production PII)
- [ ] AC IDs present; test cases mapped (`TC-001 covers AC-001`) for Tier 2+ bugs
- [ ] Stakeholder/QA clarification pack separates code suggestions vs PO/QA vs runtime gaps
- [ ] **DoR remains blocked** if runtime evidence or PO confirmation is still missing
- [ ] classify-work **not** started until DoR validator passes

## 3. Acceptance criteria

- [ ] Each AC is testable and unambiguous
- [ ] AC IDs present (**AC-001**, **AC-002**) — required Tier 2+; recommended Tier 1
- [ ] Test cases reference AC IDs where applicable (`TC-001 covers AC-001`)
- [ ] Human-confirmed items marked (pending items listed)
- [ ] Non-goals documented where scope could creep

## 4. Open questions

- [ ] All blocking questions resolved **or** explicitly accepted with named owner
- [ ] No silent assumptions on stakeholder decisions

## 5. Data safety

- [ ] No secrets, tokens, credentials, or `.env.mcp` content
- [ ] No customer PII or production data
- [ ] Public references are pattern summaries with sources to verify

## 6. Definition of Ready

- [ ] DoR checklist in output is complete
- [ ] DoR status = **ready**
- [ ] DoR validator passes:

```bash
python ai-sdlc/tools/orchestration/validate_requirement_dor.py \
  --requirement ai-sdlc/workflow-state/{ISSUE-ID}/requirement.md
```

## 7. Grooming decision

- [ ] Decision = **Ready for classify-work**
- [ ] Recommended next prompt noted (usually `classify-work`)

## 8. Artifact and workflow state

- [ ] Saved to `ai-sdlc/workflow-state/{ISSUE-ID}/requirement.md`
- [ ] `artifacts.requirement_doc` updated in workflow-state YAML
- [ ] `agent_outputs.analyst_summary` recorded
- [ ] Grooming metrics captured (`grooming-metrics.yaml` from metrics template)

---

**Reviewer:** _______________ **Date:** _______________ **Issue ID:** _______________
