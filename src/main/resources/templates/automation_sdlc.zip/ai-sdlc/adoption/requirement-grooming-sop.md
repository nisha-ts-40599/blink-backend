# Requirement Grooming — Developer SOP

Practical guide for clarifying and grooming requirements with AI-SDLC before
`classify-work`. For a quick post-run check, use
[`requirement-grooming-review-checklist.md`](requirement-grooming-review-checklist.md).

**Related artifacts:**

| Resource | Path |
|----------|------|
| Clarify prompt | `ai-sdlc/prompts/clarify-requirement.prompt.md` |
| Full template (Tier 2+) | `ai-sdlc/templates/requirement-template.md` |
| Lite template (Tier 1) | `ai-sdlc/templates/requirement-template-lite.md` |
| Examples | `ai-sdlc/examples/requirements/` |
| BA/PO guide | `ai-sdlc/adoption/ba-po-requirement-grooming-guide.md` |
| DoR validator | `ai-sdlc/tools/orchestration/validate_requirement_dor.py` |
| Grooming metrics template | `ai-sdlc/templates/grooming-metrics-template.yaml` |
| Groomed requirement schema (optional) | `ai-sdlc/schemas/requirements/groomed-requirement.schema.json` |
| Data safety | `ai-sdlc/governance/public-reference-and-data-safety.md` |
| Input sources | `ai-sdlc/adoption/prompt-input-source-map.md` |

---

## 1. Purpose

Turn a raw Jira issue (or equivalent) into a **groomed requirement** that engineering,
QA, and product can agree on before tier classification and planning.

---

## 2. When to run clarify-requirement

Run for **every new work item** before `classify-work`, unless a valid groomed
`requirement.md` already exists for that issue.

Skip re-grooming only when the existing artifact is current and DoR-ready.

**Enterprise iterative workflow (Patch 4C — seamless slash-command flow):**

Preferred operator flow — Cursor slash commands guide most developers:

```text
/sdlc-start <ISSUE>                  # Guard, prep, and fetch issue context
/clarify-requirement <ISSUE>         # First-pass requirement normalization
                                     # → auto-chains extraction or prints mandatory next command
/requirement-grooming-status <ISSUE> # Check current state; get next correct prompt (use any time)
/grooming-stakeholder-pack <ISSUE>   # Generate stakeholder review pack (if needed)
/grooming-revision <ISSUE>           # Apply stakeholder feedback
                                     # → auto-chains DoR validation + stage router
/grooming-sign-off-capture <ISSUE>   # Prepare G-GROOM readiness summary
make ai-sdlc-approve-gate ROOT=<ROOT> ISSUE=<ISSUE> GATE=G-GROOM \
  APPROVER="<Full Name>:<email>" DECISION=approved \
  EVIDENCE_REF=".cursor/ai-sdlc/workflow-state/<ISSUE>/grooming-signoff-summary.md" \
  WRITE=1                            # Approve G-GROOM gate (human gate — do not self-approve)
# ── Phase 0 exit / Phase 1 entry ─────────────────────────────────────────
/classify-work <ISSUE>               # Phase 1 — Delivery Readiness begins here
```

**Key Patch 4C improvements:**
- `requirement-grooming-status` gives the next correct step at any time.
- `clarify-requirement` auto-chains extraction; no separate manual step needed.
- `grooming-revision` auto-chains DoR validation + stage router; reports next prompt.
- G-GROOM approval uses `make ai-sdlc-approve-gate ... GATE=G-GROOM ...` with prerequisite verification.
- Issue body is reused from `/tmp/<ISSUE>-issue-body.json` if valid — no duplicate API calls.
- Router primary reason does not mention `classify-work` while DoR or G-GROOM is blocking.
- Stored question text preserves inline code tokens, underscores, and API paths.
- **Grounding & Evidence Reviewer** is integrated into all Requirement Grooming prompts.
- Implementation remains blocked until Delivery Readiness and planning gates pass.

Make commands exist for CI and local automation; slash commands are the primary developer interface.

**Full Requirement Grooming detail (Patch 4C):**

```text
─── REQUIREMENT GROOMING PHASE ─────────────────────────────────────────────────
Goal: reach DoR=ready + G-GROOM approved (Tier 2+) before classify-work.
Human effort: stakeholder answers + gate approvals only.
Use slash commands by default; Make targets exist for CI/automation.

Step 1 — Guard and prep
  /sdlc-start <ISSUE-ID>
  OR (Make commands):
  make ai-sdlc-guard-framework-clean ROOT=<workspace-root>   # embedded: ROOT=..
  make ai-sdlc-groom-prep ROOT=<workspace-root> ISSUE=<ISSUE-ID>
    → checks /tmp/<ISSUE-ID>-issue-body.json first; reuses if valid (Patch 4C)
    → attempts env-based Jira fetch if no cached result
    → distinguishes: provider configured / credentials missing / body unavailable
    → generates context bundle for clarify-requirement

Step 2 — First-pass requirement normalization
  /clarify-requirement <ISSUE-ID>
    → saves requirement.md (lite for Tier 1, full for Tier 2+)
    → includes Grounding & Evidence Review before writing (Patch 4C)
    → IMMEDIATELY auto-runs or prints mandatory next command (Patch 4C):
      make ai-sdlc-extract-grooming-state ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
      (marks state: requirement_doc_created_but_state_extraction_pending if unavailable)
    → reports: ACs extracted, Qs extracted, inferred tier, G-GROOM auto-required if Tier 2+
    → does NOT write acceptance_criteria=[] when no ACs found (preserves state)

Step 3 — Check status (use any time; replaces manual router step)
  /requirement-grooming-status <ISSUE-ID>
  OR (with state refresh):
  make ai-sdlc-requirement-grooming-status ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
    → reads workflow-state, artifact presence, DoR, G-GROOM, tiers
    → determines next correct prompt
    → implementation allowed: NO (always in Requirement Grooming phase)

  Routing rules:
    → no requirement.md → clarify-requirement
    → extraction pending → extract-grooming-state
    → DoR not ready + no pack → grooming-stakeholder-pack
    → DoR not ready + pack + open Qs → grooming-revision
    → DoR ready, signoff missing → grooming-sign-off-capture
    → G-GROOM required, not approved → `make ai-sdlc-approve-gate ... GATE=G-GROOM ...` (human gate only)
    → DoR ready, G-GROOM approved → Phase 0 exit: `/classify-work <ISSUE>` (Phase 1 entry)

Step 4 — Role-based stakeholder review (Tier 2+ required; Tier 1 optional)
  /grooming-stakeholder-pack <ISSUE-ID>
    → generates stakeholder-pack.md (role-partitioned, blank answer slots)
    → includes Grounding & Evidence Review before writing (Patch 4C)
    → skips SDLC tooling questions if workspace config is already confirmed
    → register artifacts.grooming_stakeholder_pack + grooming.stakeholder_pack_generated_at
  → Distribute pack to relevant roles; collect answers (stakeholder effort only)

Step 5 — Apply stakeholder feedback
  /grooming-revision <ISSUE-ID>
    → applies feedback surgically to requirement.md (in-place, not full regeneration)
    → saves grooming-revision-N.md as revision record
    → includes Grounding & Evidence Review before writing (Patch 4C)
    → IMMEDIATELY auto-runs or prints mandatory validation chain (Patch 4C):
      make ai-sdlc-extract-grooming-state ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
      make ai-sdlc-validate-requirement-dor ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
      make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
    → reports: revision N, AC status, Q counts, DoR status, next prompt
  # Bulk-confirm all AC items after review:
  make ai-sdlc-update-ac ROOT=<workspace-root> ISSUE=<ISSUE-ID> AC_ID=ALL \
    CONFIRMED_BY="name@email" WRITE=1
  # Resolve open questions:
  make ai-sdlc-resolve-question ROOT=<workspace-root> ISSUE=<ISSUE-ID> \
    Q_ID=Q-001 RESOLUTION="Confirmed by PO" WRITE=1
  # Accept a question as deferred:
  make ai-sdlc-resolve-question ROOT=<workspace-root> ISSUE=<ISSUE-ID> \
    Q_ID=Q-002 ACCEPT=1 OWNER="name@email" WRITE=1

  Repeat steps 4–5 as needed until all blocking questions are resolved.

Step 6 — Grooming sign-off (required when g_groom.required=true; recommended for Tier 2+)
  /grooming-sign-off-capture <ISSUE-ID>
    → includes Grounding & Evidence Review (Step 3) before writing (Patch 4C)
    → saves grooming-signoff-summary.md
    → shows READY / NOT READY / CONDITIONAL readiness verdict
    → shows: "Total questions in workflow-state", Open, Resolved, Accepted/deferred, Blocking open
  → Present summary to designated approver (human effort only)

Step 7 — Approve G-GROOM gate (human gate only — do NOT self-approve)
  Canonical command:
  make ai-sdlc-approve-gate ROOT=<ROOT> ISSUE=<ISSUE> \
    GATE=G-GROOM APPROVER="<Full Name>:<email>" DECISION=approved \
    EVIDENCE_REF=".cursor/ai-sdlc/workflow-state/<ISSUE>/grooming-signoff-summary.md" \
    WRITE=1
    → verifies: g_groom.required=true, dor_status=ready, no blocking open Qs
    → records gate decision
    → runs stage router read-only and reports next prompt
  Legacy shortcut (backward compat):
  make ai-sdlc-approve-grooming ROOT=<ROOT> ISSUE=<ISSUE> \
    APPROVER="<Full Name>:<email>" DECISION=approved WRITE=1

Step 8 — Stage router confirms REQUIREMENT GROOMING phase complete
  make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
    → reason: "Requirement Grooming is complete. Start Delivery Readiness with classify-work."
    → next_prompt: classify-work.prompt.md
    → SDLC phase handoff: REQUIREMENT_GROOMING → DELIVERY_READINESS

─── DELIVERY READINESS PHASE ────────────────────────────────────────────────────
  classify-work, impact-analysis, create-spec, technical-plan are NOT implementation.
  They are Delivery Readiness / Pre-development planning steps.
  Product code must NOT be changed during this phase.

Step 11 — Classification
  /classify-work <ISSUE-ID>
    → saves classification.md
    → sets work_tier, work_type, work_subtype in workflow-state

Step 12 — Impact analysis (Tier 2+)
  /impact-analysis <ISSUE-ID>

Step 13 — Specification
  /create-spec <ISSUE-ID>
    → record spec_review_record (expected Tier 2+, required Tier 3+)

Step 14 — Technical plan
  make ai-sdlc-validate-pre-spec ROOT=<workspace-root> ISSUE=<ISSUE-ID>
  /technical-plan <ISSUE-ID>
  → G-PLAN required for Tier 2+ before implementation
  → capture grooming metrics (grooming-metrics-template.yaml)

─── IMPLEMENTATION PHASE ────────────────────────────────────────────────────────
  /implement-step, PR, review, merge, deploy (SDLC phase: IMPLEMENTATION)
  Product implementation starts only after Delivery Readiness and G-PLAN approval.
```

**G-GROOM auto-require for Tier 2+ work (Patch 4B):**
`make ai-sdlc-extract-grooming-state WRITE=1` automatically sets
`gates.g_groom.required: true` and `grooming.inferred_tier` when the requirement.md
contains a tier indicator (e.g. `Suggested work tier (draft) | 2`). You do not need to
manually edit the YAML for inferred Tier 2+ work. The stage router will then block
classify-work until G-GROOM is approved.

**Iterative loop guidance:**
- Use short commands (`make ai-sdlc-*`, `/grooming-*`) by default.
- Human effort is limited to: filling stakeholder answers, confirming ACs, approving gates.
- Simulated stakeholder feedback is permitted in pilot mode but must be labelled `[PILOT SIMULATION]`.
- The requirement phase must not modify product code; only framework and workspace artifacts.
- Repeat steps 5–8 until DoR = ready; extract-grooming-state re-runs are safe (idempotent).

**Approval roles:** Replace role-based placeholders in `project-config.yaml` with named
owners or team aliases before **Tier 2+** implementation. See
[`ba-po-requirement-grooming-guide.md`](ba-po-requirement-grooming-guide.md).

---

## 3. Minimum inputs

| Input | Source |
|-------|--------|
| `{{REQUIREMENT}}` | Jira MCP read or paste issue body + AC |
| `{{PROJECT_CONTEXT}}` | `ai-sdlc/project-context.md` |
| Workflow state file | `ai-sdlc/workflow-state/{ISSUE-ID}.yaml` |

**Recommended optional:** `{{REQUIREMENT_TYPE}}`, `{{REPOSITORY_CONTEXT}}` (read-only for bugs/enhancements).

---

## 4. How to choose requirement type

| Issue pattern | `{{REQUIREMENT_TYPE}}` |
|---------------|------------------------|
| Broken behavior, error, defect | Bug |
| Improve existing capability | Enhancement |
| New capability in existing product | New feature |
| Greenfield product | New product |
| Upgrade, replatform, migrate | Modernization/migration |
| Test framework, coverage, CI gates | QA/test automation |
| Infra, IaC, pipeline, platform | Cloud/devops/platform |
| Docs, prompts, process, tooling | Documentation/process/tooling |

If unsure, omit — the prompt will infer and list alternatives in open questions.

---

## 5. Full template vs lite template

| Use **lite** (`requirement-template-lite.md`) | Use **full** (`requirement-template.md`) |
|---------------------------------------------|------------------------------------------|
| Tier 1 (draft) | Tier 2+ (draft) |
| Documentation / process / tooling | Production-impacting changes |
| Simple bugs, low blast radius | Customer-facing features |
| Small internal config (non-prod) | Security, auth, data, compliance |
| Small QA additions (non-release-gating) | Migration, platform, infra, cross-repo |

**Rule:** If unsure, use the **full** template.

**Time budget:** Lite ~10 min; full ~20–30 min (plus stakeholder Q&A).

---

## 6. How BA / QA / domain persona review works

`clarify-requirement.prompt.md` applies **review lenses in one pass** — not separate
autonomous agents. The output includes a **Persona review summary**:

| Lens | Validates |
|------|-----------|
| **Business Analyst** | Goal, scope, non-goals, testable AC, stakeholder gaps |
| **QA Analyst** | Testability, repro/env gaps, edge/regression tests, DoR from QA view |
| **Domain SME** | Product fit, domain rules/constraints, domain questions (no invented rules) |
| **Security/Data** | Classification, auth, compliance, tier escalation (when applicable) |

Humans still own final decisions. Persona sections are **advisory summaries** for review.

---

## 7. How to handle bugs

1. Set `{{REQUIREMENT_TYPE}} = Bug`.
2. Treat one-line or vague reports as **incomplete by default** — do **not** stop at open
   questions only when repo access is available.
3. Use read-only repo context (`{{REPOSITORY_CONTEXT}}`, Filesystem MCP); do not fix code
   during grooming.
4. Do not accept root cause without runtime evidence, logs, DB/API state, or reproducible test.
5. Use **lite** for trivial internal bugs; **full** if production, payment, security, or
   cross-repo impact.
6. See examples:
   - `examples/requirements/bug-login-timeout.requirement.md`
   - `examples/requirements/bug-payment-dues-code-informed.requirement.md` (code-informed pattern)

### One-line bug grooming workflow

For one-line bugs in existing multi-repo products:

1. Read Jira issue (MCP or paste).
2. Treat one-line or vague reports as **incomplete by default**.
3. Run **read-only code analysis** if repo access is available — trace
   `UI → API → service/model → data → query/display`.
4. Tag findings: **Confirmed from code** | **Likely from code** | **Needs runtime verification** | **Needs PO/QA confirmation**.
5. Produce **code-backed reproduction steps** (UI path + API path + data prerequisites).
6. Produce **AC IDs** and **test cases** (`TC-001 covers AC-001`).
7. Produce **impact analysis inputs** (repos, modules, roles, payment/security/data impact).
8. Separate **code facts from assumptions** — hypotheses are not root cause.
9. Prepare **stakeholder/QA clarification pack** (code suggests vs PO/QA confirms vs runtime verifies).
10. **Keep DoR not ready** until runtime verification and PO answers are resolved or
    explicitly accepted.
11. Run DoR validator; then `/requirement-grooming-status <ISSUE>` — **only** run classify-work when DoR is ready and G-GROOM is approved.

Do not proceed to classify-work while DoR validator fails.

---

## 8. How to handle enhancements

1. Document **current** behavior before **expected** behavior.
2. Call out backward compatibility and regression scope.
3. BA lens: user pain and success metric; QA lens: regression tests on existing feature.
4. See example: `examples/requirements/enhancement-export-csv.requirement.md`.

---

## 9. How to handle new features / products

1. Separate **MVP** vs **later** scope and non-goals.
2. Use **full** template.
3. Note integrations, rollout/rollback if production-facing.
4. New product: consider `setup-new-project` or `setup-new-workspace` prompts first.
5. See example: `examples/requirements/feature-user-invite.requirement.md`.

---

## 10. How to handle modernization / migration

1. Use **full** template always.
2. Capture source/target, cutover, rollback, equivalence criteria.
3. Recommend **impact-analysis** before the **modernization lane** (Phase 2): assessment → discovery → target architecture → migration strategy → gate review → **technical-plan**.
4. Set `work_type` / `work_subtype` and `modernization.enabled: true` only for genuine migration scope — not normal bugs/features.
5. Default strategy: strangler fig, phased migration, modular monolith first — microservices/rewrite need explicit justification.
6. Phase 1 rollback support applies at merge readiness; Phase 3 cutover execution is out of scope.
7. See `adoption/modernization-lane-guide.md` and `examples/requirements/migration-replatform.requirement.md`.

---

## 11. How to handle QA / test automation

1. Clarify system under test, environments, CI integration, flake policy, ownership.
2. Do not assume Tier 1 if tests gate release or touch production data.
3. QA persona lens is primary for test expectations.
4. See example: `examples/requirements/qa-automation.requirement.md`.

---

## 12. How to handle platform / devops

1. Clarify IaC scope, secrets, blast radius, environments.
2. Use **full** template; expect Tier 2–4.
3. Security/Data lens required.
4. See example: `examples/requirements/platform-iac-change.requirement.md`.

---

## 13. How to use public references safely

Follow `ai-sdlc/governance/public-reference-and-data-safety.md`:

- Pattern summaries only; cite source names to verify by a human
- No competitor copy, copyrighted UI, customer data, or secrets
- Mark public-derived ideas as **assumption** until PO confirms

---

## 14. How to review generated output

Use [`requirement-grooming-review-checklist.md`](requirement-grooming-review-checklist.md).

Quick checks:

1. Requirement type correct?
2. Persona summaries complete?
3. AC testable and confirmed?
4. Open questions resolved or owned?
5. DoR = ready?
6. Grooming decision = **Ready for classify-work**?

Revise by re-running the prompt or editing in chat: *"Update requirement: resolve Q1 as …"*.

---

## 15. How to resolve open questions

1. Take §7/§20 open questions to PO, BA, SME, or security champion as needed.
2. Record resolutions in the requirement doc.
3. Update `agent_outputs.clarification_summary` in workflow state when resolved.
4. Do not proceed to classify-work with unresolved **blocking** questions.

---

## 16. Where to save output

```
ai-sdlc/workflow-state/{ISSUE-ID}/requirement.md
```

Create the `{ISSUE-ID}/` directory if it does not exist.

---

## 17. How to update workflow-state

```bash
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/{ISSUE-ID}.yaml \
  --add-artifact "requirement_doc=ai-sdlc/workflow-state/{ISSUE-ID}/requirement.md" \
  --add-agent-output "analyst_summary=<one-line summary>" \
  --write
```

Optional prep commands:

```bash
# Recommended — single command for grooming prep:
make ai-sdlc-groom-prep ISSUE={ISSUE-ID} TARGET_PROMPT=clarify-requirement

# Or run steps individually:
python ai-sdlc/tools/orchestration/context_prefill.py \
  --workflow-state ai-sdlc/workflow-state/{ISSUE-ID}.yaml \
  --target-prompt clarify-requirement

python ai-sdlc/tools/orchestration/build_context_bundle.py \
  --workflow-state ai-sdlc/workflow-state/{ISSUE-ID}.yaml \
  --project-context ai-sdlc/project-context.md \
  --project-config ai-sdlc/project-config.yaml \
  --target-agent "Requirement Analyst" \
  --target-prompt clarify-requirement \
  --output /tmp/{ISSUE-ID}-context.json
```

After saving `requirement.md`, refresh grooming state and check status:

```bash
make ai-sdlc-extract-grooming-state ROOT=<workspace-root> ISSUE={ISSUE-ID} WRITE=1
make ai-sdlc-validate-requirement-dor ROOT=<workspace-root> ISSUE={ISSUE-ID} WRITE=1
# /requirement-grooming-status {ISSUE-ID} — next step before classify-work
```

Capture pilot metrics manually — copy `templates/grooming-metrics-template.yaml` to
`workflow-state/{ISSUE-ID}/grooming-metrics.yaml` and fill in timestamps and counts.

---

## 18. When classify-work is allowed (Delivery Readiness gate)

Run `/classify-work <ISSUE>` **only when all of the following are true:**

- Grooming decision = **Ready for classify-work**
- DoR status = **ready** (`make ai-sdlc-validate-requirement-dor WRITE=1`)
- G-GROOM approved when required (`make ai-sdlc-approve-gate ... GATE=G-GROOM ...`)
- `/requirement-grooming-status <ISSUE>` confirms next prompt is classify-work (Phase 1 entry)

Then:

```
Use ai-sdlc/prompts/classify-work.prompt.md with:
{{REQUIREMENT}} = <requirement.md restatement + acceptance criteria>
{{PROJECT_CONTEXT}} = <project-context.md>
{{SECURITY_MODEL}} = <security section from context>
{{APPROVAL_RULES}} = <approval_rules from project-config.yaml>
```

After classification, **edit workflow-state YAML manually**:

- `work_tier: <1-4>`
- `current_stage: CLASSIFIED`
- `gates.g_plan.required: true` (Tier 2+)
- `gates.g_sec.required: true` (Tier 3+ or security-triggering)

Validate:

```bash
python ai-sdlc/tools/orchestration/validate_transition.py \
  --workflow-state ai-sdlc/workflow-state/{ISSUE-ID}.yaml \
  --target-state CLASSIFIED
```

---

## 19. Pre-spec readiness before technical-plan

After classification:

1. Run `impact-analysis.prompt.md` for Tier 2+ work. There is no separate
   `IMPACT_ANALYSIS` workflow stage; this happens while the issue is `CLASSIFIED`.
2. Run `create-spec.prompt.md` using the adaptive spec shape:
   - **Bug-fix** shape for defects and regressions.
   - **Feature/enhancement** shape for product capability changes.
   - **Spike/investigation** shape when technical planning should wait for a decision.
3. Save `specification.md` and update `artifacts.spec_doc`.
4. Record `spec_review_record` using `templates/spec-review-record-template.md`.
   - Tier 1: optional/advisory.
   - Tier 2+: expected before technical-plan.
   - Tier 3+ or security/data-sensitive: required by `validate_pre_spec_bundle.py`.
5. Validate handoff readiness:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<issue-id>
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<issue-id>
make ai-sdlc-validate-pre-spec ROOT=<workspace-root> ISSUE=<issue-id>
```

Proceed to `technical-plan.prompt.md` only when `validate-pre-spec` is `PASS`, or when
a Tier 2 `WARN` / `CONDITIONAL` result has explicit human acceptance. Implementation
details, step ordering, and code design belong in `technical-plan.prompt.md`, not the spec.

Traceability expectation: adaptive specs use `FR-xxx` requirements mapped to `AC-xxx`
acceptance criteria. If `create-issues.prompt.md` is used later, issue drafts should
reference the relevant `FR-xxx` and `AC-xxx` IDs.

---

## 20. Definition of Ready checklist

A requirement is ready when:

- [ ] Clear summary and outcome
- [ ] Testable AC with **AC-001** style IDs (required Tier 2+; recommended Tier 1)
- [ ] Test cases reference AC IDs where possible (`TC-001 covers AC-001`)
- [ ] Non-goals documented (or explicitly none)
- [ ] Test expectations stated
- [ ] Open questions resolved or explicitly accepted with owner
- [ ] Persona review summary complete
- [ ] DoR status in artifact = **ready**
- [ ] Grooming decision = **Ready for classify-work**
- [ ] DoR validator passes (`validate_requirement_dor.py`)
- [ ] No secrets or unsanitized production data in artifact
- [ ] Grooming metrics captured for pilot (optional YAML sidecar)

---

## 21. Developer checklist (end-to-end)

**REQUIREMENT GROOMING PHASE**
- [ ] Issue selected; workflow-state YAML created (`make ai-sdlc-sdlc-start`)
- [ ] `make ai-sdlc-groom-prep ISSUE=<ISSUE-ID>` run (or manual prefill + bundle)
- [ ] Issue body read (MCP or paste)
- [ ] `/clarify-requirement` run with project context (+ type if known)
- [ ] `requirement.md` saved under `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/`
- [ ] `make ai-sdlc-extract-grooming-state WRITE=1` run — AC and Q extracted, tier inferred
- [ ] Stage router checked — framework guides to next step
- [ ] Stakeholder-pack generated and distributed (Tier 2+; skip if Tier 1 and no open Qs)
- [ ] Stakeholder answers collected and `/grooming-revision` applied (if needed)
- [ ] `make ai-sdlc-extract-grooming-state WRITE=1` re-run after revision (if artifacts changed)
- [ ] AC items confirmed (`AC_ID=ALL` or individually)
- [ ] Blocking questions resolved or accepted with owner
- [ ] DoR validator passed (`make ai-sdlc-validate-requirement-dor WRITE=1`)
- [ ] `grooming-signoff-summary.md` generated (`/grooming-sign-off-capture`)
- [ ] G-GROOM gate approved (Tier 2+; `make ai-sdlc-approve-gate GATE=G-GROOM`)
- [ ] `grooming_signoff_summary` artifact registered
- [ ] Stage router confirms: `safe_to_proceed: YES`, `next_prompt: classify-work.prompt.md` (Phase 0 exit)

**DELIVERY READINESS PHASE — Phase 1** (not implementation)
- [ ] `/classify-work <ISSUE>` run (Phase 1 entry); tier confirmed; `work_tier`, `CLASSIFIED` set in YAML
- [ ] Transition validated (`make ai-sdlc-validate-transition`)
- [ ] `impact-analysis` run for Tier 2+
- [ ] Adaptive `specification.md` saved and `spec_doc` recorded
- [ ] `spec_review_record` recorded when expected by tier/work type
- [ ] `make ai-sdlc-validate-pre-spec` passed (or Tier 2 conditional result explicitly accepted)
- [ ] `technical-plan` run; G-PLAN gate set for Tier 2+
- [ ] Grooming metrics captured (`grooming-metrics.yaml`)

---

## Role quick reference

| Role | Primary action in grooming |
|------|---------------------------|
| **Developer** | Run prompt, save artifact, update workflow state |
| **Engineering lead** | Confirm tier after classify-work; gate approver |
| **BA / PO** | Answer open questions; confirm AC and scope |
| **QA** | Review test expectations and persona QA summary |
| **Security champion** | Review Security/Data lens for sensitive work |
