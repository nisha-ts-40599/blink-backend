# Requirement storage guide

## Canonical locations

- Snapshots: `.cursor/ai-sdlc/intake/requirements/`
- Provenance: `.cursor/ai-sdlc/intake/requirement-sources/`

## Workspace root `requirements/`

The framework must **not** create a permanent root-level `requirements/` directory during setup.

When a framework-generated root copy exists and matches the canonical snapshot (SHA-256):

1. Update references to the canonical path.
2. Produce a cleanup plan (`integration/requirement_cleanup.py`).
3. Remove the root copy only with explicit approval.

When checksums differ → classify **CONFLICTING** and preserve both until resolved.

## Workflow-state

Derived work-item folders reference canonical source ID, snapshot path, hash, revision, and scope — they do not embed full BRDs by default.

See [issue publication guide](issue-publication-guide.md).
