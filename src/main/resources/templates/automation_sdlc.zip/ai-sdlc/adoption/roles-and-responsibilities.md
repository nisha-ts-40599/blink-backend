# Roles and Responsibilities

Define these roles before adoption to avoid approval or ownership ambiguity.

## Engineering Manager

- Owns team adoption scope and rollout timeline.
- Approves operating model changes for delivery process.
- Ensures staffing for reviewer/security/release responsibilities.
- Reviews adoption KPIs (lead time, conformance, defects).

## Tech Lead

- Owns technical quality bar and workflow applicability.
- Approves tier classification strategy for the team.
- Reviews AI-generated plans/specs before implementation.
- Escalates architectural risk and unresolved ambiguity.

## Developer

- Executes workflow steps and maintains artifact traceability.
- Uses prompts/templates consistently.
- Keeps tests and docs aligned with code changes.
- Flags uncertain requirements for clarification, not assumption.

## Reviewer

- Performs human PR review per governance policy.
- Verifies AI review findings are addressed or dispositioned.
- Blocks merge when gates, tests, or traceability are incomplete.
- Confirms risky changes have required approvals.

## Security Reviewer

- Reviews Tier 3/4 and security-impacting changes.
- Validates scanner findings and exception rationale.
- Approves/denies security-related gates.
- Owns escalation for high-risk security decisions.

## Release Manager

- Owns release-readiness and post-release verification workflow execution.
- Confirms rollback baseline exists before deployment approval.
- Coordinates go/no-go decision evidence.
- Verifies production approvals and release audit trail completeness.

## Platform Owner

- Maintains `ai-sdlc` framework integration in CI/tooling.
- Owns conformance runner and policy execution reliability.
- Curates templates/prompts/workflows with versioning discipline.
- Provides enablement and troubleshooting for project teams.

