# Rollback Policy Guide

Generic AI-SDLC guidance for **rollback planning** at merge readiness (Phase 1).

## Purpose

A **rollback plan** documents how to revert a change if post-deploy validation fails. It is **not** rollback execution. Humans approve and execute rollback.

Phase 1 enforces rollback **before merge readiness** for Tier 3+ and sensitive work — not before implementation for normal bugs/features.

## Configuration

Add or customize in `project-config.yaml`:

```yaml
rollback_policy:
  enabled: true
  required_by_tier:
    tier_1: optional
    tier_2: recommended
    tier_3: required
    tier_4: required_with_approval
  required_for_work_types:
    - payment
    - security
    - production_bugfix
  enforcement:
    tier_1: off
    tier_2: warn
    tier_3: block
    tier_4: block
  sensitive_enforcement: block
```

Set `rollback_policy.enabled: false` to disable enforcement (not recommended for production).

## Tier behavior

| Tier | Default enforcement | Merge blocked without rollback_plan? |
|------|---------------------|--------------------------------------|
| 1 | off | No |
| 2 | warn | No (warning only) |
| 3 | block | **Yes** |
| 4 | block | **Yes** |

## Sensitive work (below Tier 3)

When `risk_profile` includes `payment_sensitive`, `sensitive_data`, or `pii_adjacent`, or when `work_type` matches `required_for_work_types`, rollback is **required** even at Tier 1–2 (`sensitive_enforcement: block`).

## Rollback plan vs rollback execution

| Artifact / state | When | Who owns |
|------------------|------|----------|
| `rollback-plan.md` | Before merge readiness (Tier 3+) | Engineer + approvers review |
| `rollback.approved` | Human sign-off on plan | Engineering lead / SRE |
| `rollback.executed` | After incident or failed deploy | On-call / release owner |
| `rollback.validation_status` | After rollback run | QA + engineering |

## Workflow-state fields

```yaml
artifacts:
  rollback_plan: ".cursor/ai-sdlc/workflow-state/<ISSUE>/rollback-plan.md"

rollback:
  required: true
  status: draft
  type: git_revert
  owner: "Engineering Lead"
  approved: false
  executed: false
  validation_status: not_run
  data_cleanup_required: false
  data_cleanup_approved: false
```

## Data cleanup caveat

If rollback may require **production data cleanup** (partial writes, dual-write backfill, payment ledger correction), the plan must document cleanup steps and name approvers. `data_cleanup_approved` must be set by a human before executing cleanup.

Types requiring explicit human approval (from config):

- Database restore
- Production data cleanup
- Identity or auth rollback
- Payment data correction
- Customer-facing cutover reversal

## Prompts and tools

| Resource | Use |
|----------|-----|
| `rollback-plan.prompt.md` | Author rollback plan before merge |
| `merge-readiness.prompt.md` | Verify rollback_plan present |
| `make ai-sdlc-rollback-check ISSUE=...` | Read-only validator |
| `make ai-sdlc-stage-router ISSUE=...` | Shows `rollback_required` / `rollback_satisfied` |

## Related docs

- `adoption/implementation-evidence-lifecycle.md`
- `adoption/current-product-rollback-example.md`
- `governance/approval-gates.md` (G-REL-PROD rollback owner)
- `ai-sdlc/work-tiers.md`

## Phase 2+ (not yet enforced)

Modernization cutover rollback readiness (`G-ROLLBACK`) and post-migration validation are Phase 3 — see [cutover-readiness-guide.md](cutover-readiness-guide.md). Rollback **readiness** is distinct from rollback **execution**.
