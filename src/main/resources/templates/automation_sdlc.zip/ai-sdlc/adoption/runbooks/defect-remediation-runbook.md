# Defect Remediation Runbook

Concise loop for handling QA-found defects. Full reference:
`ai-sdlc/adoption/enterprise-dev-qa-pipeline.md`.

## Loop

1. `/sdlc-triage-defects` — triage each defect. Defects must be linked to the
   failing QA execution; P0/P1 defects block merge.
2. Fix in code via `/sdlc-implement` (developer side). This produces a new commit
   and marks downstream evidence `STALE`.
3. `/sdlc-qa-retest` — retest the fixed defect. The retest **binds to the fix
   commit**; a unit-only retest does not satisfy a QA-found defect.
4. `/sdlc-qa-regression` — run regression if the change or strategy requires it;
   record execution results (scope must match the analyzed scope).
5. Return to `/sdlc-qa-signoff-review` once defects are resolved and retest /
   regression pass.

## Guardrails

- A retest bound to the wrong (or stale) commit does not count.
- Open P0/P1 defects block G-PR-MERGE.
- Re-run developer tests / validation after the fix (they went `STALE`).

## Check status

```bash
make ai-sdlc-enterprise-progress ROOT=. ISSUE=<ISSUE>
make ai-sdlc-stage-router ROOT=. ISSUE=<ISSUE>
```
