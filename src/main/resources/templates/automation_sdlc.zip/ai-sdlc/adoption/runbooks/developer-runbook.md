# Developer Runbook

Concise operator steps for the developer side of the enterprise pipeline. Full
reference: `ai-sdlc/adoption/enterprise-dev-qa-pipeline.md`.

## Preconditions

- G-PLAN approved; the approved plan exists and is bound to the target repo.
- Working tree clean; you are on the feature branch.

## Steps

1. `/sdlc-implement-prep` — build the implementation package (binds plan hash +
   repo + G-PLAN). Blocked if G-PLAN is missing, the plan hash is stale, the
   repo mismatches, the tree is dirty, or risks are unresolved.
2. `/sdlc-plan-implementation-step` — plan the next step.
3. `/sdlc-implement` — make the change; record the change record. Declare every
   touched file and any dependency change. The change record is git-verified;
   undeclared files or material deviations are rejected.
4. `/sdlc-developer-test` — record **real** command results (no fabricated
   pass). A PASS with a nonzero exit code is rejected.
5. `/sdlc-ai-developer-review` — advisory AI review. This is **not** an
   attestation.
6. `/sdlc-developer-attest` — **human** developer attestation. Required before
   validation counts.
7. `/sdlc-validate` — validation evidence from real command results.

## Guardrails

- Any new commit invalidates developer tests, AI review, attestation, and
  validation (they go `STALE`) — re-earn them.
- Never use AI review in place of the human attestation.

## After each step

```bash
make ai-sdlc-stage-router ROOT=. ISSUE=<ISSUE>
```

to confirm the next authoritative action, then hand off to QA / PR runbooks.
