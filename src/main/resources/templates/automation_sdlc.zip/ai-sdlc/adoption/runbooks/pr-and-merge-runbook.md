# PR & Merge Runbook

Concise operator steps from draft PR through verified merge and closure. Full
reference: `ai-sdlc/adoption/enterprise-dev-qa-pipeline.md`.

## Steps

1. `/sdlc-register-draft-pr` — register the draft PR after validation passes.
2. `/sdlc-peer-review` — request peer review; resolve blocking findings with
   `/sdlc-fix-review-findings`.
3. `/sdlc-register-pr` — register the **formal provider PR**. A `LOCAL_UNPUSHED`
   candidate is not a provider PR; push and register before merge gating.
   Use `/sdlc-refresh-pr` when the PR is `STALE` after new commits.
4. `/sdlc-pr-review` — formal PR review. `CHANGES_REQUESTED` routes to
   `/sdlc-fix-review-findings`.
5. `/sdlc-approve-merge` — approves **G-PR-MERGE** via
   `make ai-sdlc-approve-gate GATE=G-PR-MERGE`.
6. `/sdlc-verify-merge` — verify the provider-side merge. An unverified merge
   blocks closure.
7. `/sdlc-post-deploy-validate` — post-deploy validation (if deployed).
8. `/sdlc-close` — closure via `make ai-sdlc-generate-closure-report` /
   `make ai-sdlc-close-merge`.

## Merge gating guardrails

Merge is blocked when any of these hold:

- An open **P0/P1** finding or defect exists.
- Required QA sign-off (G-QA-POST) is missing when QA is required.
- The candidate is still `LOCAL_UNPUSHED` (no provider PR).
- PR head has drifted from the reviewed/attested commit (downstream evidence is
  `STALE`).

Provider merge verification is required before closure; do not close on an
unverified merge.

## Registering / refreshing PRs

```bash
make ai-sdlc-register-pr ROOT=. ISSUE=<ISSUE>
make ai-sdlc-stage-router ROOT=. ISSUE=<ISSUE>
```
