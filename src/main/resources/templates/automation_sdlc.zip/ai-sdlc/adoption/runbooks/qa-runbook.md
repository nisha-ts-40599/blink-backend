# QA Runbook

Concise operator steps for the QA side of the enterprise pipeline. Full
reference: `ai-sdlc/adoption/enterprise-dev-qa-pipeline.md`.

## Planning-side (during technical planning)

1. `/sdlc-qa-requirement-analysis` — resolve QA questions. Unresolved questions
   block G-PLAN.
2. `/sdlc-qa-strategy` — strategy scaled to tier; Tier 3 requires a **standalone**
   strategy.
3. `/sdlc-design-tests` — build the test suite. Every acceptance criterion must
   map to at least one test; negative and boundary coverage is required; a
   missing test-data owner is rejected.
4. `/sdlc-regression-analysis` — define regression scope (if required).

## Execution-side (after implementation)

5. `/sdlc-qa-environment-ready` — confirm environment. Not-ready blocks; do not
   record credentials in readiness evidence.
6. `/sdlc-qa-smoke` — smoke evidence; a failed smoke blocks; a PASS requires the
   recorded checks.
7. `/sdlc-qa-execute` — **human tester** executes. A PASS without a tester or an
   AI tester is rejected; `NOT_EXECUTED` can never roll up to PASS.
8. `/sdlc-qa-signoff-review` — sign-off recommendation.
9. `/sdlc-approve-qa` — approves **G-QA-POST** via
   `make ai-sdlc-approve-gate GATE=G-QA-POST`. QA cannot approve its own gate by
   editing execution status.

## Guardrails

- QA never modifies source.
- Applicability (`qa_post_required`) depends on tier / risk — some phases will
  correctly project `NOT_REQUIRED`.
- Any new commit invalidates QA execution and G-QA-POST (`STALE`).
- A `CONFLICTING` QA state always routes back to `/sdlc-qa-execute`.

## Defects

If execution fails, follow `defect-remediation-runbook.md`.

## After each step

```bash
make ai-sdlc-stage-router ROOT=. ISSUE=<ISSUE>
```
