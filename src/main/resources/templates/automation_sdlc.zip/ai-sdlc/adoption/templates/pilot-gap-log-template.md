# Phase C Gap Log Template

Use this template during the Phase C adoption pilot. Add one row per observed gap, confusion point, blocker, or recovery action.

Use generic examples in reusable materials: `DEMO-ISSUE-1`, `demo-app`, and `https://example.test/...`. Keep real pilot evidence in the product workspace.

## Severity Values

- `blocker`: pilot cannot proceed safely.
- `high`: pilot proceeds only with a workaround or facilitator support.
- `medium`: should be addressed before broader rollout.
- `low`: minor documentation, training, or polish issue.

## Type Values

- `docs`
- `command_ux`
- `validation`
- `workflow`
- `training`
- `policy`

## Gap Log

| id | date | phase | command | severity | type | observed_behavior | expected_behavior | evidence_ref | workaround | recommended_action | owner | status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GAP-001 | YYYY-MM-DD | Phase C | `ai-sdlc-register-pr` | medium | command_ux | Example observation | Example expectation | `https://example.test/evidence/1` | Example workaround | Example recommendation | Example owner | open |

## Status Values

- `open`
- `triaged`
- `in_progress`
- `deferred`
- `resolved`
- `wont_fix`

## Notes

- Link evidence using generic or product-workspace-safe references.
- Do not paste real client secrets, private repository URLs, or internal workspace paths into framework docs.
- Prefer concrete command output snippets over broad summaries.
- Mark deferred feature requests clearly so Phase C does not expand beyond pilot preparation and feedback collection.
