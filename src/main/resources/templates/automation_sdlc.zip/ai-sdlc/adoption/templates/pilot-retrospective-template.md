# Phase C Pilot Retrospective Template

Use this template after one real low-risk issue has been run through the Phase B command spine. Keep reusable notes generic and keep real pilot evidence in the product workspace.

Generic examples may use `DEMO-ISSUE-1`, `demo-app`, and `https://example.test/...`.

## Pilot Issue Summary

- Issue ID:
- Issue title:
- Work type:
- Repository ID:
- Pilot date range:
- Requester/product owner:
- Engineering lead:
- PR reviewer/maintainer:
- Security reviewer, if required:
- Pilot observer/scribe:
- Closure report reference:

## What Worked

- 

## What Failed Or Confused Users

- 

## Command UX Gaps

| command | gap | impact | suggested_follow_up |
| --- | --- | --- | --- |
| `ai-sdlc-init-issue` |  |  |  |
| `ai-sdlc-register-artifact` |  |  |  |
| `ai-sdlc-transition` |  |  |  |
| `ai-sdlc-approve-gate` |  |  |  |
| `ai-sdlc-register-pr` |  |  |  |
| `ai-sdlc-close-merge` |  |  |  |
| `ai-sdlc-generate-closure-report` |  |  |  |

## Documentation Gaps

- 

## Governance Gaps

- Were human approvers clear before the pilot?
- Were approval evidence references reviewable?
- Were conditional approvals handled correctly?
- Was PR registration kept separate from PR approval?
- Was merge closure kept separate from deployment readiness?
- Did anyone expect the framework to close an issue tracker ticket or deploy automatically?

## Manual Interventions

Document any manual workflow-state edits or controlled recovery steps.

| intervention | reason | risk | follow_up |
| --- | --- | --- | --- |
|  |  |  |  |

## Closure Report Findings

- Overall closure status:
- Lifecycle warnings:
- Readiness blockers:
- Missing artifacts:
- Missing or invalid gates:
- PR evidence findings:
- Merge evidence findings:
- Deployment readiness notes:
- Recommended next actions:

## Rollout Recommendation

Choose one:

- `ready_for_next_pilot`
- `ready_for_limited_team_rollout`
- `needs_docs_fixes_first`
- `needs_command_ux_fixes_first`
- `not_ready`

Recommendation rationale:

- 

## Deferred Roadmap Items

Use this section for items that should not be implemented during Phase C pilot preparation.

| item | reason_deferred | suggested_phase | owner |
| --- | --- | --- | --- |
| GitHub/API integration | Out of scope for Phase C | Later roadmap |  |
| Deployment automation | Out of scope for Phase C | Later roadmap |  |
| Issue tracker closure | Out of scope for Phase C | Later roadmap |  |

## Final Notes

- 
