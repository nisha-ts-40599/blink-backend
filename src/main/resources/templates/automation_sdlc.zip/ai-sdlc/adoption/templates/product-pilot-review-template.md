# AI-SDLC Product Pilot Review

## Pilot scope

<!-- Pilot ID, issue ID, stage (A/B), repository mode, lane -->

## Framework revision

<!-- Pinned commit, branch, phase, installation digest -->

## Product revision

<!-- Base branch, pilot branch, product commit at closure -->

## Issue

<!-- Business summary, acceptance criteria count, pilot issue criteria fit -->

## Lane and slices

<!-- Lane, slice count, task count, amendments -->

## Timeline

<!-- Key checkpoints P0–P7 with timestamps -->

## Operator metrics

<!-- sdlc_run, sdlc_answer, route corrections, recaptures, human decisions -->

## Delivery metrics

<!-- AC verified, tests added/passed, defects, reopened slices -->

## Routing findings

<!-- Corrections, UNKNOWN routes, authoritative command anomalies -->

## Evidence findings

<!-- Stale evidence, lost evidence, duplicate lifecycle events -->

## Decision findings

<!-- Structured decision staleness, replay conflicts -->

## Recovery events

<!-- Transaction recovery, blocked actions -->

## Product-quality findings

<!-- Pre-PR defects, QA defects, test baseline -->

## Framework defects

<!-- Defects filed against automation_sdlc with evidence -->

## Required fixes

<!-- Blocking fixes before merge recommendation -->

## Merge recommendation

<!-- READY_FOR_MAIN | READY_AFTER_FIXES | REPEAT_PILOT | NOT_READY -->

**Note:** Do not recommend merging based only on Stage A (FINAL_PRE_PR_READY).
