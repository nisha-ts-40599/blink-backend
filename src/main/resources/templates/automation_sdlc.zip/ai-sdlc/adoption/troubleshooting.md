# Troubleshooting Guide

Quick fixes for the most common issues when using AI-SDLC locally and in CI.

**Grooming and prompt inputs:** [`developer-grooming-quick-guide.md`](developer-grooming-quick-guide.md) · [`prompt-input-source-map.md`](prompt-input-source-map.md)

---

## Local tooling

### `make ai-sdlc-install` fails

| Symptom | Cause | Fix |
|---------|-------|-----|
| `python3: command not found` | Python 3.10+ not installed | Install Python 3.10+ via Homebrew (`brew install python`) or pyenv |
| `venv` creation fails on restricted system | Missing write access to `.venv-ai-sdlc` | Run in a directory where you have write access; check disk space |
| `pip install` times out | No network access | Confirm internet connectivity; or pre-install packages manually |

---

### `make ai-sdlc-lint` fails

| Symptom | Cause | Fix |
|---------|-------|-----|
| `yamllint: wrong indentation` | Tabs used instead of 2-space indent in a YAML file | Open the reported file and replace tabs with 2 spaces |
| `yamllint: too many spaces` | Extra whitespace before a colon in YAML | Remove trailing spaces; use a YAML-aware editor |
| `yamllint: duplication of key` | Duplicate key in a YAML mapping | Find and remove the duplicate key |
| File not found error | YAML lint target refers to a file that was moved or renamed | Update the file path in the `Makefile` `ai-sdlc-lint` target |

---

### `make ai-sdlc-prompt-check` fails

| Symptom | Cause | Fix |
|---------|-------|-----|
| `MISSING placeholder: {{PLACEHOLDER_NAME}} in prompt file` | A prompt uses a placeholder not in `prompt-placeholder-catalog.md` | Either add the placeholder to the catalog (with a clear definition), or rename the placeholder in the prompt to match a registered one |
| `prompt file missing required structure: output section` | Prompt file has no `## Expected output` or `## Output` heading | Add an output format section to the prompt |
| `prompt file missing human-ownership language` | Prompt does not contain human-action language | Add a `## Human action required` section or equivalent |

---

### `make ai-sdlc-conformance-protected` fails

| Symptom | Cause | Fix |
|---------|-------|-----|
| `OPA not found at ai-sdlc/tools/bin/opa` | OPA binary not installed | Run `make ai-sdlc-install-opa` or `bash ai-sdlc/tools/install-opa.sh` |
| `Schema validation failed for test dev-schema-{name}` | Sample input no longer matches its schema | Compare `ai-sdlc/tests/sample-inputs/{test}.json` against the schema at `ai-sdlc/schemas/`; update the sample to match |
| `Policy test failed` | A Rego policy evaluation returned unexpected output | Run `opa eval` on the failing policy with the test input to debug; see `ai-sdlc/policies/` |
| `Expected PASSED but got FAILED` | A conformance test returned an error | Read the full error in the output; check the input file for issues |

---

### `make ai-sdlc-context-bundle-example` fails

| Symptom | Cause | Fix |
|---------|-------|-----|
| `workflow-state file not found` | Example workflow-state YAML missing or renamed | Ensure `ai-sdlc/examples/workflow-state/patient-registration.workflow-state.yaml` exists |
| `project-context file not found` | Example project context missing | Ensure `ai-sdlc/examples/project-context/patient-registration.project-context.md` exists |
| `SCHEMA VALIDATION ERRORS` | Generated bundle does not match `context-bundle.schema.json` | Check the error field reported; usually caused by a null value where the schema requires a string |
| `PyYAML not found` | venv not activated or install incomplete | Run `make ai-sdlc-install` first |

---

### Context bundle generation fails on your own project

| Symptom | Cause | Fix |
|---------|-------|-----|
| `ERROR: workflow-state file not found` | Wrong path supplied | Check that `--workflow-state` points to your actual `ai-sdlc/workflow-state/{ISSUE}.yaml` |
| `WARNING: last_reviewed not found` | `project-context.md` missing `**Last reviewed:** YYYY-MM-DD` | Add the `Last reviewed` line to your `project-context.md` header |
| `Safe to proceed: NO — G-PLAN approval required but not recorded` | `gates.g_plan.approved: false` in workflow state despite approval having been given | Update `ai-sdlc/workflow-state/{ISSUE}.yaml` with the approval details (approver, approved_at, comment_url) |
| `[BLOCKING] project-context.md is stale` | `last_reviewed` date is > 90 days ago | Update `project-context.md` with current information and update `last_reviewed` |

---

## Framework drift guard fails (product SDLC)

The guard (`make ai-sdlc-guard-framework-clean`) detects **uncommitted changes to framework-owned files** during product delivery. Overlay changes under `.cursor/ai-sdlc/**` and normal product repo source changes are allowed.

| Symptom | Cause | Fix |
|---------|-------|-----|
| Guard exits 1 with list of framework paths | Uncommitted edits under the embedded framework repo or protected `ai-sdlc/**` paths | **Stop** the workflow step. Do **not** patch framework files during product delivery. Revert accidental framework edits or stash them for framework maintainers. |
| Guard fails after groom-prep | Same as above — groom-prep runs the guard automatically in product mode | Resolve framework drift before continuing to clarify-requirement or classify-work |
| Guard passes but agent edited framework files | Guard only checks git porcelain status at checkpoint time | Re-run the guard; revert framework edits; file a framework gap report if a framework change is truly needed |
| Need to change framework prompts/tools intentionally | Framework development work | Use `FRAMEWORK_DEV=1 make ai-sdlc-guard-framework-clean` **only** during explicit framework maintenance — not during product issue delivery |

### If the guard fails — do this

1. **Stop** — do not continue classify, plan, implement, or review steps.
2. **Do not patch** framework files to unblock product work.
3. **Produce a framework gap report** (format in `ai-sdlc/governance/framework-protection-rule.md`).
4. Continue only after a generic framework fix is shipped and the project updates framework version, or an approved **safe project-level workaround** exists.
5. Do **not** set `FRAMEWORK_DEV=1` to bypass the guard during normal product delivery.

**Embedded workspace** (run from framework repo directory):

```bash
make ai-sdlc-guard-framework-clean ROOT=..
```

**Standalone framework repo:**

```bash
make ai-sdlc-guard-framework-clean
```

See also: `ai-sdlc/adoption/framework-guard-checkpoints.md`.

---

## Stage router says `safe_to_proceed = no`

This is intentional behaviour — the router has found a blocking condition.
Read the `Blockers` section of the output carefully.

| Blocker message | What to do |
|----------------|-----------|
| `G-PLAN approval required but not recorded` | Get the engineering lead to post an explicit approval comment on the GitHub issue, then update `workflow-state.yaml` |
| `project-context.md is stale (>90 days)` | Update `project-context.md` and set a current `**Last reviewed:**` date |
| `plan_doc artifact is missing` | Run `technical-plan.prompt.md` and save the output to `ai-sdlc/workflow-state/{ISSUE}/technical-plan.md`, then update `artifacts.plan_doc` in workflow-state |
| `Active blocker recorded` | The workflow-state `blocked_reasons` field has an entry — resolve the listed blocker and clear the field |

---

## GitHub MCP

### MCP not working in Cursor

| Symptom | Cause | Fix |
|---------|-------|-----|
| Cursor says "no MCP tools available" | `.cursor/mcp.json` not found or malformed | Check that `.cursor/mcp.json` exists and is valid JSON; restart Cursor |
| "Bad credentials" or 401 error | PAT expired or invalid | Rotate the PAT; replace in `.cursor/mcp.json`; restart Cursor |
| "Resource not accessible" | PAT lacks permissions for the requested resource | Check PAT permissions match the table in `mcp/github-readonly-setup.md`; regenerate if needed |
| MCP returns wrong repo data | PAT scoped to wrong repo | Regenerate PAT scoped to the correct repository |
| Cursor can read issues but not files | PAT missing `Contents` permission | Regenerate PAT with `Contents: Read` |

### Write-block test — MCP has write access (unexpected)

If the safety test at `adoption/mcp-setup-checklist.md` shows that Cursor created an issue, act immediately:

1. Delete the accidentally created issue.
2. Revoke the PAT immediately at `https://github.com/settings/tokens`.
3. Regenerate a new fine-grained PAT with read-only permissions only.
4. Replace in `.cursor/mcp.json` and restart Cursor.
5. Re-run the write-block test.

---

## GitHub Actions

### CI jobs do not appear in branch protection "status checks" dropdown

GitHub only shows checks that have run at least once on the repository.

**Fix:**
1. Ensure `.github/workflows/ai-sdlc-conformance.yml` is committed and pushed to `main`.
2. Open a test PR or push directly to a non-protected branch.
3. Wait for the workflow to run (even if it fails).
4. Go to Settings → Branches → branch protection rule → search for the check name.

Check names to add (exactly as shown in GitHub Actions):
- `AI-SDLC Conformance`
- `Secret Scan (Gitleaks)`
- `Dependency Audit (pip-audit)`

### CI job passes locally but fails in GitHub Actions

| Symptom | Cause | Fix |
|---------|-------|-----|
| OPA not found in CI | OPA binary not pre-installed on runner | The workflow installs OPA via `install-opa.sh`; check the install step logs |
| `requirements.txt` not found | Wrong path in `pip-audit` step | Verify the `requirements.txt` path in `ai-sdlc-conformance.yml` matches your repo structure |
| Gitleaks fails on first run | Previous commits contain secrets | Review Gitleaks output carefully; if a secret was committed historically, rotate it immediately and follow your incident process |

### `Dependency Audit (pip-audit)` fails

| Symptom | Cause | Fix |
|---------|-------|-----|
| Known CVE in a framework dependency | A dependency in `requirements.txt` has a published CVE | Upgrade the dependency to a patched version; run `pip-audit` locally to confirm |
| False positive | pip-audit flagged a CVE that does not apply | Document the exception in `project-config.yaml` with the justification; do not simply suppress the check |

---

## Prompt errors

### AI output is missing key sections

The most common cause is that the `{{PROJECT_CONTEXT}}` placeholder was not fully populated, or was truncated. The AI falls back to generic advice when context is absent.

**Fix:** Ensure `project-context.md` is complete with: tech stack, architecture, security model, conventions, and coding standards. If you are not using the context aggregator, paste the full file content as `{{PROJECT_CONTEXT}}`.

### AI recommends skipping a gate

If AI output suggests skipping a gate (e.g., "you can proceed without G-PLAN since this is a minor change"), do not follow this advice.

**Fix:** The work tiers and gates are defined in `ai-sdlc/work-tiers.md` and `governance/approval-gates.md`. Follow the tier the classifier assigned. If in doubt, escalate to the engineering lead, not to the AI.

### `check_prompt_structure.py` reports a false positive on your new prompt

If you have created a custom prompt and the structure check fails:

**Fix:** Ensure the prompt file contains:
1. A `## Instructions` or equivalent instruction section
2. A `## Required placeholders` or `## Inputs` section
3. An `## Expected output` or `## Output` section
4. A `## Human action required` or equivalent human-ownership section

---

## Context prefill tool (`context_prefill.py`)

### `ERROR: issue_id mismatch`

The `issue_id` in your prefill-input JSON does not match the workflow state.

**Fix:** Open the prefill-input file and confirm the `issue_id` field matches the workflow state exactly (case-sensitive). Do not share a prefill-input file between different work items.

### `ERROR: prefill input failed schema validation — values: Additional properties are not allowed ('G_PLAN' was unexpected)`

A gate field was included in the `values` block of the prefill input.

**Fix:** Remove `G_PLAN`, `G_SEC`, `G_PR_MERGE`, and `G_DEPLOY` from the `values` section. These are human approval gates and must never be auto-filled. Record them separately with `update_workflow_state.py --add-approval`.

### `ERROR: prefill input contains empty values`

One or more values in the prefill-input file are empty strings or whitespace.

**Fix:** Either fill in the value from your Cursor MCP query, or delete the key from the `values` object. Empty fields are rejected to prevent prompts from receiving blank context.

### `ERROR: prefill input file not found`

The `--import` path does not exist.

**Fix:** Ensure the path is correct. Run the report mode with `--emit-template /tmp/issue-prefill-input.json` first to create the template, then fill it.

### Prefill report shows unknown prompt / all fields listed

If `target_prompt` is not a recognised prompt name, the report shows all MCP-readable fields rather than the focused set.

**Fix:** Use the exact prompt filename without `.prompt.md` — e.g. `clarify-requirement`, `implement-step`, `pr-review`. Check `ai-sdlc/adoption/prompt-quick-reference.md` for the full list.

---

## Stale context warning in context bundle

The context aggregator calculates days since `project-context.md` was last reviewed.

| Status | Days since reviewed | Action |
|--------|--------------------|----|
| `current` | 0–30 | No action needed |
| `review_recommended` | 31–60 | Review context at next sprint planning |
| `review_required` | 61–90 | Update context before starting any new feature |
| `stale` | >90 | **Blocking.** Update context before any agent invocation |

To update: open `project-context.md`, verify each section still accurately reflects the project, update any stale sections, and set `**Last reviewed:** YYYY-MM-DD` to today's date.

---

## Stage router and artifact validation

### `make ai-sdlc-stage-router` reports `Safe to proceed: NO`

| Symptom | Cause | Fix |
|---------|-------|-----|
| Workflow state not found | Missing `.cursor/ai-sdlc/workflow-state/{ISSUE-ID}/{ISSUE-ID}.yaml` | Create workflow state from template |
| Missing gates | G-PLAN or G-SEC not recorded for tier | Record gate approval in workflow-state before advancing |
| Blocked stage | `blocked_reasons` populated | Resolve blockers and clear the list |

The CLI is read-only — it recommends the next prompt but never executes workflow actions.

### `make ai-sdlc-validate-artifacts` returns FAIL

| Symptom | Cause | Fix |
|---------|-------|-----|
| Missing required artifact keys | Workflow-state `artifacts` section incomplete | Add references for required keys before transitioning |
| Missing local files | Path in workflow-state does not exist on disk | Save the artifact file or update the path |
| WARN only | Recommended artifacts missing | Optional — add when available |

The validator never infers artifact presence from filenames alone; only explicit workflow-state references are checked.

### Cursor slash commands do not appear after typing `/`

Run:

```bash
make ai-sdlc-install-cursor-commands ROOT=<workspace-root>
```

For embedded framework layout:

```bash
make ai-sdlc-install-cursor-commands ROOT=..
```

Then reload or reopen Cursor if needed.

Slash commands are workspace-local files under `.cursor/commands/`. They are copied from the framework repo during setup — canonical prompt logic remains in `ai-sdlc/prompts/`.

### Setup prompt inspected the workspace but created no files

This means it ran in **discovery mode** (the default). To create files, reply:

```text
confirm setup
```

or rerun:

```text
/setup-existing-workspace apply
```

Use the matching setup slash command for your case (`/setup-existing-project`, `/setup-new-workspace`, etc.).

### Workspace changed after initial setup

Run setup in **refresh mode** instead of deleting `.cursor/ai-sdlc/**`.

Example:

```text
Run ai-sdlc/prompts/setup-existing-workspace.prompt.md in refresh mode.
```

Or:

```text
/setup-existing-workspace refresh
```

The prompt compares current workspace discovery with the existing overlay and proposes safe updates. Human-owned fields and workflow-state artifacts are preserved unless you explicitly confirm changes. Use **reset mode** only when you intend to archive and recreate config from scratch.
