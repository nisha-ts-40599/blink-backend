# When Not To Use AI Automation

AI automation should be intentionally constrained in high-risk and ambiguous areas.

## Always require explicit human decision

- Production database schema/data changes with irreversible impact.
- Destructive infrastructure operations (delete/replace core infrastructure).
- Legal, regulatory, or contractual interpretation and decisions.
- Credential rotation and secrets lifecycle operations.
- High-risk security changes (authentication model, encryption, access control).
- Ambiguous requirements with unresolved business or safety implications.

## Additional caution cases

- Emergency incidents where incomplete context may cause harmful automation.
- Cross-system changes with unknown blast radius.
- Work requiring external stakeholder sign-off not represented in tooling.

## Control policy

- Keep these actions in `restricted_tools` or `destructive_tools`.
- Require gate approvals and named approvers.
- Require auditable decision records before execution.
- Treat AI output as draft recommendation, not final authority.

## Escalation guidance

- If requirement ambiguity blocks safe automation, pause and escalate.
- If policy and delivery pressure conflict, policy wins; escalate to platform/security leadership.
- If evidence is incomplete, do not proceed automatically.

