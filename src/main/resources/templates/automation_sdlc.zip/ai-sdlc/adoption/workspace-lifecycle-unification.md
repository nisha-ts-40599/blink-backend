# Workspace lifecycle unification

Greenfield (`/setup-new-workspace`, `/setup-new-project`) and existing (`/setup-existing-workspace onboard`, `refresh`) are **lifecycle states of one project**, not separate document models. Both flows read and update the same canonical control plane under `.cursor/ai-sdlc/`.

## Canonical lifecycle states

| State | Meaning |
| --- | --- |
| `NEW_UNINITIALISED` | No setup-state / overlay not started |
| `NEW_DISCOVERED` | Discovery in progress |
| `NEW_PLANNED` | G-PLAN / spec planning |
| `NEW_BOOTSTRAPPED` | Bootstrap execution |
| `GREENFIELD_CONTEXT_READY` | Overlay valid; topology/bootstrap not started — Phase 0 grooming |
| `FIRST_IMPLEMENTATION_IN_PROGRESS` | First delivery in flight |
| `FIRST_IMPLEMENTATION_COMPLETE` | First merge + validation pending transition |
| `EXISTING_MANAGED` | Ongoing maintenance via existing refresh |
| `TRANSITION_BLOCKED` | Transition gates failed |
| `RECOVERY_REQUIRED` | Legacy or incomplete control metadata |

Authoritative files:

- `lifecycle-state.yaml` — canonical high-level state
- `setup-state.yaml` — detailed bootstrap and readiness
- `workspace-manifest.yaml` — roster, framework binding, control plane

## Workspace-control repository

Multi-repo production workspaces should version `.cursor/ai-sdlc` as a **workspace-control Git repository** (portable, non-secret). Single-repo MVPs may embed the control plane in the product repository when explicitly configured (`control_plane.mode: embedded-single-repo` in the greenfield spec).

Managed bootstrap (after **G-BOOTSTRAP**) plans and executes control-plane actions automatically: control remote creation (provider-gated), in-place Git init, manifest write/validate, product `.ai-sdlc-workspace.yaml` pointers (before initial product commit), manifest reconciliation, and evidence in `scaffold-records/workspace-control-bootstrap-evidence.yaml`. See the bootstrap action table in `managed-local-bootstrap-execution.md`.

Product repositories carry `.ai-sdlc-workspace.yaml` pointing back to the control plane (no duplicated workspace state).

## Distribution (second developer)

```bash
mkdir <workspace> && cd <workspace>
git clone <framework-repository-url> <framework-checkout-path>
mkdir -p .cursor
git clone <workspace-control-repository-url> .cursor/ai-sdlc
make -C <framework-checkout-path> ai-sdlc-onboard-existing ROOT="$PWD"
```

## Transition

After first validated implementation:

```bash
make ai-sdlc-finalize-greenfield-transition ROOT=<workspace> WRITE=1
```

## Migration (pre-contract workspaces)

```bash
make ai-sdlc-migrate-workspace-control-plane ROOT=<workspace>
make ai-sdlc-migrate-workspace-control-plane ROOT=<workspace> WRITE=1
```

Legacy evidence is preserved; uncertain values are marked `UNVERIFIED`. Initializing or pushing a control repository requires explicit confirmation.

## Role overlays

Role-specific guidance remains under `.cursor/ai-sdlc/roles/` and does not alter lifecycle neutrality.

## Secrets

Control plane artifacts store **environment variable names only**, never tokens, passwords, or `.env.mcp`.

See also: `interactive-greenfield-setup.md`, `setup-existing-workspace.prompt.md`, `manual-bootstrap-reconciliation.md`.
