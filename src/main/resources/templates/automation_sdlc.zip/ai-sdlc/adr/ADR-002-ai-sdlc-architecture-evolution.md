# ADR-002: AI-SDLC Architecture Evolution — Prompt-Triggered to Multi-Agent ACP-Orchestrated Platform

## Status

Proposed

## Date

2026-06-16

## Context

The AI-SDLC framework was designed from the ground up with a governed, AI-assisted SDLC as its target. As of June 2026, the framework is at **Maturity Level 1** (per `governance/automation-maturity-model.md`):

- 22 structured prompts covering the full SDLC lifecycle are operational.
- Automated CI quality gates (schema validation, OPA policies, YAML lint, prompt catalog, prompt structure lint, Gitleaks, pip-audit) are operational.
- Human approval gates (G-PLAN, G-SEC, G-PR-MERGE, G-DEPLOY) are defined with SLAs and escalation paths.
- All prompts are **manually triggered by engineers**. There is no event-driven automation, no agent-to-agent communication, no state machine, and no orchestrator.

A dedicated architecture document (`acp/acp-agent-topology.md`) already describes the target multi-agent topology, flagged `STATUS: FUTURE`. Handoff contract definitions exist in `acp/acp-handoff-contracts.md`. Agent role definitions exist in `agents.md`. These documents represent intended future-state design that is not yet operational.

This ADR captures the architectural decision to evolve the framework from its current prompt-triggered, human-run state to an enterprise-governed, MCP-connected, ACP-orchestrated, multi-agent AI-SDLC — and explicitly records the principles and constraints that must govern that evolution.

### Forces driving the decision

1. **Context-assembly cost**: Engineers manually fill 8–12 placeholders per prompt invocation. This is the primary friction in the current workflow. MCP-connected agents resolve this.
2. **Sequential workflow bottlenecks**: Multi-step workflows (requirement → plan → implement → test → review) require manual handoff between each stage. A state machine and stage router resolve this.
3. **Inconsistent gate adherence**: Without tooling to check gate preconditions, engineers occasionally skip steps under delivery pressure. A gate checker script enforces preconditions automatically.
4. **Reactive rather than event-driven**: Security alerts (CVE), PR events, and deployment events require engineers to notice and manually trigger the appropriate prompt. Event-driven agent invocation resolves this.
5. **Specialization**: A single context window attempting to perform requirement analysis, security review, implementation, and monitoring interpretation simultaneously produces lower-quality output than specialized agents with focused context. Multi-agent specialization resolves this.

---

## Decision

**Adopt a phased, governance-first evolution from a prompt-triggered framework to an enterprise-governed, MCP-connected, ACP-orchestrated, multi-agent AI-SDLC.**

The evolution is constrained by these binding architectural principles:

### Principle 1 — Human gates are permanent, not provisional

The four human approval gates (G-PLAN, G-SEC, G-PR-MERGE, G-DEPLOY) are permanent governance boundaries. They are not limitations of current technology. No automation path removes them. No maturity level bypasses them. Each gate requires a written approval record by a named human before the next stage begins.

In addition, the following actions are permanently human-controlled at every maturity level:

- Merge to any protected branch
- Production deployment (execution of G-DEPLOY)
- Rollback decisions during incidents
- Incident declaration and severity classification
- PII handling, data deletion, and anonymisation execution
- Secret rotation and key ceremonies
- Vendor and third-party API enablement
- Security finding waivers
- Tier override (downgrade from Tier 3+)
- External customer-facing communications

See `governance/human-in-the-loop-policy.md` for the authoritative list and rationale.

### Principle 2 — Orchestrator routes but does not decide

The Orchestrator's role is coordination, not decision-making. It reads current workflow state, checks gate preconditions, routes work to the appropriate specialist agent, and surfaces human interrupt requirements. It does not:

- Make product or architectural decisions
- Approve any governance gate
- Merge code to any branch
- Deploy to any environment
- Override tier classifications
- Resolve conflicts between agent outputs

The Orchestrator is a routing engine with a state machine. Decision authority remains with humans.

### Principle 3 — Multi-agent specialization over single super-agent

A single agent attempting to perform requirement analysis, security review, implementation, test generation, and monitoring interpretation simultaneously accumulates context bias and produces inconsistent quality. Specialization is required for three reasons:

1. **Focus**: Each specialized agent loads only the context relevant to its role, improving output quality and reducing hallucination risk.
2. **Trust calibration**: Different agents warrant different levels of autonomy. The Security Agent is permanently advisory. The Coder Agent may eventually get feature-branch write access. These trust levels cannot be cleanly isolated in a single super-agent.
3. **Failure isolation**: A failure in the Reviewer Agent does not corrupt the Coder Agent's context. Specialist agents fail independently and can be retried without restarting the full workflow.

The 12 agent roles and their prompt mappings are defined in `agents.md` and detailed in `architecture/multi-agent-evolution-roadmap.md`.

### Principle 4 — Write access is branch-scoped and incremental

No agent receives write access to protected branches at any maturity level. Write access is granted incrementally:

- Level 2: Coder Agent may write to feature branches only, after G-PLAN is recorded.
- Level 2: Docs Agent may write documentation and changelog files to feature branches.
- Level 3: Orchestrator may write workflow state files to a designated `ai-sdlc/workflow-state/` path.
- Level 4: Narrowly approved bot may merge a specific, policy-defined class of change (internal docs, dependency patches meeting SCA rules) — requires formal governance exception.

### Principle 5 — MCP access before automation

No event-driven automation is introduced for any stage until the corresponding read-only MCP access is operational and validated. Automation with incomplete context produces lower-quality output than manual invocation with complete context. The read-path (MCP + context aggregator) is built before the write-path (event triggers + automated invocation).

### Principle 6 — ACP handoff contracts gate advancement between agents

Stage advancement between any two agents requires a validated ACP handoff contract. The contract defines the typed input, the typed output, the required artifacts, and the gate condition (human approval or quality check). An agent may not begin work without receiving a valid contract from its predecessor. The canonical contract envelope is defined in `acp/acp-handoff-contracts.md`.

---

## Target Architecture

The target is an enterprise-governed, MCP-connected, ACP-orchestrated, multi-agent AI-SDLC.

### Architecture layers

```
┌─────────────────────────────────────────────────────────────┐
│  Human approval layer                                        │
│  G-PLAN · G-SEC · G-PR-MERGE · G-DEPLOY · Tier overrides   │
└──────────────────────────┬──────────────────────────────────┘
                           │ interrupt / resume
┌──────────────────────────▼──────────────────────────────────┐
│  Orchestrator                                                │
│  State machine · Stage router · Gate checker                 │
│  Artifact linker · Context aggregator                        │
└──────┬──────────┬──────────┬──────────┬──────────┬──────────┘
       │          │          │          │          │
  ┌────▼───┐ ┌───▼────┐ ┌───▼────┐ ┌───▼────┐ ┌───▼────┐
  │Analyst │ │Planner │ │ Coder  │ │Reviewer│ │Security│  ...
  └────┬───┘ └───┬────┘ └───┬────┘ └───┬────┘ └───┬────┘
       │         │          │          │          │
┌──────▼─────────▼──────────▼──────────▼──────────▼──────────┐
│  MCP read access                                             │
│  GitHub · Jira · Observability · OSV/GHSA · Code search     │
└─────────────────────────────────────────────────────────────┘
```

### Maturity levels (from `governance/automation-maturity-model.md`)

| Level | Name | Current readiness | Target gate |
|-------|------|------------------|-------------|
| Level 1 | Prompt-assisted SDLC | **85%** — operational | Pilot 02 now |
| Level 2 | MCP-connected + CI-enforced | 30% | Activate GitHub Actions + MCP in Week 1 |
| Level 3 | ACP-orchestrated workflow | 5% (design exists, no runtime) | After Level 2 is stable for 2+ sprints |
| Level 4 | Semi-autonomous select paths | 0% | Formal governance exception required |

---

## Alternatives Considered

| Alternative | Pros | Cons | Outcome |
|-------------|------|------|---------|
| Single super-agent with full SDLC context | Simpler to deploy initially; one context window | Context pollution; inconsistent quality; trust calibration impossible; single point of failure; harder to audit specific agent outputs | Rejected — see Principle 3 |
| Autonomous merge for low-tier changes (Level 4 shortcut) | Reduced merge friction for doc-only PRs | Removes human accountability; requires Level 3 operational stability as prerequisite; sets a precedent that erodes gate discipline | Deferred to Level 4 with formal governance exception requirement |
| Implement ACP runtime immediately | Establishes full orchestration sooner | ACP runtime complexity introduces new failure modes before the simpler prompt-triggered path is validated; "Level 0 to Level 3" jump skips measurable evidence collection | Deferred — build the state machine and contracts first; runtime is added at Level 3 |
| Use an off-the-shelf multi-agent framework (LangGraph, AutoGen, CrewAI) | Faster initial setup; existing tooling | Creates a hard external dependency for a governance-critical workflow; opaque failure modes; licensing and data handling risk for enterprise use | Deferred — evaluate after MVO is proven; off-the-shelf frameworks may wrap the MVO, not replace it |
| Add write MCP before read MCP is validated | Faster automation path | Write automation with incomplete or stale context produces incorrect changes and erodes trust; read path must be validated first | Rejected — violates Principle 5 |

---

## Consequences

**Positive:**
- Clear evolution path from today's operational Level 1 to a governed Level 3 architecture.
- Phased approach means each level delivers measurable value before the next begins.
- Governance principles are captured as binding constraints before any automation is built, preventing governance gaps introduced under delivery pressure.
- Existing `acp/`, `agents.md`, and `governance/automation-maturity-model.md` documents are formally anchored to an ADR, not left as undated design sketches.
- Human approval gates remain non-negotiable at every level — audit and compliance obligations are preserved.

**Negative / trade-offs:**
- Level 3 architecture requires significant investment: ACP runtime, event bus or webhook infrastructure, per-agent context management, write-access governance controls. This is not a small change.
- Phased approach means teams working at Level 1 will continue to perform manual context assembly for 60–90 days before the context aggregator reduces that burden.
- Multi-agent specialization introduces coordination overhead. An MVO bug or state file corruption affects more workflow stages than a single broken prompt.

**Operational:**
- Level 2 prerequisite: GitHub Actions must run at least once; branch protection must be configured; per-engineer GitHub PAT must be issued.
- All Level 3+ changes require an updated ADR or an addendum to this ADR.
- Advancement between maturity levels requires meeting the criteria in `governance/automation-maturity-model.md` — evidence of gate adherence, audit log completeness, and incident retrospective data.
- The engineering lead and security champion must review this ADR before any Level 3 implementation begins.

---

## What is Deferred

The following are explicitly deferred and must not be implemented until the specified prerequisites are met:

| Item | Prerequisite before building |
|------|------------------------------|
| ACP runtime service (inter-agent message passing over a live transport) | Level 2 fully operational; MVO proven in pilot; dedicated ADR for runtime choice |
| Multi-agent orchestrator service (deployed, persistent) | ACP runtime stable; 2+ sprints at Level 3 without incident |
| Write MCP for any agent | Read MCP validated per agent; branch-scoped write policy reviewed by security champion |
| Autonomous merge of any PR class | Level 4 advancement criteria met; formal governance exception approved; dedicated ADR |
| Autonomous production deployment | Not planned at any maturity level; governance exception process would be required |
| Figma / design-to-spec agent | Level 2 stable; design MCP evaluated; dedicated prompt and contract defined |
| Jira write access (issue creation, status transitions) | Jira read MCP validated; write scope formally bounded and reviewed |

---

## Compliance and Security Notes

- This ADR does not change the current MCP posture. No new tool access is granted by accepting this ADR.
- Any Level 2+ implementation that adds agent write access must be reviewed against `governance/enterprise-engineering-guardrails.md` and `governance/human-in-the-loop-policy.md`.
- Write-access grants for any agent require a security champion review at the time of implementation.
- Audit logging requirements for all agent actions are defined in `governance/audit-log-requirements.md` and must be met before any Level 3+ automation is activated.
- ACP handoff contracts must include an `audit_metadata` block per the schema in `acp/acp-handoff-contracts.md`.

---

## References

- Agent model: `ai-sdlc/agents.md`
- ACP topology (future state): `ai-sdlc/acp/acp-agent-topology.md`
- ACP handoff contracts: `ai-sdlc/acp/acp-handoff-contracts.md`
- ACP workflow example: `ai-sdlc/acp/acp-workflow-example.md`
- Automation maturity model: `ai-sdlc/governance/automation-maturity-model.md`
- Human-in-the-loop policy: `ai-sdlc/governance/human-in-the-loop-policy.md`
- Enterprise engineering guardrails: `ai-sdlc/governance/enterprise-engineering-guardrails.md`
- Approval gates and SLAs: `ai-sdlc/governance/approval-gates.md`
- Audit log requirements: `ai-sdlc/governance/audit-log-requirements.md`
- Implementation roadmap: `ai-sdlc/architecture/multi-agent-evolution-roadmap.md`
- ADR template: `ai-sdlc/templates/adr-template.md`
- Supersedes: none (first ADR for multi-agent evolution)
- Related: ADR-001 (if exists — framework adoption decision)
