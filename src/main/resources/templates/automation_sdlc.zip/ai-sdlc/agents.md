# Agent Model

This document defines **logical agents** in the AI-SDLC operating model. Implementations may map each agent to a dedicated runtime profile, a single model with role prompts, or human operators using the same templates and checklists. All agents must respect `governance/human-in-the-loop-policy.md`, `mcp/mcp-permissions.md`, and project `approval_rules`.

## Conventions

- **Inputs / outputs** use abstract artifacts (documents, issues, handoff objects). See `acp/acp-handoff-contracts.md` for structured envelopes.
- **Allowed actions** are permitted under default MCP posture; **restricted actions** require human execution or break-glass process.
- **Handoff rules** name the successor agent and minimum payload.

---

## Orchestrator Agent

**Responsibility:** Coordinate lifecycle stages, enforce tier-appropriate gates, route work, and aggregate status for humans.

**Inputs:** `project-config`, active workflow stage, issue identifiers, prior handoff objects, CI and scan summaries.

**Outputs:** Stage transitions, task assignments, escalation notices, consolidated readiness reports.

**Allowed actions:** Read issues and PRs; comment with status; trigger read-only CI or test report retrieval; request human approval; enqueue sub-agent tasks (implementation, review) within policy.

**Restricted actions:** Merge; deploy; delete branches; modify production; rotate secrets; alter IAM or infra.

**Handoff rules:** Delegates to specialist agents with a `Handoff` object (see ACP). Accepts completion `Handoff` objects and updates the workflow record.

---

## Requirement Agent

**Responsibility:** Intake raw requirements, structure them, drive clarification, and prepare material for classification and specification.

**Inputs:** Raw notes, tickets, meeting summaries, `{{REQUIREMENT}}`, `{{PROJECT_CONTEXT}}`.

**Outputs:** Normalized requirement document (see `templates/requirement-template.md`), open questions list, proposed acceptance criteria.

**Allowed actions:** Create or update draft issues/docs in permitted spaces; suggest classifications; link related issues.

**Restricted actions:** Binding commitments on delivery dates without human confirmation; creating production resources.

**Handoff rules:** To **Orchestrator** or **Documentation Agent** with requirement doc + questions; to classification step with pointers to `work-tiers.md`.

---

## Documentation Agent

**Responsibility:** Maintain specifications, ADRs, runbooks, and user-facing docs consistent with implemented behavior.

**Inputs:** Approved specs or deltas, PR diffs, `{{REPOSITORY_CONTEXT}}`, doc platform metadata from config.

**Outputs:** Updated pages or markdown PRs; new ADRs when decisions are durable (`templates/adr-template.md`).

**Allowed actions:** Propose doc edits via PR or wiki draft API within MCP allowlist; cross-link issues and ADRs.

**Restricted actions:** Publishing to externally binding compliance portals without human publish approval if required by org.

**Handoff rules:** To **Knowledge Update Agent** after release with changelog and verification pointers.

---

## Issue Agent

**Responsibility:** Decompose work into tracker issues with clear acceptance criteria, labels, and tier hints.

**Inputs:** Specification excerpts, requirement doc, `{{ACCEPTANCE_CRITERIA}}`, tracker field definitions.

**Outputs:** Parent/child issues, linking, initial estimates (as hints only unless human-approved).

**Allowed actions:** Create/update issues per MCP allowlist; add labels; link PRs when instructed.

**Restricted actions:** Closing issues as “Done” without evidence (CI, review, DoD); modifying sprint commitments if that is human-owned in the org.

**Handoff rules:** To **Repo Analysis Agent** or **Planning Agent** with issue IDs and scope boundaries.

---

## Repo Analysis Agent

**Responsibility:** Map repository structure, ownership boundaries, hotspots, and dependency graph relevant to a change.

**Inputs:** Clone or read-only repo access, issue scope, `{{REPOSITORY_CONTEXT}}`.

**Outputs:** Impact sketch, affected modules, suggested test targets, risk callouts.

**Allowed actions:** Read and search repository; read dependency manifests; read CI configuration; open draft notes on PRs if allowed.

**Restricted actions:** Pushing commits without human or policy-approved automation token scoped to non-protected workflows.

**Handoff rules:** To **Planning Agent** with structured impact summary referencing `templates/impact-analysis-template.md`.

---

## Planning Agent

**Responsibility:** Produce executable technical plans: steps, interfaces, migration order, test strategy, rollback.

**Inputs:** Impact analysis, spec, tier, `{{SECURITY_MODEL}}`, `{{APPROVAL_RULES}}`.

**Outputs:** `technical-plan` artifact; optional test plan draft (`templates/test-plan-template.md`).

**Allowed actions:** Author planning docs; propose branch naming; suggest reviewers.

**Restricted actions:** Approving its own plan for Tier 3+; scheduling production changes.

**Handoff rules:** After human gate (when required), to **Implementation Agent** with approved plan version identifier.

---

## Implementation Agent

**Responsibility:** Apply stepwise code and config changes on a branch following the approved plan.

**Inputs:** Approved technical plan, issue, repository state, coding standards from config or repo.

**Outputs:** Commits or proposed patches, step completion notes, self-review checklist.

**Allowed actions:** Create feature branch; commit to non-protected branches; open PR; run local or CI-permitted tests.

**Restricted actions:** Direct push to default branch; merge; bypass reviews; production configuration edits outside sandbox.

**Handoff rules:** To **Test Agent** and **Review Agent** with PR URL and summary of deviations from plan.

---

## Test Agent

**Responsibility:** Generate, extend, or refine tests; interpret failing tests; align coverage with tier expectations.

**Inputs:** Plan, code diff, `{{TECH_STACK}}`, existing test suites.

**Outputs:** Test code changes, test plan updates, coverage notes.

**Allowed actions:** Add tests on the same branch; trigger CI test jobs if MCP allows.

**Restricted actions:** Disabling tests or skipping security checks without documented approval.

**Handoff rules:** Back to **Implementation Agent** for fixes, or to **Review Agent** when green locally / in CI sandbox.

---

## Review Agent

**Responsibility:** Perform structured AI code review for correctness, maintainability, security smell, and policy alignment.

**Inputs:** PR diff, linked issue, `templates/ai-review-template.md`, prior self-review from implementer.

**Outputs:** Review comments categorized (must-fix vs advisory); summary risk statement.

**Allowed actions:** Post review comments; suggest patches as text or follow-up commits if permitted.

**Restricted actions:** Approving or merging PRs; dismissing required human review threads.

**Handoff rules:** To **Implementation Agent** for fixes; to humans for final approval per `governance/approval-gates.md`.

---

## Security Agent

**Responsibility:** Interpret SAST/SCA/secret scan results; assess threat model deltas; flag tier and approval needs.

**Inputs:** Scan outputs, diff, `{{SECURITY_MODEL}}`, data classification from config.

**Outputs:** Security assessment addendum; escalation when Tier 4 triggers hit.

**Allowed actions:** Read scan artifacts; annotate issues/PRs; request additional analysis tasks.

**Restricted actions:** Waiving findings; altering WAF or IAM in production.

**Handoff rules:** To **Orchestrator** for escalation; to **Planning Agent** if design must change before implementation continues.

---

## Release Agent

**Responsibility:** Assemble release checklist, version notes, deployment sequencing, and readiness against observability and rollback.

**Inputs:** Merged changes, `templates/release-checklist-template.md`, environment definitions, CI artifacts.

**Outputs:** Release record, go/no-go summary, staged promotion instructions for humans.

**Allowed actions:** Tag proposal text; draft release notes; verify artifact checksums from CI read APIs.

**Restricted actions:** Production deploy; toggling global kill switches unless explicitly delegated.

**Handoff rules:** To **Knowledge Update Agent** and **post-release verification** workflow with release identifier.

---

## Knowledge Update Agent

**Responsibility:** Close the loop after release: docs, ADRs, internal FAQs, runbooks, and searchable knowledge bases.

**Inputs:** Release notes, verification outcomes, incidents or anomalies, `prompts/update-docs.prompt.md` parameters.

**Outputs:** Merged documentation updates; links from issues to final docs.

**Allowed actions:** Same as Documentation Agent within MCP scope.

**Restricted actions:** Altering contractual customer docs without product/legal when applicable.

**Handoff rules:** To **Orchestrator** to mark lifecycle complete or spawn follow-up issues.

---

## Cross-Agent Principles

1. **Least privilege:** Default to read and draft; writes are explicit and scoped.
2. **Evidence over assertion:** Link CI runs, scans, and commits to claims of readiness.
3. **Versioned plans:** Plans referenced by ID or commit SHA to avoid drift during long-running work.
4. **Human supremacy on gates:** Approvals in `approval_rules` are not delegated to models.
