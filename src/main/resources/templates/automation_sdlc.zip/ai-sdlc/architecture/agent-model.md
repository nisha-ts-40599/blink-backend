# AI-SDLC Agent Model

> **Relationship to `agents.md`:** This document expands the foundational agent definitions in
> `ai-sdlc/agents.md` into a full 18-agent model with explicit prompts, triggers, context requirements,
> MCP access, handoff targets, quality rules, and human gate dependencies. `agents.md` remains the
> canonical short-form reference; this document is the authoritative specification.
>
> **Current implementation state:** All agents are implemented today as **manually-triggered prompts**.
> Agents become event-driven at Maturity Level 2+. Refer to `adr/ADR-002-ai-sdlc-architecture-evolution.md`
> for the evolution plan and constraints.

---

## Agent conventions

- **Inputs / outputs** reference abstract artifacts; ACP envelope schema is at `schemas/acp/handoff-envelope.schema.json`.
- **Prompts used today** are files in `ai-sdlc/prompts/`; all are manually triggered.
- **Future triggers** are at Maturity Level 2–3 only; none are currently active.
- **MCP access** lists the future tool access needed; today agents rely on manually supplied context.
- **Human gate** references gates defined in `governance/approval-gates.md`.
- **Quality rules** reference `rules/global-rule-index.md` (created alongside this document).

---

## 1. Orchestrator Agent

**Responsibility:** Coordinate all lifecycle stages. Track workflow state. Route work to specialist agents. Check gate preconditions. Surface human interrupt requirements. Maintain artifact lineage. Does NOT make product or technical decisions.

| Field | Value |
|-------|-------|
| **Inputs** | `project-config.yaml`, `project-context.md`, workflow state file, issue identifiers, prior handoff objects, CI and scan summaries |
| **Outputs** | Stage transitions, task routing instructions, gate precondition reports, escalation notices, consolidated readiness reports |
| **Prompts used today** | Stage router prompt (see `architecture/multi-agent-evolution-roadmap.md` §5) — *to be built; no current standalone prompt* |
| **Future triggers** | Issue created, stage completed webhook, gate approved event, CI completion, monitoring alert |
| **Required project context** | Full `project-config.yaml` + `project-context.md` + active workflow state file |
| **Required MCP access** | GitHub read (issues, PRs, CI status); Jira read (issue state); workflow state write (own path only) |
| **Handoff target** | Routes to any specialist agent based on current stage and tier |
| **Quality rules** | Gate checker: every stage transition requires valid ACP handoff contract; every human gate requires written approval record |
| **Human gate dependency** | Surfaces G-PLAN, G-SEC, G-PR-MERGE, G-DEPLOY gates; never bypasses them |
| **What remains human-owned** | All gate approvals; tier overrides; merge; deployment decisions; incident escalation |

---

## 2. Requirement Analyst Agent

**Responsibility:** Intake raw requirements from any source (ticket, meeting notes, design document, feature request). Normalize into a structured requirement document with acceptance criteria drafts and identified open questions.

| Field | Value |
|-------|-------|
| **Inputs** | Raw requirement text, `{{PROJECT_CONTEXT}}`, `{{TECH_STACK}}`, related issue references |
| **Outputs** | Structured requirement document (title, context, goal, constraints, acceptance criteria draft, open questions, related items) |
| **Prompts used today** | `clarify-requirement.prompt.md`, `create-spec.prompt.md` (partial) |
| **Future triggers** | GitHub issue created event (with configured label); Jira issue created webhook |
| **Required project context** | `project-context.md` (domain model, API conventions, data model); `project-config.yaml` (tier defaults) |
| **Required MCP access** | GitHub issues read; Jira read (issue body, labels, attachments); Confluence read (existing specs) |
| **Handoff target** | Clarification Agent (if open questions are critical path); Work Classification Agent (if requirement is clear) |
| **Quality rules** | Ambiguity detection rule; acceptance criteria completeness check; no binding commitment rule |
| **Human gate dependency** | None for draft; product owner or engineering lead must confirm spec before G-PLAN clock starts |
| **What remains human-owned** | Final requirement approval; acceptance criteria sign-off; priority assignment; delivery commitment |

---

## 3. Clarification Agent

**Responsibility:** Identify and resolve ambiguities in a drafted requirement before it advances to classification and planning. Produces a set of targeted questions, detects conflicting assumptions, and proposes resolutions for human confirmation.

| Field | Value |
|-------|-------|
| **Inputs** | Draft requirement document from Requirement Analyst, `{{PROJECT_CONTEXT}}`, `{{EXISTING_APIS}}`, `{{DATA_MODEL}}` |
| **Outputs** | Structured open questions list; conflict analysis; resolution proposals; revised requirement doc (human must confirm) |
| **Prompts used today** | `clarify-requirement.prompt.md` |
| **Future triggers** | Clarification-needed flag on ACP handoff from Requirement Analyst |
| **Required project context** | `project-context.md`; API conventions; domain glossary; existing feature list |
| **Required MCP access** | GitHub issues read; Confluence/docs read (existing domain specs, glossary) |
| **Handoff target** | Work Classification Agent (after human confirms resolved requirement) |
| **Quality rules** | Ambiguity detection; conflict detection; assumption surfacing (no silent assumption) |
| **Human gate dependency** | Human must confirm resolved requirement before advancement. No automation proceeds past unresolved questions. |
| **What remains human-owned** | Deciding which ambiguities are blocking vs. deferrable; approving the final requirement scope |

---

## 4. Work Classification Agent

**Responsibility:** Propose work tier (1–4) with evidence, blast radius assessment, required rigor, and escalation triggers. Applies risk rules to detect mandatory escalations.

| Field | Value |
|-------|-------|
| **Inputs** | Confirmed requirement, `{{PROJECT_CONTEXT}}`, `ai-sdlc/work-tiers.md`, `governance/risk-rules.md` |
| **Outputs** | Proposed tier 1–4 with evidence; risk flags; required gates; recommended rigor level; escalation triggers |
| **Prompts used today** | `classify-work.prompt.md` |
| **Future triggers** | Requirement confirmed event; Jira issue labeled ready-for-classification |
| **Required project context** | `project-config.yaml` (tier defaults, risk overrides); `risk-rules.md`; data classification from project context |
| **Required MCP access** | GitHub labels read; Jira field read (component, team, priority) |
| **Handoff target** | Impact Analysis Agent |
| **Quality rules** | Risk rule detection; Tier 1/2 boundary guard; self-classification guard (cannot self-confirm) |
| **Human gate dependency** | Classification is advisory; engineering lead must confirm tier, especially for Tier 2 → Tier 1 downgrade |
| **What remains human-owned** | Final tier confirmation; all tier overrides; Tier 3+4 cannot be self-classified by AI |

---

## 5. Impact Analysis Agent

**Responsibility:** Map the blast radius of the confirmed requirement: affected components, API contracts, data schemas, downstream dependencies, rollback considerations, and residual risks.

| Field | Value |
|-------|-------|
| **Inputs** | Confirmed tier, requirement doc, `{{REPOSITORY_CONTEXT}}`, `{{API_CONTRACTS}}`, `{{DATA_MODEL}}` |
| **Outputs** | Impact sketch: affected files/modules, API surface delta, schema changes, rollback approach, test targets, residual risks |
| **Prompts used today** | `impact-analysis.prompt.md` |
| **Future triggers** | Work classification confirmed event |
| **Required project context** | `project-context.md` (tech stack, component map); dependency graph; API contract registry |
| **Required MCP access** | GitHub code search read; dependency manifest read; schema registry read; Jira component labels read |
| **Handoff target** | Technical Planning Agent |
| **Quality rules** | Blast radius completeness check; dependency chain check; rollback feasibility check |
| **Human gate dependency** | Impact summary is reviewed before G-PLAN; complex impact surfaces must be reviewed by engineering lead |
| **What remains human-owned** | Accepting residual risks; approving schema change strategy; deciding rollback vs. roll-forward |

---

## 6. Technical Planning Agent

**Responsibility:** Produce an ordered, executable technical plan: implementation steps, security controls per step, rollback strategy, test strategy, and verification checkpoints. Triggers G-PLAN gate.

| Field | Value |
|-------|-------|
| **Inputs** | Impact analysis, confirmed tier, requirement doc, `{{SECURITY_MODEL}}`, `{{APPROVAL_RULES}}`, `{{ENGINEERING_GUARDRAILS}}` |
| **Outputs** | Technical plan: ordered steps, per-step security controls, rollback strategy, test targets, verification criteria, G-PLAN ready indicator |
| **Prompts used today** | `technical-plan.prompt.md` |
| **Future triggers** | Impact analysis artifact accepted event |
| **Required project context** | `project-context.md`; `project-config.yaml` (security model, deployment model); architectural principles |
| **Required MCP access** | GitHub PRs read (prior implementations for reference); CI config read; architecture diagrams read |
| **Handoff target** | Architecture Review Agent (Tier 3+); Implementation Agents (after G-PLAN) |
| **Quality rules** | Plan completeness check; security-controls-per-step check; rollback present check; minimal change principle |
| **Human gate dependency** | **G-PLAN gate is mandatory for Tier 2+.** Plan must not be implemented without written G-PLAN approval. |
| **What remains human-owned** | G-PLAN approval; architectural decisions embedded in the plan; scope negotiation; timeline |

---

## 7. Architecture Review Agent

**Responsibility:** For Tier 3+ work, review the technical plan for architectural alignment: compliance with patterns, SOLID principles, API design, data model integrity, security posture, and long-term maintainability.

| Field | Value |
|-------|-------|
| **Inputs** | Technical plan, `{{EXISTING_ARCHITECTURE}}`, `{{API_CONVENTIONS}}`, `{{ENGINEERING_GUARDRAILS}}`, existing ADRs |
| **Outputs** | Architecture review findings: blockers, concerns, advisory items; ADR recommendation if a new decision is required |
| **Prompts used today** | `self-review.prompt.md` (partial); `pr-review.prompt.md` (partial) — *dedicated architecture review prompt is a future build* |
| **Future triggers** | Technical plan produced event (Tier 3+ only) |
| **Required project context** | `project-context.md` (architectural principles, existing patterns, anti-patterns); ADR store |
| **Required MCP access** | GitHub code search (existing patterns); ADR store read; architecture diagram read |
| **Handoff target** | Technical Planning Agent (if rework required); Implementation Agents (if approved) |
| **Quality rules** | Architecture alignment check; SOLID/DRY/KISS check; ADR required check for durable decisions |
| **Human gate dependency** | Architecture blockers require engineering lead or architect sign-off before planning continues |
| **What remains human-owned** | Architectural decisions; ADR approval; pattern selection for new capabilities; exception grants |

---

## 8. Backend Implementation Agent

**Responsibility:** Implement backend changes (server-side logic, APIs, services, jobs) step-by-step following the approved plan, applying engineering guardrails on every change.

| Field | Value |
|-------|-------|
| **Inputs** | Approved technical plan (G-PLAN record must exist), issue reference, `{{REPOSITORY_CONTEXT}}`, `{{TECH_STACK}}`, `{{ENGINEERING_GUARDRAILS}}` |
| **Outputs** | Commits or proposed patches on feature branch; step completion notes; deviation log; self-review checklist |
| **Prompts used today** | `implement-step.prompt.md` |
| **Future triggers** | G-PLAN approval recorded + step N assigned by Orchestrator |
| **Required project context** | `project-context.md` (coding conventions, test conventions, deployment model); approved plan artifact |
| **Required MCP access** | GitHub repo read (full); CI status read; feature branch write (after G-PLAN, branch-scoped only) |
| **Handoff target** | Test Strategy Agent; Database Migration Agent (if schema changes present) |
| **Quality rules** | All `rules/global-rule-index.md` mandatory rules; minimal safe change; no bundled refactoring; guardrail checklist per step |
| **Human gate dependency** | G-PLAN must exist before any commit; human confirms each step output before next step begins (Tier 2+) |
| **What remains human-owned** | Code review; PR approval; merge; architectural scope decisions; production configuration |

---

## 9. Frontend Implementation Agent

**Responsibility:** Implement frontend / UI changes (components, pages, state management, API integration) step-by-step following the approved plan, applying frontend-specific conventions.

| Field | Value |
|-------|-------|
| **Inputs** | Approved technical plan, Figma design references (if available), `{{FRONTEND_CONVENTIONS}}`, `{{API_CONTRACTS}}`, `{{ENGINEERING_GUARDRAILS}}` |
| **Outputs** | Feature branch commits; component implementation; API integration; accessibility notes; self-review checklist |
| **Prompts used today** | `implement-step.prompt.md` (with frontend context) |
| **Future triggers** | G-PLAN approval + frontend step assigned by Orchestrator; Figma design exported event (Level 3+) |
| **Required project context** | `project-context.md` (frontend stack, design system, accessibility standards); Figma component library (if MCP available) |
| **Required MCP access** | GitHub repo read; Figma read (design specs, component library); CI status read; feature branch write |
| **Handoff target** | Test Strategy Agent; Documentation/OpenAPI Agent (for UI-facing API changes) |
| **Quality rules** | Global guardrails; frontend-specific: accessibility (WCAG AA minimum); no inline styles; component reuse check |
| **Human gate dependency** | G-PLAN must exist; design review by product/designer for major UI changes; human confirms step output |
| **What remains human-owned** | Design approval; UX decisions; accessibility acceptance; PR merge |

---

## 10. Database Migration Agent

**Responsibility:** Design and validate database migrations — schema changes, data migrations, index additions, referential integrity, rollback scripts — with zero-downtime and backward-compatibility as hard constraints.

| Field | Value |
|-------|-------|
| **Inputs** | Technical plan (migration section), `{{DATA_MODEL}}`, `{{DB_MIGRATION_CONVENTIONS}}`, `{{CURRENT_SCHEMA}}` |
| **Outputs** | Migration scripts (up + down); backward compatibility analysis; data volume estimate; rollback plan; risk rating |
| **Prompts used today** | `implement-step.prompt.md` (DB step) + `self-review.prompt.md` (migration review) |
| **Future triggers** | Orchestrator assigns DB migration step; schema change detected in plan |
| **Required project context** | `project-context.md` (DB platform, migration tool, zero-downtime requirements); current schema; production data volume estimates |
| **Required MCP access** | GitHub repo read; schema registry read; CI migration test results read |
| **Handoff target** | Backend Implementation Agent (for application code aligned to migration); Test Strategy Agent |
| **Quality rules** | Migration discipline rules: up+down required; no data loss without explicit approval; backward compatibility; volume risk check |
| **Human gate dependency** | All Tier 3+ migrations require DBA or engineering lead review before execution; destructive migrations require G-SEC |
| **What remains human-owned** | Production migration execution; go/no-go on destructive data changes; rollback decision |

---

## 11. Test Strategy / Test Generation Agent

**Responsibility:** Generate and refine tests: unit, integration, contract, and edge case coverage aligned with the implementation. Interpret failing tests. Align coverage with tier expectations.

| Field | Value |
|-------|-------|
| **Inputs** | Approved plan, code diff, `{{TECH_STACK}}`, `{{TEST_CONVENTIONS}}`, existing test suite structure |
| **Outputs** | Test code additions/modifications; test plan update; coverage gap analysis; regression test identification |
| **Prompts used today** | `generate-tests.prompt.md` |
| **Future triggers** | Implementation step completed ACP handoff; CI coverage threshold miss |
| **Required project context** | `project-context.md` (test framework, coverage thresholds, contract test approach); existing test patterns |
| **Required MCP access** | GitHub repo read; CI test result read; coverage report read |
| **Handoff target** | Implementation Agents (if tests reveal gaps); PR Review Agent (when tests pass) |
| **Quality rules** | Test quality rules: behavior over implementation; no hidden assertions; edge cases required; regression test required for bugs |
| **Human gate dependency** | Test adequacy is reviewed as part of PR review; coverage thresholds are project-set and CI-enforced |
| **What remains human-owned** | Test strategy decisions (TDD vs. after); acceptance test sign-off; test plan approval for Tier 3+ |

---

## 12. Security Review Agent

**Responsibility:** Interpret SAST/SCA/secret scan results; assess threat model impact of changes; identify Tier elevation triggers; triage CVEs and dependency vulnerabilities. Advisory only at all maturity levels.

| Field | Value |
|-------|-------|
| **Inputs** | Scan outputs (Gitleaks, pip-audit, SAST/CodeQL), diff, `{{SECURITY_MODEL}}`, `{{DATA_CLASSIFICATION}}`, risk rules |
| **Outputs** | Security assessment: findings categorized (must-fix, advisory, informational); tier elevation recommendation; CVE triage; upgrade path |
| **Prompts used today** | `cve-triage.prompt.md`, `bug-triage.prompt.md` (security path) |
| **Future triggers** | CI Gitleaks/pip-audit alert; Dependabot alert; SAST finding; CVE database match |
| **Required project context** | `project-context.md` (security constraints, data classification); `project-config.yaml` (security model) |
| **Required MCP access** | GitHub security alerts read; Dependabot read; OSV/GHSA database read; CI scan results read |
| **Handoff target** | Technical Planning Agent (if design change required); Orchestrator (for tier escalation); Security champion (for waivers) |
| **Quality rules** | No finding waiver by agent; minimum version upgrade; license review on major bump; one CVE per PR preference |
| **Human gate dependency** | All finding waivers require security champion. G-SEC required for Tier 3+. **Advisory only — never approves security gates.** |
| **What remains human-owned** | All security waivers; G-SEC approval; risk acceptance; WAF/IAM changes; production security configuration |

---

## 13. Documentation / OpenAPI Agent

**Responsibility:** Keep specifications, ADRs, runbooks, API docs (OpenAPI), and user-facing documentation consistent with implemented behaviour. Generate changelogs and release notes.

| Field | Value |
|-------|-------|
| **Inputs** | PR diff, implementation summary, `{{REPOSITORY_CONTEXT}}`, `{{EXISTING_DOCS}}`, `{{API_CONTRACTS}}` |
| **Outputs** | Updated markdown documentation; OpenAPI spec delta; ADR draft; changelog entry; runbook draft |
| **Prompts used today** | `update-docs.prompt.md`, `runbook-draft.prompt.md`, `changelog-generation.prompt.md` |
| **Future triggers** | PR merged event (docs update); release created event (changelog); new ADR trigger detected |
| **Required project context** | `project-context.md` (documentation locations, doc platform); existing OpenAPI spec; runbook index |
| **Required MCP access** | GitHub repo read; Confluence/docs read (existing content); feature branch write (docs files only) |
| **Handoff target** | PR Review Agent (for docs PR review); Knowledge Update Agent (post-release) |
| **Quality rules** | Documentation discipline: docs updated in same PR as code; no orphaned API endpoints; OpenAPI must reflect implementation |
| **Human gate dependency** | Engineering lead or technical writer approves docs changes for Tier 3+; publication to external docs always human-approved |
| **What remains human-owned** | External publication; contractual API documentation; compliance portal updates; release announcement |

---

## 14. PR Review Agent

**Responsibility:** Perform structured AI code review for correctness, maintainability, security smell, and policy alignment. Output is advisory; human reviewer makes the final approval.

| Field | Value |
|-------|-------|
| **Inputs** | PR diff, linked issue, prior self-review output, `{{ENGINEERING_GUARDRAILS}}`, `templates/ai-review-template.md` |
| **Outputs** | Review comment set: must-fix (blockers), advisory (suggestions), informational; overall risk statement |
| **Prompts used today** | `pr-review.prompt.md`, `self-review.prompt.md` |
| **Future triggers** | PR opened event (automated advisory review posted as comment) |
| **Required project context** | `project-context.md` (coding conventions, architecture constraints); project engineering guardrails |
| **Required MCP access** | GitHub PR diff read; CI check results read; linked issue read |
| **Handoff target** | Implementation Agents (for must-fix items); Orchestrator (for gate check after human review) |
| **Quality rules** | PR review guardrails: 13-item must-fix criteria list; guardrails checklist; evidence-based assertions only |
| **Human gate dependency** | **G-PR-MERGE requires at least one human reviewer approval.** AI review is a required input, not a substitute. |
| **What remains human-owned** | PR approval; merge decision; dismissal of review threads; final technical judgement |

---

## 15. Release Readiness Agent

**Responsibility:** Assemble release checklist, verify all required artifacts exist, check deployment sequencing, confirm observability and rollback readiness, and produce a go/hold recommendation for human decision.

| Field | Value |
|-------|-------|
| **Inputs** | Merged changes, CI artifact checksums, `templates/release-checklist-template.md`, environment definitions, `{{DEPLOYMENT_MODEL}}` |
| **Outputs** | Release record; go/hold recommendation with evidence; staged promotion instructions for humans; deployment sequencing |
| **Prompts used today** | `release-verification.prompt.md` |
| **Future triggers** | PR merged to main event; release tag created event |
| **Required project context** | `project-context.md` (deployment model, environment structure); CI artifact registry; rollback runbook |
| **Required MCP access** | GitHub CI artifact read; deployment pipeline status read; environment health check read |
| **Handoff target** | Monitoring/Feedback Agent (after deployment); Knowledge Update Agent (after successful release) |
| **Quality rules** | All required artifacts present; CI green; rollback documented; G-DEPLOY gate not bypassed |
| **Human gate dependency** | **G-DEPLOY gate: authorized human approves and executes every production deployment.** AI produces the checklist, human decides. |
| **What remains human-owned** | Go/no-go decision; deployment execution; rollback execution; customer communication |

---

## 16. Monitoring / Feedback Agent

**Responsibility:** Interpret post-deployment monitoring signals during the observation window. Structure go/hold/rollback evidence for human decision-maker. Identify anomalies, error rate changes, latency regressions.

| Field | Value |
|-------|-------|
| **Inputs** | Observability data (metrics, traces, logs), deployment metadata, `{{EXPECTED_BEHAVIOUR}}`, alert thresholds |
| **Outputs** | Signal interpretation: anomalies, normal/abnormal assessment, go/hold conditions for human review; structured incident starter if anomaly detected |
| **Prompts used today** | `monitoring-interpretation.prompt.md` |
| **Future triggers** | Deployment completed event + N-minute observation window start; monitoring alert fired |
| **Required project context** | `project-context.md` (observability platform, SLOs, alert thresholds); deployment metadata |
| **Required MCP access** | Datadog/Grafana/equivalent read; deployment log read; alert history read |
| **Handoff target** | Knowledge Update Agent (normal signal); Orchestrator (anomaly detected → human escalation required) |
| **Quality rules** | Never triggers autonomous rollback; never takes operational actions; always surfaces evidence for human decision |
| **Human gate dependency** | Human SRE reviews all go/hold recommendations. Rollback is always human-executed. |
| **What remains human-owned** | Rollback decision; incident declaration; customer communication; SLA breach handling |

---

## 17. Knowledge Update Agent

**Responsibility:** Close the post-release loop: update docs, ADRs, internal FAQs, runbooks, and knowledge bases to reflect deployed behaviour. Identify retro items and context gaps.

| Field | Value |
|-------|-------|
| **Inputs** | Release notes, verification outcomes, incidents or anomalies, `prompts/update-docs.prompt.md` parameters, retro notes |
| **Outputs** | Merged documentation updates; links from issues to final docs; retro items; project-context freshness suggestions |
| **Prompts used today** | `update-docs.prompt.md` |
| **Future triggers** | Release verified event; incident closed event; scheduled context freshness check |
| **Required project context** | `project-context.md` (doc locations, ownership); existing docs state |
| **Required MCP access** | GitHub repo write (docs files on docs branch); Confluence write (draft spaces only) |
| **Handoff target** | Orchestrator (mark lifecycle complete); spawns follow-up issues for deferred items |
| **Quality rules** | Documentation discipline; no orphaned ADRs; project-context.md freshness gate (90-day maximum age) |
| **Human gate dependency** | Documentation publication to externally visible spaces requires human approval |
| **What remains human-owned** | External publication; contractual documentation; compliance portal updates; retrospective facilitation |

---

## 18. Project Onboarding Agent

**Responsibility:** Guide the initial onboarding of a live project onto AI-SDLC. Analyse repository structure, tech stack, existing conventions, CI setup, and deployment model. Produce `project-config.yaml` and `project-context.md` proposals for human review and confirmation.

| Field | Value |
|-------|-------|
| **Inputs** | Repository URL, tech stack description, team metadata, existing CI configuration, deployment model description |
| **Outputs** | Draft `project-config.yaml`; draft `project-context.md`; onboarding gap report; suggested MCP integrations; incomplete onboarding checklist |
| **Prompts used today** | `setup-existing-project.prompt.md`, `setup-new-project.prompt.md`, `setup-existing-workspace.prompt.md`, `setup-new-workspace.prompt.md` |
| **Future triggers** | New repository created event; project onboarding issue created |
| **Required project context** | None (bootstrap agent — produces the context); uses repository read access only |
| **Required MCP access** | GitHub repo read (structure, CI config, dependency manifests); Jira project config read |
| **Handoff target** | Orchestrator (once onboarding is human-confirmed); Requirement Analyst (for first issue) |
| **Quality rules** | Minimum required fields check; incomplete onboarding detection; context freshness setup (sets 90-day review cadence) |
| **Human gate dependency** | **All generated config files require human review and approval before commit.** Onboarding sets the governance foundation. |
| **What remains human-owned** | Approval of all generated configuration; security model decisions; approval role assignment; MCP token provisioning |

---

## Cross-Agent Principles

1. **Least privilege:** Default to read and draft; writes are explicit, branch-scoped, and security-reviewed before grant.
2. **Evidence over assertion:** Link CI runs, scans, and commits to claims of readiness. No agent marks work complete without evidence.
3. **Versioned plans:** Plans are referenced by artifact ID or commit SHA to avoid drift during long-running work.
4. **Human supremacy on gates:** Approvals defined in `governance/approval-gates.md` are never delegated to models.
5. **Context freshness:** An agent must not proceed if `project-context.md` is older than 90 days without a freshness check.
6. **No silent assumptions:** Every assumption an agent cannot verify from supplied context must be surfaced as an open question.
7. **One agent, one responsibility:** Agents do not perform tasks outside their defined role. Scope creep produces unreliable and unauditable outputs.
8. **Security agent is always advisory:** No agent waives a security finding. No agent approves a security gate.

---

## Agent-to-Prompt Mapping

| Agent | Prompts |
|-------|---------|
| Orchestrator | *(stage-router prompt — to be built)* |
| Requirement Analyst | `clarify-requirement`, `create-spec` |
| Clarification | `clarify-requirement` |
| Work Classification | `classify-work` |
| Impact Analysis | `impact-analysis` |
| Technical Planning | `technical-plan` |
| Architecture Review | `self-review` (partial), `pr-review` (partial) |
| Backend Implementation | `implement-step`, `fix-review-comments` |
| Frontend Implementation | `implement-step` (frontend context), `fix-review-comments` |
| Database Migration | `implement-step` (DB step), `self-review` |
| Test Strategy / Generation | `generate-tests` |
| Security Review | `cve-triage`, `bug-triage` |
| Documentation / OpenAPI | `update-docs`, `runbook-draft`, `changelog-generation` |
| PR Review | `pr-review`, `self-review` |
| Release Readiness | `release-verification` |
| Monitoring / Feedback | `monitoring-interpretation` |
| Knowledge Update | `update-docs` |
| Project Onboarding | `setup-existing-project`, `setup-new-project`, `setup-existing-workspace`, `setup-new-workspace` |
