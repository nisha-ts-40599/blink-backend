# MCP Integration Model

> MCP (Model Context Protocol) connections allow AI agents to read context directly from source
> systems rather than requiring engineers to manually paste content into prompts.
>
> **Governing principle:** Read path before write path. No agent receives write access before its
> read access is validated and operational. No write access is granted to protected branches at any
> maturity level.
>
> **Current state (Level 1):** Only GitHub read-only MCP is documented and available for setup.
> All other integrations are planned. See `mcp/github-readonly-setup.md` for the active guide.
>
> Reference: `mcp/mcp-permissions.md`, `mcp/mcp-security-guidelines.md`

---

## 1. GitHub MCP

### Read use cases

| Use case | Agent | Context assembled | MCP tool |
|----------|-------|------------------|---------|
| Read issue body and labels | Analyst, Classifier | Requirement text, tier hints | `get_issue` |
| Search repository structure | Impact Analysis, Coder | Affected files, component map | `search_code` |
| Read PR diff | PR Review, Self Review | Code changes for review | `get_pull_request_files` |
| Read CI job status | Orchestrator, Release Readiness | Green/failing status | `list_check_runs_for_ref` |
| Read existing PRs | Coder, Planner | Prior implementations for reference | `list_pull_requests` |
| Read Dependabot / security alerts | Security Review | CVE and dependency alerts | `list_dependabot_alerts` |
| Read branch protection status | Orchestrator | Gate enforcement posture | `get_branch_protection` |

### Write use cases

| Use case | Agent | Scope | Maturity level |
|----------|-------|-------|---------------|
| Post advisory review comment | PR Review | PR comments only | Level 2 |
| Post status update comment | Orchestrator | Issue comments only | Level 2 |
| Assign tier label | Work Classification | Issue labels only | Level 2 |
| Commit to feature branch | Coder, Docs Agent | Feature branches only (never protected) | Level 2 |
| Open PR | Coder (future) | Feature branch → base | Level 2–3 |

### Maturity level required
- Read: Level 2 (can be set up now with fine-grained PAT per `mcp/github-readonly-setup.md`)
- Write (comments/labels): Level 2
- Write (branch commits): Level 2 with security champion review of scope

### Token scope
Fine-grained PAT with repository-scoped read permissions. See `mcp/github-readonly-setup.md` for exact permission list.

### Project onboarding requirements
Each engineer creates a fine-grained PAT for their own GitHub account. Token is stored in `.cursor/mcp.json` (not committed). Per `mcp/github-readonly-setup.md`.

### Security controls
- Fine-grained PAT — never a classic token with broad scope
- Per-engineer tokens — no shared service account for developer-facing MCP
- Token scope limited to read (initially); write scope reviewed by security champion before addition
- Tokens expire per project policy (recommended: 90 days)
- `.cursor/mcp.json` never committed to version control (`.gitignore` enforces this)

### Data sensitivity concerns
- PRs and issues may contain PHI, PCI data, or customer PII in description/comments in some projects
- Projects with high data sensitivity (healthcare, finance) must assess whether GitHub issue content is in scope for PII controls before enabling MCP access

### Agent access mapping

| Agent | Read access | Write access |
|-------|------------|-------------|
| Orchestrator | Issues, PRs, CI, branch protection | Issue comments (status) |
| Requirement Analyst | Issues, linked docs | None |
| Clarification | Issues | None |
| Work Classification | Issues, labels | Issue labels (Level 2) |
| Impact Analysis | Repo structure, code search | None |
| Technical Planning | PRs (reference), CI config | None |
| Architecture Review | Code search, ADR store | None |
| Backend / Frontend / DB Implementation | Repo read, CI status | Feature branch commits (Level 2) |
| Test Agent | Repo read, CI test results | Feature branch commits (Level 2) |
| Security Review | Security alerts, Dependabot, CI scan results | None |
| Documentation/OpenAPI | Repo read | Feature branch docs commits (Level 2) |
| PR Review | PR diff, CI status | PR review comments (Level 2) |
| Release Readiness | CI artifacts, environment status | None |
| Monitoring/Feedback | CI run history | None |
| Knowledge Update | Repo read | Docs branch commits (Level 2) |
| Project Onboarding | Repo structure, CI config | None |

---

## 2. Jira MCP

### Read use cases

| Use case | Agent | Context assembled |
|----------|-------|-----------------|
| Read issue fields (summary, description, components, priority) | Analyst, Classifier | Structured requirement; tier hints |
| Read issue history and comments | Clarification | Prior discussion; resolved questions |
| Read sprint context | Orchestrator | Capacity context for planning |
| Read linked issues | Impact Analysis | Related work; dependency context |

### Write use cases

| Use case | Agent | Scope | Maturity level |
|----------|-------|-------|---------------|
| Add issue label or component | Work Classification | Label write only | Level 2 |
| Post AI-assisted status comment | Orchestrator | Comment on issue | Level 2 |
| Transition issue status (future) | Orchestrator | Limited state transitions | Level 3 with formal scope review |
| Create sub-tasks | Issue Agent | Sub-task creation | Level 2–3 |

### Maturity level required
- Read: Level 2 (validate before activating any read triggers)
- Write: Level 2–3 (each write scope requires dedicated security review)

### Token scope
Jira API token with project-scoped read. Write scope added incrementally with each validated write use case.

### Project onboarding requirements
Jira project key and base URL recorded in `project-config.yaml`. Field mapping (Jira field → AI-SDLC placeholder) defined per project.

### Security controls
- Jira tokens are per-engineer or per-service-account depending on project policy
- Write access to Jira is bounded by issue key scope — no bulk operations
- Jira field mapping must be reviewed for PII before enabling MCP

### Data sensitivity concerns
Medium–high: Jira issues may contain customer-related context, incident details, or business-sensitive priorities.

---

## 3. Figma MCP

### Read use cases

| Use case | Agent | Context assembled |
|----------|-------|-----------------|
| Read component definitions | Frontend Implementation | Component props, layout, variants |
| Read design tokens | Frontend Implementation | Colour, spacing, typography values |
| Read annotation/specification layers | Design-to-Spec Agent (future) | Requirement text embedded in design |

### Write use cases
None planned. Figma is read-only at all maturity levels.

### Maturity level required
Level 2–3 (after design-to-spec workflow is defined; dedicated prompt required)

### Token scope
Figma read-only API token scoped to specific project files.

### Project onboarding requirements
Figma project URL and file IDs recorded in `project-config.yaml`. Component library file ID required.

### Security controls
- Read-only token; no write access to Figma at any maturity level
- Token scoped to specific files, not entire Figma workspace

### Data sensitivity concerns
Low for component/design data; medium if design files contain unreleased product screenshots or customer data mockups.

---

## 4. Confluence / Docs MCP

### Read use cases

| Use case | Agent | Context assembled |
|----------|-------|-----------------|
| Read existing architecture docs | Impact Analysis, Architecture Review | Architectural constraints; existing decisions |
| Read runbooks | Monitoring/Feedback, Release Readiness | Operational procedures |
| Read domain glossary | Clarification, Analyst | Domain terminology |
| Read API documentation | Documentation/OpenAPI | Existing API contract context |

### Write use cases

| Use case | Agent | Scope | Maturity level |
|----------|-------|-------|---------------|
| Update runbook draft | Knowledge Update | Draft spaces only | Level 2–3 |
| Create documentation page draft | Docs Agent | Draft spaces only | Level 3 |
| Publish page | None | Never — human always publishes | N/A |

### Maturity level required
- Read: Level 2
- Write (draft spaces): Level 3

### Token scope
Confluence API token with read access to specified spaces. Write access limited to draft/sandbox spaces.

### Security controls
- Published spaces are never written by agents — only humans publish
- Draft space is reviewed by engineering lead or technical writer before publish

---

## 5. CI/CD MCP

### Read use cases

| Use case | Agent | Context assembled |
|----------|-------|-----------------|
| Read CI job status | Orchestrator, Release Readiness | Gate precondition check |
| Read test results | Test Agent, PR Review | Coverage; test failures |
| Read artifact checksums | Release Readiness | Release validation |
| Read pipeline logs (filtered) | Implementation Agent (failure trigger) | Failure root cause |

### Write use cases

| Use case | Agent | Scope | Maturity level |
|----------|-------|-------|---------------|
| Trigger re-run of failing test job | Orchestrator (future) | Non-production builds only | Level 3 |

### Maturity level required
- Read: Level 2 (GitHub Actions status API is included in GitHub MCP)
- Write (pipeline trigger): Level 3 with explicit scope limitation

---

## 6. Observability MCP

### Read use cases

| Use case | Agent | Context assembled |
|----------|-------|-----------------|
| Read service metrics (error rate, latency, availability) | Monitoring/Feedback | Post-deploy signal interpretation |
| Read trace data | Monitoring/Feedback | Latency breakdown; slow path identification |
| Read log query results | Monitoring/Feedback | Error log context |
| Read alert history | Monitoring/Feedback | Alert correlation with deploy |

### Write use cases
None. Observability is always read-only. No agent modifies dashboards, alert thresholds, or silences.

### Maturity level required
Level 2–3 (requires observability platform MCP server to be available; often a custom MCP for each platform)

### Token scope
Service account with read-only access to specified service namespaces. No admin or alert management access.

### Security controls
- Read-only at all maturity levels
- Scoped to specific service namespaces — no cross-tenant or global read
- Metric data may contain PII-adjacent information (user IDs, session IDs) — confirm data handling with security champion

---

## 7. Security Scanners MCP

### Read use cases

| Use case | Agent | Context assembled |
|----------|-------|-----------------|
| Read SAST / CodeQL findings | Security Review | Vulnerability characterisation |
| Read Gitleaks results | Security Review | Secret detection |
| Read pip-audit / npm audit results | Security Review | Dependency CVE triage |
| Read Dependabot alerts | Security Review | CVE advisory list |
| Query OSV / GHSA database | Security Review | CVE severity and exploitability |

### Write use cases
None. Security agents are advisory only. No agent dismisses, suppresses, or waives findings.

### Maturity level required
Level 2 (Gitleaks and pip-audit are already in CI; OSV/GHSA is a public API)

### Security controls
- Never allows agents to waive security findings
- Security champion reviews all tier-elevation recommendations
- SAST results may contain code snippets — handle per data classification policy

---

## 8. Cloud / Deployment Platform MCP

### Read use cases

| Use case | Agent | Context assembled |
|----------|-------|-----------------|
| Read deployment status | Release Readiness | Deployment confirmation |
| Read environment health | Release Readiness | Pre-deploy environment readiness |
| Read infrastructure config (read-only snapshot) | Architecture Review (Tier 4) | Infrastructure risk context |

### Write use cases
**None.** Production deployment is always human-executed (G-DEPLOY gate). No AI agent triggers, initiates, or executes deployments.

### Maturity level required
Level 3 (read-only for deployment status); write access is permanently prohibited.

### Security controls
- Read-only deployment status API only
- No access to infrastructure management consoles, IAM, secrets stores, or kill switches
- Cloud read tokens are service-account-based with minimal permission scope

---

## MCP integration sequence

Activate MCP integrations in this order. Each must be validated before the next is enabled.

| Priority | Integration | Target agents | Validation criteria |
|----------|-------------|--------------|---------------------|
| **P1 — Now** | GitHub read (issues, PRs, CI) | Analyst, Coder, PR Review, Orchestrator | Per-engineer PAT issued; example prompts work |
| **P2 — Week 5–6** | Jira read | Analyst, Classifier | Issue field mapping defined; test with 3 pilot issues |
| **P2 — Week 5–6** | GitHub write (comments, labels) | PR Review, Orchestrator, Classification | Scope formally reviewed; tested on non-main branches |
| **P3 — Week 7–10** | Confluence/docs read | Docs Agent, Architecture Review | Read-only token; tested with 2 doc types |
| **P3 — Week 7–10** | Security scanner read | Security Review | pip-audit and Dependabot read validated |
| **P4 — Level 3** | Observability read | Monitoring/Feedback | MCP server for platform installed; read-only validated |
| **P4 — Level 3** | Figma read | Frontend Implementation | Design-to-spec prompt defined; token scoped to project files |
| **P5 — Level 3+** | GitHub write (feature branch commits) | Coder, Docs, Test | Security champion review; scope formally bounded |
| **Never** | Any production infrastructure write | Any agent | Permanent prohibition |
