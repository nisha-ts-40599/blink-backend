# Multi-Agent AI-SDLC Evolution Roadmap

> **Current state:** Single-agent, prompt-triggered, human-run framework (Maturity Level 1).
> Every prompt is manually invoked by an engineer who fills all placeholders, reviews the output,
> and decides what to do next. There is no orchestration, no event-driven automation,
> and no agent-to-agent communication today.
>
> **Target state:** Enterprise-governed, MCP-connected, ACP-orchestrated, multi-agent AI-SDLC
> (Maturity Level 3), with Level 4 as a constrained future possibility.
>
> Governing ADR: `ai-sdlc/adr/ADR-002-ai-sdlc-architecture-evolution.md`

---

## 1. Agent Role Catalog — 22 Prompts → 12 Agent Roles

Each role clusters one or more current prompts. At Level 1 these are stateless LLM calls. At Level 3 each role becomes a specialized agent with its own context scope, MCP tool access, and ACP message handler. The agent model is defined in `ai-sdlc/agents.md`.

| Agent Role | Current prompts | Core responsibility | Today's trigger | Autonomy level |
|-----------|-----------------|---------------------|----------------|----------------|
| **Orchestrator** | *(to be built — no current prompt)* | Reads workflow state; routes work to specialist agents; checks gate preconditions; surfaces human interrupt requirements; maintains artifact lineage. Does NOT decide. | N/A today | Coordinator; no decision authority |
| **Analyst** | `clarify-requirement`, `create-spec`, `create-issues` | Transforms a raw requirement into a clarified spec with acceptance criteria, open questions, and a structured issue set | Manual — engineer invokes | Advisory; proposals require human confirmation |
| **Classifier** | `classify-work` | Proposes work tier 1–4 with evidence, blast radius, escalation triggers, and required rigor | Manual — engineer invokes | Advisory; human retains override authority |
| **Impact Analyst** | `impact-analysis` | Maps affected components, API and schema contracts, rollback considerations, and residual risks | Manual — engineer invokes | Advisory; output reviewed before G-PLAN |
| **Planner** | `technical-plan` | Produces ordered implementation steps, security controls, rollback strategy, verification checkpoints | Manual — engineer invokes | Advisory until G-PLAN; blocked from advancing without explicit written approval |
| **Coder** | `implement-step`, `fix-review-comments` | Implements the approved plan step-by-step; applies engineering guardrails; flags deviations from plan | Manual — engineer invokes one step at a time | Supervised; human reviews every diff before next step; never self-merges |
| **Test Agent** | `generate-tests` | Generates unit and integration tests covering behaviour, edge cases, and failure paths | Manual — engineer invokes after each implement-step | Supervised; engineer validates test quality |
| **Docs Agent** | `update-docs`, `runbook-draft`, `changelog-generation` | Updates documentation, ADRs, runbooks, and changelogs aligned with shipped behaviour | Manual — engineer invokes | Supervised; engineering lead or technical writer approves before publication |
| **Reviewer** | `self-review`, `pr-review` | Reviews diffs against guardrails, must-fix criteria, security, and architecture alignment | Manual — engineer invokes before PR and on PR open | Advisory only; never approves; human reviewer makes independent judgment |
| **Security Agent** | `cve-triage`, `bug-triage` (security path) | Assesses CVE severity, exploitability, upgrade path, breaking changes, license risk, and security bug root cause | Manual — engineer invokes on alert or bug report | Advisory only at all maturity levels; never waives security review |
| **Observability Agent** | `monitoring-interpretation`, `release-verification` | Interprets post-deploy monitoring signals; structures smoke check plan, go/hold evidence, rollback trigger conditions | Manual — engineer invokes after deployment | Advisory only; never takes operational actions; never decides go/hold |
| **Setup Agent** | `setup-existing-project`, `setup-new-project`, `setup-existing-workspace`, `setup-new-workspace` | Generates `project-config.yaml`, `project-context.md`, and workspace config proposals for new or existing repositories | Manual — engineering lead invokes during onboarding | Advisory; all config files require human review before commit |

---

## 2. Stage Trigger Analysis — Manual Today, Event-Driven in Future

All stages are manually triggered today. The following table shows the current trigger, the target event trigger, the complexity of making the transition safely, and the prerequisite.

| Stage | Today (manual trigger) | Target (event trigger) | Complexity | Prerequisite |
|-------|----------------------|----------------------|-----------|-------------|
| Requirement intake | Engineer pastes requirement text and invokes Analyst prompt | Issue created webhook → Analyst Agent (after issue schema is validated) | Medium — requires structured issue schema | Jira/GitHub MCP read; structured issue template |
| Work tier classification | Engineer runs classify-work | Issue triaged webhook → Classifier Agent | Medium — requires issue label write access | GitHub MCP read; classifier confidence threshold |
| Impact analysis | Engineer runs impact-analysis | Auto after classification for Tier 2+ | Medium — needs context retrieval from code | GitHub MCP + code search read |
| Technical planning | Engineer runs technical-plan | Auto after impact analysis quality check | Medium | Planner output schema validation |
| G-PLAN gate | Engineer awaits engineering lead comment | Issue comment pattern match → gate checker | Low — pattern match on comment events | Gate checker script (see Section 5) |
| Implementation | Engineer runs implement-step per step | Step-by-step after G-PLAN; human confirms prior step before next auto-triggers | High — requires careful human-in-loop confirmation | Coder write access on feature branch; per-step human checkpoint |
| Test generation | Engineer runs generate-tests after implement-step | Auto after implement-step ACP handoff completes | Low — safe, deterministic | Test Agent on feature branch |
| Self-review | Engineer runs self-review before PR | Auto when feature branch is pushed | Low | Branch push webhook |
| AI PR review | Engineer runs pr-review with PR context | Auto on PR open event | Low — already in CI prompt-check scope | PR-open webhook; read-only review output |
| G-PR-MERGE gate | Human reviewer approves in GitHub | Branch protection enforces — no automation here | None — must remain human | Branch protection active |
| Changelog / docs update | Engineer runs after merge | Auto on PR merge to main event | Low — safe post-merge, advisory output | Docs Agent with feature branch write; GitHub merge webhook |
| G-DEPLOY gate | Human SRE executes deployment | Never automated — non-delegable human decision | N/A — permanent boundary | N/A |
| Release verification | Engineer pastes signals into prompt | Auto N minutes after deployment event detected | Medium — needs observability MCP | Observability MCP read |
| CVE triage alert | Engineer runs on audit alert | Auto when pip-audit / Dependabot raises CVE | Low — audit job webhook exists | Security Agent; CVE webhook from CI |
| Bug triage | Engineer runs on filed bug | Auto when issue labeled `bug` with reproduction steps | Medium — requires structured issue schema | Issue schema; Classifier + Security Agent chaining |

---

## 3. Read-Only MCP Access by Agent

MCP access follows the principle: **read-path before write-path**. No agent receives write access before the corresponding read access is validated and operational.

| Agent | MCP sources (future) | Priority | Notes |
|-------|---------------------|----------|-------|
| Analyst | GitHub issues + PRs, Jira, Confluence/docs | P1 | Eliminates manual issue paste; most immediate ROI |
| Classifier | GitHub issues, risk-rules.md, tier history | P1 | Needs issue label context |
| Impact Analyst | GitHub repo structure, code search, schema registry | P2 | Needs full repo traversal capability |
| Planner | GitHub, ADR store, specification templates | P2 | Needs access to existing ADRs and specs |
| Coder | GitHub repo (full read), code search, CI results | P1 | Must read before any write access is considered |
| Test Agent | Source files (read), test framework docs | P2 | Needs code context |
| Docs Agent | GitHub, Confluence (future), existing changelogs | P2 | Needs existing docs for delta calculation |
| Reviewer | GitHub PR diff, CI status, check results | P1 | Already partially available via GitHub MCP |
| Security Agent | OSV/GHSA vulnerability database, GitHub alerts, Dependabot | P1 | Enables automated CVE triage trigger |
| Observability Agent | Datadog / Grafana / equivalent (future), deployment logs | P2 | Highest value for monitoring-interpretation prompt |
| Setup Agent | GitHub repo structure, existing `ai-sdlc/` artifacts | P1 | Needed for accurate project profiling |
| Orchestrator | All agent outputs, per-issue workflow state file, gate records | P1 | Core orchestration requires all agent read paths first |

---

## 4. Future Limited Write Access by Agent

Write access is granted incrementally, scoped to feature branches, and preceded by a security champion review. No agent ever writes to a protected branch. Humans merge.

| Agent | Write scope (future) | Maturity level | Prerequisite |
|-------|---------------------|---------------|-------------|
| Classifier | Issue tier label (narrowly scoped GitHub label) | Level 2 | GitHub MCP read validated; label scope formally bounded |
| Planner | Plan file to `ai-sdlc/plans/` on feature branch | Level 2 | G-PLAN written approval exists; file-path scope limit |
| Coder | Source files on feature branch only | Level 2 | G-PLAN recorded; guardrails enforced; human confirms each step |
| Test Agent | Test files on feature branch | Level 2 | Coder step ACP handoff complete; test file scope limit |
| Docs Agent | Docs and runbook files on feature branch; changelog on merge | Level 2 | PR merged (for changelog); feature branch only (for draft docs) |
| Orchestrator | Workflow state file in `ai-sdlc/workflow-state/` | Level 3 | MVO operational; state schema validated |
| Reviewer | PR review comments only (not code changes) | Level 3 | GitHub review API write; human reviewer still required for approval |
| Security Agent | **None — advisory only at all maturity levels** | N/A | Security findings are always human-reviewed; no autonomous write |
| Observability Agent | **None — advisory only at all maturity levels** | N/A | Operational actions are always human-executed |

---

## 5. Priority ACP Handoff Contracts

Three contracts to define and validate before any automated agent-to-agent routing begins. The canonical envelope schema is in `acp/acp-handoff-contracts.md`.

### Contract 1 — Analyst → Planner

**When:** After the Analyst produces a confirmed spec and the Classifier assigns a validated tier.

| Field | Analyst produces | Planner requires |
|-------|-----------------|-----------------|
| Requirement body | Clarified, structured requirement text | Confirmed — human reviewed |
| Acceptance criteria | Structured list, measurable | Confirmed by product owner or engineering lead |
| Work tier | Proposed tier 1–4 with evidence | Human-validated tier — not just AI proposal |
| Impact surface | Affected components, API surface, data stores | Reviewed — used to scope security controls |
| Open questions | Items requiring human resolution | All blocking questions must be resolved before Planner starts |
| Gate condition | Human confirms spec and tier | **G-PLAN clock does not start until spec is human-confirmed** |

### Contract 2 — Planner → Coder

**When:** After G-PLAN written approval is recorded on the issue.

| Field | Planner produces | Coder requires |
|-------|-----------------|---------------|
| Technical plan | Ordered implementation steps with verification | Approved plan (G-PLAN record must exist) |
| Current step | Step N of M | Coder works one step at a time |
| Security controls | Per-step security requirements | Applied as hard constraints, not suggestions |
| Rollback strategy | Per-step rollback approach | Referenced if deviation from plan is flagged |
| Acceptance criteria | From Analyst contract | Used as done-definition for each step |
| Gate condition | G-PLAN approval record in issue comments | **Coder must not start without G-PLAN record** |

### Contract 3 — Coder → Reviewer

**When:** After all implementation steps are complete and self-review passes.

| Field | Coder produces | Reviewer requires |
|-------|---------------|-----------------|
| Diff / patch | Source changes for this step set | PR diff — no context fabrication |
| Self-review output | Self-review results from `self-review` prompt | Advisory input — Reviewer performs independent check |
| Test coverage | Tests added or updated | Confirms tests cover new behaviour |
| CI status | Conformance and lint results | CI must be green before review is requested |
| Deviations from plan | Any scope changes with rationale | Deviations require engineering lead sign-off |
| Gate condition | Self-review pass + CI green | **Reviewer output is advisory; G-PR-MERGE requires human approval** |

---

## 6. Minimum Viable Orchestrator (MVO)

The MVO does not require a deployed service at Level 2. It starts as scripts and a state file. A running service is introduced at Level 3 only after the state file and gate checker are validated in the pilot.

### MVO component specifications

#### Component 1 — Workflow state file

**Path:** `ai-sdlc/workflow-state/{issue-id}.yaml` (one file per tracked issue)

**Purpose:** Single source of truth for the current stage, tier, gate records, and artifact references for a tracked piece of work.

**Minimum schema:**

```yaml
schema_version: "1.0"
issue_id: "{{ISSUE_ID}}"
issue_url: "{{ISSUE_URL}}"
work_tier: null           # set by Classifier agent; human confirmed
current_stage: "REQUIREMENT"  # enum: see state machine below
gates:
  g_plan:
    required: false       # false for Tier 1
    approved: false
    approver: null
    approved_at: null
    comment_url: null
  g_sec:
    required: false       # true for Tier 3+
    approved: false
    approver: null
    approved_at: null
    comment_url: null
  g_pr_merge:
    required: true
    approved: false
    pr_url: null
  g_deploy:
    required: false
    approved: false
    approver: null
    approved_at: null
artifacts:
  spec_path: null
  plan_path: null
  implementation_prs: []
  test_coverage_report: null
  ai_review_output: null
agent_outputs:
  analyst_summary: null
  planner_summary: null
  self_review_summary: null
  ai_pr_review_summary: null
updated_at: null
```

**When to build:** Week 2–3 (Level 2 foundation). Engineers fill it manually first; Orchestrator writes it later at Level 3.

#### Component 2 — Gate checker

**Purpose:** Before any agent advances to the next stage, verify that the required gate for the current transition is recorded in the state file.

**Logic:**
1. Read the state file for the issue.
2. For the requested stage transition (e.g., PLAN_APPROVED → IMPLEMENTING), check the corresponding gate record.
3. If the gate is not approved: stop, output the missing gate requirements, surface the escalation path.
4. If the gate is approved: allow the transition and update `current_stage`.

**Implementation path:** Python script, callable from the Makefile and from GitHub Actions. Does not require a running service.

**When to build:** Week 2–3, alongside the state file schema.

#### Component 3 — Stage router prompt

**Purpose:** A meta-prompt that reads the current state file and outputs: "current stage is X, next action is Y, invoke prompt Z with the following context."

**Input:** State file YAML + `project-context.md` + issue body.

**Output:**
- Current workflow position (stage, tier, gates passed)
- Next recommended action
- Which prompt to invoke
- Which placeholders to fill (with sources)
- Any blocking conditions

**Value:** Eliminates the engineer's need to know which prompt to run next. Engineer reads the router output, confirms, and invokes the indicated prompt.

**When to build:** Week 3–4. Can be implemented as a Cursor rule or a standalone prompt file before a running Orchestrator service exists.

#### Component 4 — Event hooks (GitHub Actions)

**Purpose:** Transform specific GitHub events into agent invocations or engineer notifications.

**Priority event hooks (Week 4–6):**

| Event | Agent triggered | Action |
|-------|----------------|--------|
| Issue labeled `cve` or Dependabot alert | Security Agent | Run `cve-triage` with issue context; post advisory comment |
| PR opened | Reviewer | Run `pr-review` prompt; post advisory AI review as PR comment |
| PR merged to main | Docs Agent | Run `changelog-generation`; post draft to linked issue |
| Monitoring alert during post-deploy window | Observability Agent | Run `monitoring-interpretation`; notify on-call engineer |

**Implementation path:** GitHub Actions workflow steps; Cursor rules for Cursor-invoked prompts. Does not require a running orchestration service.

#### Component 5 — Artifact linker

**Purpose:** Ensure all produced artifacts (spec, plan, implementation PRs, test results) are cross-linked in the issue state file and in issue comments before any gate check proceeds.

**Logic:** Before a gate check runs, verify that all `required_artifacts` listed in the ACP handoff contract for the current stage exist and have resolvable paths in the state file.

**When to build:** Week 4–6, after state file and gate checker are operational.

#### Component 6 — Context aggregator

**Purpose:** Before invoking any agent prompt, automatically assemble the required context: `project-context.md`, issue body, prior agent outputs (from state file), gate records, and engineering guardrails — reducing manual placeholder fill from 8–12 items to 2–3.

**Implementation options (in order of complexity):**
1. Cursor rule that reads the state file and assembles context on prompt invocation (lowest complexity, available at Level 2).
2. Python script that generates a pre-filled prompt file from the state file and project context (medium complexity).
3. MCP-connected context fetch that queries GitHub and Jira directly (requires MCP, Level 2+).

**When to build:** Week 4–8 (start with Cursor rule; evolve to MCP-connected aggregator at Level 2).

---

## 7. Workflow State Machine

States and transitions. Human interrupt states are marked. No automated step advances past a human interrupt state without an explicit written approval record.

| State | Trigger to enter | Automated actions on entry | Human interrupt required |
|-------|-----------------|---------------------------|-------------------------|
| `REQUIREMENT` | Issue created or requirement filed | Analyst + Classifier invoked (future: auto; today: manual) | None — intake stage |
| `CLASSIFIED` | Tier validated by engineering lead | Impact Analyst invoked (Tier 2+) | Human confirms tier before advancing |
| `SPEC_DRAFTED` | Analyst output confirmed | Technical plan drafted | Human reviews spec; resolves open questions |
| `PLAN_DRAFTED` | Planner output complete | G-PLAN SLA clock starts (2-day default) | **G-PLAN gate — engineering lead must approve in writing** |
| `PLAN_APPROVED` | G-PLAN approval recorded | Coder begins step 1; Test Agent primed | G-PLAN record must exist in state file |
| `IMPLEMENTING` | Coder completes each step | Test Agent runs per step; human confirms before next step | Human confirms each step output; Tier 3+: security champion reviews |
| `PR_OPEN` | Feature branch PR created | AI PR review runs; conformance CI runs | Branch protection: CI green required |
| `REVIEW_COMPLETE` | AI review complete; human review requested | Human reviewer reviews diff | **G-PR-MERGE — 1 human reviewer approval required by branch protection** |
| `APPROVED` | PR approved + CI green | No automation — human presses merge | **Human merge — never automated** |
| `MERGED` | Code merged to main | Docs Agent: changelog + docs update; CI runs on main | None — post-merge automation is advisory |
| `DEPLOYING` | Authorized human initiates G-DEPLOY | Deployment pipeline runs under human control | **G-DEPLOY — authorized human approves and executes deployment** |
| `DEPLOYED` | Deployment complete | Observability Agent begins monitoring window | None — monitoring is read-only |
| `VERIFIED` | Monitoring window complete; go/hold recommendation reviewed | Issue closed or next action triggered | Human reviews go/hold recommendation; human decides on rollback if needed |

---

## 8. What Must Never Be Automated

These are permanent governance boundaries — not current technology limitations. No maturity level removes them.

| Action | Reason | Permanence |
|--------|--------|-----------|
| Merge to any protected branch | Human accountability for production code; branch protection enforces | Forever |
| Production deployment execution | SRE accountability; unbounded blast radius; regulatory compliance | Forever |
| Rollback decision during incidents | Real-time situational awareness and business context required | Forever |
| Incident declaration and severity classification | Activates SLA obligations and response procedures | Forever |
| PII handling, data deletion, anonymisation | GDPR/CCPA legal accountability; named human decision-maker required | Forever |
| Secret rotation and key ceremony | Cryptographic accountability; break-glass authorization required | Forever |
| Vendor / third-party API enablement | Commercial and legal commitments | Forever |
| Security finding waivers | Known risk acceptance requires human accountability | Forever |
| Tier override (downgrade from Tier 3+) | Reduces governance obligations; named human must own the accountability difference | Forever |
| Customer-facing communications | External commitments carry commercial and reputational risk | Forever |

---

## 9. 30 / 60 / 90 Day Implementation Plan

### Days 1–30 — Foundation: Make Level 1 real and measurable

| Task | Why | Target |
|------|-----|--------|
| Trigger GitHub Actions — open first PR | P0: CI job names must appear in branch protection dropdown before protection can be configured | Day 1–2 |
| Configure branch protection (all 3 required status checks) | P0: Merges to main are unguarded until this is active | Day 2–3 |
| Issue GitHub fine-grained PAT per pilot engineer | P1: GitHub read-only MCP requires a PAT; eliminates manual GitHub context paste | Day 1–3 |
| Run 2–3 complete Tier 2 issues through the full 12-step workflow | Validates the prompt chain end-to-end; generates concrete lessons learned data | Week 1–2 |
| Define and commit the workflow state YAML schema | Foundation for MVO; engineers begin filling manually as a discipline-builder | Week 2–3 |
| Write the 3 priority ACP handoff contract templates | Analyst→Planner, Planner→Coder, Coder→Reviewer — structured YAML output format that agents will eventually produce automatically | Week 3–4 |
| Identify and automate one safe event trigger (CVE alert → Security Agent) | Proof of concept for event-driven agents; low risk, measurable | Week 3–4 |

### Days 31–60 — MCP-connected: Eliminate manual context assembly

| Task | Why | Target |
|------|-----|--------|
| Enable Jira read-only MCP for Analyst + Classifier prompts | Highest ROI: eliminates issue body paste; improves context fidelity | Week 5–6 |
| Enable GitHub read-only MCP for Coder + Reviewer prompts | Eliminates repo structure paste; enables code-aware review | Week 5–6 |
| Enable observability read-only MCP for Observability Agent | Enables monitoring-interpretation without manual signal paste | Week 6–7 |
| Build context aggregator — Cursor rule version | Reduces manual placeholder fill from 8–12 to 2–3 per prompt invocation | Week 5–8 |
| Add SAST / CodeQL on product repos participating in pilot | Closes the biggest security gap in AI-generated code validation | Week 5–6 |
| Implement gate checker script for G-PLAN | Reads issue comments for approval pattern; prevents accidental step advancement | Week 7–8 |
| Add PR-open event → auto-invoke AI PR review via GitHub Actions | Eliminates one manual step; output is advisory only | Week 7–8 |

### Days 61–90 — Orchestration seed: First automated agent loop

| Task | Why | Target |
|------|-----|--------|
| Deploy MVO: state file + stage router + gate checker as integrated toolset | First functional orchestration: Analyst through Coder with human checkpoints | Week 9–12 |
| Enable Coder Agent limited write access to feature branches | Closes the implementation loop; requires audit trail and branch-scope controls | Week 10–12 |
| Add Analyst Agent event trigger: new issue created → clarify-requirement | Reduces time-to-plan; engineer still reviews before G-PLAN clock starts | Week 9–10 |
| Implement ACP message passing for the 3 core agent pairs | Planner→Coder and Coder→Reviewer carry structured context without manual re-paste | Week 10–12 |
| Run retrospective: measure prompt quality, gate adherence, rework rate, time-to-plan | Data foundation for Level 2 → Level 3 decision; no maturity advance without measurement | Week 12 |
| Publish ADR addendum or ADR-003 for Level 3 ACP runtime design | Commits the team to a specific runtime approach with full context from pilot data | Week 11–12 |

---

## 10. What Remains Prompt-Triggered Intentionally

These stages are permanently or temporarily excluded from event-driven automation.

| Prompt / Stage | Why it stays manual | Condition for reconsideration |
|---------------|--------------------|-----------------------------|
| All Tier 4 work | Platform/security/data/regulatory risk requires full human attention at every step; automation reducing attention at these tiers is dangerous regardless of maturity | Never for Tier 4 — automation may be added for Tier 4 preparation tasks only |
| `release-verification` + G-DEPLOY decision | Go/hold carries operational, customer, and business accountability that requires a named human SRE | Draft checklist can be auto-generated; decision always manual |
| Critical/high severity CVE triage assessment | Security champion review required before any proposed change is acted upon | Initial triage *notification* can be automated; assessment review stays manual |
| `runbook-draft` validation | Runbooks are operational accountability documents; accuracy must be verified by the SRE who will use them in incidents | Draft can be AI-generated at any time; validation and publish always human |
| All setup prompts (`setup-*`) | Initial configuration sets the governance foundation for everything downstream; errors compound across the full project lifecycle | Always human-reviewed before any config file is committed |
| Any prompt for a new team in their first 2 sprints | Teams need to develop context and judgment before automation reduces their direct engagement with the workflow | After team demonstrates consistent gate adherence for 2 sprints, selective automation may be introduced |
| Any prompt where `project-context.md` is stale (>90 days without review) | Stale context produces unreliable AI output; automation with stale context is worse than manual | Automated staleness check must pass before any event trigger fires |

---

## 11. What Should Not Be Built Yet

Building these before the prerequisites are met adds complexity without benefit and risks introducing trust-eroding failures.

| Item | Why not now | Prerequisites before building |
|------|-------------|-------------------------------|
| ACP runtime service (persistent, deployed) | Adds new failure modes before the simpler state file + gate checker is validated; MVO must be proven first | Level 2 fully operational; MVO proven in pilot; dedicated ADR for runtime technology choice |
| Multi-agent orchestrator service | Same as above; additionally requires ACP runtime stability | ACP runtime stable; 2+ stable sprints at Level 3 |
| Write MCP for any agent | Write automation with incomplete or stale context is worse than no automation; read path must be validated per agent first | Read MCP validated; branch-scoped write policy reviewed by security champion; security champion approves each new write scope |
| Autonomous merge of any PR class | Requires Level 4 advancement criteria (not yet met) and a formal governance exception | All Level 3 criteria met; governance exception approved; branch protection controls verified; audit logging in place |
| Autonomous production deployment | Not planned — permanent human gate | Not applicable |
| Figma / design-to-spec MCP | Low ROI until design-to-spec workflow is defined; design tooling MCP has significant scope and data-handling implications | Design workflow defined; MCP evaluated for data handling; dedicated prompt and ACP contract designed |
| Jira write access (issue creation, status transitions) | Write scope is hard to bound safely without issue schema validation; creates risk of incorrect state transitions in the project tracker | Jira read MCP validated; write scope formally bounded; schema validation in place |
| Off-the-shelf multi-agent framework (LangGraph, AutoGen, etc.) as primary runtime | Creates a hard dependency for a governance-critical workflow; opaque failure modes; licensing and data-handling risk | Evaluate after MVO is proven; off-the-shelf frameworks should wrap MVO contracts, not replace them |

---

## References

- Governing ADR: `ai-sdlc/adr/ADR-002-ai-sdlc-architecture-evolution.md`
- Agent model: `ai-sdlc/agents.md`
- ACP topology (future state): `ai-sdlc/acp/acp-agent-topology.md`
- ACP handoff contracts: `ai-sdlc/acp/acp-handoff-contracts.md`
- ACP workflow example: `ai-sdlc/acp/acp-workflow-example.md`
- Automation maturity model: `ai-sdlc/governance/automation-maturity-model.md`
- Human-in-the-loop policy: `ai-sdlc/governance/human-in-the-loop-policy.md`
- Approval gates and SLAs: `ai-sdlc/governance/approval-gates.md`
- Enterprise engineering guardrails: `ai-sdlc/governance/enterprise-engineering-guardrails.md`
- Work tier classification: `ai-sdlc/work-tiers.md`
- Branch protection setup: `ai-sdlc/adoption/branch-protection-setup.md`
- Operator workflow: [`docs/operating-model/current-sdlc-flow.md`](../../docs/operating-model/current-sdlc-flow.md)
