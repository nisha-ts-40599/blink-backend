# Normalized Issue Model

**Purpose:** Provider-neutral internal issue metadata used by prompts, groom-prep, stage-router, and artifact tooling.

The framework does **not** assume Jira, Azure DevOps, GitHub Issues, Linear, or any single tracker. Configuration declares the provider; tools map external fields to this model.

---

## Configuration

Declare tracker settings in `.cursor/ai-sdlc/project-config.yaml` or, for multi-repo workspaces, `.cursor/ai-sdlc/workspace-config.yaml` (workspace-level takes precedence).

```yaml
issue_tracking:
  provider: manual  # jira | azure_devops | github_issues | linear | generic | manual
  mode: read_only   # read_only | write_with_approval | disabled
  base_url: "https://your-tracker.example.com"
  project_key: "PROJ"
  issue_id_pattern: "PROJ-123"
  issue_url_template: "https://your-tracker.example.com/browse/{issue_id}"
```

Legacy `tooling.issue_tracker` is still read as a fallback. Prefer `issue_tracking` for new overlays.

**Write policy:** Default mode is `read_only`. Any tracker write/update requires explicit human approval and `mode: write_with_approval`.

Schema: `schemas/issue/issue-tracking.schema.json`

---

## Normalized issue shape

All providers map to:

```yaml
issue:
  id: "<issue-id>"
  provider: "<provider>"
  url: "<issue-url>"
  title: "<title>"
  description: "<description>"
  acceptance_criteria: []
  status: "<normalized-status>"
  labels: []
  assignee: "<optional>"
  updated_at: "<optional>"
  source: tracker | manual | mcp | pasted | bundle
```

Schema: `schemas/issue/normalized-issue.schema.json`

---

## Detection

```bash
make ai-sdlc-resolve-issue-tracker ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

The resolver reads overlay config only — no credentials, no API calls, no hard failure when tracker config is missing (`manual` fallback).

---

## Prompt rules

- Use normalized issue metadata from the configured tracker provider when available.
- If tracker integration is unavailable, use manually provided issue details.
- Do not assume Jira or ADO.
- Do not fabricate issue status, acceptance criteria, approvals, or comments.
- Mark missing live tracker evidence as **missing evidence**.

---

## References

- [`adoption/prompt-input-source-map.md`](../adoption/prompt-input-source-map.md)
- [`adoption/developer-grooming-quick-guide.md`](../adoption/developer-grooming-quick-guide.md)
- [`prompts/stage-router.prompt.md`](../prompts/stage-router.prompt.md)
