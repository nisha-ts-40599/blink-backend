# Orchestrator Responsibilities

> The Orchestrator is a **coordinator**, not a super-agent. It reads workflow state, checks gate
> preconditions, routes work to specialist agents, and surfaces human interrupt requirements.
> It does not make product or technical decisions.
>
> **Current state:** The Orchestrator exists as design documentation and a reference Python implementation
> (`runtime/orchestrator.py`). The Python implementation is demo-only and not production-ready.
> As of Maturity Level 1, orchestration is performed manually by engineers following the
> `docs/operating-model/current-sdlc-flow.md`.
>
> Reference ADR: `adr/ADR-002-ai-sdlc-architecture-evolution.md`

---

## What the Orchestrator does

### 1. Track workflow state

The Orchestrator owns the workflow state file for each tracked piece of work
(`architecture/workflow-state-and-handoff-model.md`). It is the single source of truth for:

- Current SDLC stage
- Assigned work tier
- Gate records (approved/pending/missing)
- Agent assignments
- Artifact references and lineage
- Blocked, escalated, and rework states

The state file is updated atomically after each agent completion and gate event.

### 2. Determine current SDLC stage

At any point, the Orchestrator can answer: "What stage is this issue in, and what is required to advance?"

Stage determination is based on:
- Current `state` field in the workflow state file
- Gate records for the current tier
- Required artifacts for the current state (from the artifact checklist in `workflow-state-and-handoff-model.md`)
- CI status (read-only, via MCP)

### 3. Determine the next required agent

Given the current stage and tier, the Orchestrator routes work to the next appropriate specialist agent.

Routing rules:
- Tier 1 → compressed path (fewer gates; simpler handoffs)
- Tier 2 → standard path (G-PLAN required; all specialist agents used)
- Tier 3 → extended path (G-PLAN + G-SEC; Architecture Review Agent included)
- Tier 4 → maximally governed path (all gates; every specialist agent; dual approvals for destructive steps)

The routing table is defined in `orchestration/workflow-state-model.yaml` and `orchestration/orchestrator-state-machine.md`.

### 4. Gather required context

Before invoking any agent, the Orchestrator assembles the minimum required context:

- `project-context.md` for the target repository
- Issue body and linked artifacts
- Prior agent outputs from the workflow state file
- Current gate records
- Engineering guardrails (from `governance/enterprise-engineering-guardrails.md`)
- Project-specific rule overrides (from `project-config.yaml`)

The context aggregator component (`architecture/multi-agent-evolution-roadmap.md` §5) assists with this.

### 5. Validate prerequisites

Before routing to any agent, the Orchestrator checks:

- Required input artifacts are present and non-stale
- `project-context.md` is within the 90-day freshness window
- The required gate for the current transition is recorded (via gate checker)
- No open blocking questions exist in the current stage
- CI is green (for post-implementation stages)

If any prerequisite fails, the Orchestrator enters a `waiting_for_artifact` or `blocked` state and
notifies the relevant human.

### 6. Check whether a human gate is required

The Orchestrator checks the gate conditions defined in `governance/approval-gates.md` for the
current stage and tier:

| Transition | Gate check |
|-----------|-----------|
| Planning complete → Implementation begins | G-PLAN: written approval from engineering lead |
| Tier 3+ planning | G-SEC: security champion review recorded |
| Implementation complete → PR merge | G-PR-MERGE: branch protection + 1 human reviewer |
| Release → Production deployment | G-DEPLOY: authorized human executes deployment |

If a gate is required and not yet recorded, the Orchestrator stops the pipeline and generates
a human-action notice with:
- Gate ID and description
- Required approver(s)
- SLA deadline (from `governance/approval-gates.md`)
- Escalation path

### 7. Identify missing artifacts

The Orchestrator checks the artifact checklist for the current stage against the state file's
`artifacts` map. Missing required artifacts cause the workflow to enter `waiting_for_artifact`
state with a notification to the engineer responsible for producing them.

### 8. Route work to the next agent

Once prerequisites are validated and gate conditions are met, the Orchestrator:

1. Selects the next agent based on the routing table
2. Assembles the ACP handoff envelope (per `schemas/acp/handoff-envelope.schema.json`)
3. Populates the required payload fields
4. Sets the expected output artifact types
5. Records the routing event in the audit log
6. Hands off to the agent (via ACP at Level 3; via manual prompt today)

### 9. Record outputs

When an agent completes its stage, the Orchestrator:

- Validates the output payload against the payload schema
- Records the produced artifacts in the state file
- Updates `current_stage` and `updated_at`
- Links artifacts in the relevant issue (via GitHub MCP)
- Emits an audit event

### 10. Maintain artifact lineage

Every artifact produced by an agent is linked to:
- The issue that triggered the work
- The handoff contract that requested the artifact
- The agent that produced it
- The timestamp and schema version

Lineage is stored in the workflow state file and the audit log, enabling full traceability
from requirement to deployment.

### 11. Recommend next human action

The Orchestrator produces a human-readable status report at each checkpoint:

- Current stage
- Completed stages with artifact links
- Current gate status (approved / pending / missing)
- Next required human action (specific person, specific action, SLA)
- Blocked items with resolution guidance

This report is posted as an issue comment and is the primary interface between the
Orchestrator and the engineer.

### 12. Stop when required context or approval is missing

The Orchestrator applies a **fail-open, not fail-silent** policy. It stops and notifies rather
than proceeding with incomplete information. Specific stop conditions:

- Required artifact is missing or stale
- Gate is required but not recorded
- `project-context.md` is older than 90 days
- Conflicting or unresolved open questions remain
- CI is failing at a post-implementation stage
- Security finding is in `must-fix` state with no remediation PR
- Agent output fails payload schema validation

Stop events are recorded in the audit log as `AUD-EVT-BLOCKED-*` events.

---

## What the Orchestrator does NOT do

### Does not replace specialist agents

The Orchestrator does not perform requirement analysis, write code, review PRs, or interpret
monitoring signals. It delegates to specialist agents for each task. This is the core
specialization principle — each agent loads focused context; the Orchestrator loads routing context.

### Does not silently skip gates

Gate checks are hard preconditions. The Orchestrator never sets a gate as "approved by default",
never infers approval from silence, and never advances a workflow past a required gate without
a recorded, named-human approval. Gate bypass is a security and audit violation.

### Does not hide uncertainty

When the Orchestrator cannot determine the correct next action (ambiguous state, missing routing
rule, unexpected agent output), it stops and surfaces the ambiguity to the engineer. It does not
guess and proceed. Every open question is logged and escalated.

### Does not create project-specific rules inside the core framework

Project-specific overrides belong in `project-config.yaml`. The Orchestrator loads and applies
these overrides but does not modify the core framework rules (`rules/global-rule-index.md`) on
behalf of any project.

### Does not override project policies

If a project's `project-config.yaml` defines a tier override, a custom SLA, or an extended
approval rule, the Orchestrator applies those project policies without modification. It cannot
override a project's security model, deployment model, or approval requirements.

### Does not mark work complete without required evidence

Work is marked `COMPLETED` only when:
- All required artifacts for the current stage are recorded
- The required gate for the stage transition is approved
- CI is green (where applicable)
- No open must-fix items exist in the most recent review output

Claiming completion without evidence is an audit violation.

---

## Orchestrator component model

The Minimum Viable Orchestrator (MVO) is built incrementally. Detailed component specifications
are in `architecture/multi-agent-evolution-roadmap.md` §5.

| Component | Purpose | When to build |
|-----------|---------|--------------|
| Workflow state file | Per-issue YAML file tracking stage, tier, gates, artifacts | Week 2–3 (manually filled first) |
| Gate checker | Script verifying gate records before stage transitions | Week 2–3 |
| Stage router prompt | Meta-prompt reading state file and recommending next action | Week 3–4 |
| Event hooks | GitHub Actions steps triggering agents on events | Week 4–6 |
| Artifact linker | Verifies all required artifacts exist before gate check | Week 4–6 |
| Context aggregator | Assembles agent context from state file + MCP | Week 4–8 |
| ACP message handler | Sends/receives ACP handoff envelopes between agents | Level 3 (future) |
| Orchestrator service | Persistent deployed service running the state machine | Level 3 (future) |
| **Context aggregator** | **Assembles the full context bundle for an agent before invocation** | **Available now (local script)** |
| **Stage router prompt** | **Reads workflow state and recommends the next agent/prompt** | **Available now (manual prompt)** |

---

## Orchestrator operating constraints

From `adr/ADR-002-ai-sdlc-architecture-evolution.md`:

1. **Human gates are permanent** — The Orchestrator never bypasses G-PLAN, G-SEC, G-PR-MERGE, or G-DEPLOY.
2. **Orchestrator routes but does not decide** — Routing is deterministic based on state; decisions belong to humans and specialist agents.
3. **Read-only MCP by default** — The Orchestrator's MCP posture is read-only except for the workflow state file path.
4. **Audit trail required** — Every state transition emits an audit event per `governance/audit-log-requirements.md`.
5. **Context freshness enforced** — The Orchestrator checks `project-context.md` age before any agent invocation; stops at 90-day staleness.

---

## Context aggregator and stage router (available now)

Two MVO components are operational today without a running Orchestrator service:

**Context aggregator** (`tools/orchestration/build_context_bundle.py`): Reads workflow state, project-context.md, and project-config.yaml and produces a validated context bundle (`schemas/context/context-bundle.schema.json`). Reduces manual placeholder filling from 8–12 items to 2–3. Run with `make ai-sdlc-context-bundle-example`. See `orchestration/context-aggregator.md`.

**Stage router** (`prompts/stage-router.prompt.md`): Given a context bundle or workflow state summary, recommends the next agent, next prompt, required placeholders, missing gates, and whether it is safe to proceed. Run manually: paste workflow state + project context as input. See `architecture/workflow-state-and-handoff-model.md` for the stage transition table.
