# Project Onboarding Model

> This document defines how a live internal project is onboarded onto the AI-SDLC framework.
> It specifies required metadata, configuration, and context files, as well as how agents
> behave when project context is incomplete.
>
> For a step-by-step walkthrough, see `adoption/live-project-handover-guide.md`.
> For setup prompts, use `prompts/setup-existing-project.prompt.md` or `prompts/setup-new-project.prompt.md`.

---

## Onboarding objectives

1. Ensure agents have sufficient, accurate project context to produce reliable outputs.
2. Establish the governance configuration for the project (tiers, approval roles, MCP integrations).
3. Set up CI enforcement so the framework's quality gates are active from day one.
4. Enable the engineering team to use the 12-step Cursor workflow immediately.

---

## Required project metadata

### 1. Repository structure

| Field | Description | Where defined |
|-------|-------------|---------------|
| Repo name | Canonical repository identifier | `project-config.yaml` |
| Primary language(s) | Backend and frontend language(s) | `project-context.md` |
| Framework(s) | e.g., FastAPI, Spring Boot, Next.js, Django | `project-context.md` |
| Monorepo / polyrepo | Single repo or distributed services | `project-context.md` |
| Key directory structure | Source, tests, docs, infra layout | `project-context.md` |

### 2. Tech stack

| Field | Description |
|-------|-------------|
| Backend runtime | Language, version, runtime (e.g., Python 3.12, JVM 21) |
| Frontend stack | Framework, bundler, CSS system |
| Database(s) | Type, platform, migration tool |
| Message queue / event bus | If applicable |
| External services | Key third-party APIs, identity providers, payment processors |
| Containerisation / orchestration | Docker, Kubernetes, ECS |

### 3. Build and test commands

| Command | Description |
|---------|-------------|
| `build` | Full build command |
| `test:unit` | Unit test command with coverage |
| `test:integration` | Integration test command |
| `lint` | Linter command |
| `format` | Auto-format command |
| `db:migrate` | Migration execution command |
| `db:rollback` | Migration rollback command |

These are recorded in `project-config.yaml` under `commands`.

### 4. Deployment model

| Field | Description |
|-------|-------------|
| Environments | dev, staging, production (and any intermediate) |
| Deployment method | CI/CD pipeline, manual, blue/green, canary |
| Deployment tooling | GitHub Actions, ArgoCD, Terraform, etc. |
| Release frequency | Sprint-based, continuous, scheduled window |
| Rollback approach | Git revert + redeploy, feature flag, traffic shift |

### 5. Coding conventions

| Field | Description |
|-------|-------------|
| Code style guide | Link or name (e.g., PEP 8, Google Java Style) |
| Naming conventions | Classes, functions, files, constants |
| Module/package structure | How code is organised |
| Error handling approach | Exception types, error wrapping, HTTP error mapping |
| Logging conventions | Log levels, structured vs. unstructured, PII masking |
| Comment policy | When to comment; what is prohibited |

### 6. Security constraints

| Field | Description |
|-------|-------------|
| Data classification | Public, internal, confidential, restricted, PII |
| Authentication scheme | JWT, OAuth2, API key, session |
| Authorization model | RBAC, ABAC, row-level security |
| Secret management | Vault, KMS, environment variables, secret rotation policy |
| PII handling | Fields containing PII; masking requirements |
| Compliance requirements | GDPR, HIPAA, PCI-DSS, SOC2, FERPA, etc. |

### 7. API conventions

| Field | Description |
|-------|-------------|
| API style | REST, GraphQL, gRPC, event-driven |
| Versioning strategy | URL versioning, header versioning, semantic versioning |
| OpenAPI spec location | Path in repository |
| Pagination convention | Cursor, offset, page number |
| Error response format | Schema for error responses |
| Authentication in API | How auth tokens are passed |

### 8. Database migration conventions

| Field | Description |
|-------|-------------|
| Migration tool | Alembic, Flyway, Liquibase, Prisma, etc. |
| Migration directory | Path in repository |
| Naming convention | e.g., `V001__description.sql` |
| Zero-downtime requirement | Yes/no; expand-contract pattern required? |
| Rollback requirement | Down migration required for all changes? |
| Data migration policy | Separate data migrations from schema migrations? |

### 9. Test conventions

| Field | Description |
|-------|-------------|
| Test framework | pytest, JUnit, Jest, RSpec, etc. |
| Test directory structure | Where unit, integration, e2e tests live |
| Coverage tool | coverage.py, JaCoCo, Istanbul, etc. |
| Coverage threshold | Minimum coverage % (overall and per-module) |
| Contract testing | Pact or equivalent; consumer/provider registry |
| Test naming convention | Naming pattern for test functions/classes |

### 10. Documentation locations

| Type | Location |
|------|----------|
| API docs (OpenAPI) | Path or URL |
| Architecture docs | Path or external URL (Confluence, Notion) |
| Runbooks | Path or external URL |
| ADR store | Path in repository |
| User documentation | External URL |
| Changelog | Path in repository |

### 11. Ownership model

| Field | Description |
|-------|-------------|
| Engineering lead | Named person: approval authority for G-PLAN, G-DEPLOY |
| Security champion | Named person: approval authority for G-SEC |
| On-call / SRE | Named person or rotation: deployment executor |
| Tech lead / architect | Named person: ADR and architecture decisions |
| Product owner | Named person: requirement and acceptance criteria approval |

### 12. Approval roles

These map directly to the approval gates in `governance/approval-gates.md`:

| Gate | Required approver |
|------|-----------------|
| G-PLAN | Engineering lead |
| G-SEC | Security champion |
| G-PR-MERGE | Peer reviewer (branch protection) |
| G-DEPLOY | Engineering lead or authorized SRE |

### 13. MCP integrations available

List which MCP integrations are configured and validated for this project:

| Integration | Status | Notes |
|-------------|--------|-------|
| GitHub read | — | Required |
| Jira read | — | Optional |
| Figma read | — | Optional |
| Confluence read | — | Optional |
| Observability read | — | Optional |
| Feature branch write | — | Level 2+ only |

### 14. CI capabilities

| CI tool | Status | Notes |
|---------|--------|-------|
| GitHub Actions | — | Required for AI-SDLC CI jobs |
| Branch protection | — | Required for gate enforcement |
| SAST / CodeQL | — | Recommended |
| Dependency scanning | pip-audit / npm audit / etc. | Recommended |
| Secret scanning | Gitleaks (AI-SDLC CI) | Provided by framework |
| Coverage reporting | — | Project-configured |

### 15. Project-specific overrides

Projects may override or extend framework defaults in `project-config.yaml`:

```yaml
ai_sdlc_version: "1.x"
project_id: "my-service"
rules:
  overrides:
    RULE-DB-002: { relax_zero_downtime: false }  # tighten — never relax ZDT
  extensions:
    - id: "RULE-EXT-001"
      name: "HIPAA PHI encryption"
      description: "All PHI fields encrypted at rest with AES-256"
tier_defaults:
  auth_changes: 3          # elevate auth changes to Tier 3 minimum
  pii_access: 3
context_freshness_days: 30  # tighter than default 90
approval_roles:
  g_plan: "@engineering-lead"
  g_sec: "@security-champion"
  g_deploy: "@sre-team"
mcp:
  github_read: true
  jira_read: true
  figma_read: false
```

---

## Minimum required project-context.md

A `project-context.md` is considered **minimally complete** if it contains:

1. Project name and one-sentence description
2. Primary language and framework
3. Tech stack summary (backend, frontend, database)
4. Key architectural decisions (top 3 relevant to daily development)
5. Coding conventions summary (naming, structure, error handling)
6. Test framework and coverage expectation
7. Deployment model summary
8. Security/data sensitivity summary
9. Ownership model (engineering lead, security champion)
10. Last reviewed date

An incomplete `project-context.md` (missing 3 or more of the above) triggers incomplete
onboarding detection and prevents agent invocation in Maturity Level 2+.

---

## Minimum required project-config.yaml

A `project-config.yaml` is considered **minimally complete** if it contains:

1. `ai_sdlc_version`
2. `project_id`
3. `tech_stack` (at minimum: language, framework, db)
4. `commands` (at minimum: build, test, lint)
5. `approval_roles` (g_plan approver name; g_deploy approver name)
6. `mcp` block with at least `github_read: true`

---

## How to detect incomplete onboarding

The Project Onboarding Agent produces an **onboarding gap report** identifying:

| Check | Minimum complete | Warning | Block |
|-------|-----------------|---------|-------|
| `project-context.md` exists | yes | no | n/a |
| `project-context.md` has ≥7 of 10 required fields | yes | <7 | <5 |
| `project-config.yaml` exists | yes | no | n/a |
| `project-config.yaml` has all minimum fields | yes | missing 1 | missing 2+ |
| Approval roles named | yes | missing 1 | missing all |
| Context freshness | ≤90 days | 61–90 | >90 |
| Branch protection configured | recommended | not configured | n/a |
| GitHub Actions running | recommended | never triggered | n/a |

**Block** conditions prevent agent invocation and must be resolved before work begins.
**Warning** conditions are surfaced but do not block Level 1 usage.

---

## How agents behave when project context is missing

| Missing context | Agent behaviour |
|----------------|----------------|
| `project-context.md` missing entirely | Agent refuses to proceed. Provides onboarding gap report. Refers to `setup-existing-project.prompt.md`. |
| `project-context.md` is stale (>90 days) | Agent stops. Surfaces staleness alert. Recommends context refresh before any work begins. |
| `project-config.yaml` missing | Agent uses framework defaults for non-critical fields. Flags missing approval roles as blocking. |
| Ownership roles not named | Orchestrator cannot check gates. Surfaces as blocking gap. |
| MCP not configured | Agent proceeds with manually supplied context. Flags MCP gaps as usability improvement. |
| Tech stack unclear | Agent asks clarification questions before producing implementation output. |
| Security model unclear | Security Review Agent and Work Classification Agent default to most-conservative classification. |

---

## Onboarding steps for a live project

1. **Run `setup-existing-project.prompt.md`** — Produces draft `project-config.yaml` and `project-context.md`.
2. **Engineering lead reviews and approves** the generated configuration files.
3. **Commit approved config files** — Never commit AI-generated config without human review.
4. **Configure GitHub Actions** — Trigger the AI-SDLC conformance workflow at least once.
5. **Configure branch protection** — Require AI-SDLC Conformance + Gitleaks + pip-audit.
6. **Set up GitHub read-only MCP** — Per `mcp/github-readonly-setup.md`.
7. **Brief the pilot team** — Share `docs/operating-model/current-sdlc-flow.md` and `adoption/live-project-handover-guide.md`.
8. **Run the first issue through the 12-step workflow** — Document gaps and update `project-context.md`.
9. **Set a 90-day context freshness reminder** — Calendar or issue tracker alert.
