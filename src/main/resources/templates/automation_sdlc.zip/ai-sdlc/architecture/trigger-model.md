# AI-SDLC Trigger Model

> **Current state (Level 1):** All triggers are manual. Engineers decide when to invoke each
> prompt and supply all context manually. No event-driven invocation is active today.
>
> **Target state (Level 2–3):** Selected triggers become event-driven. Each trigger is only
> activated after the corresponding read-only MCP access is validated and the agent output
> quality is confirmed through pilot observation.
>
> Governing ADR: `adr/ADR-002-ai-sdlc-architecture-evolution.md` (Principle 5: MCP read path before automation).

---

## Trigger type definitions

| Type | Description | Complexity | Minimum maturity level |
|------|-------------|-----------|----------------------|
| **Manual trigger** | Engineer explicitly invokes an agent prompt with manually supplied context | None | Level 1 (current) |
| **Event trigger** | A system event automatically invokes an agent; output is advisory or informational | Medium | Level 2 |
| **Scheduled trigger** | Time-based trigger (e.g., weekly context freshness check) | Low | Level 2 |
| **Compound trigger** | Multiple conditions must be true before trigger fires | High | Level 3 |

---

## 1. Manual Trigger (all stages today)

**Source system:** Engineer (Cursor IDE or terminal)
**Event:** Prompt invoked explicitly
**Target agent:** Any agent
**Required context:** All placeholders filled manually by engineer
**Required MCP:** None (context is supplied directly)
**Output artifact:** Per-prompt output reviewed and acted on by engineer
**Human review required:** Yes — engineer reviews every output
**Safe maturity level:** Level 1+
**Current status:** ✅ ACTIVE — all 22 prompts are manual triggers today
**Risks:** Context quality depends on engineer; placeholder errors produce unreliable output
**Controls:** Prompt placeholder catalog validation (`make ai-sdlc-prompt-check`); engineer review of every output

---

## 2. GitHub Issue Created Trigger

**Source system:** GitHub
**Event:** Issue created with AI-SDLC label (e.g., `ai-sdlc-intake`) or in configured projects
**Target agent:** Requirement Analyst Agent
**Required context:** Issue body; project-context.md (via MCP); domain context
**Required MCP:** GitHub issues read
**Output artifact:** Structured requirement doc posted as issue comment; open questions list
**Human review required:** Yes — product owner or engineering lead confirms requirement
**Safe maturity level:** Level 2
**Risks:** Issue body may be too sparse for reliable requirement structuring
**Controls:** Minimum issue template enforced; agent posts draft for human confirmation; does not auto-advance workflow

---

## 3. Jira Issue Created / Moved Trigger

**Source system:** Jira
**Event:** Issue created in configured project, or issue moved to "Ready for Development" column
**Target agent:** Requirement Analyst Agent
**Required context:** Jira issue fields; project-context.md (via MCP); Jira project context
**Required MCP:** Jira read
**Output artifact:** Structured requirement doc; open questions list
**Human review required:** Yes — product owner confirms requirement before advancement
**Safe maturity level:** Level 2 (after Jira MCP is validated)
**Risks:** Jira field mapping varies by project; misread fields produce incorrect requirements
**Controls:** Jira field mapping defined in `project-config.yaml`; output is draft only; human confirmation required

---

## 4. Figma Design Published / Updated Trigger

**Source system:** Figma
**Event:** Design file published or specific frame/page published to dev-ready status
**Target agent:** Frontend Implementation Agent (future: dedicated Design-to-Spec Agent)
**Required context:** Figma frame content; component library; UI conventions
**Required MCP:** Figma read
**Output artifact:** UI implementation spec; component mapping; acceptance criteria draft for UI
**Human review required:** Yes — designer and product owner review spec before implementation
**Safe maturity level:** Level 2–3 (after Figma MCP and design-to-spec workflow defined)
**Risks:** Design intent is not always expressed in file structure; agent may misinterpret layout intent
**Controls:** Design-to-spec prompt must be defined before trigger is activated; designer reviews output; dedicated ADR required

---

## 5. Pull Request Opened Trigger

**Source system:** GitHub
**Event:** Pull request opened against main or a designated base branch
**Target agent:** PR Review Agent
**Required context:** PR diff; linked issue; CI status; self-review output; engineering guardrails
**Required MCP:** GitHub PR read; CI status read
**Output artifact:** AI review comment posted on PR (advisory)
**Human review required:** Yes — G-PR-MERGE requires human reviewer approval regardless of AI review
**Safe maturity level:** Level 2 (low risk; output is advisory comment)
**Current status:** Can be implemented as a GitHub Actions step today
**Risks:** AI review without full project context may produce irrelevant or incorrect comments
**Controls:** Agent must read `project-context.md` from repo; review comment is clearly labeled "AI Review (advisory)"; must-fix findings require human confirmation

---

## 6. CI Failure Trigger

**Source system:** GitHub Actions
**Event:** CI job fails on feature branch or main
**Target agent:** Backend / Frontend Implementation Agent (for lint/test failures); Security Review Agent (for security job failures)
**Required context:** CI failure log; affected file list; branch context
**Required MCP:** GitHub CI results read; repository read
**Output artifact:** Failure analysis; suggested remediation steps (advisory)
**Human review required:** Yes — engineer reviews analysis and decides on fix
**Safe maturity level:** Level 2
**Risks:** CI failure analysis may surface incorrect root cause
**Controls:** Output is advisory; engineer reviews before applying; false-positive remediation is not auto-applied

---

## 7. Security Scan Finding Trigger

**Source system:** GitHub Actions (Gitleaks, SAST/CodeQL), Dependabot
**Event:** Secret detected, SAST finding above severity threshold, or Dependabot security alert
**Target agent:** Security Review Agent
**Required context:** Scan output; diff (if applicable); security model from project config
**Required MCP:** GitHub security alerts read; SAST results read
**Output artifact:** Security triage assessment; remediation recommendation; tier elevation recommendation if applicable
**Human review required:** Yes — security champion reviews all security findings; no finding is auto-waived
**Safe maturity level:** Level 2 (notification and triage only; no autonomous remediation)
**Risks:** Over-broad triage may flood engineers with low-signal alerts
**Controls:** Severity threshold configured per project; security champion reviews all tier-elevation recommendations; output is advisory

---

## 8. CVE / Dependency Alert Trigger

**Source system:** Dependabot, pip-audit (CI), npm audit, GHSA
**Event:** CVE alert or dependency vulnerability found in production dependency
**Target agent:** Security Review Agent
**Required context:** CVE ID; affected dependency version; codebase usage; upgrade path
**Required MCP:** GitHub Dependabot alerts read; OSV/GHSA database read
**Output artifact:** CVE triage report; upgrade recommendation; breaking change risk assessment; license check
**Human review required:** Yes — security champion reviews triage; engineer executes upgrade
**Safe maturity level:** Level 2
**Current status:** Partially active — pip-audit CI job fires; triage requires manual prompt invocation
**Controls:** One-CVE-per-PR rule (RULE-DEP-001); triage is advisory; engineer opens the upgrade PR manually

---

## 9. Deployment Completed Trigger

**Source system:** CI/CD pipeline (GitHub Actions, ArgoCD, etc.)
**Event:** Deployment to target environment confirmed complete
**Target agent:** Monitoring / Feedback Agent
**Required context:** Deployment confirmation; monitoring window duration; observability data
**Required MCP:** Observability platform read; deployment log read
**Output artifact:** Monitoring signal interpretation; go/hold/escalate recommendation
**Human review required:** Yes — on-call SRE reviews recommendation; rollback is human-only
**Safe maturity level:** Level 2–3 (requires observability MCP to be configured)
**Risks:** Observability data may not be available immediately post-deploy; false anomaly alerts
**Controls:** Configurable observation window; human on-call must acknowledge the report; no autonomous action

---

## 10. Monitoring Alert Trigger

**Source system:** Datadog, Grafana, PagerDuty, or equivalent
**Event:** Alert fired above defined severity threshold during post-deploy window
**Target agent:** Monitoring / Feedback Agent
**Required context:** Alert details; deployment context; current metric state
**Required MCP:** Observability platform read
**Output artifact:** Alert characterisation; rollback conditions for human decision; incident starter (if warranted)
**Human review required:** Yes — on-call SRE receives notification and makes incident/rollback decision
**Safe maturity level:** Level 2 (notification + characterisation; no autonomous response)
**Risks:** Alert noise may cause alert fatigue; alert during unrelated deploy may produce incorrect correlation
**Controls:** Agent characterises alert in context of recent deployment; human makes all incident decisions

---

## 11. Incident Closed Trigger

**Source system:** PagerDuty / Jira Service Management / equivalent
**Event:** Incident marked resolved
**Target agent:** Knowledge Update Agent
**Required context:** Incident summary; root cause; changes deployed during incident window; retro notes
**Required MCP:** Incident management system read (future)
**Output artifact:** Runbook update suggestions; `project-context.md` freshness suggestions; retro items
**Human review required:** Yes — SRE and engineering lead review runbook updates before merge
**Safe maturity level:** Level 2–3
**Risks:** Incident root cause may be inaccurately attributed
**Controls:** Output is draft and suggestions only; post-incident review by engineering lead before any runbook change is merged

---

## 12. Scheduled Context Freshness Trigger

**Source system:** GitHub Actions (cron schedule) or calendar reminder
**Event:** `project-context.md` age exceeds 60 days (warning) or 90 days (block)
**Target agent:** Knowledge Update Agent
**Required context:** Current `project-context.md`; recent changes (last 90 days of merged PRs)
**Required MCP:** GitHub repo read; PR history read
**Output artifact:** Context freshness report: which fields are likely stale; suggested updates
**Human review required:** Yes — engineering lead reviews and updates `project-context.md`
**Safe maturity level:** Level 2
**Risks:** Auto-suggested updates may introduce inaccuracies
**Controls:** Suggestions are draft; engineering lead approves before commit; 90-day block is hard — agents refuse to proceed until context is updated

---

## Trigger activation sequence (recommended)

Activate triggers in this order, validating each before the next:

| Phase | Trigger | When to activate |
|-------|---------|-----------------|
| Week 1–2 | Manual (all) | Active now |
| Week 4–6 | PR opened → AI review | After GitHub Actions is stable |
| Week 4–6 | CVE/Dependabot alert → Security Agent | After pip-audit CI job validated |
| Week 4–6 | CI failure → Implementation Agent | After GitHub MCP read is validated |
| Week 6–8 | Scheduled context freshness | After 1 sprint of stable operation |
| Week 7–10 | GitHub issue created → Analyst | After Jira/GitHub MCP read is validated |
| Level 3 | Deployment completed → Monitoring | After observability MCP is validated |
| Level 3 | Incident closed → Knowledge Update | After incident management MCP is validated |
| Level 3+ | Figma published → Frontend Agent | After Figma MCP and design-to-spec prompt defined |
