# Workflow State and Handoff Model

> This document defines the complete SDLC state machine: states, transitions, required artifacts,
> gate conditions, agent assignments, handoff contract format, artifact lineage, and error recovery.
>
> **Relationship to existing docs:**
> - State machine design: `orchestration/orchestrator-state-machine.md`
> - State model YAML (runtime subset): `orchestration/workflow-state-model.yaml`
> - Handoff envelope schema: `schemas/acp/handoff-envelope.schema.json`
> - ACP contracts: `acp/contracts/` (per-transition contracts)
> - Workflow state schema: `schemas/workflow/workflow-state.schema.json`

---

## SDLC States

| State | Description | Stage label |
|-------|-------------|-------------|
| `REQUIREMENT` | Raw requirement received; intake in progress | Requirement intake |
| `CLASSIFIED` | Tier proposed; human confirmation required | Work classification |
| `SPEC_DRAFTED` | Structured spec and clarified requirement complete | Specification |
| `PLAN_DRAFTED` | Technical plan produced; G-PLAN clock started | Planning |
| `PLAN_APPROVED` | G-PLAN written approval recorded | Plan approved |
| `SECURITY_REVIEW` | G-SEC required (Tier 3+); security champion reviewing | Security gate |
| `IMPLEMENTING` | Implementation in progress (step-by-step) | Implementation |
| `REVIEW_REQUESTED` | Self-review and AI review complete; human review requested | Review |
| `PR_OPEN` | PR created; CI running; AI review posted | PR review |
| `APPROVED` | PR approved; CI green; G-PR-MERGE satisfied | Approved |
| `MERGED` | Code merged to main | Merged |
| `DEPLOYING` | G-DEPLOY approved; deployment executing under human control | Deployment |
| `DEPLOYED` | Deployment complete; monitoring window active | Post-deploy |
| `VERIFIED` | Monitoring window complete; signal reviewed by human | Verified |
| `COMPLETE` | Issue closed; all artifacts linked; documentation updated | Complete |
| `BLOCKED` | Prerequisites missing; awaiting human action | Blocked |
| `ESCALATED` | Blocker escalated to approver group | Escalated |
| `CANCELLED` | Work cancelled; reason recorded | Cancelled |

---

## State Transitions

| From | Event | To | Gate required | Agent responsible |
|------|-------|----|--------------|------------------|
| `REQUIREMENT` | Requirement structured + questions resolved | `CLASSIFIED` | Human confirms tier | Work Classification |
| `CLASSIFIED` | Tier human-confirmed | `SPEC_DRAFTED` | None (Tier 1); human Q&A confirmed (Tier 2+) | Clarification → Requirement Analyst |
| `SPEC_DRAFTED` | Technical plan produced | `PLAN_DRAFTED` | None — G-PLAN clock starts on entry | Technical Planning |
| `PLAN_DRAFTED` | G-PLAN written approval recorded | `PLAN_APPROVED` | **G-PLAN** | Orchestrator (gate check) |
| `PLAN_APPROVED` | Tier 3+: security review requested | `SECURITY_REVIEW` | **G-SEC** | Security Review |
| `PLAN_APPROVED` or `SECURITY_REVIEW` | Implementation begins | `IMPLEMENTING` | Gate(s) for tier satisfied | Backend/Frontend/DB Migration |
| `IMPLEMENTING` | All steps complete; self-review passed | `REVIEW_REQUESTED` | None — CI must be green | PR Review |
| `REVIEW_REQUESTED` | PR opened; AI review complete | `PR_OPEN` | None | PR Review |
| `PR_OPEN` | Human reviewer approves; CI green | `APPROVED` | **G-PR-MERGE** (branch protection) | Human reviewer |
| `APPROVED` | Human merges PR | `MERGED` | Human merge action | Human |
| `MERGED` | G-DEPLOY authorized; deployment begins | `DEPLOYING` | **G-DEPLOY** | Human SRE |
| `DEPLOYING` | Deployment complete | `DEPLOYED` | None — monitoring window begins | Monitoring / Feedback |
| `DEPLOYED` | Observation window elapsed; signals reviewed | `VERIFIED` | Human reviews signals | Human + Monitoring / Feedback |
| `VERIFIED` | Docs updated; issue closed | `COMPLETE` | None | Knowledge Update |
| `any non-terminal` | Prerequisite missing | `BLOCKED` | Surfaced to responsible human | Orchestrator |
| `BLOCKED` | Blocker escalated | `ESCALATED` | Named escalation target | Orchestrator |
| `ESCALATED` | Resolution recorded | Prior active state | Resolution artifact required | Orchestrator |
| `any non-terminal` | Work cancelled | `CANCELLED` | Reason recorded | Human |

---

## Required Artifacts Per State

| State | Required artifacts |
|-------|-------------------|
| `CLASSIFIED` | Structured requirement doc; open questions list |
| `SPEC_DRAFTED` | Confirmed spec; acceptance criteria; resolved open questions |
| `PLAN_DRAFTED` | Technical plan artifact; G-PLAN SLA deadline recorded |
| `PLAN_APPROVED` | G-PLAN approval record (issue comment URL + approver name) |
| `SECURITY_REVIEW` | Security assessment artifact; G-SEC status |
| `IMPLEMENTING` | Approved plan artifact ID; G-PLAN record; step completion notes per step |
| `PR_OPEN` | PR URL; CI status; AI review output; self-review output |
| `APPROVED` | Human reviewer approval event; CI green evidence |
| `MERGED` | Merge commit SHA; PR URL |
| `DEPLOYING` | G-DEPLOY approval record; deployment runbook reference |
| `DEPLOYED` | Deployment confirmation; monitoring window start timestamp |
| `VERIFIED` | Signal interpretation report; human go/hold decision record |
| `COMPLETE` | Documentation update PR; issue close record; all artifact links |

---

## Required Gates Per State Transition

| Transition | Gate ID | Required approver | SLA (default) |
|-----------|---------|------------------|---------------|
| `PLAN_DRAFTED` → `PLAN_APPROVED` | G-PLAN | Engineering lead | 2 business days |
| `PLAN_APPROVED` → `SECURITY_REVIEW` resolved | G-SEC | Security champion | 2 business days |
| `PR_OPEN` → `APPROVED` | G-PR-MERGE | 1 peer reviewer (branch protection) | Per team SLA |
| `APPROVED` → `MERGED` | Human merge | Engineering lead or PR author | Per team SLA |
| `MERGED` → `DEPLOYING` | G-DEPLOY | Engineering lead or authorized SRE | Per deployment window |

---

## Handoff Contract Format

All agent-to-agent handoffs use the ACP envelope schema defined in
`schemas/acp/handoff-envelope.schema.json`. Per-transition contracts are in `acp/contracts/`.

### Minimum valid handoff

```yaml
schema_version: "2.0"
handoff_id: "HDO-<UUID>"
correlation_id: "<issue-id>"
workflow_id: "WF-<PROJECT>-<NNN>"
from_agent: "<source-agent-role>"
to_agent: "<target-agent-role>"
payload_type: "<PayloadType>"
payload_schema: "acp.schemas/<PayloadType>/v2"
status: "pending"
retry_count: 0
idempotency_key: "<deterministic-hash>"
required_artifacts:
  - "<artifact-id>"
produced_artifacts: []
approval_state:
  required: false
  gate_ids: []
  status: "not_required"
audit_metadata:
  event_id: "AUD-EVT-<UUID>"
  actor: "<human-or-agent-id>"
  source_system: "ai-sdlc-orchestrator"
  trace_id: "<trace-id>"
timestamps:
  created_at: "<RFC3339-UTC>"
  updated_at: "<RFC3339-UTC>"
  due_at: null
error_code: null
escalation_state:
  is_escalated: false
payload:
  # payload fields per payload_type schema
```

---

## Artifact Lineage

Every artifact produced during the lifecycle is linked in the workflow state file:

```yaml
artifacts:
  requirement_doc: "<path-or-url>"
  spec_doc: "<path-or-url>"
  plan_doc: "<path-or-url>"
  g_plan_record: "<issue-comment-url>"
  g_sec_record: "<issue-comment-url>"        # null if not required
  implementation_prs: ["<pr-url-1>", "..."]
  test_coverage_report: "<ci-artifact-url>"
  ai_review_output: "<pr-comment-url>"
  self_review_output: "<pr-comment-url>"
  release_checklist: "<path-or-url>"
  monitoring_report: "<path-or-url>"
  docs_update_pr: "<pr-url>"
```

Lineage is immutable once written. Superseded artifacts are marked `invalidated` rather than deleted.

---

## Orchestration Helper Scripts

Three CLI scripts manage workflow state safely without manual YAML editing:

| Script | Command | Purpose |
|--------|---------|---------|
| `check_gates.py` | `make ai-sdlc-check-gates` | Verify required gate approvals before advancing |
| `validate_transition.py` | `make ai-sdlc-validate-transition` | Confirm a stage transition is permitted |
| `update_workflow_state.py` | `make ai-sdlc-update-state-dry-run` | Update workflow-state fields safely (dry-run by default) |

**Recommended flow for every stage advance:**
1. `check_gates.py` — gates satisfied? If no, get approval first.
2. `validate_transition.py --target-state <NEXT>` — transition allowed? If no, follow suggested_next_stage.
3. Run the prompt for the stage (see `architecture/agent-model.md`).
4. `update_workflow_state.py --set-current-stage <NEXT> --write` — update stage atomically.
5. Regenerate context bundle: `make ai-sdlc-context-bundle-example`.

See `tools/orchestration/` for full script documentation.

---

## Context Aggregator Integration

The workflow state file is the primary input to the **context aggregator**
(`tools/orchestration/build_context_bundle.py`). The aggregator reads the state file, extracts
gate records, artifact references, and prior agent summaries, and assembles a validated
**context bundle** (`schemas/context/context-bundle.schema.json`) that pre-fills most prompt
placeholders automatically.

The **stage router** (`prompts/stage-router.prompt.md`) takes the assembled context bundle
and produces a routing recommendation: current stage, gate status, missing artifacts,
`safe_to_proceed`, and the exact next human action.

Run locally: `make ai-sdlc-context-bundle-example`

---

## Workflow State File Structure

One file per tracked issue at `ai-sdlc/workflow-state/{issue-id}.yaml`.
Full JSON schema: `schemas/workflow/workflow-state.schema.json` (see adjacent file).

```yaml
schema_version: "1.0"
issue_id: "PROJ-123"
issue_url: "https://github.com/org/repo/issues/123"
title: "Add patient registration endpoint"
work_tier: 2
current_stage: "PLAN_DRAFTED"
gates:
  g_plan:
    required: true
    approved: false
    approver: null
    approved_at: null
    comment_url: null
    sla_due_at: "2026-07-01T17:00:00Z"
  g_sec:
    required: false
    approved: false
  g_pr_merge:
    required: true
    approved: false
    pr_url: null
  g_deploy:
    required: true
    approved: false
    approver: null
    approved_at: null
artifacts:
  requirement_doc: "ai-sdlc/workflow-state/PROJ-123/requirement.md"
  spec_doc: null
  plan_doc: "ai-sdlc/workflow-state/PROJ-123/technical-plan.md"
  g_plan_record: null
  implementation_prs: []
  ai_review_output: null
agent_outputs:
  analyst_summary: "Patient registration endpoint — 3 open questions resolved"
  planner_summary: "5-step plan: validation, service layer, DB write, test, docs"
  self_review_summary: null
  ai_pr_review_summary: null
blocked_reasons: []
updated_at: "2026-06-16T10:30:00Z"
```

---

## Blocked State Handling

When the Orchestrator detects a missing prerequisite, it transitions to `BLOCKED`:

1. Identifies the specific missing artifact or unmet gate condition.
2. Determines the responsible human (from `project-config.yaml` approval roles).
3. Posts a human-action notice to the issue with: missing item, responsible person, action required, SLA.
4. Records the block reason in `workflow_state.blocked_reasons`.
5. Does not proceed until the block is resolved and the prerequisite is present.

---

## Rework Loop Handling

When a review produces must-fix findings:

1. The workflow re-enters the `IMPLEMENTING` state (not a new state — stage counts increase).
2. The handoff to the Implementation Agent includes the must-fix list as required inputs.
3. The rework count is incremented in the state file.
4. If rework count exceeds the project threshold (default: 3 rounds), the Orchestrator escalates to the engineering lead.

---

## Escalation Handling

Escalation triggers:
- Gate SLA exceeded (G-PLAN: 2 business days, G-SEC: 2 business days)
- Rework count threshold exceeded
- Security finding with no remediation PR after 5 business days
- Blocking context gap unresolved after 1 business day

Escalation process:
1. Transition to `ESCALATED`.
2. Notify the escalation target (from `project-config.yaml` approval roles).
3. Record escalation ID and timestamp.
4. Do not advance or unblock automatically — resolution requires human action and a resolution artifact.
