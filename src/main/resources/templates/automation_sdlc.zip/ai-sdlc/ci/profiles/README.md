# CI Profile Pack

Reusable stack profiles for generic CI templates.

Each profile defines:

- `install_command`
- `build_command`
- `lint_command`
- `unit_test_command`
- `integration_test_command_placeholder`
- `coverage_command`
- `artifact_paths`

Profiles are intentionally generic and should be overridden by project-specific commands where needed.
