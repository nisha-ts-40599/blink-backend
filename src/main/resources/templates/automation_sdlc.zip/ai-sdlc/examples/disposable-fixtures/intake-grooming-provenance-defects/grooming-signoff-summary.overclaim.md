# Grooming Sign-off Summary — SAMPLE-INTAKE-GROOMING-01

> **Fixture artifact (overclaims)** — lists nine ACs as confirmed while workflow state has `human_confirmed: false`.

- AC-001: confirmed=yes
- AC-002: confirmed=yes
- AC-003: confirmed=yes
- AC-004: confirmed=yes
- AC-005: confirmed=yes
- AC-006: confirmed=yes
- AC-007: confirmed=yes
- AC-008: confirmed=yes
- AC-009: confirmed=yes
