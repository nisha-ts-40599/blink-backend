# Requirement: Login page times out after idle period

> Example only — generic product "Acme Portal". Sanitized; no real customer data or logs.

---

## 1. Requirement metadata

| Field | Value |
|-------|-------|
| **Issue ID** | BUG-442 |
| **Issue type (tracker)** | Bug |
| **Source** | Support ticket (sanitized summary) |
| **Product / project** | Acme Portal |
| **Requester** | Support queue |
| **Date** | 2026-06-01 |
| **Current workflow stage** | REQUIREMENT |
| **Suggested work tier (draft)** | 2 |

---

## 2. Requirement type

- [x] **Bug**

---

## 3. Requirement restatement

Authenticated users on the web login session are redirected to the login page with a
generic timeout message after approximately 15 minutes of inactivity, even when the user
is actively viewing a read-only dashboard tab.

---

## 4. Business goal / user pain

Users lose unsaved filter selections and must re-authenticate frequently, increasing
support volume and perceived unreliability.

---

## 5. Current behavior

After ~15 minutes without API activity, the next user action triggers redirect to `/login`
with message "Session expired." Reproducible in staging with a standard user account.

---

## 6. Expected behavior

Idle timeout remains configurable, but read-only dashboard views should not force logout
while the tab is visible and the session refresh endpoint returns success. User receives
clear warning before forced logout when applicable.

---

## 7. Reproduction steps (bugs only)

| Step | Action | Expected | Actual |
|------|--------|----------|--------|
| 1 | Log in to staging as role `viewer` | Dashboard loads | OK |
| 2 | Open dashboard; no clicks for 16 minutes | Session stays valid or warning shown | Redirect to login |
| 3 | Click any navigation item | Stays authenticated | Login page |

**Environment:** Staging, Chrome 125, desktop  
**Frequency / severity:** Often / medium — affects all viewer-role users  
**Error messages / logs (sanitized):** HTTP 401 on `/api/session/refresh`; UI message "Session expired."  
**Browser / device / version:** Chrome 125 / desktop (Firefox not yet tested)

---

## 8–9. Enhancement / new capability scope

N/A — bug fix.

---

## 10–11. Public references

None.

---

## 12. Privacy / copyright review

| Check | Status |
|-------|--------|
| No customer PII in this document | yes |
| No credentials or secrets | yes |
| Production data anonymized or excluded | yes |

---

## 13. Impacted systems / repos / modules

| System / module | Impact type | Notes |
|-----------------|-------------|-------|
| `web-app` session middleware | Likely | Idle timer / refresh handling |
| `auth-service` refresh endpoint | Possible | 401 response path |
| Dashboard read-only routes | Possible | Activity detection |

---

## 14. Data / security / compliance impact

| Area | Impact |
|------|--------|
| Auth / authz | Session lifecycle change — review idle policy |
| PII | None in repro |

---

## 15–16. Dependencies, edge cases

- Depends on existing session refresh contract.
- Edge: multiple tabs; background tab throttling; mobile browsers.

---

## 17. Refined acceptance criteria

1. **AC-001:** Viewer role can remain on read-only dashboard for configured idle period without
   unexpected logout when refresh succeeds — _human confirmed: pending_
2. **AC-002:** Forced logout shows user-visible warning at least 60 seconds before expiry when
   configurable — _human confirmed: pending_
3. **AC-003:** Automated regression test covers idle refresh success path — _human confirmed: pending_

---

## 18. Suggested test cases

### Regression

- Existing login/logout flows unchanged for active users

### Integration

- Session refresh called on idle boundary; 401 handled gracefully

### Negative / error

- Refresh failure redirects to login with stable error message

---

## 19. Risks and assumptions

| Item | Type | Notes |
|------|------|-------|
| Root cause in session middleware | assumption | Needs code/log confirmation |
| 15-minute timeout is intentional policy | assumption | Confirm with PO |

---

## 20. Open questions

| # | Question | Owner | Status |
|---|----------|-------|--------|
| 1 | Is 15-minute idle timeout a hard compliance requirement? | PO | open |
| 2 | Should warning UI be required for MVP fix? | PO | open |

---

## 21. Definition of Ready

**DoR status:** not ready — **Reason:** PO questions on timeout policy open.

---

## 22. Grooming decision

- [x] **Needs stakeholder clarification**

**Recommended next prompt:** Resolve open questions, then re-run clarify or proceed to
`classify-work` when DoR ready.

---

## 10. Persona review summary (inline for bug workflow)

### Business Analyst review

Goal and user pain clear; AC need PO confirmation on timeout policy.

### QA Analyst review

Repro steps documented; needs Firefox/mobile matrix; regression on auth flows required.

### Domain review

Fits standard session-management domain; confirm idle policy with product.

### Security / Data review

Auth session change — expect Tier 2 minimum; no G-SEC unless policy touches compliance.
