# Requirement: Admin activation should surface registration fee in pending dues

> **Example only** — generic product "Acme Academy Portal". Sanitized pattern based on
> real-project one-line bug grooming; no customer data, credentials, or private URLs.
> **DoR: not ready** — runtime verification pending (intentional).

---

## 1. Requirement metadata

| Field | Value |
|-------|-------|
| **Issue ID** | BUG-881 |
| **Issue type (tracker)** | Bug |
| **Source** | Internal backlog (one-line report) |
| **Product / project** | Acme Academy Portal |
| **Requester** | Support queue |
| **Date** | 2026-06-19 |
| **Current workflow stage** | REQUIREMENT |
| **Suggested work tier (draft)** | 2 |
| **Code analysis pass** | read-only — example |

---

## 2. Requirement type

- [x] **Bug**

**Type notes:** One-line Jira report; groomed via read-only code analysis across admin web,
mobile API, and payment display modules.

---

## 3. Requirement restatement

When an admin activates a member before registration payment is complete, the registration
fee should appear under pending dues. The one-line report implies the fee is missing from the
pending/outstanding payment view. Code analysis identifies likely activation and invoice
paths but **does not confirm root cause** without runtime repro.

---

## 4. Business goal / user pain

Organizations must collect registration fees when members are activated without prior payment.
Missing pending dues causes revenue leakage and manual admin follow-up.

---

## 5. Current behavior

**From Jira (Needs PO/QA confirmation):** When admin activates a member before payment,
registration fee does not appear under pending dues.

**Code-informed summary:**

| Finding | Detail | Label |
|---------|--------|-------|
| Activation flag | Admin activation API sends `skip_fee_setup=true` when fee-plan UI disabled | Confirmed from code |
| Fee setup skipped | When flag true, fee-setup endpoint not called; member marked active without invoice | Confirmed from code |
| Pending dues query | Payment history API returns unpaid invoices; empty list → UI shows "No pending payments" | Confirmed from code |
| Version delta | Older API skips fee setup on activation; newer API always calls fee setup but invoice still depends on due-date rules | Likely from code |
| Root cause | Invoice never created vs created but not displayed — **not confirmed** | Needs runtime verification |

---

## 6. Expected behavior

After admin activation of an unpaid member, registration fee appears in pending/outstanding
dues for admin and member payment views until paid or waived per product rules.

---

## 7. Bug analysis and reproduction

### 7A. Code-informed analysis

**Flow diagram (text):**

```
Admin UI: Activate member → POST /api/members/activate → MemberActivationService
  → (if skip_fee_setup) bypass FeeSetupService → member.status=ACTIVE
  → GET /api/payments/unpaid → UnpaidInvoiceQuery → admin/member UI pending dues list
```

**Confirmed code facts:**

| Finding | Detail | Evidence reference |
|---------|--------|-------------------|
| Activation payload | `skip_fee_setup` derived from org fee-plan display setting | `MemberActivationService.activate()` |
| Unpaid list source | UI reads `unpaid_invoices[]` from payment history endpoint | `PaymentHistoryController` |

**Likely failure points (hypotheses — not root cause):**

| Hypothesis | Detail | Label |
|------------|--------|-------|
| H1 | Fee setup bypassed on activation when flag true | Likely from code |
| H2 | Invoice created but filtered out by due-date rule | Likely from code |
| H3 | Wrong API version deployed in reported environment | Needs runtime verification |

**What code analysis cannot answer:**

- Which client surface reporter used (admin web vs mobile)
- Whether invoice row exists in database for affected member
- Deployed API version in staging/production

### 7B. Findings classification

| # | Finding | Label |
|---|---------|-------|
| 1 | Activation can bypass fee setup when org setting disables fee-plan page | Confirmed from code |
| 2 | Pending dues UI empty when unpaid invoice list is empty | Confirmed from code |
| 3 | Reporter's environment matches code path H1 vs H2 | Needs runtime verification |
| 4 | Product rule: fee must always appear after admin activation | Needs PO/QA confirmation |

### 7C. Reproduction steps

#### UI path

| Step | Action | Expected | Actual |
|------|--------|----------|--------|
| 1 | Log in as org admin | Dashboard loads | _Needs runtime verification_ |
| 2 | Open member list; activate member with unpaid registration | Activation succeeds | _Needs runtime verification_ |
| 3 | Open Payments / pending dues for member | Registration fee listed | Fee missing (per report) |

#### API-level path

| Step | Endpoint / action | Payload / prerequisites | Expected response / state | Actual |
|------|-------------------|-------------------------|----------------------------|--------|
| 1 | POST `/api/members/activate` | `{ member_id, skip_fee_setup }` per org setting | 200; member active | _Needs runtime verification_ |
| 2 | GET `/api/payments/unpaid?member_id=` | Active member, no prior payment | `unpaid_invoices` includes registration fee | _Needs runtime verification_ |

**Data prerequisites:** Test org with fee-plan page disabled; member in pre-payment state  
**Before/after verification:** Capture unpaid invoice count before/after activation

**Environment:** Staging (to be confirmed)  
**Frequency / severity:** Unknown / payment-impacting  
**Screenshots / logs needed (sanitized):** Before/after pending dues screen; API response JSON (no PII)

### 7D. Runtime verification checklist

- [ ] Target environment identified: _pending_
- [ ] Deployed API version confirmed: _pending_
- [ ] Activation payload captured (sanitized): _pending_
- [ ] Before-state API response recorded: _pending_
- [ ] After-state API response recorded: _pending_
- [ ] Before/after UI state documented (no PII): _pending_
- [ ] Sanitized test account reference documented: _pending_

### 7E. Stakeholder / QA clarification pack

| # | Topic | What code analysis suggests | Needs PO/QA confirmation | Needs runtime verification |
|---|-------|----------------------------|--------------------------|----------------------------|
| 1 | Activation path | Fee setup may be skipped when org fee-plan page disabled | Must fee always appear after admin activation? | Confirm API version and repro in staging |
| 2 | Pending dues display | UI reads unpaid invoice list; empty list shows no dues | Which client did reporter use? | Capture before/after API + UI state |
| 3 | Root cause | H1: fee setup bypassed; H2: invoice filtered by due-date rule | N/A | Verify invoice row exists after activation |

---

## 13. Impacted systems / repos / modules

| System / repo / module | Impact type | Notes |
|------------------------|-------------|-------|
| `admin-web` | Display | Pending dues tab |
| `member-api` | Logic | Activation + fee setup |
| `payment-service` | Query | Unpaid invoice list |
| `mobile-app` | Display | Member payment screen (if in scope) |

---

## 14. Data / security / compliance impact

| Area | Impact | Action required |
|------|--------|-----------------|
| Data classification | INTERNAL | Payment records |
| PII / payment | Payment amounts, member references | Sanitized test data only in repro |
| Auth / authz | Admin-only activation | Confirm role in repro |

---

## 17. Refined acceptance criteria

1. **AC-001:** After admin activation of member with unpaid registration, registration fee
   appears in pending dues for admin payment view — _human confirmed: pending_
2. **AC-002:** Same fee visible in member-facing payment view when applicable — _human confirmed: pending_
3. **AC-003:** No regression for members who paid before activation — _human confirmed: pending_
4. **AC-004:** Automated integration test covers activation → unpaid invoice present — _human confirmed: pending_

---

## 18. Suggested test cases

### Integration

- **TC-001** covers **AC-001:** Activation with fee-plan disabled → unpaid registration invoice exists
- **TC-002** covers **AC-003:** Pre-paid member activation → no duplicate fee

### Regression

- **TC-003** covers **AC-004:** Self-registration path still creates expected invoices

### UI / e2e

- **TC-004** covers **AC-002:** Member app shows pending registration fee after admin activation

---

## 20. Open questions

| # | Question | Owner | Status | Resolution |
|---|----------|-------|--------|------------|
| 1 | Which client did reporter use (admin web, mobile, both)? | PO/QA | open | |
| 2 | Is fee always required on admin activation per product rule? | PO | open | |
| 3 | Deployed API version in affected environment? | Engineering | open | |
| 4 | Does unpaid invoice row exist after repro (API/DB)? | QA | open | |

---

## 21. Definition of Ready checklist

- [x] Clear summary and business goal stated
- [ ] Acceptance criteria testable and human-confirmed
- [x] Affected systems/repos identified
- [x] Security/data impact assessed
- [x] Test expectations stated
- [ ] Open questions resolved or explicitly accepted
- [ ] Runtime verification complete for payment-impacting bug

**DoR status:** not ready — **Reason:** Runtime verification and PO confirmation pending;
code analysis complete but insufficient for payment bug.

---

## 22. Grooming decision

- [x] **Needs stakeholder clarification**
- [x] **Needs runtime verification** (complete §7D checklist before DoR = ready)

**Recommended next prompt:** Resolve Q1–Q4 and complete runtime checklist, then re-groom or
update artifact; run DoR validator; then `classify-work` → `impact-analysis`.

---

## Persona review summary

### Business Analyst review

Payment/revenue impact clear; product rule on admin activation vs fee display needs PO answer.

### QA Analyst review

Strong code-informed repro plan; runtime captures required before AC confirmation.

### Domain review

Fits membership + registration fee domain; org fee-plan setting affects path.

### Security / Data review

Payment data — Tier 2; use sanitized test accounts only for runtime verification.

---

## 12. Privacy / copyright review

| Check | Status |
|-------|--------|
| No customer PII in this document | yes |
| No credentials or secrets | yes |
| Production data anonymized or excluded | yes |

**Reviewer (human):** Example author — **Date:** 2026-06-19
