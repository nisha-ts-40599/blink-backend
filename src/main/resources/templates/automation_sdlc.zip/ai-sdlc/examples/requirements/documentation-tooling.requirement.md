# Requirement (Lite): Add onboarding link to internal wiki in README

> Example only — generic product "Acme Portal". Sanitized; no real customer data.

---

## 1. Metadata

| Field | Value |
|-------|-------|
| **Issue ID** | DOCS-101 |
| **Requirement type** | Documentation/process/tooling |
| **Source** | Internal backlog |
| **Product / project** | Acme Portal (internal admin app) |
| **Current stage** | REQUIREMENT |
| **Suggested tier (draft)** | 1 |

---

## 2. Requirement restatement

Add a clearly labeled "Team onboarding" section to the repository README that links to the
internal wiki page describing local setup, test commands, and support contacts.

---

## 3. Current behavior / problem

New contributors cannot find onboarding steps from the repo root. Setup instructions exist
only on the internal wiki; README does not reference them.

---

## 4. Expected behavior / outcome

README contains a short "Team onboarding" section with one link to the canonical wiki page
and a one-sentence description of what the page covers.

---

## 5. Acceptance criteria

1. **AC-001:** README includes a `## Team onboarding` section with a markdown link to the wiki URL
   provided by the doc owner — _human confirmed: yes_
2. **AC-002:** Link text is descriptive (not "click here") — _human confirmed: yes_
3. **AC-003:** No secrets, internal credentials, or environment-specific tokens appear in README —
   _human confirmed: yes_

**Non-goals:** Rewriting wiki content; changing CI or application code.

---

## 6. Suggested test expectations

- **Automated:** Markdown lint / link checker in CI (if configured) passes
- **Manual:** New team member can reach wiki from README in under 30 seconds
- **Regression:** None — documentation-only

---

## 7. Open questions

| # | Question | Owner | Status |
|---|----------|-------|--------|
| — | None | — | — |

---

## 8. Definition of Ready

- [x] Summary and outcome are clear
- [x] Acceptance criteria are testable and human-confirmed
- [x] Open questions resolved or explicitly accepted
- [x] Test expectations stated
- [x] No secrets, PII, or proprietary copy in this document

**DoR status:** ready — **Reason:** Documentation-only; AC confirmed by doc owner.

---

## 9. Grooming decision

- [x] **Ready for classify-work**

**Recommended next prompt:** `classify-work`

---

## 10. Persona review summary

### Business Analyst review

| Item | Notes |
|------|-------|
| Business goal / user pain | Reduce time-to-first-commit for new contributors |
| Scope / non-goals | README link only; no wiki rewrite |
| Stakeholder decisions needed | Wiki URL confirmed by doc owner |
| AC quality | Testable via section presence and link text |
| Readiness | Ready |

### QA Analyst review

| Item | Notes |
|------|-------|
| Testability | Manual smoke + optional markdown link check |
| Missing repro / env details | N/A |
| Edge / regression risks | Low — docs only |
| Automation vs manual | Manual review sufficient |
| DoR concerns | None |

### Domain review

| Item | Notes |
|------|-------|
| Product / domain fit | Standard open-source-style README pattern |
| Domain constraints | Use internal wiki URL approved by doc owner |
| Domain open questions | None |

### Security / Data review

| Item | Notes |
|------|-------|
| Data / compliance impact | None — no credentials in README |
| Tier escalation note | Remains Tier 1 |
| Gate recommendations | None beyond normal PR review |
