# Requirement: Export report results to CSV

> Example only — generic product "Acme Portal". Sanitized; no real customer data.

---

## 1. Requirement metadata

| Field | Value |
|-------|-------|
| **Issue ID** | ENH-88 |
| **Requirement type** | Enhancement |
| **Product / project** | Acme Portal |
| **Suggested work tier (draft)** | 2 |

---

## 3. Requirement restatement

Allow users with the `analyst` role to export the current filtered report table to a CSV
file from the Reports screen, preserving visible columns and row order.

---

## 4. Business goal / user pain

Analysts manually copy data into spreadsheets daily; export reduces errors and saves
~10 minutes per report run.

---

## 5. Current behavior

Reports screen shows filterable table (max 500 rows per page). No export action exists.
Users copy/paste into external tools.

---

## 6. Expected behavior

"Export CSV" button downloads a UTF-8 CSV of currently filtered rows (respecting column
visibility), filename includes report name and date. Export limited to 5,000 rows with
clear message if truncated.

---

## 8. Existing feature assessment (enhancements)

| Aspect | Current state | Proposed change |
|--------|---------------|-----------------|
| Reports table | View/filter only | Add export action |
| Backward compatibility | N/A | No API contract change to existing JSON API |

---

## 17. Refined acceptance criteria

1. **AC-001:** `analyst` role sees Export CSV on Reports screen — _human confirmed: yes_
2. **AC-002:** CSV matches visible columns and filter order — _human confirmed: pending_
3. **AC-003:** Truncation message when >5,000 rows — _human confirmed: pending_
4. **AC-004:** `viewer` role does not see export — _human confirmed: yes_

**Non-goals:** Excel format; scheduled exports; email delivery.

---

## 18. Suggested test cases

### Regression

- Report filtering and pagination unchanged

### Integration

- Export respects server-side filters; auth enforced

### Negative

- Unauthorized role receives 403; empty result set produces header-only CSV

---

## 20. Open questions

| # | Question | Owner | Status |
|---|----------|-------|--------|
| 1 | Include hidden identifier columns in CSV? | PO | open |

---

## 21. Definition of Ready

**DoR status:** not ready — **Reason:** Q1 open.

---

## 22. Grooming decision

- [x] **Needs stakeholder clarification**

**Recommended next prompt:** classify-work after Q1 resolved.

---

## Persona review summary

### Business Analyst review

Clear user pain and scope; one stakeholder decision on column set.

### QA Analyst review

Regression on reports module; test authz and truncation edge cases.

### Domain review

Fits existing Reports bounded context; reuse existing filter query.

### Security / Data review

Export may include business data — confirm classification; Tier 2 appropriate.
