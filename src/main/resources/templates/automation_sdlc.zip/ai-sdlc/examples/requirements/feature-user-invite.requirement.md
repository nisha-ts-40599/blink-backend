# Requirement: Invite user to organization by email

> Example only — generic product "Acme Portal". Sanitized; no real customer data.

---

## 1. Requirement metadata

| Field | Value |
|-------|-------|
| **Issue ID** | FEAT-201 |
| **Requirement type** | New feature |
| **Product / project** | Acme Portal |
| **Suggested work tier (draft)** | 2 |

---

## 3. Requirement restatement

Organization admins can invite a new member by email address, assign an initial role, and
send an invitation the recipient accepts to join the organization.

---

## 4. Business goal / user pain

Self-serve team growth without support tickets; admins need controlled onboarding.

---

## 9. New capability scope

### MVP scope

- Admin enters email + role; system sends invitation link
- Recipient accepts invite and creates/links account
- Invitation expires after 7 days

### Later scope (deferred)

- Bulk invite CSV upload
- Custom invitation message

### Non-goals

- SSO provisioning; billing seat management

---

## 14. Data / security / compliance impact

| Area | Impact |
|------|--------|
| PII | Email addresses stored for pending invites |
| Auth / authz | Admin-only; role assignment on accept |
| Audit | Log invite created/accepted/revoked |

---

## 17. Refined acceptance criteria

1. **AC-001:** Admin with `org_admin` role can send invite — _human confirmed: pending_
2. **AC-002:** Duplicate pending invite returns stable error — _human confirmed: pending_
3. **AC-003:** Expired invite cannot be accepted — _human confirmed: pending_
4. **AC-004:** Audit event recorded for invite lifecycle — _human confirmed: pending_

---

## 18. Suggested test cases

### Unit / integration

- Invite creation, acceptance, expiry, duplicate handling

### Security

- Non-admin cannot invite; token single-use

### UI / e2e

- Admin flow happy path; accept flow new user

---

## 21. Definition of Ready

**DoR status:** not ready — **Reason:** Email template and audit retention policy TBD.

---

## 22. Grooming decision

- [x] **Needs architecture/security review** before planning

**Recommended next prompt:** Resolve audit/email policy, then `classify-work` →
`impact-analysis` → `technical-plan`.

---

## Persona review summary

### Business Analyst review

MVP vs later clear; stakeholder needs email branding decision.

### QA Analyst review

Strong test matrix needed for token expiry and authz; e2e for two-user flow.

### Domain review

Fits Organization membership context; check existing User entity relationships.

### Security / Data review

PII + auth change — confirm Tier 2; security champion review recommended before implement.
