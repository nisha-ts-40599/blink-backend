# Project Context: TalentServ AI-SDLC Framework

> This is the `{{PROJECT_CONTEXT}}` document for the `automation_sdlc` repository itself.
> It is the reference example of a filled `project-context-template.md`.
> Use it when running AI-SDLC prompts against this repository.

---

## 1. Project Summary

| Field | Value |
|-------|-------|
| **Project name** | TalentServ AI-SDLC Framework |
| **Identifier** | `automation_sdlc` |
| **Description** | Reusable framework for AI-assisted, governed SDLC — prompts, workflows, policies, schemas, conformance tooling |
| **Business domain** | Developer tooling |
| **Primary users** | Engineering teams adopting AI-assisted development; contributors extending the framework |
| **Team** | TalentServ engineering |
| **Engineering lead** | TalentServ/engineering |
| **Security champion** | TalentServ/engineering |
| **Git remote** | `git@github.com:TalentServ/automation_sdlc.git` |
| **Default branch** | `main` |

### Core capabilities

- Parameterized prompt library for every SDLC stage (14 prompts)
- Workflow documentation from requirement intake through post-release verification (7 workflows)
- OPA/Rego policy enforcement for gates, MCP permissions, workflow transitions, artifact integrity
- JSON Schema validation for governance and ACP payload objects
- Conformance runner with CI integration (GitHub Actions, GitLab CI, Azure Pipelines, Jenkins)
- Single-project and multi-repo workspace setup prompts
- Reference Python runtime for local demo and architectural exploration

### Non-goals

- Auto-merging code to any branch
- Production deployment of any service
- MCP integrations with real external systems (Jira, GitHub API, etc.) — these are planned, not built

---

## 2. Architecture

| Field | Value |
|-------|-------|
| **Architecture style** | Single-purpose tooling monorepo |
| **Deployment model** | No deployable artifact; `main` = current release |
| **Cloud provider** | None |
| **Infrastructure as code** | None |
| **Diagram** | `ai-sdlc/README.md` (flow diagram) |

### Bounded contexts

| Context | Responsibility |
|---------|----------------|
| `governance` | Approval gates, risk rules, human-in-the-loop policy, audit log requirements |
| `policy-engine` | OPA/Rego policies for gates, MCP permissions, workflow transitions, artifact integrity |
| `conformance` | Schema self-validation, policy test matrix, conformance runner, JUnit output |
| `workflows-and-prompts` | Workflow markdown files and parameterized prompt templates |
| `runtime` | **Reference demo only** — local Python orchestrator with mock adapters |

---

## 3. Technology Stack

| Layer | Technology |
|-------|-----------|
| **Language** | Python 3.x (conformance runner, reference runtime) |
| **Policy language** | Rego (OPA v0.68.0) |
| **Schema format** | JSON Schema 2020-12 |
| **Config format** | YAML |
| **Package manager** | pip |
| **Build tool** | make (Makefile) |
| **Test harness** | `run_conformance.py` (jsonschema + OPA subprocess) |
| **CI** | GitHub Actions (templates in `ai-sdlc/ci/`) |

---

## 4. Repository Layout

| Path | Role |
|------|------|
| `ai-sdlc/prompts/` | Parameterized LLM prompts — primary daily-use artifacts |
| `ai-sdlc/workflows/` | Stage-by-stage workflow procedures — operational runbooks |
| `ai-sdlc/templates/` | Document templates for issues, PRs, plans, ADRs |
| `ai-sdlc/governance/` | Approval gates, risk rules, HITL policy, maturity model |
| `ai-sdlc/policies/` | OPA/Rego policy files — enforceable via conformance runner |
| `ai-sdlc/schemas/` | JSON Schema files for governance and ACP payloads |
| `ai-sdlc/registry/` | Central ID registries (artifacts, events, gates, escalations, policies) |
| `ai-sdlc/tests/` | Conformance fixtures, expected results, test matrix |
| `ai-sdlc/tools/` | Conformance runner, OPA installer |
| `ai-sdlc/ci/` | CI pipeline templates and stack profiles |
| `ai-sdlc/adoption/` | Onboarding, rollout, and usage guides |
| `ai-sdlc/examples/` | Filled configuration examples including this self-adoption set |
| `ai-sdlc/runtime/` | **Reference demo only** — local Python orchestrator |
| `ai-sdlc/acp/` | **Experimental** — multi-agent handoff protocol documentation |

---

## 5. Operational Maturity

### What is stable and usable today

| Component | Status |
|-----------|--------|
| Prompt library (`prompts/`) | Stable — use in Cursor daily |
| Workflow documents (`workflows/`) | Stable — use as runbooks |
| Templates (`templates/`) | Stable — use for issues, PRs, plans |
| Governance docs (`governance/`) | Stable — reference for approval rules |
| Work-tiers model (`work-tiers.md`) | Stable — use for tier classification |
| OPA policies (`policies/`) | Stable — enforced via conformance runner |
| JSON schemas (`schemas/`) | Stable — validated in CI |
| Conformance runner (`tools/`) | Stable — production-quality CI tooling |
| CI templates (`ci/`) | Stable — adapt for your CI system |
| Setup prompts (single + workspace) | Stable — use for onboarding |
| Adoption materials (`adoption/`) | Stable — use for rollout |

### What is reference/demo only

| Component | Status | Note |
|-----------|--------|------|
| Runtime orchestrator (`runtime/`) | **Reference demo** | All step executors are noop; all adapters are mocks writing local JSON files |
| Mock adapters | **Reference demo** | `MockGitProvider`, `MockIssueTracker`, `MockDocumentStore` write to local JSON files only |

### What is experimental

| Component | Status | Note |
|-----------|--------|------|
| ACP multi-agent protocol (`acp/`) | **Experimental** | Protocol defined; no real agents implement it yet |
| `policies/org-role-mapping.rego` | **Experimental** | No callers in current runtime |
| `policies/gate-sla.rego` | **Experimental** | No SLA clock integrated |

---

## 6. How Contributors Work

### Branch conventions

- Branch naming: `feature/<issue-number>-<short-slug>` (example: `feature/42-add-impact-prompt`)
- All changes require a pull request to `main`
- No direct commits to `main` or `protected` branches
- Commit messages: `<type>(<scope>): <description>` (example: `feat(prompts): add impact-analysis prompt`)

### PR expectations

- PR title: `[issue-number] description` or clear summary
- PR body: use `ai-sdlc/templates/pr-template.md`
- Work tier label required on every PR
- `make ai-sdlc-conformance-protected` must pass before merge
- Human review required for all PRs

### Issue tracker

- System: GitHub Issues
- URL: `https://github.com/TalentServ/automation_sdlc/issues`
- Labels: work tier, component (prompts / workflows / policies / schemas / conformance / runtime / adoption)

---

## 7. Work Tier Examples

| Tier | Example task | Required approvals |
|------|-------------|-------------------|
| **Tier 1** | Fix typo in a workflow doc; update a non-normative README section | None / optional peer |
| **Tier 2** | Add a new prompt template; add a new example config; update adoption guide | Engineering lead |
| **Tier 3** | Modify an OPA policy (Rego); change a JSON schema; add a new governance doc normative section; change conformance runner logic | Eng lead + security champion |
| **Tier 4** | N/A for this repository | N/A |

**Default tier when unclassified:** 2

---

## 8. Approval Rules

| Role | Maps to | Approves |
|------|---------|---------|
| Engineering lead | `TalentServ/engineering` | Tier 2+ plans and all PRs to main |
| Security champion | `TalentServ/engineering` | Tier 3 policy/schema/governance changes |

**Merge to main requires:** CI green (`make ai-sdlc-conformance-protected`) + human PR approval

---

## 9. CI Commands

| Stage | Command |
|-------|---------|
| Install dependencies | `make ai-sdlc-install` |
| Lint | `make ai-sdlc-lint` |
| Conformance — dev profile | `make ai-sdlc-conformance` |
| Conformance — protected profile | `make ai-sdlc-conformance-protected` |
| Schema check only | `make ai-sdlc-schema-check` |
| Policy check only | `make ai-sdlc-policy-check` |
| JUnit output | `make ai-sdlc-conformance-junit` |
| Clean | `make ai-sdlc-clean` |
| Install OPA | `sh ai-sdlc/tools/install-opa.sh` |

**Expected dev-profile result:** Schema checks pass; OPA-dependent tests skipped (no OPA required).

**Expected protected-profile result:** All protected conformance checks pass; zero failures.

---

## 10. Security Rules

| Dimension | Value |
|-----------|-------|
| **Data classification** | INTERNAL |
| **PII processing** | NONE |
| **Regulatory context** | None |
| **Secrets handling** | No credentials in repo; GitHub Actions secrets for future CI tokens |

### Hard rules

- No credentials, tokens, or API keys in any committed file.
- No MCP server credentials in `.vscode/mcp.json` or any tracked file.
- Any change to OPA policy logic is Tier 3 — requires peer review of Rego correctness.
- A policy change must be accompanied by an updated conformance test or a documented reason why no test is needed.

---

## 11. Manual vs Automated Boundaries

### AI may automate

- Drafting issue descriptions from a requirement statement
- Classifying work tier (human confirms)
- Drafting technical plans (human approves)
- Running conformance checks and surfacing failures
- Generating new test fixtures from schema examples
- Drafting PR descriptions and review summaries

### AI assists; human must approve

- Technical plan for Tier 2+ changes (G-PLAN gate)
- Policy (Rego) changes — AI may draft, human verifies correctness
- Schema changes — AI may draft, human validates constraints
- PR review — AI produces findings, human resolves threads and merges

### Must remain manual

- Merge to `main`
- Creating GitHub releases or version tags
- Overriding a failing conformance test
- Downgrading a Tier 3 change to Tier 2

### Must never be automated initially

- Any merge to `main` without CI green + human approval
- Any production deployment (N/A for this repo — reinforce the pattern)
- Modifying OPA policies without a passing conformance test

---

## 12. Definition of Done

- [ ] Acceptance criteria evidenced in the PR.
- [ ] `make ai-sdlc-conformance-protected` passes: 0 failures, 0 schema failures.
- [ ] For policy changes: conformance test updated or absence documented.
- [ ] For schema changes: all affected fixtures pass.
- [ ] PR reviewed by at least one team member.
- [ ] No YAML lint errors in registry/schema files.

---

## 13. Prompt Placeholder Values

```
{{PROJECT_CONTEXT}}    → [paste contents of this file]
{{TECH_STACK}}         → Python 3.x + Rego (OPA) + JSON Schema 2020-12 + YAML
{{SECURITY_MODEL}}     → Classification: INTERNAL | PII: NONE | Regulatory: none
{{APPROVAL_RULES}}     → Tier 2: engineering_lead | Tier 3: eng_lead + security_champion | Merge: CI green + human approval
{{REPOSITORY_CONTEXT}} → Single-purpose tooling monorepo | Key paths: ai-sdlc/prompts/, ai-sdlc/policies/, ai-sdlc/schemas/
```
