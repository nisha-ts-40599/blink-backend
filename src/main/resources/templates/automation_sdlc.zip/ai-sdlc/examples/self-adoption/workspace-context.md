# Workspace Context: TalentServ Platform

> This is the `{{WORKSPACE_CONTEXT}}` document for the TalentServ Platform workspace.
> It is the reference example of a filled `workspace-context-template.md`.
> Load this into an AI session when planning work that spans multiple repositories.

---

## 1. Workspace Summary

| Field | Value |
|-------|-------|
| **Workspace name** | TalentServ Platform |
| **Identifier** | `talentserv-platform` |
| **Description** | Full-stack talent management product: React SPA, FastAPI backend, PostgreSQL database |
| **Architecture** | BFF + SPA frontend, containerized backend, dedicated migration repo |
| **Repositories** | 4 (web-ui, api-service, db-migrations, automation-sdlc) |
| **Cloud** | AWS |
| **Engineering lead** | TalentServ/engineering |
| **Security champion** | TalentServ/engineering |
| **Source of truth** | `workspace-config.yaml` (this directory) |

---

## 2. Repository Map

| Repo | Role | Language | Owner | Local path |
|------|------|----------|-------|-----------|
| `web-ui` | Frontend SPA | TypeScript + React 18 | TalentServ/frontend-team | `../web-ui` |
| `api-service` | REST API backend | Python + FastAPI | TalentServ/backend-team | `../api-service` |
| `db-migrations` | PostgreSQL schema owner | SQL + Alembic | TalentServ/backend-team | `../db-migrations` |
| `automation-sdlc` | AI-SDLC governance tooling | Python + Rego | TalentServ/engineering | `../automation_sdlc` |

### Per-repo responsibilities

**web-ui**
- All React components, pages, routing
- Vite build, TypeScript compilation, Tailwind styles
- Calls REST API at `/api/v1/*`
- Playwright e2e tests against staging

**api-service**
- All REST endpoints `/api/v1/*`
- Business logic, SQLAlchemy models
- FastAPI, Pydantic schemas
- Integration tests via Testcontainers (PostgreSQL)
- Owns `api-service/docs/openapi.yaml`

**db-migrations**
- PostgreSQL schema ownership: all `CREATE TABLE`, `ALTER TABLE`, index definitions
- Alembic migration scripts — single source of truth for database shape
- Seed data for local development

**automation-sdlc**
- Governance rules (OPA/Rego), JSON schemas, conformance runner
- Prompts, workflows, templates, adoption guides
- CI pipeline templates for all other repos
- AI-SDLC is a tooling dependency, not a runtime service

---

## 3. Cross-Repo Dependency Map

```
web-ui  ──[REST API calls /api/v1/*]──►  api-service
                                               │
                          [SQLAlchemy models]  │
                                               ▼
                                       db-migrations
                                     (Alembic migrations)

automation-sdlc  ──[governs]──►  all repos (prompts, policies, CI templates)
```

**API contract:** `api-service/docs/openapi.yaml` (provider: api-service, consumer: web-ui)

**Database ownership:** `db-migrations` owns the schema; `api-service` reads/writes via SQLAlchemy; no direct DB access from `web-ui`.

---

## 4. Deployment Topology

| Environment | web-ui | api-service | db-migrations |
|-------------|--------|-------------|---------------|
| **Local** | `npm run dev` on port 3000 | `uvicorn main:app` on port 8000 | `alembic upgrade head` (local Postgres) |
| **Staging** | Docker image → ECS Fargate | Docker image → ECS Fargate | Run migrations in ECS task at deploy start |
| **Production** | Docker image → ECS Fargate | Docker image → ECS Fargate | Run migrations in ECS task at deploy start |

**Deployment order (mandatory):**

```
Step 1: db-migrations → apply Alembic migrations (staging or production)
         ↓ Verify: migration exit code 0; schema version matches expectation
Step 2: api-service  → deploy new container image
         ↓ Verify: /health endpoint returns 200; API smoke tests pass
Step 3: web-ui       → deploy static assets / new container image
         ↓ Verify: frontend loads; core user journey passes smoke test
```

---

## 5. How AI-SDLC Governs This Workspace

### Single-repo changes (Tier 1–2)

Work confined to one repo follows that repo's own project-context and project-config rules.

Typical flow in Cursor:
1. Open `ai-sdlc/projects/<repo>/project-context.md` in a context window.
2. Run `clarify-requirement.prompt.md` with `{{PROJECT_CONTEXT}}` filled.
3. Run `classify-work.prompt.md` to confirm tier.
4. Run `technical-plan.prompt.md` for Tier 2+.
5. Implement and open a PR.

### Cross-repo changes (Tier 2+)

When a feature or fix touches more than one repo, include `{{WORKSPACE_CONTEXT}}` (this document) alongside `{{PROJECT_CONTEXT}}` for each affected repo.

Minimum tier: 2. API contract or schema changes: Tier 3.

Recommended planning sequence for cross-repo changes:
1. Load this workspace-context.md into the Cursor chat.
2. Load project-context.md for each affected repo.
3. Run `clarify-requirement.prompt.md` — describe the full scope across repos.
4. Run `classify-work.prompt.md` — include all affected repos in the classification prompt.
5. Run `technical-plan.prompt.md` — the plan must include an ordered implementation list by repo.
6. Get G-PLAN approval from engineering lead before implementation.
7. Open PRs per repo; link them in each PR description.
8. Ensure all PRs pass CI before merging any of them.
9. Merge in deployment order (db-migrations → api-service → web-ui).

---

## 6. Common AI-SDLC Operational Rules for This Workspace

| Rule | Applies to |
|------|-----------|
| AI may draft issues, plans, PR descriptions | All repos |
| AI may run conformance checks | automation-sdlc repo only |
| AI must not merge any branch | All repos |
| AI must not deploy to any environment | All repos |
| AI must not run migrations | db-migrations |
| Human G-PLAN gate required for Tier 2+ cross-repo changes | All repos |
| Human G-SEC gate required for API contract breaking changes | api-service, web-ui |
| Human G-DEPLOY gate required for all production deployments | All repos |
| SRE approval required for production deploy | All repos |

---

## 7. Work Tier Examples (Cross-Repo)

| Tier | Example | Affected repos | Minimum approvals |
|------|---------|---------------|-------------------|
| **Tier 2** | Add a new UI page that calls an existing endpoint | web-ui, (api-service if endpoint added) | Eng lead |
| **Tier 3** | Add a new REST endpoint + new database column | api-service, db-migrations | Eng lead + security champion |
| **Tier 3** | Rename a REST endpoint (breaking API change) | api-service, web-ui | Eng lead + security champion |
| **Tier 4** | Authentication refactor touching API, DB schema, and UI | api-service, db-migrations, web-ui | Eng lead + security champion + SRE + product owner |

---

## 8. Approval Chain for Cross-Repo Changes

```
Engineering lead  → G-PLAN (all Tier 2+ cross-repo changes)
Security champion → G-SEC  (all Tier 3+ cross-repo changes, API contract changes)
SRE / Platform    → G-DEPLOY (all production deployments, all Tier 4)
Product owner     → G-PLAN (Tier 4 cross-repo changes)
```

All of the above are **human decisions**. AI assists with drafts and analysis; humans record approvals.

---

## 9. Merge Readiness Rules

Before merging any PR in a cross-repo change set:

**Per PR (each affected repo):**
- [ ] CI is green on this repo's PR.
- [ ] Human PR approval recorded.
- [ ] Work tier label added.
- [ ] PR description links all other PRs in this change set.
- [ ] Acceptance criteria checked off in PR body.

**Cross-repo coordination:**
- [ ] All PRs in the change set are approved and CI-green before any is merged.
- [ ] API contract compatibility verified if `openapi.yaml` changed (use `openapi-diff` or equivalent).
- [ ] Database migration tested in staging and rollback documented.
- [ ] Deployment order confirmed (db-migrations → api-service → web-ui).

**Gate approvals recorded:**
- [ ] G-PLAN (Tier 2+)
- [ ] G-SEC (Tier 3+)
- [ ] G-DEPLOY (production)

---

## 10. Deployment Readiness Rules

A cross-repo deployment to production is ready when:

- [ ] All PRs merged to `main` in all affected repos.
- [ ] Staging deployment succeeded (all three stages complete).
- [ ] Staging smoke tests pass for all affected repos.
- [ ] Database migration rollback documented in the change ticket.
- [ ] API contract compatibility confirmed (no unplanned breaking changes).
- [ ] SRE has confirmed the deployment window and runbook.
- [ ] Monitoring dashboards open; alert thresholds confirmed.
- [ ] Rollback plan recorded (migration rollback command, container rollback command).

---

## 11. What Remains Manual

| Decision | Why it must be manual |
|----------|----------------------|
| Merging any PR | Final human accountability for what lands in main |
| Deploying to staging | Prevents unreviewed changes from reaching integration environment |
| Deploying to production | SRE must own production state |
| Applying database migrations | Irreversible unless rollback is tested; DBA judgment needed |
| Breaking API contract changes | Downstream consumers may not be ready |
| Adding new environment variables or secrets | Security and infrastructure concern |
| Escalating a tier classification | Risk judgment; human must own it |

---

## 12. Recommended Workflow Order for a Cross-Repo Feature

This example shows adding a new endpoint + new DB column + new UI page.

```
1. PLAN (Cursor, all repos open)
   └─ clarify-requirement.prompt.md   [WORKSPACE_CONTEXT + PROJECT_CONTEXT for each repo]
   └─ classify-work.prompt.md         → Tier 3
   └─ technical-plan.prompt.md        → ordered plan: DB schema → API → UI
   └─ human approves G-PLAN           ← MANDATORY HUMAN ACTION

2. IMPLEMENT (separate chat per repo)
   ├─ db-migrations: add Alembic migration
   ├─ api-service:   add endpoint + SQLAlchemy model
   └─ web-ui:        add new page + API call

3. REVIEW + VALIDATE (Cursor per PR)
   └─ pr-review.prompt.md per repo
   └─ human reviews and approves      ← MANDATORY HUMAN ACTION PER PR

4. PRE-MERGE CHECK
   └─ all-prs-green check (manual: open each PR)
   └─ openapi-diff for api-service
   └─ migration rollback test in staging

5. MERGE (in deployment order)
   ├─ 1. db-migrations PR             ← HUMAN MERGES
   ├─ 2. api-service PR               ← HUMAN MERGES
   └─ 3. web-ui PR                    ← HUMAN MERGES

6. DEPLOY (staging first, then production)
   └─ SRE executes per deployment runbook
   └─ Smoke tests per repo
   └─ G-DEPLOY recorded               ← MANDATORY HUMAN ACTION
```

---

## 13. Prompt Placeholder Values

```
{{WORKSPACE_CONTEXT}}       → [paste this file]
{{REPOSITORY_MAP}}          → web-ui (React), api-service (FastAPI), db-migrations (Alembic)
{{CROSS_REPO_DEPENDENCIES}} → web-ui→api-service (REST); api-service→db-migrations (Alembic/Postgres)
{{DEPLOYMENT_ORDER}}        → 1. db-migrations → 2. api-service → 3. web-ui
{{APPROVAL_CHAIN}}          → G-PLAN: eng lead | G-SEC: eng lead + security champion | G-DEPLOY: SRE
{{API_CONTRACT_LOCATIONS}}  → api-service/docs/openapi.yaml
{{DATABASE_OWNER}}          → db-migrations repo; migration tool: Alembic
```
