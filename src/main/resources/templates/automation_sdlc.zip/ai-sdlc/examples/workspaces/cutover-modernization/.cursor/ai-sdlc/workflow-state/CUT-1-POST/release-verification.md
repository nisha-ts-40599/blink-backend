# Release verification (fixture)

Post-cutover release checklist for CUT-1-POST.
