# Cutover plan (fixture)

Generic cutover plan for CUT-1-READY.
