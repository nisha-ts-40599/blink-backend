# Rollback plan (fixture)

Generic rollback plan for CUT-1-READY.
