# Technical plan (fixture)

Generic migration technical plan for CUT-1-READY.
