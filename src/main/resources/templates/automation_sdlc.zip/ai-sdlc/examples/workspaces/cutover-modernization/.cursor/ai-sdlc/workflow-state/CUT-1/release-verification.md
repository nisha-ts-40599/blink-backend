# Release verification (fixture)

Pre-cutover release checklist for CUT-1.
