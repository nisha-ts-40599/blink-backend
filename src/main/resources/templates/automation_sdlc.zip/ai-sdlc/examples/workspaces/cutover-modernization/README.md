# Cutover Modernization Example Workspace

Generic Phase 3 fixture for production cutover and post-migration validation demos. No product-specific data.

## Issues

| Issue ID | Stage | Purpose |
|----------|-------|---------|
| `CUT-1` | `DEPLOY_READY` | Cutover required; missing cutover planning artifacts |
| `CUT-1-READY` | `DEPLOY_READY` | Cutover artifacts complete; ready for `CUTOVER_READY` |
| `CUT-1-POST` | `DEPLOYED` | Cutover complete; awaiting post-migration validation |

## Commands

From repository root:

```bash
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/cutover-modernization ISSUE=CUT-1
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/cutover-modernization ISSUE=CUT-1-READY
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/cutover-modernization ISSUE=CUT-1-POST
```

Expected:

- `CUT-1`: `cutover_required: true`, next prompt `cutover-plan.prompt.md`
- `CUT-1-READY`: cutover artifacts satisfied, suggested next `CUTOVER_READY`
- `CUT-1-POST`: next prompt `post-migration-validation.prompt.md`
