# Generic Platform Service — Project Context

Minimal generic context for modernization lane fixture demos. No client-specific data.

## System overview

Monolithic application scheduled for phased stack modernization using strangler-fig approach.

## Technology

- Backend: legacy runtime (generic)
- Database: relational store
- Deployment: container platform

## Security

- Role-based access control
- Sanitized logs only in SDLC artifacts
