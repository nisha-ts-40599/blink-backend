# compatibility-contract.md — MOD-1-READY fixture stub
