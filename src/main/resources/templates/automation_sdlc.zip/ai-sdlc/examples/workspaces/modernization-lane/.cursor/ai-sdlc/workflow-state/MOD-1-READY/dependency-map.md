# dependency-map.md — MOD-1-READY fixture stub
