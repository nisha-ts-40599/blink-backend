# migration-strategy.md — MOD-1-READY fixture stub
