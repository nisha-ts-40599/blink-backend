# regression-baseline.md — MOD-1-READY fixture stub
