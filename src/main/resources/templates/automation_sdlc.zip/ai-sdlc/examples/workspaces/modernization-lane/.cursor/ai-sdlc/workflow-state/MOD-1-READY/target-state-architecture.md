# target-state-architecture.md — MOD-1-READY fixture stub
