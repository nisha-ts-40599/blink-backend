# Impact Analysis: MOD-1

Affected modules: core API, batch jobs. Tier 3 blast radius.
