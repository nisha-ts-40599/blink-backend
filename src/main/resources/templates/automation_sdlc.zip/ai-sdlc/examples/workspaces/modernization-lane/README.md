# Modernization Lane Example Workspace

Generic fixture for Phase 2 modernization lane demos. No product-specific data.

## Issues

| Issue ID | Stage | Purpose |
|----------|-------|---------|
| `MOD-1` | `CLASSIFIED` | Impact complete; routes to modernization assessment |
| `MOD-1-READY` | `MIGRATION_STRATEGY` | Strategy artifacts complete; recommends gate review prompt |

## Commands

From repository root:

```bash
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/modernization-lane ISSUE=MOD-1
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/modernization-lane ISSUE=MOD-1-READY
make ai-sdlc-validate-artifacts ROOT=ai-sdlc/examples/workspaces/modernization-lane ISSUE=MOD-1
```

Expected:

- `MOD-1`: `modernization_enabled: true`, next prompt `modernization-assessment.prompt.md`
- `MOD-1-READY`: next prompt `modernization-gate-review.prompt.md`, suggested stage `MODERNIZATION_GATE_REVIEW` (human advances stage manually)
