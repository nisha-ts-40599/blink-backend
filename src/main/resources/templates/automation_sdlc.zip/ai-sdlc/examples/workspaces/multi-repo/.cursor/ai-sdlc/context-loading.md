# AI-SDLC Context Loading Guide

> Example copy — see `ai-sdlc/templates/context-loading-template.md` for the canonical template.

## Context load order

1. `.cursor/ai-sdlc/workspace-config.yaml`
2. `.cursor/ai-sdlc/workspace-context.md`
3. `.cursor/ai-sdlc/project-config.yaml`
4. `.cursor/ai-sdlc/project-context.md`
5. `.cursor/ai-sdlc/repos/<repo-id>/project-config.yaml`
6. `.cursor/ai-sdlc/repos/<repo-id>/project-context.md`
7. `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/`
8. Fallback: `ai-sdlc/` paths in framework repo only when overlay files are missing
