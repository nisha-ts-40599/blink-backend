# Project Context: Example Platform Pilot

> Location: `.cursor/ai-sdlc/project-context.md`

**last_reviewed:** 2026-06-19

## Pilot purpose

Adopt AI-SDLC for cross-repo feature delivery on Example Platform (web-admin + backend-api).

## Domain summary

Internal admin platform for customer record management with audit requirements.

## Business rules (known)

- Operators require authenticated sessions for all mutations
- Audit views are read-only; no PII in logs

## Open unknowns

- Production on-call rotation not assigned
- Mobile client scope deferred

## Using this context with AI-SDLC

1. Load files per `.cursor/ai-sdlc/context-loading.md`
2. For UI work, also load `repos/web-admin/` context
3. For API work, also load `repos/backend-api/` context
4. Save issue artifacts under `workflow-state/<ISSUE-ID>/`

## Repo context links

- [web-admin](repos/web-admin/project-context.md)
- [backend-api](repos/backend-api/project-context.md)
