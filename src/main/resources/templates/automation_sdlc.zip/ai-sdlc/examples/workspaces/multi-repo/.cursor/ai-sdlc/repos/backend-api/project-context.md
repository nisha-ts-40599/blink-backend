# Repo Context: backend-api

> Machine config: `.cursor/ai-sdlc/repos/backend-api/project-config.yaml`

## Purpose

FastAPI service exposing REST v1 for record management and audit queries.

## Architecture

Layered: routes → services → repositories → PostgreSQL. OpenAPI spec in `docs/openapi.yaml`.

## Key flows

- POST /api/v1/auth/login → JWT
- CRUD /api/v1/records with role-based authorization
- GET /api/v1/audit/export for auditor role

## Integration points

- Primary consumer: `web-admin`
- Database: PostgreSQL with Alembic migrations

## Test strategy

pytest unit + integration with ephemeral test DB. Contract tests against OpenAPI schema.

## Risks

- Schema migrations require coordinated deploy with zero-downtime strategy TBD
- Breaking API changes are Tier 3 minimum per workspace config
