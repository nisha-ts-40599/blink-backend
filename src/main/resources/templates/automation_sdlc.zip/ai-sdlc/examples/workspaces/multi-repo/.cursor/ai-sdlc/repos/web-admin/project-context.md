# Repo Context: web-admin

> Machine config: `.cursor/ai-sdlc/repos/web-admin/project-config.yaml`

## Purpose

React admin UI for Example Platform operators.

## Architecture

SPA with feature folders under `src/features/`. API client layer wraps REST v1 calls.

## Key flows

- Login → session token → authenticated API requests
- Record search → edit form → save with validation errors surfaced inline

## Integration points

- Consumes `backend-api` REST `/api/v1/*`
- Config via `VITE_API_BASE_URL` (key name only in docs)

## Test strategy

Unit/component tests with Vitest; API mocked with MSW. E2E planned with Playwright.

## Risks

- API contract changes require coordinated UI release
- Token storage approach must follow security review for Tier 3 changes
