# Workspace Context: Example Platform

> Sanitized generic example for multi-repo AI-SDLC overlay.
> Location: `.cursor/ai-sdlc/workspace-context.md`

**last_reviewed:** 2026-06-19

## Product overview

Example Platform is a fictional internal admin system for managing customer records.
Two repositories deliver the product: a React admin UI and a Python API backend.

## Repository map

| Repo | Role | Purpose |
|------|------|---------|
| web-admin | frontend | Operator UI for search, edit, audit views |
| backend-api | backend | REST API, auth, persistence |

## How repos interact

```
web-admin --[REST /api/v1]--> backend-api --> PostgreSQL
```

The UI reads configuration key `VITE_API_BASE_URL` (name only in configs) to reach the API.

## User roles

- **Operator** — day-to-day record management
- **Auditor** — read-only compliance views
- **Platform engineer** — deploy and observability

## Major workflows

1. Operator login → list records → edit → save (API validation)
2. Auditor export → filtered read-only query

## Domain glossary

| Term | Meaning |
|------|---------|
| Record | Primary business entity managed by the platform |
| Audit view | Read-only snapshot for compliance review |

## Cross-repo risks

- API version drift if UI deploys before API contract update
- Shared auth token format changes require coordinated release

## Deployment / release risks

- Backend must deploy before UI when breaking API changes ship
- Staging smoke test placeholder not yet automated

## Context freshness

Review quarterly or after architecture changes. Unknowns tracked in `workspace-config.yaml`.
