# Generic API Service — Example Context

> Machine config: `.cursor/ai-sdlc/project-config.yaml`

Minimal project context for **rollback-tier3** workspace fixture. Used to demonstrate Phase 1 rollback policy enforcement at merge readiness.

- **Domain:** generic internal API
- **Deployment:** staging → production with human approval
- **Rollback:** document revert via `rollback-plan.prompt.md` before merge for Tier 3+
