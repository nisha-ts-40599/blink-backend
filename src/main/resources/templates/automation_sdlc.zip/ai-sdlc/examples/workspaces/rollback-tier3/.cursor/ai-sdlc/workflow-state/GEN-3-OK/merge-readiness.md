# Merge Readiness — GEN-3-OK

Example fixture — rollback_plan present.
