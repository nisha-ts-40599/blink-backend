# Rollback Plan: GEN-3-OK

## Change summary

- Issue: GEN-3-OK
- Work type: production_bugfix
- Tier: 3
- Repo(s): generic-api
- PR(s): https://example.test/pr/42
- Commit(s): abc1234
- Target environment: staging

## Rollback classification

- Rollback required: yes
- Rollback type: git_revert
- Data cleanup required: no
- Customer impact expected: no
- Downtime expected: no

## Rollback triggers

- Functional trigger: error rate > 1% for 5 minutes post-deploy
- Data trigger: n/a
- Performance trigger: p95 latency regression > 20%
- Security trigger: n/a
- Operational trigger: failed health checks

## Rollback decision

- Decision owner: engineering-lead@example.test
- Deployment owner: platform@example.test
- QA owner: qa@example.test
- Data owner: n/a
- Communication owner: engineering-lead@example.test

## Rollback steps

1. Revert merge commit on main branch
2. Redeploy previous build artifact
3. Run smoke tests on staging

## Validation after rollback

- API smoke: GET /health returns 200
- UI smoke: n/a
- Data validation: n/a
- Log/monitoring check: error rate normalized
- Business validation: QA sign-off

## Data impact

- Data written by failed change: none expected
- Cleanup needed: no
- Cleanup approval: n/a
- Reconciliation method: n/a

## Communication

- Internal notification: #releases channel
- Client/user notification: n/a
- Incident/ticket link: n/a

## Status

Draft

## Human approval required

Database restore and production data cleanup require explicit human approval before execution.
