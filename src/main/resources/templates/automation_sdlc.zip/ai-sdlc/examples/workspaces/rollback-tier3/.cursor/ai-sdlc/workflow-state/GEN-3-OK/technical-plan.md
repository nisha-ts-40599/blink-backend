# Technical Plan — GEN-3-OK

Example fixture only.
