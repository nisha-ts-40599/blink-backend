# Merge Readiness — GEN-3

Example fixture — rollback_plan intentionally missing for merge-block demonstration.
