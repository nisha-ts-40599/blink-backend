# QA Validation — GEN-3

Example fixture only.
