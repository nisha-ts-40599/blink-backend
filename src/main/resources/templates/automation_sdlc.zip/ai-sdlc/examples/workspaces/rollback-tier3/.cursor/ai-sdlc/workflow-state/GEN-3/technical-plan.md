# Technical Plan — GEN-3

Example fixture only.
