# Rollback Tier 3 Example Workspace

Generic fixture for Phase 1 rollback tooling demos. No product-specific data.

## Issues

| Issue ID | Stage | rollback_plan | Purpose |
|----------|-------|---------------|---------|
| `GEN-3` | `MERGE_READY` | Missing | Demonstrates rollback-check fail and merge block |
| `GEN-3-OK` | `MERGE_READY` | Present | Demonstrates rollback-check pass |

## Commands

From repository root:

```bash
make ai-sdlc-rollback-check ROOT=ai-sdlc/examples/workspaces/rollback-tier3 ISSUE=GEN-3
make ai-sdlc-rollback-check ROOT=ai-sdlc/examples/workspaces/rollback-tier3 ISSUE=GEN-3-OK
make ai-sdlc-stage-router ROOT=ai-sdlc/examples/workspaces/rollback-tier3 ISSUE=GEN-3
```

Expected:

- `GEN-3`: rollback check **FAIL**; stage router `safe_to_proceed: NO` at merge stage
- `GEN-3-OK`: rollback check **PASS** (other merge gates may still apply)
