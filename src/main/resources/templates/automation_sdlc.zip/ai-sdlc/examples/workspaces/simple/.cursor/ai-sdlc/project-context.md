# Project Context: Simple Example

Minimal overlay for simple-shape smoke tests.

**last_reviewed:** 2026-06-22
