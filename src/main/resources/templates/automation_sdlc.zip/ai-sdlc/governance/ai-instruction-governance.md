# AI Instruction Governance

AI behaviour in the development workflow is configured through instruction files: prompt templates, Cursor rules, `CLAUDE.md`, `.cursorrules`, and `project-context.md`. These files are **code**. They determine how AI interprets context, what it produces, and how it behaves within team conventions. This document defines how they are owned, changed, reviewed, and audited.

---

## Governed AI Instruction Files

| File type | Location | Purpose | Review required |
|-----------|----------|---------|-----------------|
| Prompt templates | `ai-sdlc/prompts/*.prompt.md` | Parameterised instructions for each SDLC stage | PR with at least 1 reviewer |
| Cursor rules | `.cursor/rules/*.md` | Persistent AI guidance for this repo loaded automatically in Cursor | PR with at least 1 reviewer |
| CLAUDE.md | `CLAUDE.md` (repo root, if present) | Anthropic Claude system-level instruction file | PR with security champion review if scope includes security or auth context |
| Project context | `ai-sdlc/projects/[repo]/project-context.md` | Repo-specific context loaded into every prompt | PR with engineering lead review |
| Workspace context | `ai-sdlc/examples/[workspace]/workspace-context.md` | Cross-repo context for multi-repo prompts | PR with engineering lead review |

---

## Change Process

1. **Any change to an AI instruction file must go through a PR.** No direct push to `main`.
2. **PR description must explain** what the instruction change does, why it is needed, and what risk it introduces or removes.
3. **High-risk instruction changes** — those that modify security scope, data access guidance, or approval gate behaviour — require the security champion as a reviewer.
4. **Prompt placeholder changes** must be reflected in `prompt-placeholder-catalog.md`.
5. **The conformance runner** validates prompt headers and placeholder structure; CI blocks merge if these checks fail.

---

## Quality Gate Definitions

These definitions are the authoritative written criteria. They are referenced in the PR template and [`docs/operating-model/current-sdlc-flow.md`](../../docs/operating-model/current-sdlc-flow.md).

### merge-ready

A PR is merge-ready when **all** of the following are true:

- [ ] CI conformance check is green on the latest commit
- [ ] Branch is up to date with `main` (no unresolved rebase conflicts)
- [ ] All `must-fix` findings from `self-review.prompt.md` are resolved
- [ ] All `must-fix` findings from `pr-review.prompt.md` are resolved
- [ ] AI review summary is filled in the PR body
- [ ] G-PLAN approval is recorded on the issue (Tier 2+)
- [ ] G-SEC approval is recorded (Tier 3+, or R-AUTH-001 / R-API-001 triggered)
- [ ] Work tier label is set on the PR
- [ ] No secrets, credentials, or tokens in the diff
- [ ] OpenAPI spec updated if the API surface changed
- [ ] Documentation updated or explicitly deferred with a follow-up issue

### deployment-ready (staging)

- [ ] All PRs in the change set are merged to `main`
- [ ] CI build is green
- [ ] DB migration rollback script verified (if applicable)
- [ ] Smoke test steps documented
- [ ] SRE or on-call engineer notified

### deployment-ready (production)

- [ ] Staging verified and stable for the required observation window
- [ ] G-DEPLOY approval obtained from SRE — recorded in GitHub Actions environment approval log
- [ ] Rollback owner named and rollback procedure confirmed
- [ ] Observability dashboards open and baseline noted
- [ ] Customer-facing communication drafted and approved if the change is customer-impacting

### AI output accepted

AI output is accepted for use in a decision when:

- It is grounded in the source context loaded into the prompt (no hallucinated references)
- The engineer has reviewed and edited the output where needed
- Material deviations from the approved technical plan are documented in the PR body
- The output is referenced by PR number or issue comment — not discarded after use

---

## AI Output Traceability

Every AI output that influences a decision must be traceable. The minimum traceability record is:

| Artifact | Where it is recorded |
|----------|---------------------|
| Technical plan | Committed to `ai-sdlc/plans/[issue-id].md`; linked from PR body |
| G-PLAN approval | Comment on GitHub issue: "G-PLAN approved — [plan link] — @approver" |
| AI review findings | PR body "AI review summary" section; must-fix resolutions noted |
| Tier classification | Label on GitHub issue and PR; classification rationale in issue comment |
| Impact analysis | Linked from PR body or included in technical plan |
| Escalation record | Issue comment: "AI output requires review — [reason]" + resolution comment |

---

## Escalation Path for AI Output

When AI output requires escalation (see `human-in-the-loop-policy.md` for triggers):

1. **Engineer** records on the GitHub issue: "AI output requires review — [brief reason]."
2. **Engineering lead** reviews the AI output. May consult security champion for security-sensitive cases.
3. **Engineering lead** records the outcome: "Reviewed — proceed with [changes] / do not proceed — [reason]."
4. Work proceeds only after the engineering lead's review comment is posted.
5. If the engineering lead and security champion disagree, the security champion's position prevails for any security-affecting decision.

---

## Ownership and Accountability

- **Prompt templates** are owned by the engineering team. Changes require peer review.
- **Cursor rules and CLAUDE.md** are owned by the engineering lead. Changes affecting security or data scope require security champion co-review.
- **Project context files** are owned by the engineering lead for each repo. Outdated context is the responsibility of the last engineer to make a significant architectural change.
- **AI output used in a decision** is the responsibility of the engineer who used it. "The AI said so" is not an accepted justification for bypassing a gate or making a consequential decision.

---

## Feedback and Continuous Improvement

After each pilot or significant feature delivery:

1. Record which prompts produced high-quality output with minimal editing.
2. Record which prompts needed significant human correction — these are candidates for improvement.
3. Record any case where AI output was confidently wrong — these are candidates for added guardrails in the prompt instructions.
4. Prompt improvements go through the normal PR process; they are not ad-hoc edits.

See [`ai-sdlc/adoption/pilot-run-guide.md`](../adoption/pilot-run-guide.md) for pilot retrospective guidance.

---

## References

- Human-in-the-Loop Policy: `ai-sdlc/governance/human-in-the-loop-policy.md`
- Approval Gates: `ai-sdlc/governance/approval-gates.md`
- Public Reference and Data Safety: `ai-sdlc/governance/public-reference-and-data-safety.md`
- Prompt Placeholder Catalog: `ai-sdlc/prompts/prompt-placeholder-catalog.md`
- Operator workflow: [`docs/operating-model/current-sdlc-flow.md`](../../docs/operating-model/current-sdlc-flow.md)
