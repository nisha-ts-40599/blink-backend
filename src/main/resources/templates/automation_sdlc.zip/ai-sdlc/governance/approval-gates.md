# Approval Gates

Canonical gate requiredness, approver roles, waiver rules, and decision statuses are defined in `ai-sdlc/registry/gate-registry.yaml` (policy version **1.1**) and evaluated at runtime by `ai-sdlc/tools/orchestration/gate_policy.py`. Prompts and overlays must not contradict that registry.

Approval gates ensure **human accountability** for decisions that models cannot own: legal, operational, and security accountability. Gates are **tier-aware** and configurable via `project-config.template.yaml` under `approval_rules`.

## Gate Catalog

| Gate ID | When required | Typical approvers | Evidence |
|---------|----------------|-------------------|----------|
| G-CLASS | Work tier ambiguous or disputed | Engineering lead | Comment on issue with rationale |
| G-PLAN | Tier 2+ technical plan before coding | Per `tier_approvals` | Linked approved plan revision |
| G-BOOTSTRAP | Greenfield bootstrap plan and instruction scope approved | Engineering lead / platform owner | Linked bootstrap plan revision (`make ai-sdlc-approve-gate GATE=G-BOOTSTRAP`) |
| G-BOOTSTRAP-EXEC | Managed bootstrap execution proposal approved | Engineering lead / platform owner | Managed approval artifact only (`make ai-sdlc-managed-approval-validate`) — **not** `approve-gate` |
| G-SEC | Tier 3+ or risk-rule match | Security champion | Security assessment comment or ticket |
| G-PR-MERGE | Merge to protected branch | CODEOWNERS + policy | Approved PR reviews, green CI |
| G-REL-STG | Promote to staging (org-dependent) | Team lead or automated if low risk | Pipeline record |
| G-REL-PROD | Production deploy | SRE/platform + change record | Change ticket, pipeline approval |
| G-EXC | Waive failing scan or skip test | Security or engineering leadership | Exception ticket with expiry |

## Gate Response SLAs

These SLAs define the maximum expected wait time before an escalation is raised. Teams may override the defaults in `project-config.yaml` under `approval_rules`.

| Gate | Default SLA | Escalation trigger |
|------|------------|-------------------|
| G-PLAN | 2 business days | Raise `ESC-GATE-001` if no response after 2 business days |
| G-SEC | 2 business days | Raise `ESC-GATE-001`; security champion must respond or delegate |
| G-PR-MERGE | 1 business day | Raise `ESC-GATE-001` if no reviewer assigned within 1 business day |
| G-REL-PROD | Same-day (deployment window) | Raise `ESC-GATE-001` immediately if approver is unreachable during change window |
| G-EXC | 1 business day | Raise `ESC-GATE-001`; exception cannot be assumed approved by silence |

**G-PLAN SLA detail:**

1. The technical plan must be submitted (linked in a comment on the issue) before the SLA clock starts.
2. The engineering lead has 2 business days to review and either: approve (comment "G-PLAN approved — @approver"), request changes (comment with specific items), or delegate to a named alternate approver.
3. If no response is received within 2 business days, the engineer raises `ESC-GATE-001` by pinging the engineering lead and their manager in the issue.
4. If the engineering lead is on leave, the designated alternate approver named in `project-config.yaml` handles the gate.
5. Approval by silence is never valid. G-PLAN requires an explicit written approval comment.

**Override:** Teams with faster release cadences may set a shorter G-PLAN SLA in their `project-config.yaml`. Teams in regulated environments may require longer. Document the override in the project config with a rationale comment.

## Escalation IDs

- `ESC-GATE-001`: Approver unavailable past SLA.
- `ESC-GATE-002`: Gate conflict between approvers.
- `ESC-GATE-003`: Policy denied but delivery window critical.
- `ESC-GATE-004`: Emergency stop triggered during gated action.

## Approval Chain Examples

- **Tier 2 path:** `G-PLAN -> G-PR-MERGE -> G-REL-PROD`
- **Tier 3 path:** `G-CLASS (if needed) -> G-PLAN -> G-SEC -> G-PR-MERGE -> G-REL-PROD`
- **Tier 4 path:** `G-CLASS -> G-PLAN -> G-SEC -> G-PR-MERGE -> G-REL-STG -> G-REL-PROD (+ dual control)`

## Preconditions (Non-exhaustive)

### G-PLAN

- Impact analysis attached for Tier 3+.
- Open questions resolved or explicitly deferred with risk acceptance note.
- **H9 package binding:** G-PLAN approval binds to exact specification, technical plan, and test/QA strategy versions/hashes plus requirement revision and business AC hash. Artifact file presence alone does not satisfy G-PLAN. Tier 2+ requires specification and plan at least `REVIEWED`; confirmed business ACs need planned verification coverage. Material upstream or plan changes expire or supersede G-PLAN.

### G-PR-MERGE

- All **must-fix** review threads resolved.
- AI review artifact present if org policy requires (informational still allowed).
- Tier-appropriate scans completed or G-EXC documented.
- Tier 3+: `artifacts.rollback_plan` recorded when `rollback_policy` requires it (see `adoption/rollback-policy-guide.md`).

### Modernization gate (Phase 2)

Before **technical plan** for modernization/migration work:

- Required artifacts: target architecture, migration strategy, compatibility contract, regression baseline, modernization gate review.
- Human approval recorded in `modernization_gate_review` — AI must not approve without explicit human evidence.
- Conditional artifacts by subtype (cloud readiness, data migration plan, decomposition plan).
- Production cutover gates (`G-CUTOVER`, `G-ROLLBACK`, `G-PROD-MIGRATION`, `G-POST-MIGRATION`) are **Phase 3** — enforced only for cutover-active modernization/migration work. See [production-migration-gates-guide.md](../adoption/production-migration-gates-guide.md).

See `adoption/modernization-lane-guide.md`.

### G-REL-PROD

- Release checklist complete (`templates/release-checklist-template.md`).
- Rollback owner named.
- Observability dashboards ready for monitoring window.

## Dual Control

For Tier 4 production changes, enforce **two human approvers** from distinct groups where regulations or internal policy require dual control.

## Human Override Procedure

1. Open exception record with scope, duration, and compensating controls.
2. Obtain approvers required by `G-EXC` plus affected gate owner.
3. Emit override audit event `AUD-EVT-GATE-OVERRIDE-001`.
4. Set automatic expiry and required post-expiry review.

## Emergency Change Path

Emergency changes still require **post-facto** evidence package: incident link, approvers, diffs, and verification. AI agents may assist documentation but **cannot** authorize emergency bypass alone.

## Emergency Stop Procedure

1. Trigger `ESTOP-001` via orchestrator control plane.
2. Block all `restricted_tools` and `destructive_tools`.
3. Preserve in-flight audit trails and artifact snapshots.
4. Resume only after incident commander approval and `AUD-EVT-ESTOP-CLEARED-001`.

## Revocation

If new information appears (for example exploitable vulnerability), approvers may **revoke** prior gate; Orchestrator blocks downstream automation until replanning occurs.

## Gate Audit Event IDs

- `AUD-EVT-GATE-EVALUATED-001`
- `AUD-EVT-GATE-APPROVED-001`
- `AUD-EVT-GATE-REJECTED-001`
- `AUD-EVT-GATE-OVERRIDE-001`
- `AUD-EVT-GATE-REVOKED-001`

## Machine-Readable References

- Gate registry: `ai-sdlc/registry/gate-registry.yaml`
- Event registry: `ai-sdlc/registry/event-registry.yaml`
- Approval schema: `ai-sdlc/schemas/governance/approval-state.schema.json`
- Evidence schema: `ai-sdlc/schemas/governance/evidence-record.schema.json`
- Gate approval evidence model: `ai-sdlc/governance/gate-approval-evidence.md`
- Gate policy enforcement: `ai-sdlc/policies/gates.rego`

## Evidence provenance (H2+)

Gate approvals recorded through `approve-gate` emit canonical evidence in `workflow-state.evidence.records`. Source type, verification status, and confidence are separate dimensions. Manual or pasted references remain `UNVERIFIED` until provider-retrieved evidence exists. See `gate-approval-evidence.md` for authority boundaries. Merge-specific reconciliation is deferred to H3.
