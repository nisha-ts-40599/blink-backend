# Historical Governance Archive

**Status:** Historical  
**Operational authority:** None  
**Retained for:** audit and validation traceability

These records preserve release validation evidence, prospective trial authorization, and remediation history. They are not active operator guidance.

## Current canonical guidance

Active reusable guidance lives under [internal-production-candidate](../internal-production-candidate/README.md).

Controlled adoption templates live under [templates/governance](../../templates/governance/).

## Archive layout

| Directory | Contents |
|-----------|----------|
| [release-validation/](release-validation/) | Release merge authorization, H1–H13 commit inventory |
| [prospective-validation/](prospective-validation/) | Limited rollout setup, readiness, authorization, observation logs |
| [remediation-history/](remediation-history/) | Helper and remediation classification audits |

Each archived document begins with a historical status header where applicable.
