> **Status:** Historical  
> **Operational authority:** None  
> **Retained for:** audit and validation traceability  
> **Current guidance:** [internal-production-candidate/README.md](../../internal-production-candidate/README.md)

# Phase R1B — Limited Internal Pilot Readiness

**Recorded:** 2026-07-17 (Phase R1B push, tag, pilot-setup authorization)  
**Updated:** 2026-07-17 (Phase R1C — owners assigned, Project 1 setup complete)  
**Release tag:** `v0.6.0` @ `777f41453ac0e00b1f9e7d1d3cae1443c5814e6d`  
**Classification:** Internal Production Candidate — **not** Enterprise Ready  
**Phase R1B verdict:** `R1B_RELEASED_PILOT_SETUP_PENDING` → superseded by R1C  
**Phase R1C verdict:** `R1C_PILOT_READY` — see [pilot-setup.md](pilot-setup.md)

Remote release is complete. Pilot workflow start authorized in R1C; `/sdlc-start` not yet executed.

---

## Rollout owner registry

```yaml
rollout:
  framework_version: "0.6.0"
  release_tag: "v0.6.0"
  release_commit: "777f41453ac0e00b1f9e7d1d3cae1443c5814e6d"
  classification: internal_production_candidate
  enterprise_ready: false

  owners:
    rollout_owner: "Atul Kumar Maurya <talentserv@h.local>"
    framework_maintainer: "Atul Kumar Maurya <talentserv@h.local>"
    support_escalation_owner: "Atul Kumar Maurya <talentserv@h.local> (dual-hat — see pilot-setup.md)"
    engineering_approver: "Atul Kumar Maurya <talentserv@h.local>"
    product_approver: "Atul Kumar Maurya <talentserv@h.local>"
    qa_approver: "Atul Kumar Maurya <talentserv@h.local> (pilot-operator alias)"

  cadence:
    weekly_rollout_review: "Mondays 10:00 IST (pilot period)"
    defect_triage: "Wednesdays 10:00 IST (pilot period)"
    reporting_to: "rollout_owner"

  authorization:
    merge_authorization: "R1A complete (2026-07-17)"
    push_tag_authorization: "R1B complete (2026-07-17)"
    pilot_setup_authorization: "R1C complete (2026-07-17)"
    pilot_start_authorization: "APPROVED — operator /sdlc-start pending"
```

---

## Project 1 — existing-project pilot (AITA Dashboard)

```yaml
project_1_existing:
  label: "Project 1 — AITA Dashboard existing-project pilot"
  status: setup_complete_awaiting_sdlc_start
  pilot_type: existing_project
  recommended_tier: "Tier 2 — URL hash section navigation sync"

  project_name: "aita-dashboard"
  repository_path: "/Users/talentserv/Projects/TalentServ/aita-dashboard"
  product_repo: "acadware_aita_dashboard"
  project_owner: "Atul Kumar Maurya <talentserv@h.local>"
  engineering_lead: "Atul Kumar Maurya <talentserv@h.local>"
  qa_actor: "Atul Kumar Maurya <talentserv@h.local> (pilot-operator@talentserv.local)"
  operator: "Atul Kumar Maurya <talentserv@h.local>"
  jira_issue: "none — manual intake; issue prospective-existing-pilot-01"
  workspace_root: "/Users/talentserv/Projects/TalentServ/aita-dashboard"

  lifecycle_route: >
    intake → grooming → Phase 1 → G-PLAN → implementation → evidence →
    merge readiness → candidate/PR → G-PR-MERGE → merge reconciliation → closure

  scope_constraints:
    - Single work item through full lifecycle
    - No production-critical emergency change
    - No regulated client data environment
    - No manual YAML repair planned
```

---

## Project 2 — greenfield pilot (deferred)

```yaml
project_2_greenfield:
  label: "Project 2 — H13 greenfield pilot"
  status: placeholder
  pilot_type: greenfield
  recommended_use: "Internal Engineering Decision Log (h13-greenfield-pilot)"

  project_name: "engineering-decision-log"
  repository_path: "/Users/talentserv/Projects/TalentServ/h13-greenfield-pilot"
  project_owner: "Atul Kumar Maurya <talentserv@h.local>"
  engineering_lead: "Atul Kumar Maurya <talentserv@h.local>"
  qa_actor: "TBD at greenfield intake"
  operator: "Atul Kumar Maurya <talentserv@h.local>"
  jira_issue: "TBD — real issue ID for bootstrap + first feature"
  workspace_root: "/Users/talentserv/Projects/TalentServ/h13-greenfield-pilot"
  planned_start_condition: "After Project 1 G-PLAN on live pilot workflow"

  lifecycle_route: >
    intake → grooming → Phase 1 → G-PLAN → bootstrap plan → G-BOOTSTRAP →
    G-BOOTSTRAP-EXEC → managed execution → completion candidate → Phase 4 readiness →
    first feature → merge readiness → candidate → G-PR-MERGE → reconciliation → closure

  scope_constraints:
    - Local/managed bootstrap only (no unsupported provider automation)
    - Single greenfield repo; no multi-repo program
    - Disposable or internal-only data; no payment systems
```

---

## Recommended pilot scope

| Parameter | Value |
|-----------|-------|
| Framework version | `0.6.0` (`v0.6.0` tag) |
| Projects | 2 (existing + greenfield); optional 3rd QA/automation workflow later |
| Teams | Up to 2 internal delivery teams |
| Duration | 4–8 weeks observation |
| Concurrency | Single-team pilots only; no multi-team federation proof |

### In scope

- Prospective existing-project lifecycle (H12 route)
- Prospective greenfield lifecycle (H13 route)
- Make/Cursor command spine per [operator-command-inventory.md](operator-command-inventory.md)
- Human gate approvals with evidence URLs
- Weekly rollout review and defect triage

### Exclusions (initial phase)

- Production-critical emergency changes
- Regulated client data environments
- Payment systems
- High-risk infrastructure changes
- Multi-repository enterprise programs
- External customer self-service usage
- Claiming Enterprise Ready or multi-team readiness

---

## Entry checks checklist (per project — all required before start)

| # | Check | Project 1 | Project 2 | Notes |
|---|-------|-----------|-----------|-------|
| 1 | Named project owner assigned | ☑ | ☑ | Atul Kumar Maurya |
| 2 | Named engineering lead assigned | ☑ | ☑ | Atul Kumar Maurya |
| 3 | Named QA actor assigned | ☑ | ☐ | P1 complete; P2 at intake |
| 4 | Named operator assigned | ☑ | ☑ | Atul Kumar Maurya |
| 5 | Repository supported (local git, Cursor, Make) | ☑ | ☐ | P2 deferred |
| 6 | Setup compatibility CURRENT or refreshable | ☑ | ☐ | P1 CURRENT @ 0.6.0 |
| 7 | `make ai-sdlc-framework-setup-refresh` dry-run PASS | ☑ | ☐ | P1 PASS |
| 8 | No unsupported provider dependency | ☑ | ☐ | P1 manual tracker |
| 9 | Human gate approval roles agreed | ☑ | ☐ | P1 documented in R1C |
| 10 | No manual YAML editing planned | ☑ | ☑ | |
| 11 | Support escalation owner identified | ☑ | ☑ | Dual-hat documented |
| 12 | MCP Phase 0 read-only safety verified | ☑ | ☐ | P1 per pilot-run-guide |
| 13 | Rollout owner signed entry approval | ☑ | ☐ | P1 R1C; P2 deferred |

**Framework repo validation (once, on tagged release):**

```bash
git checkout v0.6.0
make ai-sdlc-release-candidate-test
make ai-sdlc-guard-framework-clean
```

Both must PASS before any project pilot start. **Verified 2026-07-17 on `main` @ `c35b648`.**

---

## Operating controls

| Control | Requirement |
|---------|-------------|
| Command authority | Trust `make ai-sdlc-stage-router` over prompt-only routing |
| Gate evidence | No `approved: true` without named approver + reference URL |
| State edits | No direct YAML repair; use documented recovery in [support-runbook.md](support-runbook.md) |
| Framework drift | `make ai-sdlc-guard-framework-clean` on product workspaces; stop on failure |
| Provider writes | MCP read-only during pilot; no unattended Jira/GitHub writes |
| Release validation | Re-run `make ai-sdlc-release-candidate-test` after any authorized framework fix |
| Reporting | Weekly rollup to rollout owner; P0 immediate notification |
| Feature branch | `feature/end-to-end-pilot-hardening` retained for audit — do not delete |

### Role responsibilities

| Role | Responsibility |
|------|----------------|
| Rollout owner | Coordinates adoption, weekly review, stop/pause authority (joint on P1) |
| Framework maintainer | RC validation, defect triage, authorized fixes only |
| Project operator | Executes Make/Cursor commands per stage-router |
| Engineering approver | G-PLAN, G-SEC as required |
| Product approver | G-GROOM sign-off |
| QA approver | QA execution evidence |
| Support escalation owner | P0/P1 response per [support-runbook.md](support-runbook.md) |

---

## Stop criteria

### P0 — immediate stop (any project)

- False verified merge or closure
- Unsafe filesystem mutation outside allowed roots
- Provider authority fabrication (synthetic PR URLs, etc.)
- Manual YAML repair required for recovery
- Data loss or unrecoverable state corruption
- Non-waivable gate bypass
- Release-candidate suite regression on `main`
- More than one unresolved P0

**Stop authority:** Any project operator may invoke P0 immediately; rollout owner + framework maintainer confirm pause.

### P1 — pause if repeated across two projects

- Repeated revision conflicts
- Release-candidate suite regression
- Repeated merge-readiness blockers from framework defects

### Metrics to collect (weeks 1–2 baseline)

See [pilot-observation-log.md](pilot-observation-log.md) — initialized with UNKNOWN baseline.

---

## Start boundary

| Operation | Status |
|-----------|--------|
| Merge to `main` | **DONE** — `777f414` |
| Push `origin/main` | **DONE** — `c35b648` |
| Tag `v0.6.0` | **DONE** — points to `777f414` |
| Feature branch retention | **DONE** — `feature/end-to-end-pilot-hardening` retained |
| Assign rollout owners | **DONE** — R1C 2026-07-17 |
| Complete entry checks (Project 1) | **DONE** — R1C 2026-07-17 |
| Complete entry checks (Project 2) | **PENDING** — deferred |
| `sdlc-start` / live pilot execution | **AUTHORIZED** — operator action pending |

**Pilot start gate:** R1C authorization APPROVED. Operator may run `/sdlc-start` from AITA Dashboard workspace.

---

## Related artifacts

- [pilot-setup.md](pilot-setup.md)
- [pilot-start-authorization.md](pilot-start-authorization.md)
- [pilot-observation-log.md](pilot-observation-log.md)
- [merge-authorization.md](merge-authorization.md)
- [release-review-package.md](release-review-package.md)
- [RELEASE-NOTES-v0.6.0.md](RELEASE-NOTES-v0.6.0.md)
- [support-runbook.md](support-runbook.md)
- [test-release-baseline.md](test-release-baseline.md)
- [pilot-run-guide.md](../../adoption/pilot-run-guide.md)
