> **Status:** Historical  
> **Operational authority:** None  
> **Retained for:** audit and validation traceability  
> **Current guidance:** [internal-production-candidate/README.md](../../internal-production-candidate/README.md)

# R1C Pilot Observation Log — AITA Dashboard (Project 1)

**Pilot ID:** `r1c-existing-pilot-01`  
**Initialized:** 2026-07-17 (pre-workflow baseline)  
**Framework version:** `0.6.0` @ `c35b648f68485403a5d29a9a7ba97ed4858c72b7`  
**Observer / rollout owner:** Atul Kumar Maurya \<talentserv@h.local\>

Observation period begins at first `/sdlc-start` execution. Entries below marked **BASELINE** were captured during R1C setup only.

---

## Baseline metrics (weeks 1–2 — pre-pilot)

| Metric | Value | Notes |
|--------|-------|-------|
| workflow starts | 0 | BASELINE — no live pilot intake yet |
| workflows completing Phase 0 | 0 | BASELINE |
| DoR failure rate | UNKNOWN | BASELINE |
| gate rejection rate | UNKNOWN | BASELINE |
| time in each phase | UNKNOWN | BASELINE |
| manual workaround count | 0 | BASELINE — setup only |
| direct-state-edit count | 0 | BASELINE — target remains 0 |
| evidence recognition failures | 0 | BASELINE |
| merge-readiness blockers | UNKNOWN | BASELINE |
| bootstrap recovery count | 0 | BASELINE — existing_managed |
| projection failures | 0 | BASELINE |
| closure contradictions | 0 | BASELINE |
| P0 defect count | 0 | BASELINE |
| P1 defect count | 0 | BASELINE |
| operator satisfaction | UNKNOWN | BASELINE — qualitative |
| delivery lead time | UNKNOWN | BASELINE |

---

## Setup observations (R1C)

| ID | Date | Phase | Severity | Type | Observation | Expected | Status |
|----|------|-------|----------|------|-------------|----------|--------|
| OBS-R1C-001 | 2026-07-17 | R1C setup | low | validation | `setup-state.yaml` top-level `delivery_ready: false` while live validator returns `delivery_ready: true` after framework binding refresh to 0.6.0 | Consistent setup-state snapshot after refresh | open |
| OBS-R1C-002 | 2026-07-17 | R1C setup | low | workflow | `ai-sdlc-existing-refresh-dry-run` reports `CURRENT_PLAN_REFERENCE_MISSING` on existing_managed workspace | N/A for non-greenfield — document skip | wont_fix |
| OBS-R1C-003 | 2026-07-17 | R1C setup | medium | policy | Support escalation dual-hatted on Atul Kumar Maurya — no second named senior engineer in overlays | Distinct support owner before broader rollout | accepted_risk |

---

## Gap log (live pilot — use during execution)

| id | date | phase | command | severity | type | observed_behavior | expected_behavior | evidence_ref | workaround | recommended_action | owner | status |
|----|------|-------|---------|----------|------|-------------------|-------------------|--------------|------------|-------------------|-------|--------|
| — | — | — | — | — | — | *(no live pilot gaps yet)* | — | — | — | — | — | — |

Template: [pilot-gap-log-template.md](../../adoption/templates/pilot-gap-log-template.md)

---

## Weekly review rollup

| Week | Date | Reviewer | Summary | Actions |
|------|------|----------|---------|---------|
| 0 | 2026-07-17 | Atul Kumar Maurya | R1C setup complete; awaiting first `/sdlc-start` | Execute first live workflow |

---

## Stop criteria acknowledgement

Signatories confirm understanding of P0 immediate stop and P1 pause criteria per [pilot-readiness.md](pilot-readiness.md) § Stop criteria.

| Signatory | Role | Acknowledged | Date |
|-----------|------|------------|------|
| Atul Kumar Maurya | Rollout owner | Yes | 2026-07-17 |
| Atul Kumar Maurya | Project operator | Yes | 2026-07-17 |

---

## Operating controls acknowledgement

| Control | Acknowledged by | Date |
|---------|-----------------|------|
| Command authority via stage-router | Atul Kumar Maurya | 2026-07-17 |
| Gate evidence requires named human + URL | Atul Kumar Maurya | 2026-07-17 |
| No direct YAML repair | Atul Kumar Maurya | 2026-07-17 |
| MCP read-only during pilot | Atul Kumar Maurya | 2026-07-17 |
| Framework drift guard on product workspaces | Atul Kumar Maurya | 2026-07-17 |
