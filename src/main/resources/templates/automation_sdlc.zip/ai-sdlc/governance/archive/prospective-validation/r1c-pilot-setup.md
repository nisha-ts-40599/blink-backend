> **Status:** Historical  
> **Operational authority:** None  
> **Retained for:** audit and validation traceability  
> **Current guidance:** [internal-production-candidate/README.md](../../internal-production-candidate/README.md)

# Phase R1C — Pilot Setup Completion and Start Authorization

**Recorded:** 2026-07-17  
**Framework version:** `0.6.0` (`v0.6.0` @ `777f41453ac0e00b1f9e7d1d3cae1443c5814e6d`)  
**Framework repo `origin/main`:** `c35b648f68485403a5d29a9a7ba97ed4858c72b7`  
**Classification:** Internal Production Candidate — **not** Enterprise Ready  
**Phase R1C verdict:** `R1C_PILOT_READY` (setup complete; workflow start **not** executed)

---

## 1. Release baseline verification

| Check | Result |
|-------|--------|
| Branch | `main` |
| Local HEAD | `c35b648f68485403a5d29a9a7ba97ed4858c72b7` |
| `origin/main` | `c35b648f68485403a5d29a9a7ba97ed4858c72b7` |
| Local = origin | **PASS** |
| Release tag on `777f414` | `v0.6.0` |
| `make ai-sdlc-release-candidate-test` | **PASS** |
| `make ai-sdlc-guard-framework-clean` | **PASS** |

---

## 2. Rollout governance owners

```yaml
rollout:
  framework_version: "0.6.0"
  release_tag: "v0.6.0"
  release_commit: "777f41453ac0e00b1f9e7d1d3cae1443c5814e6d"
  origin_main: "c35b648f68485403a5d29a9a7ba97ed4858c72b7"
  classification: internal_production_candidate
  enterprise_ready: false

  owners:
    rollout_owner:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
      authorized: "2026-07-17"
      responsibilities:
        - "Coordinate limited internal pilot adoption"
        - "Weekly rollout review chair"
        - "Joint stop/pause authority on P1; immediate P0 escalation recipient"
    framework_maintainer:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
      authorized: "2026-07-17"
      responsibilities:
        - "Release-candidate validation on authorized fixes"
        - "Framework defect triage"
        - "Joint stop/pause authority on P1"
    support_escalation_owner:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
      authorized: "2026-07-17"
      dual_role_risk: >
        No second named senior engineer was documented in TalentServ project overlays.
        Support escalation is temporarily dual-hatted with rollout/framework roles.
        Accepted limited-rollout risk: P0 stop remains available to any operator;
        escalation path documented in support-runbook.md.
      responsibilities:
        - "P0/P1 response per support-runbook.md"
        - "Operator unblock during pilot hours"
    weekly_review_owner:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
    stop_authority:
      - "Atul Kumar Maurya (rollout owner)"
      - "Atul Kumar Maurya (framework maintainer)"
      - "Any operator detecting a P0"

  approvers:
    engineering_approver:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
      pilot_role_alias: "Engineering Lead Pilot:engineering-lead@talentserv.local"
      policy: "Limited rollout — single human executes G-PLAN and G-PR-MERGE gate approvals"
    product_approver:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
      pilot_role_alias: "Product Owner Pilot:product-owner@talentserv.local"
      policy: "Limited rollout — single human executes G-GROOM gate approvals"
    qa_approver:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
      pilot_role_alias: "pilot-operator@talentserv.local"
      policy: "Limited rollout — QA execution evidence recorded by operator human; distinct pilot mailbox retained for audit trail"

  cadence:
    weekly_rollout_review: "Mondays 10:00 IST (pilot period)"
    defect_triage: "Wednesdays 10:00 IST (pilot period)"
    reporting_to: "rollout_owner"

  escalation_path:
    p0: "Any operator → immediate stop → notify rollout_owner + framework_maintainer"
    p1: "Operator → support_escalation_owner → weekly review if repeated"
    framework_defect: "framework_maintainer → authorized fix → re-run RC test"

  authorization:
    merge_authorization: "R1A complete (2026-07-17)"
    push_tag_authorization: "R1B complete (2026-07-17)"
    pilot_setup_authorization: "R1C complete (2026-07-17) — see pilot-start-authorization.md"
    pilot_start_authorization: "APPROVED — workflow start deferred to operator /sdlc-start"
```

---

## 3. First pilot — existing project selection

**Selected project:** AITA Dashboard (`aita-dashboard`)  
**Workspace root:** `/Users/talentserv/Projects/TalentServ/aita-dashboard`  
**Product repository:** `acadware_aita_dashboard` @ `/Users/talentserv/Projects/TalentServ/aita-dashboard/acadware_aita_dashboard`  
**Selection rationale:** H12 validated existing-project route; overlay present; Tier 2 frontend POC; tests present (287 passing).

### Inspection summary

| Check | Result | Notes |
|-------|--------|-------|
| Workspace git root | N/A (multi-repo workspace) | Expected for H12 workspace shape |
| Product repo git clean | **PASS** | `acadware_aita_dashboard` clean working tree |
| Product repo branch | `feature/h12-hash-section-sync` | H12 implementation branch (not merged) |
| `.cursor/ai-sdlc` overlay | **PASS** | Multi-repo overlay present |
| Tests present | **PASS** | Vitest — 34 files, 287 tests passing |
| Tier 1/2 suitability | **PASS** | Static React dashboard POC; no prod/regulated data |
| Conflicting workflows | **DOCUMENTED** | See workflow inventory below |

### Workflow inventory (inactive vs designated)

| Issue ID | Stage (approx.) | Pilot designation |
|----------|-----------------|-------------------|
| `prospective-existing-pilot-01` | PLAN_APPROVED (H12 evidence) | **Designated first live pilot issue** |
| `functional-enhancements-03` | REQUIREMENT (groomed, not started) | Inactive — do not start concurrently |
| `function-enhancements-02` | Historical | Inactive |
| `LOCAL-E7488BA3` | Local/test | Inactive |

**Concurrent pilot rule:** Single active workflow only. Do not start `functional-enhancements-03` until first pilot closes or is explicitly paused.

### Proposed change (not implemented in R1C)

```yaml
proposed_change:
  title: "URL hash section navigation sync"
  issue_id: "prospective-existing-pilot-01"
  tier: 2
  type: "Enhancement — single-repo frontend behavior"
  description: >
    Synchronize dashboard section navigation with browser URL hash so users can
    deep-link to sections, use browser back/forward, and share URLs that open the
    correct section. Groomed in H12 prospective pilot; implementation on branch
    feature/h12-hash-section-sync pending live pilot completion through merge/closure.
  risk: "Low — UI-only; unit tests present; no backend or auth changes"
  alternative_if_fresh_intake_preferred: >
    Tier 2 validation improvement such as manifest data-freshness indicator in header
```

---

## 4. Pilot record — Project 1 (existing)

```yaml
pilot_record:
  pilot_id: "r1c-existing-pilot-01"
  label: "Project 1 — AITA Dashboard existing-project pilot"
  status: "setup_complete_awaiting_sdlc_start"
  pilot_type: existing_project
  framework_binding:
    version: "0.6.0"
    commit: "c35b648f68485403a5d29a9a7ba97ed4858c72b7"
    compatibility_status: "CURRENT"
    release_channel: "internal-production-candidate"

  workspace:
    name: "AITA Dashboard Workspace"
    identifier: "aita-dashboard"
    root_path: "/Users/talentserv/Projects/TalentServ/aita-dashboard"
    shape: "multi-repo"

  product_repository:
    repo_id: "acadware-aita-dashboard"
    path: "acadware_aita_dashboard"
    git_present: true
    git_clean: true

  actors:
    project_owner:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
    engineering_lead:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
      gate_role: "G-PLAN, G-PR-MERGE"
      pilot_alias: "engineering-lead@talentserv.local"
    product_owner:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
      gate_role: "G-GROOM"
      pilot_alias: "product-owner@talentserv.local"
    qa_actor:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
      pilot_alias: "pilot-operator@talentserv.local"
    operator:
      name: "Atul Kumar Maurya"
      email: "talentserv@h.local"
      pilot_alias: "pilot-operator@talentserv.local"

  issue_tracker:
    system: manual
    jira_issue: "none — manual intake mode"

  lifecycle_route: >
    intake → grooming → Phase 1 → G-PLAN → implementation → evidence →
    merge readiness → candidate/PR → G-PR-MERGE → merge reconciliation → closure

  scope_constraints:
    - Single work item through full lifecycle
    - No production-critical emergency change
    - No regulated client data environment
    - No manual YAML repair planned
    - MCP read-only during pilot

  setup_validation:
    validate_setup_readiness: "PASS (delivery_ready: true)"
    framework_setup_refresh_dry_run: "PASS (REFRESH_NO_OP, CURRENT)"
    framework_setup_refresh_write: "PASS (REFRESH_NO_OP idempotent, CURRENT @ 0.6.0)"
    existing_refresh_dry_run: "SKIP — CURRENT_PLAN_REFERENCE_MISSING (existing_managed; bootstrap plan N/A)"
    stage_router: "PASS (read-only, issue prospective-existing-pilot-01)"
```

---

## 5. Pilot record — Project 2 (greenfield, deferred)

```yaml
pilot_record_greenfield:
  pilot_id: "r1c-greenfield-pilot-02"
  label: "Project 2 — H13 greenfield pilot (deferred)"
  status: placeholder
  pilot_type: greenfield
  candidate_workspace: "/Users/talentserv/Projects/TalentServ/h13-greenfield-pilot"
  candidate_spec: "Internal Engineering Decision Log"
  planned_start_condition: >
    Start AFTER Project 1 reaches G-PLAN approval on live pilot workflow
    (not H12 synthetic completion). Do not use as first existing-project pilot.
  placeholders:
    project_name: "engineering-decision-log"
    operator: "Atul Kumar Maurya <talentserv@h.local>"
    jira_issue: "TBD — real issue ID at greenfield intake"
```

---

## 6. Setup compatibility and refresh log

| Step | Command | Result | Reviewer |
|------|---------|--------|----------|
| 1 | `make ai-sdlc-validate-setup-readiness ROOT=aita-dashboard FORMAT=json` | PASS — `delivery_ready: true`, no blocking reasons | Automated |
| 2 | `make ai-sdlc-framework-setup-refresh ROOT=aita-dashboard` (dry-run) | PASS — `REFRESH_NO_OP`, CURRENT | Automated |
| 3 | Human review | **Signed** — Atul Kumar Maurya (rollout owner), 2026-07-17 | Atul Kumar Maurya |
| 4 | `make ai-sdlc-framework-setup-refresh ROOT=aita-dashboard WRITE=1` | PASS — binding updated to `0.6.0` / `c35b648` | Automated |
| 5 | Idempotent `WRITE=1` repeat | PASS — `REFRESH_NO_OP` | Automated |
| 6 | `make ai-sdlc-validate-setup-readiness ROOT=aita-dashboard REQUIRE=delivery FORMAT=json` | PASS | Automated |
| 7 | `make ai-sdlc-stage-router ROOT=aita-dashboard ISSUE=prospective-existing-pilot-01` | PASS (read-only) | Automated |

**Note:** `setup-state.yaml` top-level `setup_readiness.delivery_ready` may show stale `false` from prior refresh_result snapshot; live validator and `framework.compatibility_status: CURRENT` are authoritative post-R1C refresh.

---

## 7. Role validation (human gates)

| Gate | Configured approver identity | Named human executor | AI-only? |
|------|------------------------------|----------------------|----------|
| G-GROOM | Product Owner Pilot:product-owner@talentserv.local | Atul Kumar Maurya | **No** |
| G-PLAN | Engineering Lead Pilot:engineering-lead@talentserv.local | Atul Kumar Maurya | **No** |
| G-PR-MERGE | Engineering Lead Pilot:engineering-lead@talentserv.local | Atul Kumar Maurya | **No** |

Pilot mailboxes are role aliases for audit; gate evidence must record named human approver + reference URL per operating controls.

---

## 8. Observation log and baseline metrics

- **Framework template:** [pilot-observation-log.md](pilot-observation-log.md)
- **Project-local mirror (optional):** `aita-dashboard/.cursor/ai-sdlc/pilot/observation-log.md` — not created (framework governance path used)

Baseline metrics initialized with `UNKNOWN` where no live pilot data exists yet. See observation log § Baseline metrics.

---

## 9. Operating controls and stop criteria sign-off

| Signatory | Role | Controls acknowledged | Stop criteria acknowledged | Date |
|-----------|------|----------------------|---------------------------|------|
| Atul Kumar Maurya | Rollout owner | Yes | Yes | 2026-07-17 |
| Atul Kumar Maurya | Framework maintainer | Yes | Yes | 2026-07-17 |
| Atul Kumar Maurya | Project operator | Yes | Yes | 2026-07-17 |

Controls per [pilot-readiness.md](pilot-readiness.md) § Operating controls and [support-runbook.md](support-runbook.md).

---

## 10. Pilot-start authorization

See [pilot-start-authorization.md](pilot-start-authorization.md) — status **APPROVED**.

**Workflow start:** **NOT EXECUTED** in R1C.

### Next command (operator only — do not run in R1C)

From workspace `/Users/talentserv/Projects/TalentServ/aita-dashboard`:

```
/sdlc-start "URL hash section navigation sync — Tier 2 frontend enhancement for deep-linking dashboard sections"
```

Or continue existing issue `prospective-existing-pilot-01` per stage-router if resuming H12 evidence path instead of fresh intake.

---

## 11. R1C completion criteria (23/23)

| # | Criterion | Status |
|---|-----------|--------|
| 1 | Release baseline verified | PASS |
| 2 | Rollout owners assigned (named humans) | PASS |
| 3 | Support owner named (dual-hat documented) | PASS |
| 4 | First pilot project selected | PASS — aita-dashboard |
| 5 | Product repo git clean | PASS |
| 6 | Overlay present | PASS |
| 7 | Tests present | PASS |
| 8 | Conflicting workflows documented | PASS |
| 9 | Proposed change recorded | PASS |
| 10 | Pilot record created | PASS |
| 11 | Compatibility check pass | PASS |
| 12 | Dry-run refresh pass | PASS |
| 13 | Human review documented | PASS |
| 14 | WRITE=1 refresh applied | PASS |
| 15 | Idempotent refresh verified | PASS |
| 16 | Framework CURRENT @ 0.6.0 | PASS |
| 17 | Gate role humans documented | PASS |
| 18 | Observation log initialized | PASS |
| 19 | Baseline metrics recorded | PASS |
| 20 | Operating controls sign-off | PASS |
| 21 | Stop criteria acknowledgement | PASS |
| 22 | Authorization APPROVED artifact | PASS |
| 23 | No intake / sdlc-start executed | PASS |

**Verdict:** `R1C_PILOT_READY`

---

## Related artifacts

- [pilot-readiness.md](pilot-readiness.md)
- [pilot-start-authorization.md](pilot-start-authorization.md)
- [pilot-observation-log.md](pilot-observation-log.md)
- [merge-authorization.md](merge-authorization.md)
