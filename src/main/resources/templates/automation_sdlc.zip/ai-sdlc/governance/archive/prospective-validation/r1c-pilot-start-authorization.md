> **Status:** Historical  
> **Operational authority:** None  
> **Retained for:** audit and validation traceability  
> **Current guidance:** [internal-production-candidate/README.md](../../internal-production-candidate/README.md)

# Phase R1C — Pilot-Start Authorization

**Status:** APPROVED  
**Authorization date:** 2026-07-17  
**Authorizing party:** Atul Kumar Maurya (rollout owner)  
**Authorization channel:** Phase R1C operator instruction with named human assignments

---

## Framework binding

| Field | Value |
|-------|-------|
| Framework version | `0.6.0` |
| Release tag | `v0.6.0` |
| Release commit | `777f41453ac0e00b1f9e7d1d3cae1443c5814e6d` |
| Framework repo `origin/main` | `c35b648f68485403a5d29a9a7ba97ed4858c72b7` |
| Classification | Internal Production Candidate |
| Enterprise Ready | **false** |

---

## Authorized scope

| Item | Authorization |
|------|---------------|
| Limited internal pilot setup on AITA Dashboard | **APPROVED** |
| Framework setup refresh on product workspace (`WRITE=1`) | **APPROVED** (completed in R1C) |
| First live workflow via `/sdlc-start` | **APPROVED** — operator may execute after reading this record |
| Push to remote | **NOT AUTHORIZED** by R1C |
| Tag creation | **NOT AUTHORIZED** by R1C |
| Enterprise Ready claim | **NOT AUTHORIZED** |

---

## Preconditions verified

| Precondition | Verified |
|--------------|----------|
| `make ai-sdlc-release-candidate-test` PASS on framework `main` | Yes — 2026-07-17 |
| `make ai-sdlc-guard-framework-clean` PASS | Yes — 2026-07-17 |
| Local HEAD = `origin/main` | Yes — `c35b648` |
| Rollout owners assigned (named humans) | Yes |
| Support escalation owner assigned | Yes (dual-hat — see pilot-setup.md) |
| Project 1 setup compatibility CURRENT @ 0.6.0 | Yes |
| Entry checks signed for Project 1 | Yes |
| Gate approver humans documented | Yes |
| Observation log initialized | Yes |
| No workflow intake started during R1C | Yes |

---

## Authorized pilot

```yaml
authorized_pilot:
  project: "aita-dashboard"
  workspace_root: "/Users/talentserv/Projects/TalentServ/aita-dashboard"
  product_repo: "acadware_aita_dashboard"
  proposed_issue: "prospective-existing-pilot-01"
  proposed_change: "URL hash section navigation sync (Tier 2)"
  operator: "Atul Kumar Maurya <talentserv@h.local>"
```

---

## Signatories

| Name | Role | Signature | Date |
|------|------|-----------|------|
| Atul Kumar Maurya | Rollout owner | Authorized via Phase R1C instruction | 2026-07-17 |
| Atul Kumar Maurya | Framework maintainer | Authorized via Phase R1C instruction | 2026-07-17 |

---

## Explicit deferrals

- Workflow execution (`/sdlc-start`, intake mutation) deferred to post-R1C operator action
- Greenfield pilot (Project 2) deferred until Project 1 reaches G-PLAN on live workflow
- Remote push of framework or governance docs not authorized by R1C

---

## Next operator action

Execute from AITA Dashboard workspace (not during R1C automation):

```
/sdlc-start "URL hash section navigation sync — Tier 2 frontend enhancement for deep-linking dashboard sections"
```

Framework Make spine alternative (if using stage-router prep only):

```bash
cd /Users/talentserv/Projects/TalentServ/automation_sdlc
make ai-sdlc-stage-router ROOT=/Users/talentserv/Projects/TalentServ/aita-dashboard ISSUE=prospective-existing-pilot-01
```

---

## Related artifacts

- [pilot-setup.md](pilot-setup.md)
- [pilot-readiness.md](pilot-readiness.md)
