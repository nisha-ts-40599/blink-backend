> **Status:** Historical  
> **Operational authority:** None  
> **Retained for:** audit and validation traceability  
> **Current guidance:** [internal-production-candidate/README.md](../../internal-production-candidate/README.md)

# H1–H13 Commit Inventory

Source of truth: Git history on `feature/end-to-end-pilot-hardening` (starting commit `daee41b`).

## Inventory

| Phase | Commit(s) | Capability | Validation | Status |
|-------|-----------|------------|------------|--------|
| H1 | `f36f032` | Cross-platform safety (Phase 5 symlink escape harness) | `ai-sdlc-phase5-*-test`, orchestration | **CANONICAL** |
| H2 | `5813aa2` | Evidence provenance and verification model | `test_intake_provenance`, `test_evidence_common`, orchestration | **CANONICAL** |
| H3 | `5835c11` | Merge reconciliation; block contradictory/unverified merge closure | `test_merge_reconciliation`, `test_close_merge`, orchestration | **CANONICAL** |
| H4 | `bfcc0b1` | Closure evidence completeness | `test_closure_eligibility`, `test_lifecycle_evidence`, orchestration | **CANONICAL** |
| H5 | `9d75a79` | Canonical workflow state and artifact projection sync | `test_artifact_projection`, `test_workflow_transaction`, orchestration | **CANONICAL** |
| H6 | `afaad07`, `aea6cec` | Framework versioning, overlay binding, setup refresh migration | `test_framework_compatibility`, `test_setup_state_migration`, orchestration | **CANONICAL** (two commits, single capability) |
| H7 | `c8181e1` | Gate policy and approval role reconciliation | `test_gate_policy`, `test_role_authorization`, `test_tier2_gplan_drift_fixture` | **CANONICAL** |
| H8 | `b687da0` | Intake and grooming provenance | `test_grooming_model`, `test_intake_grooming_provenance_fixture`, orchestration | **CANONICAL** |
| H9 | `e1bf74e` | Phase 1 pre-development approval and QA strategy | `test_predevelopment_*`, `test_predevelopment_legacy_gplan_fixture`, orchestration | **CANONICAL** |
| H10 | `e8ca894` | Implementation and QA evidence normalization | `test_command_evidence`, `test_qa_execution`, `test_implementation_execution_legacy_fixture` | **CANONICAL** |
| H11 | `3974b9c` | Greenfield bootstrap operator integration | `ai-sdlc-greenfield-h11-test`, `ai-sdlc-greenfield-e2e-test` | **CANONICAL** |
| H12 | `4c5945d`, `85b947b`, `f9f5fcd` | Prospective existing-pilot defects, closure path, local candidate metadata | `test_existing_project_remediation`, `test_pr_candidate_metadata`, boundary fixture | **CANONICAL** (three commits, one remediation arc) |
| H13 | `f58b737`, `3ddedce`, `daee41b` | Grooming resolution semantics, duplicate intake, bootstrap resume/closure | `test_greenfield_bootstrap_remediation`, `test_duplicate_workflow`, boundary fixture | **CANONICAL** (three commits, one remediation arc) |

## Analysis

### Missing
None of the expected H1–H13 major commits are absent from the branch tip ancestry.

### Duplicate / superseded
- **H6:** `afaad07` (version binding) superseded in part by `aea6cec` (migration/readiness metadata). Both retained; `aea6cec` is the operational migration commit.
- **H12:** Three sequential fix commits — not duplicates; each addresses distinct defect classes (general defects → closure path → candidate push/metadata).
- **H13:** Three sequential fix commits — grooming semantics → duplicate workflows → bootstrap resume/false closure.

### Mixed-scope
- **H1** (`f36f032`): Labeled cross-platform safety; commit message references Phase 5 test harness. Scope is test infrastructure, not new lifecycle capability — acceptable as H1 anchor.
- Pre-H1 history (Phase 5 managed bootstrap, Phase 4) remains foundational but is outside H1–H13 inventory.

### Orphaned
- No orphaned H-phase commits without corresponding tests or docs.
- External pilot workspace `<project-root>/h13-greenfield-pilot` is optional for H13 scenarios P/Q/T; in-repo disposable fixtures replace this for CI.

## Historical evidence
All pilot evidence directories under `.cursor/ai-sdlc/` in live workspaces and `ai-sdlc/examples/disposable-fixtures/` are preserved. No history rewrite performed.
