> **Status:** Historical  
> **Operational authority:** None  
> **Retained for:** audit and validation traceability  
> **Current guidance:** [internal-production-candidate/README.md](../../internal-production-candidate/README.md)

# Pilot Helper Audit (H12/H13)

Classification of helpers referenced in H12/H13 remediation. Files named `h13_bootstrap_execute.py`, `h13_record_evidence.py`, `h13_workflow_helper.py` **do not exist** in the repository; functionality lives in canonical framework modules below.

## Classification key

| Class | Meaning |
|-------|---------|
| CANONICAL_FRAMEWORK_COMPONENT | Production operator/runtime path |
| TEST_FIXTURE | Disposable regression fixture or test helper |
| NONCANONICAL_DIAGNOSTIC | Debug/pilot-only; not in operator guidance |
| PILOT_ARTIFACT | Live pilot evidence; preserved, not deleted |
| OBSOLETE_WORKAROUND | Superseded; retained for regression only |
| REMOVE_FROM_OPERATOR_PATH | Excluded from runbooks; historical only |

## Inventory

| Helper | Classification | Canonical replacement | Action |
|--------|----------------|----------------------|--------|
| `orchestration/pr_candidate.py` | CANONICAL_FRAMEWORK_COMPONENT | `ai-sdlc-register-pr` | Document in operator inventory |
| `orchestration/correct_pr_registration.py` | CANONICAL_FRAMEWORK_COMPONENT | `ai-sdlc-correct-pr-registration` | Document |
| `orchestration/record_execution_provenance.py` | CANONICAL_FRAMEWORK_COMPONENT | `ai-sdlc-record-execution-provenance` | Document |
| `orchestration/duplicate_workflow.py` | CANONICAL_FRAMEWORK_COMPONENT | `ai-sdlc-consolidate-duplicate-workflow` | Document |
| `orchestration/intake_operator_status.py` | CANONICAL_FRAMEWORK_COMPONENT | `ai-sdlc-intake-operator-status` | Document |
| `setup/managed_bootstrap/finalize_runtime.py` | CANONICAL_FRAMEWORK_COMPONENT | `ai-sdlc-managed-finalize` | Document |
| `setup/managed_bootstrap/action_classification.py` | CANONICAL_FRAMEWORK_COMPONENT | Used by managed execute | Internal |
| `setup/managed_bootstrap/approved_action_selection.py` | CANONICAL_FRAMEWORK_COMPONENT | Used by managed execute | Internal |
| `setup/phase4_test_helpers.py` | TEST_FIXTURE | N/A | Keep for unit tests |
| `setup/concurrency_test_helpers.py` | TEST_FIXTURE | N/A | Keep for Phase 5.3 tests |
| `orchestration/test_existing_project_remediation.py` | TEST_FIXTURE | H12 boundary tests | Keep |
| `orchestration/test_pr_candidate_metadata.py` | TEST_FIXTURE | H12R2 scenarios | Keep |
| `setup/test_greenfield_bootstrap_remediation.py` | TEST_FIXTURE | H13 scenarios A–T | Keep |
| `orchestration/test_duplicate_workflow.py` | TEST_FIXTURE | Duplicate intake | Keep |
| `examples/disposable-fixtures/aita-*` | TEST_FIXTURE | Phase-specific regression | Preserve all |
| `examples/disposable-fixtures/existing-project-delivery-boundary` | TEST_FIXTURE | S1 H12 boundary | Keep |
| `examples/disposable-fixtures/greenfield-delivery-boundary` | TEST_FIXTURE | S1 H13 boundary | Keep |
| External `h13-greenfield-pilot` workspace | PILOT_ARTIFACT | In-repo H13 boundary fixture | Optional; not required for CI |
| Live AITA dashboard overlay | PILOT_ARTIFACT | Disposable fixtures | Never modify in tests |
| Synthetic PR URLs (`local.unverified.example`) | OBSOLETE_WORKAROUND | `LOCAL_UNPUSHED_CANDIDATE` | Rejected at registration |
| Direct YAML repair scripts (none shipped) | REMOVE_FROM_OPERATOR_PATH | Operator commands | Not documented |

## Operator guidance

Normal operator path uses **Make targets** and **Cursor slash commands** only. Test helpers (`phase4_test_helpers`, `concurrency_test_helpers`) and `test_*` modules must not appear in adoption docs or runbooks.

## Historical evidence

All pilot execution artifacts under `bootstrap-executions/`, managed proposals/approvals, and live workspace `.cursor/ai-sdlc/` directories are preserved. S1 adds disposable in-repo boundary fixtures without deleting pilot history.
