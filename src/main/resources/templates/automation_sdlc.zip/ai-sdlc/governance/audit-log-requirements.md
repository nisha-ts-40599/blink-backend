# Audit Log Requirements

Audit logs provide **traceability** for AI-assisted SDLC: who/what approved, what tools ran, and what artifacts promoted between environments.

## Events to Capture

| Category | Event examples | Minimum fields |
|----------|----------------|------------------|
| Identity | Human login, agent profile activation | subject, time, MFA status if applicable |
| Issue lifecycle | Create, transition, close | issue_id, from_state, to_state, actor |
| Planning | Plan approved/revoked | plan_id, revision, approvers |
| Code change | Push, PR open, PR merge | repo, branch, sha, actor |
| CI/CD | Pipeline start/end, promotion | pipeline_id, commit, result |
| MCP / tools | Tool invocation start/end | server, tool, args_digest, result, correlation_id |
| Security | Scan ingest, waiver | finding_id, action, approver |
| Release | Tag, deploy command | environment, version, actor |

## Audit Event ID Catalog

- `AUD-EVT-ISSUE-STATE-001`
- `AUD-EVT-PLAN-APPROVAL-001`
- `AUD-EVT-PR-MERGE-DECISION-001`
- `AUD-EVT-PR-MERGE-COMPLETION-001`
- `AUD-EVT-REL-CANDIDATE-001`
- `AUD-EVT-DEPLOY-BASELINE-001`
- `AUD-EVT-POSTREL-VERIFY-001`
- `AUD-EVT-POLICY-VIOLATION-001`
- `AUD-EVT-ESTOP-TRIGGERED-001`

## Field Standards

- **Timestamps:** UTC RFC 3339.
- **Actor:** Distinguish `human:user_id` vs `agent:profile` vs `service_account:mcp-git`.
- **Correlation:** `correlation_id` must chain issue → PR → pipeline → deploy record.
- **Integrity:** Append-only storage; tamper detection for regulated environments.

## Policy Violation Lifecycle (Audit Perspective)

1. Detect and record `AUD-EVT-POLICY-VIOLATION-001`.
2. Mark workflow `blocked`.
3. Emit escalation (`ESC-*`) with approver routing metadata.
4. Record remediation event (`AUD-EVT-POLICY-REMEDIATE-001`) or closure event (`AUD-EVT-POLICY-CLOSED-001`).

## Retention

Align with `project-config.audit_and_compliance.retention_days` and legal hold procedures.

## Audit Retention Model

- **Hot store:** 0-30 days for operational queries.
- **Warm store:** 31-365 days for compliance and investigations.
- **Cold archive:** >365 days per regulatory requirements.
- **Legal hold:** immutable extension beyond standard retention windows.

## Access Control

Audit readers are **least privilege**; modification of audit streams restricted to security operations.

## Agent-Specific Notes

Model prompts and completions may contain sensitive content; **redact** or **avoid logging** raw prompts where policy requires, while still logging tool boundaries and decisions.

## Reporting

Support export for **internal audit** and **customer assurance** questionnaires with filters by release_id and service.
