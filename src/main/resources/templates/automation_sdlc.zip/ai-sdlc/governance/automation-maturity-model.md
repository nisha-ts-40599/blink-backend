# Automation Maturity Model (AI-SDLC)

This model describes progression from **assisted** AI usage to **semi-autonomous** SDLC orchestration. Levels are cumulative.

## Level 0 — Ad hoc assistance

- Individuals use AI in the IDE without shared prompts, templates, or audit expectations.
- **Risks:** Inconsistent quality, no traceability, tool sprawl.

## Level 1 — Assisted documentation and analysis

- Shared prompts (`ai-sdlc/prompts/`) and templates adopted.
- MCP read-only for repo, issues, CI results.
- Humans execute all merges and deployments.
- **Outcome:** Faster drafting; governance lightly enforced.

## Level 2 — Standardized workflow integration

- Workflows in `ai-sdlc/workflows/` adopted as team runbooks.
- Tier classification mandatory; approval gates documented.
- CI templates include scans and coverage thresholds.
- AI review required as informational input on PRs.
- **Outcome:** Predictable rigor; merge/deploy still human.

## Level 3 — Orchestrated agentic execution (non-production)

- Orchestrator coordinates agents with ACP handoffs for feature branches.
- Automated issue/spec generation with human confirmation gates.
- Sandboxed auto-fix loops for lint/test failures within PRs.
- **Outcome:** Higher throughput; strong audit and MCP permissions required.

## Level 4 — Semi-autonomous SDLC (select paths)

- Policy-approved bots merge **narrow** classes of change (for example internal docs, dependency patches meeting SCA rules).
- Progressive delivery automation with human go/no-go for production only.
- Continuous post-release verification with automated knowledge updates to draft spaces.
- **Outcome:** Maximum safe velocity; highest operational maturity and monitoring investment.

## Advancement Criteria

Advance a level only when **all** are true for the prior level:

1. Audit logs meet `audit-log-requirements.md`.
2. MCP posture matches `mcp-security-guidelines.md`.
3. Incident retros show controllable blast radius from AI-assisted changes.
4. Training completed for humans on new gates and exceptions.

## Operational Control IDs by Level

- **L1:** `POL-L1-READONLY-001`, `AUD-L1-MIN-001`
- **L2:** `POL-L2-GATES-001`, `AUD-L2-WORKFLOW-001`
- **L3:** `POL-L3-ACP-001`, `POL-L3-RETRY-001`, `AUD-L3-ORCH-001`
- **L4:** `POL-L4-AUTO-MERGE-SCOPE-001`, `POL-L4-PROD-HITL-001`, `AUD-L4-CHANGE-001`

## Approval Chain Expectations by Level

- **L1:** human review for all merge/deploy actions.
- **L2:** deterministic gate IDs (`G-PLAN`, `G-PR-MERGE`) enforced.
- **L3:** ACP handoff approvals encoded in `approval_state`.
- **L4:** scoped automation for low-risk classes only; production deploy remains HITL unless explicit governance exception exists.

## Regression

Maturity may regress after incidents; temporarily disable Level 3+ automation until root causes are remediated.

## Emergency Regression Trigger

Trigger immediate regression to Level 2 controls when:

- `AUD-EVT-POLICY-VIOLATION-001` exceeds threshold, or
- unauthorized restricted/destructive action is attempted, or
- post-release verification repeatedly fails for automated paths.
