# Enterprise Engineering Guardrails

These guardrails define the engineering quality floor for all AI-generated and AI-assisted code in this organisation. They apply to every prompt that produces code, tests, documentation, or technical decisions. They are not aspirational — they are the minimum acceptable standard.

When referenced in a prompt, treat every guardrail in this document as an active instruction, not background reading.

---

## 1. Core Principle

Write code that solves the stated problem clearly and safely. Every line must have a reason. Complexity that is not required by the problem is a defect.

AI must not:
- Add features, abstractions, or patterns that are not required by the current step.
- Volunteer refactoring that is not part of the approved plan.
- Increase the scope of any change without noting it explicitly as a deviation.

---

## 2. SOLID Principles

Apply SOLID where the code genuinely benefits — that is, where the principle prevents a concrete maintenance, testability, or extensibility problem.

| Principle | Apply when | Do not apply when |
|-----------|-----------|------------------|
| Single Responsibility | A class or function handles clearly distinct concerns | The unit is simple and splitting it adds indirection without benefit |
| Open/Closed | Extension is a foreseeable and documented requirement | No extension is planned; premature abstraction will add dead code |
| Liskov Substitution | Inheritance is used | Not using inheritance |
| Interface Segregation | Consumers need only part of a contract | A single consumer uses the full interface |
| Dependency Inversion | Testability or swappability of a collaborator is needed | Hard-wiring is simpler and the collaborator is stable |

Do not apply SOLID mechanically. "Every class must be open/closed" is not a valid instruction. A flat function that does one clear thing is correct code.

---

## 3. DRY, KISS, YAGNI

**DRY (Don't Repeat Yourself):** Extract shared logic when duplication creates real maintenance risk — two or more copies of non-trivial logic that must stay in sync. Do not extract to eliminate cosmetic similarity. Premature extraction creates coupling.

**KISS (Keep It Simple, Stupid):** The simplest correct solution is the right solution. Each step toward complexity must be justified by a real requirement. If two approaches solve the problem equally well, choose the one that is easier to read.

**YAGNI (You Aren't Gonna Need It):** Do not implement capability that is not required by the current issue. Do not add configuration options, extension points, or abstraction layers "for future use." Future use that never arrives is dead code with a maintenance cost.

---

## 4. Reuse-First Development

Before writing new code, check what already exists:

1. Does the codebase already have a utility, service, or module that handles this?
2. Does the framework or standard library provide this?
3. Does an already-approved dependency provide this?

If yes to any: reuse it. Describe what you are reusing and why it fits.

If no: write the new code. Do not introduce a new abstraction layer just to wrap existing code with a different name.

---

## 5. Architecture Alignment

AI-generated code must fit the existing architecture. It must not:

- Introduce a new architectural layer without explicit plan approval.
- Cross established module or service boundaries.
- Introduce a new cross-cutting concern (logging framework, error handling strategy, configuration pattern) that diverges from the existing approach.
- Create circular dependencies between modules or packages.

If the approved plan requires an architectural change, implement only the change described. If the existing architecture makes the change harder than expected, surface this as a deviation — do not silently redesign.

---

## 6. Layered Responsibility

Respect the responsibility of each layer in the system:

| Layer | Responsibility | Must not |
|-------|---------------|---------|
| API / controller | Accept input, validate shape, delegate to service | Contain business logic |
| Service / use-case | Orchestrate business rules, call repositories or adapters | Access the database directly or format HTTP responses |
| Repository / data access | Data retrieval and persistence | Contain business rules or call external APIs |
| Domain / model | Business entities and invariants | Depend on infrastructure |
| Infrastructure | Databases, queues, file systems, HTTP clients | Leak into the domain |

A violation of layer responsibility is a must-fix finding in any review.

---

## 7. Design Patterns — With Justification, Not Overuse

Use a design pattern where it solves a real maintainability, extensibility, or testability problem that is present in the code being written now.

Before applying a pattern:
1. State the problem the pattern solves in this specific case.
2. Confirm the problem is real and present, not hypothetical.
3. Choose the simplest pattern that addresses it.

Do not use design patterns:
- To demonstrate pattern knowledge.
- Because the pattern sounds applicable to the domain.
- As a default structure when a simpler structure works.

Common misapplication examples to avoid:
- Factory for a class with one concrete implementation and no planned variations.
- Strategy pattern when there is one strategy and no second is planned.
- Observer / event bus when a direct function call is sufficient.
- Repository pattern wrapping an ORM that already provides the same interface.

---

## 8. Minimal Safe Change for Bug Fixes

Bug fixes must change the minimum code necessary to correct the confirmed root cause.

Procedure:
1. Root cause is confirmed and documented on the issue before any code is written.
2. The fix addresses the root cause directly — not a symptom.
3. No refactoring, renaming, or style changes are bundled in the bug-fix commit unless they are required to make the fix correct.
4. If surrounding code has a pre-existing problem, create a separate issue for it rather than fixing it in the same PR.
5. A regression test that would have caught the bug is added.

A bug-fix PR that contains unrequested refactoring is a scope violation. Reviewers must flag it.

---

## 9. Refactoring Discipline

Refactoring is only appropriate when:
- It is explicitly part of the approved plan.
- It is required to make the current change correct, testable, or safe.
- It is a dedicated refactoring PR with no feature or bug-fix changes.

AI must not initiate refactoring as a side effect of any other change type. "This code could be cleaner" is not a reason to refactor. Refactoring mixed with feature work obscures review and complicates rollback.

When refactoring is approved:
- Change behaviour is zero — tests pass before and after.
- The diff is as small as it can be to achieve the stated improvement.
- Reviewers can verify it is behaviour-neutral.

---

## 10. Secure Coding by Default

Security is not a separate phase. Every code change must:

- **Validate all input** at the entry point (type, length, format, allowlist where appropriate).
- **Sanitise output** before rendering to prevent injection into HTML, SQL, shell, or other interpreters.
- **Authorise before acting** — check permissions at the function that performs the action, not only at the caller.
- **Never log secrets, tokens, PII, or full request bodies** containing sensitive data.
- **Avoid path traversal** — never construct file paths from user input without canonicalisation and boundary enforcement.
- **Use parameterised queries** — never build SQL or query strings by string concatenation.
- **Fail closed** — when in doubt about access, deny; log the denial with enough context to diagnose.
- **Follow the principle of least privilege** for any service account, IAM role, or API credential the code touches.

Security findings in review are always must-fix. There are no advisory security findings.

---

## 11. Error Handling and Resilience

- Handle errors at the appropriate layer. Do not swallow exceptions silently.
- Log enough context to diagnose the error: operation attempted, identifiers involved, sanitised input summary.
- Do not log full stack traces for expected, user-caused errors (e.g. validation failures). Reserve stack traces for unexpected, operational errors.
- Use structured error types where the codebase uses them. Do not introduce a new error-handling pattern.
- For external calls (HTTP, database, queue): apply timeouts, handle transient failures (retry with backoff where appropriate), and degrade gracefully.
- Distinguish between retriable and non-retriable errors. Retrying a non-retriable error is wasteful and may amplify incidents.

---

## 12. Observability and Logging

- Log at the level that matches the intent: DEBUG for development traces, INFO for significant state transitions, WARN for recoverable anomalies, ERROR for unhandled failures.
- Every significant operation must have a log entry at a level that will surface in production monitoring.
- Include correlation IDs (request ID, trace ID) in log lines where the codebase uses them.
- Do not add logging so verbose it obscures signal in production. Prefer structured key-value log lines over narrative sentences.
- Metrics: if the change affects throughput, latency, or error rates of a tracked operation, confirm the existing metric captures it. Add a metric only if none exists and the change is significant enough to warrant it.
- Do not log PII. Log anonymised identifiers (user ID, not email or name) where association is needed for support.

---

## 13. API Quality

For any public or internal API surface change:

- **Naming**: consistent with existing API conventions in this project (casing, verb/noun choice, resource naming).
- **Input validation**: all parameters validated at the handler before business logic runs.
- **Error responses**: follow the existing error response envelope. Do not invent new error shapes.
- **Status codes**: use HTTP status codes correctly. Do not use 200 for failures. Do not use 500 for client errors.
- **Versioning**: if the change breaks an existing contract, it requires a version bump and a migration path. Breaking changes must be flagged in the PR body.
- **OpenAPI / contract spec**: update the spec as part of the same PR. An API change without a spec update is incomplete.
- **Idempotency**: POST operations that create resources should be idempotent where possible (or document why not).

---

## 14. Database Migration Discipline

- Every migration must be reversible with an explicit rollback script verified before merge.
- Migrations must not drop a column or table that application code still references.
- Additive migrations (add column, add table) are low risk. Column removal, renaming, and index changes on large tables are high risk and require SRE review.
- Do not include data-backfill logic in the same migration script as schema changes unless they are atomic and reviewed.
- Migrations that take an exclusive lock on a large table (ALTER TABLE on a busy table) require explicit SRE sign-off and a maintenance window or an online-schema-change approach.
- Test migrations against a copy of production data shape before merge.

---

## 15. Dependency Discipline

- Do not add a new dependency to solve a problem the existing codebase or standard library already solves.
- Every new dependency must be justified: what problem does it solve, what is the alternative, what is the license.
- Prefer well-maintained libraries with active security patch histories over unmaintained or single-author packages.
- When upgrading a dependency to fix a CVE, upgrade only the minimum version required to resolve the vulnerability. Do not bundle unrelated upgrades in the same PR unless they are explicitly planned.
- Transitive dependency changes must be reviewed. A major transitive version bump is as significant as a direct one.
- Do not pin dependencies to exact versions in library code; use ranges. In application code, pin to a specific version and update intentionally.

---

## 16. Test Quality Over Test Count

Tests must prove meaningful behaviour. Passing tests that do not catch real regressions provide false confidence and slow the build.

**Required for a test to be acceptable:**
- It tests one clear, described behaviour or invariant.
- It fails when the behaviour it describes is broken.
- It does not rely on implementation details that are irrelevant to the behaviour.
- It is readable: the arrangement, action, and assertion are clear without needing comments.

**Must avoid:**
- Tests that only assert the method was called (mock-heavy tests with no behaviour assertion).
- Tests that duplicate production logic rather than asserting its outcome.
- Tests that always pass regardless of the implementation.
- Coverage inflation: writing trivial tests to raise a percentage metric.
- Broad happy-path tests that leave error paths, boundary conditions, and security inputs uncovered.

**Prioritise:**
- Negative cases and boundary conditions over additional happy-path coverage.
- Integration tests at boundaries that change (service-to-DB, service-to-API).
- Regression tests specifically targeting the bug or edge case being fixed.

---

## 17. Documentation Discipline

Write documentation when and where it adds information the code cannot convey.

**Write:**
- A module or package docstring/README when the purpose and ownership are not obvious from the name.
- A function or method comment when the why is non-obvious (business rule, workaround, external constraint).
- Inline comments for non-obvious algorithms or complex conditional logic.
- API documentation (OpenAPI) for every public endpoint.

**Do not write:**
- Comments that restate what the code does: `// increment counter` above `count++`.
- Documentation that will immediately diverge from the code and become misleading.
- README sections that describe planned features not yet implemented.

When a change modifies existing documented behaviour, update the documentation in the same PR. A PR that changes behaviour without updating its documentation is incomplete.

---

## 18. Backward Compatibility

Unless the plan explicitly authorises a breaking change:

- Public API contracts must not change in a breaking way.
- Serialised data formats (JSON, Protobuf, database schemas) must be backward-compatible with the deployed version.
- Configuration keys must not be renamed or removed without a deprecation period.
- Behaviour that existing callers depend on must not change without a version bump and migration notice.

When a breaking change is required, it must be flagged in the PR body, approved at G-PR-MERGE, and accompanied by a migration guide.

---

## 19. Performance Awareness

Performance is not premature optimisation — it is the obligation not to introduce obvious regressions.

**Always avoid:**
- N+1 query patterns in any loop that processes a list from the database.
- Unbounded queries (SELECT * with no LIMIT or pagination on large tables).
- Synchronous blocking calls in a hot path where the codebase uses async patterns.
- Loading large objects into memory to process a subset.

**Acceptable to defer:**
- Micro-optimisations that require profiling to identify.
- Caching strategies that are not needed at current scale.
- Parallel processing improvements that are speculative.

When a change touches a code path that is known to be performance-sensitive (noted in the plan or the codebase), confirm the change does not worsen the relevant metric.

---

## 20. Configuration and Environment Discipline

- Secrets and credentials are never hardcoded or committed. Use environment variables or a secrets manager.
- Configuration that differs between environments (dev, staging, production) must be externalised. Do not use `if ENV == 'production'` branches in business logic.
- Default values must be safe — defaults should work in a local or test environment without requiring production configuration.
- Do not introduce new configuration keys without documenting them (name, type, required/optional, default, example).
- Feature flags are treated as technical debt from the moment they are added. Flag addition must include a stated removal condition.

---

## 21. Reviewability

Code is written to be reviewed. If a reviewer cannot understand a change without a lengthy explanation, the change needs refactoring, better naming, or decomposition.

Every PR must be:
- **Scoped** — it does one thing. Multiple independent changes belong in multiple PRs.
- **Small enough to review** — a PR that cannot be understood in a single sitting is too large unless the plan explicitly requires it.
- **Ordered** — commits within the PR should tell a coherent story: test first, then implementation, or incremental steps.
- **Self-contained** — the reviewer should not need to read Slack messages or emails to understand what the PR does and why.

The PR description must answer: what changed, why it changed, and how to verify it works.

---

## How These Guardrails Are Used

These guardrails are loaded as optional context (`{{ENGINEERING_GUARDRAILS}}`) into implementation and review prompts. When loaded, every instruction in this document is active and binding on the AI output.

AI is expected to call out violations it observes in existing code — but may only fix them if they are within the scope of the current approved change. Violations outside scope must be noted as separate recommendations, not silently fixed.

---

## References

- HITL Policy: `ai-sdlc/governance/human-in-the-loop-policy.md`
- AI Instruction Governance: `ai-sdlc/governance/ai-instruction-governance.md`
- Approval Gates: `ai-sdlc/governance/approval-gates.md`
- Risk Rules: `ai-sdlc/governance/risk-rules.md`
