# Framework Protection Rule

When `automation_sdlc` (or an embedded copy) is used inside a **product workspace**, SDLC
workflows run in **product SDLC execution mode** by default. Framework code is immutable during
product delivery. Project-specific configuration, context, workflow state, approvals, and
issue artifacts belong under `.cursor/ai-sdlc/**` only.

Framework maintainers may change framework code only in **explicit framework development mode**
(for example `FRAMEWORK_DEV=1 make ai-sdlc-guard-framework-clean`).

---

## Product SDLC execution mode (default)

### Read-only — framework-owned paths

Do **not** modify during product SDLC workflows:

```text
<framework-repo>/**
<framework-repo>/ai-sdlc/prompts/**
<framework-repo>/ai-sdlc/tools/**
<framework-repo>/ai-sdlc/schemas/**
<framework-repo>/ai-sdlc/policies/**
<framework-repo>/ai-sdlc/templates/**
<framework-repo>/ai-sdlc/adoption/**
<framework-repo>/ai-sdlc/runtime/**
<framework-repo>/ai-sdlc/mcp/**
<framework-repo>/ai-sdlc/acp/**
```

When the framework repo is embedded (any directory name, e.g. `automation_sdlc/`), treat the
entire embedded framework repository as read-only except as noted below.

Also read-only: any path under `ai-sdlc/` that resolves inside the framework repository root.

### Allowed — project overlay and approved product work

```text
.cursor/ai-sdlc/**
approved product repository files during an approved implementation step only
```

### Required behavior when a framework limitation is discovered

1. **Do not patch** framework files during product delivery.
2. **Report a framework gap** using the format below.
3. Continue the product workflow with a **safe project-level workaround** when one exists.
4. Escalate to framework maintainers for a generic fix in framework development mode.

---

## Framework development mode

Set `FRAMEWORK_DEV=1` when intentionally changing the reusable framework (prompts, tools,
schemas, policies, templates, adoption docs, Makefile targets, etc.).

Product overlay files under `.cursor/ai-sdlc/**` may be edited in either mode.

---

## Git operations rule

During **product SDLC execution**, do **not** run Git write operations unless **explicitly
requested by the user**.

**Blocked by default:**

- `git add`
- `git commit`
- `git push`
- `git branch` creation
- `git checkout` / `git switch` that changes branches
- `git merge`
- `git rebase`
- `git reset`
- `git clean`
- tag creation
- any GitHub / GitLab / remote write action

This applies regardless of execution method:

- shell command
- IDE Git UI
- MCP Git / GitHub / GitLab tool
- script
- automation

If a commit is recommended, **report the suggested commands** instead of executing them.

**Framework development mode** may allow **local commits** only when the user explicitly asks
to commit. **Push always requires separate explicit approval.**

The drift guard (`make ai-sdlc-guard-framework-clean`) checks **uncommitted framework file
changes** only. It does **not** block normal product repository source changes outside the
framework repo.

See **`ai-sdlc/adoption/framework-guard-checkpoints.md`** for when to run the guard during
product SDLC stages.

---

## Product workflow guard checkpoints

| Stage | Run guard before |
|-------|------------------|
| Workspace setup complete | First product issue / pilot |
| Groom-prep / clarify-requirement | `make ai-sdlc-groom-prep` (guard runs automatically in product mode) |
| classify-work | Classification prompt |
| impact-analysis | Impact analysis prompt |
| technical-plan | Technical plan prompt |
| implement-step | Implementation prompt / coding session |
| self-review / PR review | Review prompts |
| release verification | Release verification prompt |

**Embedded command** (from framework repo):

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Example: `make ai-sdlc-guard-framework-clean ROOT=..`

---

## Framework gap report format

Use this format in agent output, Jira comments, or workflow notes when a framework limitation
blocks or complicates product delivery:

```text
Framework gap detected

Type: [bug / feature request / documentation gap / schema limitation / policy gap / prompt improvement]
Discovered during: [workflow step]
Issue/work item: [issue id]
Blocked product workflow: [yes/no]
Framework area affected: [prompt/tool/schema/policy/template/docs]
Observed problem:
[short description]

Expected framework behavior:
[short description]

Suggested framework backlog item:
[title]

Suggested acceptance criteria:
- [criterion 1]
- [criterion 2]
- [criterion 3]

Safe project-level workaround, if any:
[describe workaround or state "none"]
```

---

## Guard command

Run from the framework repository (or with `ROOT` / `FRAMEWORK_ROOT` set for embedded layouts):

```bash
# Product SDLC mode — fail if framework files have uncommitted changes
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>

# Framework development mode — allow framework changes
FRAMEWORK_DEV=1 make ai-sdlc-guard-framework-clean
```

---

## Related documents

- `ai-sdlc/governance/enterprise-engineering-guardrails.md`
- `ai-sdlc/governance/public-reference-and-data-safety.md`
- `ai-sdlc/adoption/quick-start.md`
