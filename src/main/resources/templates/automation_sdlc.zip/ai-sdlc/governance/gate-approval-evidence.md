# Gate Approval Evidence

Human gates may include structured **evidence** alongside `comment_url` / `pr_url`. This supplements — does not replace — explicit human approval.

## Legacy evidence fields (`approval_evidence`)

| Field | Description |
|-------|-------------|
| `source_type` | `jira`, `slack`, `teams`, `outlook`, `pr`, or `manual` |
| `source_ref` | Safe URL or local artifact path (no secrets) |
| `approved_by` | Approver name and email |
| `approved_at` | RFC 3339 timestamp |
| `decision` | `approved`, `rejected`, `approved_with_conditions`, or `needs_confirmation` |
| `conditions` | List of unresolved items when decision is conditional |
| `evidence_id` | Optional link to canonical record in `evidence.records` (H2+) |

## Canonical evidence model (H2+)

Gate approvals recorded through `approve-gate` also emit a canonical evidence record in `workflow-state.evidence.records`. Legacy `approval_evidence` fields are retained for backward compatibility.

Schema: `ai-sdlc/schemas/governance/evidence-record.schema.json`

### Source type (how evidence was obtained)

| Value | Meaning |
|-------|---------|
| `AUTHORITATIVE_PROVIDER` | Retrieved from authenticated provider/API (Bitbucket, GitHub, CI, deployment platform) |
| `LOCAL_GIT_DERIVED` | Derived from local Git (commit existence, branch containment, ancestry) |
| `AUTOMATED_COMMAND` | Produced by executed command (lint, build, tests, schema validation) |
| `MANUAL_ATTESTATION` | Human statement via chat, CLI, form, or authored artifact |
| `UNVERIFIED_EXTERNAL` | External reference not retrieved authoritatively (pasted PR URL, reported status) |
| `LEGACY_UNCLASSIFIED` | Imported legacy evidence without full provenance |

### Verification status (whether the claim was independently verified)

Distinct from source type and confidence.

| Value | Meaning |
|-------|---------|
| `VERIFIED` | Claim independently verified for its subject scope |
| `PARTIALLY_VERIFIED` | Verified for part of the claim only |
| `UNVERIFIED` | Not independently verified |
| `CONTRADICTORY` | Conflicts with other evidence |
| `REJECTED` | Verification failed or claim rejected |
| `SUPERSEDED` | Replaced by newer evidence |
| `NOT_APPLICABLE` | Verification not applicable to this subject |

### Confidence

`HIGH`, `MEDIUM`, `LOW`, or `UNKNOWN` — expresses trust in the claim, separate from verification status.

Example:

```yaml
source_type: MANUAL_ATTESTATION
verification_status: UNVERIFIED
confidence: LOW
reported_by: lead@example.com
```

### Reported vs verified actors

| Field | Meaning |
|-------|---------|
| `reported_by` | Who supplied the evidence |
| `reported_actor` | Actor named in the claim when different from reporter |
| `verified_actor` | Actor confirmed by authoritative provider evidence only |

Manual attestation and unverified external evidence **must not** populate `verified_actor`.

## Authority boundaries

| Source | Can prove | Cannot prove |
|--------|-----------|--------------|
| `MANUAL_ATTESTATION` | Human attestation was recorded | Provider PR status, merge actor, CI result |
| `UNVERIFIED_EXTERNAL` | A reference was supplied | Provider state without API retrieval |
| `LOCAL_GIT_DERIVED` | Local commit/branch/ancestry facts | Provider PR identity, review approval, merge actor |
| `AUTOMATED_COMMAND` | Command execution outcome (exit code) | Unrelated provider or merge facts |
| `AUTHORITATIVE_PROVIDER` | Provider-scoped facts retrieved via API | Facts outside provider scope |

**Upgrade rules:** `MANUAL_ATTESTATION` and `UNVERIFIED_EXTERNAL` cannot silently become `AUTHORITATIVE_PROVIDER` or `VERIFIED` without new provider-retrieved verification evidence.

**Merge reconciliation:** H3 enforces contradiction-aware reconciliation in `close-merge`. Reported merge remains unverified until `merge_reconciliation.status` is `MERGED_VERIFIED`.

## Merge reconciliation statuses (H3+)

| Status | Meaning |
|--------|---------|
| `MERGE_REPORTED_UNVERIFIED` | Manual merge report without provider verification |
| `MERGE_DETECTED_UNRECONCILED` | Local Git detection without PR identity reconciliation |
| `MERGE_RECONCILIATION_REQUIRED` | PR mismatch or other blocking contradiction |
| `MERGED_VERIFIED` | Provider-authoritative reconciliation succeeded |
| `LEGACY_MERGED_UNVERIFIED` | Historical merge without verification envelope |

`reported_merge_actor` and `verified_merge_actor` are separate. Code equivalence does not substitute for PR identity.

## Legacy evidence treatment

Existing workflow states without `evidence.records` remain valid. When normalized:

- Legacy `manual` / chat-channel sources → `MANUAL_ATTESTATION`, `UNVERIFIED`
- Legacy `pr` source (pasted URL) → `UNVERIFIED_EXTERNAL`, `UNVERIFIED`
- Unknown legacy shapes → `LEGACY_UNCLASSIFIED`, `UNVERIFIED`

Legacy evidence is **never** treated as authoritative by default.

## Examples

### Provider-verified PR (future H3 integration)

```yaml
source_type: AUTHORITATIVE_PROVIDER
source_system: bitbucket
retrieval_method: api
source_ref: https://api.bitbucket.org/2.0/repositories/org/repo/pullrequests/3
subject_type: pr_status
verification_status: VERIFIED
confidence: HIGH
```

### Manual PR claim (chat approval)

```yaml
source_type: MANUAL_ATTESTATION
subject_type: gate_approval
subject_ref: G-PLAN
reported_by: lead@example.com
claim: Gate G-PLAN approved
verification_status: UNVERIFIED
confidence: LOW
```

### Local Git commit containment

```yaml
source_type: LOCAL_GIT_DERIVED
subject_type: commit_containment
repository: /path/to/repo
branch: main
commit_sha: abc1234
verification_status: VERIFIED
confidence: HIGH
```

### Automated test execution

```yaml
source_type: AUTOMATED_COMMAND
subject_type: validation_check
subject_ref: unit_tests
command: npm test
exit_code: 0
verification_status: VERIFIED
confidence: HIGH
```

### Contradictory merge evidence (structure only in H2)

```yaml
verification_status: CONTRADICTORY
contradictions:
  - cx-merge-001
```

Contradiction records live in `evidence.contradictions` with `evidence_refs` linking both records. Resolution enforcement is deferred to H3.

## Conditional approvals

When `decision` is `approved_with_conditions` or gate-level `conditions` is non-empty:

- Set `conditions_met: false` until each condition is explicitly confirmed by a human.
- Stage router and implementation preflight **block full implementation** until `conditions_met: true`.

## Vague approval

Phrases like "looks good" without scope context map to `needs_confirmation`. Orchestration tools treat this as **not approved**.

## Provider-unavailable behavior

When a provider API is unavailable, record `UNVERIFIED_EXTERNAL` or `MANUAL_ATTESTATION` evidence with `verification_status: UNVERIFIED`. Do not infer provider state from URLs, chat claims, or local Git facts alone.

## Related artifacts

| Artifact | Use |
|----------|-----|
| `gate-review-record.md` | Human-readable approval thread summary |
| `spike-notes.md` | Step 0 spike findings |
| `assumption-log.md` | Assumptions validated or failed — failed assumptions route to plan revision |
| `runtime-repro.md` | Sanitized runtime reproduction |
| `qa-validation.md` | QA test-case evidence for G-QA |

Schemas:

- `ai-sdlc/schemas/workflow/workflow-state.schema.json` (`$defs.approval_evidence`, `evidence`, `gate_record.conditions`)
- `ai-sdlc/schemas/governance/evidence-record.schema.json`

## Closure and implementation evidence (H4+)

Verified closure requires `closure_eligibility` evaluation (`closure_eligibility.py`). `current_stage: MERGED` does not imply `closure.status: CLOSED_VERIFIED`.

| Contract | Location |
|----------|----------|
| Machine implementation state | `implementation` block (`mode`, `repos[]`, optional `steps[]`, attestation) |
| Canonical evidence artifact | `artifacts.implementation_evidence` → `implementation-evidence.md` |
| Narrative summary (optional) | `artifacts.implementation_summary` → `implementation-step-summary.md` |

Missing canonical implementation evidence blocks closure and cannot be waived. Approved non-critical waivers are recorded under `closure.waivers[]`. Merge reconciliation statuses from H3 control whether closure may be verified.
- `ai-sdlc/schemas/governance/evidence-record.schema.json`

Shared helpers: `ai-sdlc/tools/orchestration/evidence_common.py`
