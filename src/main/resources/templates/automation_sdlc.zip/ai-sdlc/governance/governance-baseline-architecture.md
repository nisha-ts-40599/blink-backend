# AI-SDLC v2 Governance Baseline Architecture

Operator-oriented summary of the governance baseline tagged `ai-sdlc-v2-governance-baseline`.
Framework version **2.0.0**. Generic — no customer-specific paths or identities.

## 1. Canonical authorities

| Authority | Location | Purpose |
|-----------|----------|---------|
| Workflow state | `.cursor/ai-sdlc/workflow-state/<issue>/<issue>.yaml` | Per-work-item lifecycle, gates, artifacts |
| Role registry | `.cursor/ai-sdlc/governance/role-registry.yaml` | Canonical role assignments and revisions |
| Artifact registry | Workflow state + enterprise artifact paths | Required evidence per stage |
| Gate registry | `ai-sdlc/registry/gate-registry.yaml` | Gate definitions, tier defaults, migration policy |
| Mutation authorizations | `.cursor/ai-sdlc/governance/*-authorization.yaml` | Bootstrap and implementation write grants |

## 2. Derived projections

The role registry is the single source of truth. Critical projections are synchronized atomically on assignment transactions:

- `setup-state.yaml` role block
- `project-config.yaml` approval rules
- Per-repo `project-config.yaml` (multi-repo topologies)
- Workflow state role snapshots
- Non-critical human-readable role summaries (render-only; failure does not roll back canonical registry)

Use `make ai-sdlc-sync-role-projections` to repair drift from canonical registry.

## 3. Mutation decision flow

```
Write attempt
  → Cursor hook (pre-tool-use / before-shell) OR Make entry preflight (WRITE=1)
  → product_mutation_guard.evaluate / require_entry_point_authorization
  → checks: delivery_ready, authorization binding, freeze/quarantine, path scope
  → allow | deny (fail-closed) + audit event
```

Make targets `ai-sdlc-implement-step`, `ai-sdlc-run-autonomous`, and `ai-sdlc-managed-execute` invoke `mutation_guard_preflight.py` only when `WRITE=1`.

## 4. Role and gate authorization flow

```
role-registry.yaml
  → scope precedence + delegation resolution (role_resolver)
  → role consistency validation
  → separation of duties (sod-policy.yaml)
  → gate authorization decision
  → immutable gate record append (historical records preserved)
```

Gate consumers resolve approvers from the canonical registry, not legacy setup-state projections, except during the documented legacy compatibility window.

## 5. Audit streams and linkage

| Stream | Path | Content |
|--------|------|---------|
| Role lifecycle | `governance/role-lifecycle-events.jsonl` | Assignment, deferral, delegation, revocation, projection sync |
| Mutation audit | `governance/mutation-audit.jsonl` | Product mutation allow/deny decisions |
| Workflow lifecycle | `workflow-state/<issue>/lifecycle-events.jsonl` | Gate and governance cross-references |
| Gate records | `workflow-state/<issue>/gates/` | Immutable approval evidence |

`validate_audit_linkage.py` verifies cross-stream references.

## 6. Migration behavior

- **Dry-run default:** `make ai-sdlc-migrate-role-registry ROOT=<workspace>` (no `WRITE=1`)
- Legacy setup-state and project-config roles import as `human_confirmed` or `pending_assignment` based on evidence
- Historical gate approvers are **not** treated as confirmed role assignments
- Legacy compatibility allowed for existing workspaces until framework **3.0.0** or organization deadline
- New workspaces require canonical registry when policy enforcement is active

## 7. Supported topologies

Neutral fixtures cover: single repo, monorepo, multi-repo, sibling repositories, nested repositories.

## 8. Known boundaries and limitations

- Manual IDE edits outside Cursor agent hooks are not intercepted
- External/container mutations outside installed hooks bypass enforcement
- Legacy authorization events may lack hash binding until re-authorized
- Summary render failures are non-critical and do not roll back canonical state
- Phase 3 guided handoffs and artifact governance are **not** part of this baseline

## 9. Operator commands

```bash
# Install Cursor mutation hooks
make ai-sdlc-install-cursor-hooks ROOT=<workspace> WRITE=1

# Validate mutation safety (read-only CLI check)
make ai-sdlc-check-product-mutation ROOT=<workspace> ISSUE=<issue> TARGET_PATH=<path>

# Assign canonical role (dry-run unless WRITE=1)
make ai-sdlc-assign-role ROOT=<workspace> ROLE=<role> EMAIL=<email> WRITE=1

# Validate registry/projection consistency (read-only)
make ai-sdlc-validate-role-consistency ROOT=<workspace> FORMAT=json

# Approve gate (dry-run unless WRITE=1)
make ai-sdlc-approve-gate ROOT=<workspace> ISSUE=<issue> GATE=<gate> APPROVER=<email> WRITE=1

# Regression suites
make ai-sdlc-mutation-guard-test
make ai-sdlc-role-governance-test
make ai-sdlc-gate-authorization-test
make ai-sdlc-schema-check
```

## 10. Phase 3 entry assumptions

Phase 3 (guided lifecycle handoffs and artifact governance) assumes:

- Canonical role registry and gate authorization are operational
- Mutation guard hooks are installed in agent environments
- Workspaces have migrated or are within legacy compatibility policy
- `delivery_ready` and setup reconciliation gates pass before implementation
- No Phase 3 handoff automation is enabled in this baseline
