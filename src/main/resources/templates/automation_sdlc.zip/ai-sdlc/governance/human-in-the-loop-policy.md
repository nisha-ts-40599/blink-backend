# Human-in-the-Loop (HITL) Policy

This policy defines where **humans must** remain in control versus where **automation and AI** may operate under guardrails.

## Non-Delegable Human Decisions

Humans, not models, must decide:

1. **Product intent** when specifications conflict with business risk appetite.
2. **Merge to protected branches** unless an explicitly approved, narrowly scoped bot meets regulatory and org criteria.
3. **Production deployment** and **infrastructure apply** affecting customer-facing systems.
4. **Secret rotation**, **key ceremony**, and **break-glass** access.
5. **Compliance exceptions** (for example delaying a mandatory control).
6. **Waiving security findings** or lowering mandatory gates.
7. **Incident declaration** — severity classification, escalation, and incident commander assignment.
8. **Rollback decisions during incidents** — any revert, hotfix, or configuration change to production.
9. **Stakeholder and customer communication** — all external-facing incident or operational communications.
10. **PII handling and data deletion** — execution of any data subject request, deletion, or anonymisation action.
11. **Third-party and vendor integration enablement** — granting API access, provisioning credentials, or enabling data sharing with external parties.
12. **Customer-impacting operational decisions** — feature rollbacks, SLA adjustments, or commitments made to customers.

AI may assist with analysis, draft communications, and surface context for all of the above — but the decision and any system action must be taken by a named human.

## AI-Permitted Autonomy (Default)

Within MCP **allowed** tools, agents may:

- Draft, summarize, and cross-link documentation and issues.
- Propose code changes on non-protected branches.
- Generate tests and run read-only or sandboxed validations.
- Post AI reviews and suggest fixes.

## Supervised Autonomy

> **Level 4 capability — not currently enabled.**
>
> The following describes a future state that requires the organisation to be operating stably at Maturity Level 3 (orchestrated agentic execution) before it is considered. None of the behaviours below are active in the current framework.
>
> Not currently enabled: autonomous merge of any PR class, autonomous deployment to any environment, autonomous incident response, autonomous rollback, autonomous PII handling, autonomous data deletion, and autonomous vendor integration enablement. All of these remain non-delegable human decisions regardless of tier. See "Non-Delegable Human Decisions" above.

Semi-autonomous operation would **only ever be considered** for auto-merging **low-tier** doc-only PRs or auto-applying non-production changes at a future maturity level, and **only** if all of the following conditions are met:

- Explicit org policy enables it at Level 4 maturity,
- Separate service account and branch protections exist,
- Monitoring and rollback are trivial,
- A formal governance exception is approved and recorded.

This is a design placeholder for a future state, not a currently available configuration. Document such exceptions in `project-config` addenda when and if this level is reached. Do not activate before Level 4 maturity criteria are met per `governance/automation-maturity-model.md`.

## Human Oversight Cadence

| Tier | Minimum human touchpoints |
|------|---------------------------|
| 1 | Optional peer review; human merge per team norm |
| 2 | Plan approval per policy; human PR approval |
| 3 | Plan + security review; human PR approval; staged validation |
| 4 | Expanded approvers; dual control for production; post-release review |

## AI Output Confidence and Escalation

AI output must be escalated to a human before acting when:

- The output is low-confidence, hedged, or contains significant caveats.
- The output contradicts the approved technical plan or prior design decisions.
- The output touches authentication, authorisation, cryptography, PII, or security-control scope.
- The context loaded into the prompt was incomplete, stale, or contained unfilled placeholders.
- The change is outside the defined scope of the approved plan for the current issue.

**Escalation procedure:** Engineer notes "AI output requires review — [reason]" on the issue. Engineering lead reviews with or without input from the security champion. Work proceeds only after human judgment is applied and recorded.

See `ai-sdlc/governance/ai-instruction-governance.md` for the quality gate definitions and traceability requirements for AI output.

## Escalation

If an agent proposes a **restricted action**, the Orchestrator must **stop** and surface a human task; partial progress remains on a branch or draft, never promoted silently.

## Escalation IDs

- `ESC-HITL-001`: Restricted action requested without approval token.
- `ESC-HITL-002`: Human approval conflict.
- `ESC-HITL-003`: Tier downgrade request from Tier 3/4 to Tier 2.
- `ESC-HITL-004`: Emergency stop invoked.

## Human Override Procedure

1. Human submits override request with scope, ticket, and expiry.
2. Secondary approver validates risk and compensating controls.
3. Orchestrator records override artifact and emits `AUD-EVT-HITL-OVERRIDE-001`.
4. Override expires automatically; stale overrides are invalid.

## Emergency Stop Procedure

1. Trigger `ESTOP-001` from authorized human role.
2. Orchestrator blocks all non-read MCP classes.
3. In-flight workflows move to `blocked` with `escalation_state`.
4. Resume requires explicit human release event `AUD-EVT-HITL-ESTOP-CLEARED-001`.

## Policy Violation Lifecycle

1. Detect violation (for example unauthorized restricted tool attempt).
2. Emit `AUD-EVT-POLICY-VIOLATION-001`.
3. Pause affected workflow and require human adjudication.
4. Record decision: `approve_remediation`, `rollback_required`, or `terminate_workflow`.
5. Close with immutable audit record.

## Accountability

Humans who approve gates remain accountable for outcomes; AI outputs are **advisory evidence** unless formally adopted via human-signed artifacts.
