# Internal Production Candidate Baseline (v0.6.0)

Stabilization baseline for the AI-SDLC framework on `main`.
This is an **Internal Production Candidate** — not Enterprise Ready.

## Architecture and authority

| Document | Scope |
|----------|--------|
| [architecture-baseline.md](architecture-baseline.md) | Canonical architecture: Phase 0–4, greenfield, state, gates |
| [status-vocabulary-audit.md](status-vocabulary-audit.md) | Domain status vocabularies and normalization |
| [operator-command-inventory.md](operator-command-inventory.md) | Definitive operator command reference |
| [test-release-baseline.md](test-release-baseline.md) | Required test targets and release-candidate gate |

## Operator guidance

| Document | Scope |
|----------|--------|
| [operations-and-security.md](operations-and-security.md) | Failure/recovery, security, observability |
| [support-runbook.md](support-runbook.md) | Operator/support scenarios (no manual YAML repair) |

## Release management

| Document | Scope |
|----------|--------|
| [release-maturity-backlog.md](release-maturity-backlog.md) | Release plan, maturity assessment, enterprise backlog |
| [RELEASE-NOTES-v0.6.0.md](RELEASE-NOTES-v0.6.0.md) | v0.6.0 release notes (Internal Production Candidate) |
| [release-review-package.md](release-review-package.md) | Release merge authorization review package |

## Controlled adoption templates

Generic rollout templates (no active approvals; default status `PENDING`):

| Template | Purpose |
|----------|---------|
| [rollout-readiness-template.md](../../templates/governance/rollout-readiness-template.md) | Pre-rollout baseline and owner assignment |
| [workflow-start-authorization-template.md](../../templates/governance/workflow-start-authorization-template.md) | Workflow start authorization record |
| [rollout-observation-log-template.md](../../templates/governance/rollout-observation-log-template.md) | Controlled adoption observation log |
| [role-assignment-template.yaml](../../templates/governance/role-assignment-template.yaml) | Role assignment overlay |

Copy completed templates to `<project-root>/.cursor/ai-sdlc/governance/` — do not commit project-specific records to the framework repository.

## Historical validation archive

Non-operational audit and validation records:

| Archive | Contents |
|---------|----------|
| [../archive/README.md](../archive/README.md) | Archive index |
| [../archive/release-validation/](../archive/release-validation/) | Commit inventory, merge authorization |
| [../archive/prospective-validation/](../archive/prospective-validation/) | Limited rollout setup and observation records |
| [../archive/remediation-history/](../archive/remediation-history/) | Helper and remediation classification audits |

## Lifecycle routes (authoritative)

**Existing project:** intake → grooming → Phase 1 → G-PLAN → implementation → evidence → merge readiness → candidate/PR → G-PR-MERGE → merge reconciliation → closure

**Greenfield:** intake → grooming → Phase 1 → G-PLAN → bootstrap plan → G-BOOTSTRAP → G-BOOTSTRAP-EXEC → managed execution → completion candidate → Phase 4 readiness → first feature → merge readiness → candidate → G-PR-MERGE → reconciliation → closure

## Release validation

```bash
make ai-sdlc-release-candidate-test
make ai-sdlc-genericity-check
```

## Framework pin

| Field | Value |
|-------|-------|
| Base release tag | `v0.6.0` — **unchanged** |
| Classification | Internal Production Candidate |

Framework development guard (while uncommitted framework changes exist):

```bash
FRAMEWORK_DEV=1 make ai-sdlc-guard-framework-clean
```
