# Release Notes — AI-SDLC v0.6.0 (Internal Production Candidate)

**Classification:** Internal Production Candidate — **not** Enterprise Ready  
**Candidate commit:** `838bdbe2d50573ce5a3772c0bd3fff53ec959879`  
**Branch:** `feature/end-to-end-pilot-hardening`  
**Prior baseline:** `main` @ `538b57be8d73ec79016eadd79ab41b3cf3bcbc09`

---

## Summary

v0.6.0 consolidates framework hardening into a governed, evidence-based internal production candidate. The framework supports prospective existing-project and greenfield lifecycle routes with strict authority separation, merge reconciliation, closure eligibility, managed local bootstrap, and setup refresh compatibility — validated by a release-candidate gate.

---

## Major capabilities

| Area | Capability |
|------|------------|
| **Phase 0** | Intake provenance, duplicate workflow detection/consolidation, grooming model and sign-off |
| **Phase 1** | Pre-development package, G-PLAN binding, QA strategy, role authorization |
| **Phase 2** | Command evidence, execution provenance, AI review vs developer attestation separation, QA execution, verification results |
| **Phase 3** | Merge readiness evaluation, local unpushed candidate registration, G-PR-MERGE binding, merge reconciliation |
| **Closure** | Closure eligibility assessment, blocked closure without verified merge |
| **Greenfield** | Managed local bootstrap (plan → gates → execute → finalize → Phase 4 reconciliation), recoverable failure/resume |
| **Setup** | Framework version binding, setup-state migration, compatibility assessment, transactional refresh |
| **Governance** | Gate policy module, evidence record schema, release-candidate aggregate test |
| **Operations** | Operator command inventory, support runbook, architecture baseline, delivery boundary fixtures |

---

## Validated routes

### Prospective existing-project delivery route

Validated prospectively through one existing-project delivery route including failure recovery, merge readiness, local candidate registration, reconciliation, and blocked closure without verified merge.

```
intake → grooming → Phase 1 → G-PLAN → implementation → evidence
  → merge readiness → LOCAL_UNPUSHED_CANDIDATE → G-PR-MERGE
  → merge reconciliation → closure
```

Boundary fixture: `ai-sdlc/examples/disposable-fixtures/existing-project-delivery-boundary/`  
Tests: `test_existing_project_boundary_fixture.py`, `test_existing_project_remediation.py`, `test_pr_candidate_metadata.py`

### Prospective greenfield delivery route

Validated prospectively through one greenfield delivery route including bootstrap recovery, merge readiness, local candidate registration, reconciliation, and blocked closure without verified merge.

```
intake → grooming → Phase 1 → G-PLAN → bootstrap plan → G-BOOTSTRAP → G-BOOTSTRAP-EXEC
  → managed execution → completion candidate → Phase 4 readiness
  → first feature → merge readiness → candidate → G-PR-MERGE → reconciliation → closure
```

Boundary fixture: `ai-sdlc/examples/disposable-fixtures/greenfield-delivery-boundary/`  
Tests: `test_greenfield_boundary_fixture.py`, `test_greenfield_bootstrap_remediation.py`, `ai-sdlc-greenfield-e2e-test`

---

## Release validation

```bash
make ai-sdlc-install          # once per clone
make ai-sdlc-install-opa      # required for protected conformance
make ai-sdlc-release-candidate-test
make ai-sdlc-guard-framework-clean
```

All 16 required suites + framework guard + version consistency: **PASS** on candidate commit `838bdbe`.

---

## Known limitations

| Limitation | Impact |
|------------|--------|
| No enterprise IAM / SSO | Gate approvers are local policy only |
| No provider webhook merge reconciliation | Human merge + `close-merge` required |
| No centralized telemetry | Events are local JSONL; no multi-team dashboard |
| No multi-team concurrency proof | Single-team pilots only |
| No centralized immutable audit export | Local lifecycle-events only |
| No production remote bootstrap | Managed bootstrap is local-only, no network |
| No enterprise compliance mapping | Tier 3 governance is project-local |
| Local candidate push state | Operator truthfulness; no provider verification for unpushed candidates |
| OPA binary not in Git | Requires `make ai-sdlc-install-opa` per machine/CI |

**Classification remains Internal Production Candidate.** Do not represent as Enterprise Ready or internal multi-team ready.

---

## Upgrade guidance

### New consuming workspace

1. Merge or pin framework to v0.6.0 (after authorized promotion from `0.6.0-dev`).
2. Run `make ai-sdlc-install` and `make ai-sdlc-install-opa`.
3. Run `make ai-sdlc-validate-overlay ROOT=<workspace>`.
4. Run `make ai-sdlc-existing-refresh-dry-run ROOT=<workspace>` (existing) or greenfield setup path.
5. Review compatibility status (CURRENT, MIGRATION_REQUIRED, POLICY_DRIFT_DETECTED, INCOMPATIBLE).
6. Apply transactional refresh: `make ai-sdlc-framework-setup-refresh ROOT=<workspace> WRITE=1`.
7. Run `make ai-sdlc-validate-setup-readiness ROOT=<workspace>`.
8. Install Cursor commands: `make ai-sdlc-install-cursor-commands ROOT=<workspace>`.

### Existing pilot workspace on older framework

1. **Dry run first:** `make ai-sdlc-existing-refresh-dry-run ROOT=<workspace>`.
2. Review migration report; do not skip INCOMPATIBLE or MIGRATION_REQUIRED without human review.
3. Apply refresh with `WRITE=1`; repeat refresh is idempotent.
4. Re-run project readiness checks before starting new workflows.
5. In-flight workflows: preserve canonical state and events; use operator commands for recovery — no manual YAML edits.

### Rollback (if upgrade fails)

Revert framework merge commit; re-run setup compatibility dry run; preserve workflow state and `lifecycle-events.jsonl`. See [release-review-package.md](release-review-package.md) rollback section.

---

## H1–H13 commit inventory

| Phase | Commits | Capability |
|-------|---------|------------|
| H1 | `f36f032` | Cross-platform Phase 5 symlink escape harness |
| H2 | `5813aa2` | Evidence provenance and verification model |
| H3 | `5835c11` | Merge reconciliation; block unverified merge closure |
| H4 | `bfcc0b1` | Closure evidence completeness |
| H5 | `9d75a79` | Canonical workflow state and artifact projection |
| H6 | `afaad07`, `aea6cec` | Framework versioning, overlay binding, setup migration |
| H7 | `c8181e1` | Gate policy and approval role reconciliation |
| H8 | `b687da0` | Intake and grooming provenance |
| H9 | `e1bf74e` | Phase 1 pre-development and QA strategy |
| H10 | `e8ca894` | Implementation and QA evidence normalization |
| H11 | `3974b9c` | Greenfield bootstrap operator integration |
| H12 | `4c5945d`, `85b947b`, `f9f5fcd` | Existing-pilot defects, closure path, local candidate metadata |
| H13 | `f58b737`, `3ddedce`, `daee41b` | Grooming semantics, duplicate intake, bootstrap resume/closure |
| S1 | `838bdbe` | Internal production-candidate baseline documentation and RC gate |

Full validation history: [../archive/release-validation/h1-h13-commit-inventory.md](../archive/release-validation/h1-h13-commit-inventory.md)

---

## Related documentation

- [Architecture baseline](architecture-baseline.md)
- [Operator command inventory](operator-command-inventory.md)
- [Support runbook](support-runbook.md)
- [Test release baseline](test-release-baseline.md)
- [Release review package](release-review-package.md)
