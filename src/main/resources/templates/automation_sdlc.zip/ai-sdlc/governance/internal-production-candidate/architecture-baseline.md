# Architecture Baseline — Internal Production Candidate

Single canonical reference for Phase 0 intake through Phase 4 delivery readiness, greenfield bootstrap, versioning, state/events, and gates.

## Authority boundaries

| Concern | Authority | Notes |
|---------|-----------|-------|
| **Current workflow state** | Canonical workflow YAML (`.cursor/ai-sdlc/workflow-state/{ISSUE}/{ISSUE}.yaml`) | Sole mutable state authority |
| **Audit history** | `lifecycle-events.jsonl` (append-only) | Never edited; replay source |
| **Human-readable projections** | Generated Markdown (merge-readiness, closure reports, etc.) | Derived only; not authority |
| **Delivery readiness** | Phase 4 setup-state (`readiness.delivery_readiness`) | Phase 5 completion candidate ≠ delivery readiness |
| **Merge truth** | `merge_reconciliation` block | Merge readiness ≠ merge; G-PR-MERGE ≠ merge |
| **Closure eligibility** | `assess_closure_eligibility()` outcome | Requires verified merge when merge in scope |
| **Gate decisions** | Gate records in workflow YAML + evidence records | Non-waivable by policy |
| **Developer attestation** | `record_developer_attestation` / self-review evidence | AI review ≠ developer attestation |

## Phase model

### Phase 0 — Intake and grooming
- Issue normalization via `init_issue`, tracker resolution, grooming loop (stakeholder pack → revision → sign-off).
- G-GROOM gate when required by tier/policy.
- Duplicate workflow detection (`duplicate_workflow.py`) blocks parallel canonical workflows for same issue.

### Phase 1 — Pre-development
- Specification, technical plan, test strategy with G-PLAN package binding.
- G-PLAN reapproval supersedes prior binding when material artifacts change.
- Tier 2+ requires structured pre_development blocks.

### Phase 2 — Implementation
- Step-by-step implementation with command evidence, verification results, AI review, developer attestation.
- Execution provenance mode (PROSPECTIVE vs RETROSPECTIVE) governs evidence requirements.
- QA execution and runtime QA applicability tracked separately.

### Phase 3 — Merge readiness and candidate
- `evaluate_merge_readiness()` produces structured status (READY, BLOCKED, STALE, etc.).
- PR registration supports LOCAL_UNPUSHED_CANDIDATE without provider URL.
- G-PR-MERGE approval binds to candidate identity, not PR URL alone.

### Phase 4 — Setup and delivery readiness (greenfield / existing refresh)
- Setup-state YAML is authority for bootstrap lifecycle and framework binding.
- Bootstrap plan → G-BOOTSTRAP → managed execution → completion candidate → reconciliation.
- `validate_setup_readiness()` enforces delivery_readiness; Phase 5 managed completion publishes candidate only.
- Existing-project refresh via `run_existing_setup_refresh.py` (dry-run default).

### Closure
- `close_merge` records merge reconciliation; closure requires verified merge when applicable.
- `generate_closure_report` is projection; closure block in workflow state reflects eligibility assessment.

## Greenfield bootstrap path

```
intake → grooming → Phase 1 → G-PLAN
  → bootstrap plan (generate/validate)
  → G-BOOTSTRAP approval
  → G-BOOTSTRAP-EXEC (managed proposal/approval)
  → ai-sdlc-managed-execute (local-only, WRITE=1)
  → ai-sdlc-managed-finalize → completion candidate
  → ai-sdlc-reconcile-bootstrap-completion (Phase 4)
  → validate_setup_readiness (delivery_readiness)
  → first feature issue (standard path from Phase 1)
  → merge readiness → candidate → G-PR-MERGE → reconciliation → closure
```

Managed bootstrap constraints:
- Local-only execution; no network; no remote git operations.
- Action classification: MANAGED_MUTATION, MANUAL_ONLY, OPTIONAL_DIAGNOSTIC, validation stages.
- Recoverable failure (`failed_recoverable`) supports resume without duplicate runs.

## Versioning and framework binding (H6)

- Authoritative manifest: `ai-sdlc/framework-version.yaml` (`0.6.0`).
- Setup-state `framework_binding` captures version, policy bundle, compatibility_status.
- Refresh via `ai-sdlc-framework-setup-refresh` updates binding transactionally.
- Compatibility: CURRENT, MIGRATION_REQUIRED, POLICY_DRIFT_DETECTED, INCOMPATIBLE.

## State and events

```
┌─────────────────────┐     write (transaction)     ┌──────────────────────┐
│  Operator commands  │ ──────────────────────────► │  workflow-state.yaml │
└─────────────────────┘                               └──────────┬───────────┘
                                                                 │
                    append                                       │ project
┌─────────────────────┐                                          ▼
│ lifecycle-events    │ ◄──────────────────────────  ┌──────────────────────┐
│ .jsonl              │                               │ Markdown projections │
└─────────────────────┘                               └──────────────────────┘
```

- All mutations go through orchestration/setup tools with revision checks.
- Direct YAML editing is **not** a supported recovery path.

## Gate authority

| Gate | Scope | Waivable |
|------|-------|----------|
| G-GROOM | Requirement grooming sign-off | Policy-dependent |
| G-PLAN | Pre-development package | No (Tier 2+) |
| G-SEC | Security review | Tier 3+ only |
| G-BOOTSTRAP | Bootstrap plan approval | Greenfield |
| G-BOOTSTRAP-EXEC | Managed execution approval | Greenfield |
| G-PR-MERGE | Merge authorization | No |
| G-DEPLOY | Deployment | When deploy in scope |

## Review authority separation

- **AI implementation review:** `record_ai_review` — advisory/automated; cannot satisfy developer attestation.
- **Developer self-review / attestation:** `record_developer_attestation` — human developer accountability.
- **QA execution:** `record_qa_execution` / verification results — separate from review.

## Related architecture docs

- `ai-sdlc/architecture/workflow-state-and-handoff-model.md` — state machine detail
- `ai-sdlc/architecture/project-onboarding-model.md` — onboarding metadata
- `ai-sdlc/governance/approval-gates.md` — gate definitions
- `ai-sdlc/adoption/managed-bootstrap-pilot-runbook.md` — managed bootstrap operations
