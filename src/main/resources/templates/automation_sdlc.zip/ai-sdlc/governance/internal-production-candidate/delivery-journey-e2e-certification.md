# Phase 4g delivery journey E2E certification

Operator-run certification for the neutral `/sdlc-run` delivery journey (Phase 4g).

## Scope

Certifies one complete neutral workspace journey using documented operator commands:

- `/sdlc-run <ISSUE>` planning (`EXECUTE=0`) before each mutating action
- handoff confirmation and consumption before each bounded execution
- `/sdlc-run <ISSUE> EXECUTE=1 ACTION=<bounded_action_id>` for exactly one action per invocation

Segments exercised in order:

1. Bootstrap authorize → execute → publish → reconcile (`SETUP-<workspace-id>`)
2. Register implementation package → authorize → prep → slice
3. QA evidence → QA gate → PR → merge → release → deployment simulation → post-deploy verification

## Running certification

```bash
make ai-sdlc-delivery-journey-e2e-test
```

Full orchestration regression (includes Phase 4g):

```bash
make ai-sdlc-orchestration-test
```

## Topology coverage

| Topology | Full E2E | Bootstrap + implementation path |
|----------|----------|-----------------------------------|
| single_repo | yes | yes |
| monorepo | — | yes |
| multi_repo | — | yes |
| sibling_repos | — | yes |
| nested_repos | — | yes |

## Certification artifacts

Each full-journey run writes a disposable timeline under:

`.cursor/ai-sdlc/certification-artifacts/<ISSUE>/delivery-journey-timeline.json`

The timeline records workflow revisions, handoff IDs, execution results, recovery metadata, and action counts. Artifacts are not committed.

## Invariants proved

- one `EXECUTE=1` → at most one bounded action
- one confirmation → one bounded action
- completed actions are not replayed as new work (`REPLAYED` / idempotent denial)
- bootstrap authorization and execution are separate bounded actions
- implementation authorize, prep, and slice are separate
- no feature/product paths before `IMPLEMENTATION_SLICE`
- strict mode requires consumed handoff + matching execution plan
- recoverable failures emit canonical repair and resume commands
- post-deploy verification failure cannot mark journey complete

## External mocks (allowed)

Remote Git hosting, QA recorders, and autonomous implementation backends may be mocked. The orchestration spine (`plan_sdlc_run`, `run_sdlc_run`, handoff consumption, gate authorization) is not mocked.
