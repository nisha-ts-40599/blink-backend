# Operations, Failure Recovery, Security, and Observability

## Failure and recovery audit

| Failure | Recovery command | Safe retry | Evidence preserved | Notes |
|---------|------------------|------------|-------------------|-------|
| Transaction conflict / revision mismatch | Re-run failing command; check `lifecycle-events.jsonl` | Yes after inspect | Yes (append-only events) | No YAML edit |
| Projection stale (Markdown vs YAML) | `ai-sdlc-sync-validation-status`, re-run evaluator | Yes | Yes | Projections regenerated |
| G-PLAN binding stale | `ai-sdlc-approve-gate GATE=G-PLAN` after artifact update | Yes | Reapproval supersedes | Binding captured automatically |
| Managed bootstrap `failed_recoverable` | Fix scaffold; `ai-sdlc-managed-execute` resume | Yes | Run history preserved | `finalize` idempotent |
| Bootstrap duplicate run | Check `bootstrap-executions/` run-id | No parallel runs | Audit log | Use existing run_id |
| Lease contention (Phase 5.3) | Retry after lease expiry | Yes | Lease events | Concurrency-safe publication |
| Command evidence gap | `ai-sdlc-record-command-execution` | Yes | Append evidence | Maps to verification |
| Merge readiness STALE | Re-record evidence at current commit | Yes | Prior evidence kept | Evaluate after fix |
| PR registration error | `ai-sdlc-correct-pr-registration` | Yes | History array | Transactional |
| Merge not verified | `ai-sdlc-close-merge` with merge SHA | Yes after human merge | Reconciliation block | Closure blocked until verified |
| False closure projection | `ai-sdlc-generate-closure-report` | Yes | Re-evaluates eligibility | H13 daee41b |
| Duplicate workflow intake | `ai-sdlc-consolidate-duplicate-workflow` | Yes with WRITE | Consolidation event | H13 3ddedce |
| Setup refresh migration | `ai-sdlc-framework-setup-refresh WRITE=1` | Yes (idempotent) | Pre-migration snapshot in report | Dry-run first |
| Phase 4 delivery readiness stale | `ai-sdlc-reconcile-bootstrap-completion` | Yes | Completion evidence | Phase 4 authority |
| Stale evidence (commit mismatch) | Re-run evidence commands at HEAD | Yes | Stale markers | Automatic detection |

**No recovery via direct YAML edits.** All recovery uses operator commands.

## Security and safety review

### Path safety
- Bootstrap plans validated for path traversal (`invalid-path-traversal.yaml` fixture).
- Allowed roots enforced in managed bootstrap execution.
- Symlink escape blocked in Phase 5 test harness (H1).

### Network
- Managed bootstrap: **no network** by design.
- Release candidate tests: no network required.
- MCP/issue fetch: optional, operator-initiated only.

### Remote Git
- Managed bootstrap: local git init only; no remote push/pull.
- Merge/PR: human-operated; framework records metadata only.

### Secrets
- No secrets in workflow YAML or evidence records.
- MCP tokens in `.cursor/mcp.json` — out of framework scope.

### Framework/product separation
- `ai-sdlc-guard-framework-clean` blocks uncommitted framework changes during product work.
- `FRAMEWORK_DEV=1` for explicit framework development.

### Roles and gates
- `role_authorization.py` enforces approver roles per gate policy.
- **Authorization precedence (default deny):**
  1. **Issue-level designated approver** — when present in workflow `role_assignments.issue.designated_approvers`, a matching actor is authorized for that gate only.
  2. **Project/org roles** — identities resolved from setup-state `roles` merged with `project-config.yaml` `approval_rules.roles`.
  3. **Deny** — missing overlay, missing/unresolved required roles, or actor not matching any allowed identity. No CI bypass, no `.local` domain magic, no Git author implicit allow.
- Denial diagnostics include gate id, actor, allowed policy roles, role source, and reason code (`OVERLAY_ABSENT`, `ROLE_NOT_CONFIGURED`, `ROLE_NOT_RESOLVED`, `UNAUTHORIZED_ACTOR`) without secrets.
- Non-waivable subjects: implementation evidence, PR identity, merge reconciliation, mandatory test failure.

### Evidence and attestation
- Provenance model (H2): source_type, verification_status, actor attribution.
- AI review cannot satisfy developer attestation.
- Gate approvals require evidence refs (URL or artifact path — not URL-only for G-PR-MERGE).

### Remaining limitations
- No enterprise IAM/SSO integration.
- No centralized telemetry platform.
- Local candidate push state relies on operator truthfulness.
- Provider webhook merge detection not implemented.

## Observability baseline

### Events (`lifecycle-events.jsonl`)
- Gate approvals, state transitions, evidence captures, merge reconciliation, bootstrap audit.

### Logs
- Managed bootstrap: `audit-events.jsonl` per run under `bootstrap-executions/`.
- Command stderr preserved in release candidate test output tails.

### Metrics
- No centralized metrics agent. Suite durations in `release-candidate-summary.json`.

### JUnit
- `ai-sdlc/tests/results/conformance-report.junit.xml` (conformance)
- `ai-sdlc/tests/results/release-candidate.junit.xml` (release aggregate)

### Reports
- Closure reports, merge readiness projections, bootstrap verification reports, setup readiness assessments.

### Gaps
- No distributed trace IDs across workspaces.
- No automated staleness alerting.
- No dashboard for multi-team pilot status.
