# Operator Command Inventory

Definitive reference for setup through closure. Commands run from framework repo root unless `ROOT=` points to consuming workspace.

**Totals:** ~100 `make ai-sdlc-*` targets | **Dry-run default:** refresh, managed bootstrap preview/simulate, update-state-dry-run | **Write mode:** `WRITE=1` on mutation commands | **Status/next:** stage-router, bootstrap-operator-status, intake-operator-status, requirement-grooming-status

## Setup and framework binding

| Command | Purpose | Required inputs | Mutations | Dry run | Output | Next command |
|---------|---------|-----------------|-----------|---------|--------|--------------|
| `ai-sdlc-install` | Create venv, install deps | — | No | N/A | venv | `ai-sdlc-validate-overlay` |
| `ai-sdlc-detect-workspace` | Detect workspace shape | `ROOT` | No | Default | stdout JSON/text | `ai-sdlc-validate-overlay` |
| `ai-sdlc-validate-overlay` | Validate context overlay | `ROOT` | No | Default | PASS/FAIL | `ai-sdlc-validate-setup-readiness` |
| `ai-sdlc-validate-setup-readiness` | Assess setup readiness | `ROOT` | Optional `WRITE=1` | Without WRITE | readiness report | refresh or bootstrap |
| `ai-sdlc-framework-setup-refresh` | Refresh framework binding | `ROOT`, optional `WRITE=1` | With WRITE | Default dry-run | binding update plan | `ai-sdlc-validate-setup-readiness` |
| `ai-sdlc-existing-refresh` | Existing project refresh orchestration | `ROOT`, `WRITE=1` for write | With WRITE | `ai-sdlc-existing-refresh-dry-run` | refresh report | `ai-sdlc-validate-setup-readiness` |
| `ai-sdlc-install-cursor-commands` | Install slash-command wrappers | `ROOT` | Yes (commands only) | No | installed list | `ai-sdlc-stage-router` |

## Greenfield bootstrap

| Command | Purpose | Required inputs | Mutations | Dry run | Output | Next command |
|---------|---------|-----------------|-----------|---------|--------|--------------|
| `ai-sdlc-validate-greenfield-spec` | Validate greenfield spec | `SPEC` path | No | Default | validation | `ai-sdlc-generate-bootstrap-plan` |
| `ai-sdlc-greenfield-setup-discover` | Interactive setup discovery (tools, MCP, recommendations) | `ROOT`, `INPUT` or `PROJECT_NAME` | No | Always | JSON report stdout | user confirm → apply |
| `ai-sdlc-greenfield-setup-apply` | Persist init input, report, draft spec, scaffold records | `ROOT`, `INPUT` or `PROJECT_NAME`, implicit write | Yes | No | JSON result | `/setup-new-workspace apply` + refresh |
| `ai-sdlc-validate-project-init-input` | Validate initialisation intake YAML | `INPUT` | No | Default | VALID/INVALID | discover or apply |
| `ai-sdlc-generate-bootstrap-plan` | Generate bootstrap plan | `SPEC`, `ROOT` | With `WRITE=1` | Default | plan YAML | `ai-sdlc-validate-bootstrap-plan` |
| `ai-sdlc-validate-bootstrap-plan` | Validate bootstrap plan | `PLAN` | No | Default | validation | gate approval |
| `ai-sdlc-managed-capability-discovery` | Discover local capabilities | `ROOT` | No | Always dry | capability profile | `ai-sdlc-managed-proposal` |
| `ai-sdlc-managed-proposal` | Build execution proposal | `PLAN`, `ROOT` | No | Always dry | proposal | `ai-sdlc-managed-proposal-validate` |
| `ai-sdlc-managed-execute` | Execute approved bootstrap | `PLAN`, `PROPOSAL`, `APPROVAL`, `WRITE=1` | Yes | No | run artifacts | `ai-sdlc-managed-finalize` |
| `ai-sdlc-managed-finalize` | Finalize run → completion candidate | `RUN_ID`, `WRITE=1` | Yes | No | candidate | `ai-sdlc-reconcile-bootstrap-completion` |
| `ai-sdlc-reconcile-bootstrap-completion` | Phase 4 reconciliation | `ROOT`, `WRITE=1` | Yes | Default dry | reconciliation | `ai-sdlc-validate-setup-readiness` |
| `ai-sdlc-bootstrap-operator-status` | Read-only bootstrap status | `ROOT`, optional `ISSUE` | No | Always | status JSON/text | per recommendation |

## Issue intake and grooming

| Command | Purpose | Required inputs | Mutations | Dry run | Output | Next command |
|---------|---------|-----------------|-----------|---------|--------|--------------|
| `ai-sdlc-init-issue` | Initialize workflow state | `ROOT`, `ISSUE`, `WRITE=1` | Yes | Without WRITE | init report | `ai-sdlc-groom-prep` |
| `ai-sdlc-groom-prep` | Grooming context bundle | `ROOT`, `ISSUE` | No | Default | bundle paths | `/grooming-stakeholder-pack` |
| `ai-sdlc-validate-requirement-dor` | Definition-of-ready check | `ROOT`, `ISSUE`, optional `WRITE=1` | Optional | Without WRITE | DoR result | `ai-sdlc-approve-grooming` |
| `ai-sdlc-approve-grooming` | Record G-GROOM | `ROOT`, `ISSUE`, gate params, `WRITE=1` | Yes | Without WRITE | gate record | Phase 1 prompts |
| `ai-sdlc-intake-operator-status` | Intake/duplicate status | `ROOT`, `ISSUE` | No | Always | status | `ai-sdlc-consolidate-duplicate-workflow` |
| `ai-sdlc-consolidate-duplicate-workflow` | Consolidate duplicate workflows | `ROOT`, `ISSUE`, `WRITE=1` | Yes | Without WRITE | consolidation | `ai-sdlc-stage-router` |

## Phase 1 and gates

| Command | Purpose | Required inputs | Mutations | Dry run | Output | Next command |
|---------|---------|-----------------|-----------|---------|--------|--------------|
| `ai-sdlc-validate-pre-spec` | Pre-spec bundle readiness | `ROOT`, `ISSUE` | No | Default | PASS/WARN/FAIL | `/technical-plan` |
| `ai-sdlc-check-gates` | Evaluate gate requirements | `ROOT`, `ISSUE` | No | Default | gate status | `ai-sdlc-approve-gate` |
| `ai-sdlc-approve-gate` | Record gate approval | `ROOT`, `ISSUE`, `GATE`, `WRITE=1` | Yes | Without WRITE | approval | implementation |

## Implementation evidence (H10)

| Command | Purpose | Required inputs | Mutations | Dry run | Output | Next command |
|---------|---------|-----------------|-----------|---------|--------|--------------|
| `ai-sdlc-record-command-execution` | Record command evidence | `ROOT`, `ISSUE`, `COMMAND`, `EXIT_CODE`, `COMMIT_SHA`, `WRITE=1` | Yes | Without WRITE | evidence id | `ai-sdlc-record-verification-result` |
| `ai-sdlc-record-ai-review` | Record AI review | `ROOT`, `ISSUE`, model, commit, `WRITE=1` | Yes | Without WRITE | review record | `ai-sdlc-record-developer-attestation` |
| `ai-sdlc-record-developer-attestation` | Developer attestation | `ROOT`, `ISSUE`, developer, commit, `WRITE=1` | Yes | Without WRITE | attestation | `ai-sdlc-record-qa-execution` |
| `ai-sdlc-record-qa-execution` | QA execution | `ROOT`, `ISSUE`, status, commit, `WRITE=1` | Yes | Without WRITE | QA record | `ai-sdlc-evaluate-merge-readiness` |
| `ai-sdlc-record-execution-provenance` | Execution provenance mode | `ROOT`, `ISSUE`, mode, `WRITE=1` | Yes | Without WRITE | provenance | evidence commands |
| `ai-sdlc-record-verification-result` | Verification result | `ROOT`, `ISSUE`, verification id, `WRITE=1` | Yes | Without WRITE | verification | merge readiness |

## Merge, PR, closure

| Command | Purpose | Required inputs | Mutations | Dry run | Output | Next command |
|---------|---------|-----------------|-----------|---------|--------|--------------|
| `ai-sdlc-evaluate-merge-readiness` | Assess merge readiness | `ROOT`, `ISSUE`, optional `WRITE=1` | Optional | Without WRITE | readiness | `ai-sdlc-register-pr` |
| `ai-sdlc-register-pr` | Register PR/candidate | `ROOT`, `ISSUE`, repo/branch/commit; **PR URL optional** for local candidate | Yes `WRITE=1` | Without WRITE | registration | `ai-sdlc-approve-gate GATE=G-PR-MERGE` |
| `ai-sdlc-correct-pr-registration` | Correct PR metadata | `ROOT`, `ISSUE`, `WRITE=1` | Yes | Without WRITE | correction | `ai-sdlc-close-merge` |
| `ai-sdlc-close-merge` | Record merge reconciliation | `ROOT`, `ISSUE`, merge evidence, `WRITE=1` | Yes | Without WRITE | reconciliation | `ai-sdlc-generate-closure-report` |
| `ai-sdlc-generate-closure-report` | Closure projection | `ROOT`, `ISSUE` | No | Default | report MD | issue close (external) |

## Routing and validation (read-only)

| Command | Purpose | Required inputs | Mutations | Dry run | Output | Next command |
|---------|---------|-----------------|-----------|---------|--------|--------------|
| `ai-sdlc-stage-router` | Recommend next action | `ROOT`, `ISSUE` | No | Always | recommendation | suggested command |
| `ai-sdlc-validate-artifacts` | Artifact completeness | `ROOT`, `ISSUE` | No | Always | PASS/WARN/FAIL | stage advance |
| `ai-sdlc-validate-stage` | Stage eligibility | `ROOT`, `ISSUE`, `STAGE` | No | Always | eligibility | transition |
| `ai-sdlc-rollback-check` | Rollback readiness | `ROOT`, `ISSUE` | No | Always | check result | merge readiness |
| `ai-sdlc-repo-status` | Git topology | `ROOT` | No | Always | topology | register-pr |

## Deprecated / non-canonical

| Command | Replacement | Notes |
|---------|-------------|-------|
| Direct workflow YAML edits | Operator commands above | Never recommended |
| Synthetic local PR URLs | `LOCAL_UNPUSHED_CANDIDATE` + `provider_unavailable` | Removed H12 |
| Assuming G-PR-MERGE = merged | `ai-sdlc-close-merge` after human merge | Documented |
| Phase 5 completion for delivery readiness | Phase 4 `validate_setup_readiness` | Authority split |

## Gaps (enterprise backlog)

- Centralized IAM integration for gate approvers
- Remote CI/provider auto-verification without manual attestation
- Multi-team workspace federation
- Automated merge detection from provider webhooks
