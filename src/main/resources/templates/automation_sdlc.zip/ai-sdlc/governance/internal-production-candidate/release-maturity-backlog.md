# Release Plan, Maturity Assessment, and Enterprise Backlog

## Release plan — Internal Production Candidate v0.6.0

| Item | Value |
|------|-------|
| Candidate version | `0.6.0` (promoted from `0.6.0-dev` per Phase R1A authorization) |
| Target branch | `feature/end-to-end-pilot-hardening` → `main` (not executed in S1) |
| Merge strategy | Standard merge commit after release-candidate-test PASS |
| Pre-merge | `make ai-sdlc-release-candidate-test`; framework guard PASS; doc review |
| Rollback | Revert merge commit; consuming workspaces re-run `ai-sdlc-framework-setup-refresh` dry-run |
| Post-merge | Tag `v0.6.0` (not executed in S1); announce operator inventory + architecture baseline |

**S1 does not execute merge, tag, or push.**

## Maturity assessment

| Level | Status | Evidence |
|-------|--------|----------|
| controlled_pilot_baseline | **YES** | Phase 5 complete; pilot-readiness assessment; H1–H13 remediation tests |
| internal_production_candidate | **YES** | 16-suite release gate; architecture baseline; operator inventory; boundary fixtures |
| internal_multi_team_ready | **NOT YET PROVEN** | Single-team pilots only; no federation tests |
| enterprise_pilot_ready | **PARTIAL** | Command spine, governance docs; gaps in IAM, telemetry, provider automation |
| enterprise_ready | **NO** | Explicit non-goal for S1 |

## Enterprise backlog (prioritized — do not implement in S1)

| Capability | Priority | Required before | Rationale |
|------------|----------|-----------------|-----------|
| Enterprise IAM / SSO for gate approvers | P1 | enterprise_pilot_ready | Role authorization is local policy only |
| Provider webhook merge verification | P1 | enterprise_pilot_ready | Manual close-merge is error-prone at scale |
| Centralized observability / audit export | P2 | internal_multi_team_ready | Events are local JSONL only |
| Multi-workspace federation | P2 | internal_multi_team_ready | No cross-team state coordination |
| Automated CI evidence ingestion | P2 | enterprise_pilot_ready | Command evidence is operator-recorded |
| Remote bootstrap (non-local) | P3 | enterprise_ready | Contradicts current safety model |
| Policy bundle hot-reload | P3 | enterprise_ready | Requires migration contract versioning |
| Enterprise overlay marketplace | P3 | enterprise_ready | Manual overlay validation only |

## Documentation alignment (S1)

### Existing-project route
intake → grooming → Phase 1 → G-PLAN → implementation → evidence → merge readiness → candidate/PR → G-PR-MERGE → merge reconciliation → closure

### Greenfield route
intake → grooming → Phase 1 → G-PLAN → bootstrap plan → G-BOOTSTRAP → G-BOOTSTRAP-EXEC → managed execution → completion candidate → Phase 4 readiness → first feature → merge readiness → candidate → G-PR-MERGE → reconciliation → closure

### Incorrect guidance removed
- PR registration **does not require** URL (local candidate supported)
- Local candidate is **not** pushed by default
- G-PR-MERGE **does not mean** merged
- Completion candidate **≠** delivery readiness (Phase 4 authority)
- AI review **≠** human/developer review
- Phase 5 **does not set** delivery readiness
- Closure **not verifiable** without merge when merge in scope

### Files updated (S1)
- `ai-sdlc/governance/internal-production-candidate/*` (this baseline)
- `ai-sdlc/adoption/quick-start.md` (authority clarifications)
- `ai-sdlc/adoption/pilot-run-guide.md` (merge/closure/candidate guidance)
- `ai-sdlc/README.md` (link to internal production candidate baseline)
