# Phase R1 — Human Review Package

**Prepared:** 2026-07-17  
**Verdict target:** `R1_READY_FOR_MERGE_AUTHORIZATION` (merge **not** authorized in this phase)  
**Classification:** Internal Production Candidate — not Enterprise Ready

---

## 1. Candidate identification

| Field | Value |
|-------|-------|
| Candidate branch | `feature/end-to-end-pilot-hardening` |
| Candidate commit | `838bdbe2d50573ce5a3772c0bd3fff53ec959879` |
| Candidate version | `0.6.0-dev` |
| Target branch | `main` |
| Target commit | `538b57be8d73ec79016eadd79ab41b3cf3bcbc09` |
| Merge base | `538b57be8d73ec79016eadd79ab41b3cf3bcbc09` |
| Commits on candidate since divergence | 19 |
| Commits on main since divergence | 0 |

---

## 2. Commit inventory (19 commits)

```
838bdbe chore(ai-sdlc): establish internal production-candidate baseline
daee41b fix(ai-sdlc): reconcile resumed bootstrap and prevent false closure
3ddedce fix(ai-sdlc): prevent duplicate workflows during issue intake
f58b737 fix(ai-sdlc): align grooming resolution status semantics
f9f5fcd fix(ai-sdlc): correct local candidate push and provider metadata
85b947b fix(ai-sdlc): complete prospective existing-pilot closure path
4c5945d fix(ai-sdlc): address prospective existing-pilot defects
3974b9c feat(ai-sdlc): harden greenfield bootstrap integration and operator flow
e8ca894 feat(ai-sdlc): normalize implementation and QA evidence
e1bf74e feat(ai-sdlc): strengthen pre-development approval and QA strategy
b687da0 feat(ai-sdlc): harden intake and grooming provenance
c8181e1 fix(ai-sdlc): reconcile gate policy and approval roles
aea6cec fix(ai-sdlc): migrate refreshed setup state and readiness metadata
afaad07 feat(ai-sdlc): bind overlays to framework and policy versions
9d75a79 fix(ai-sdlc): synchronize workflow state and generated artifacts
bfcc0b1 fix(ai-sdlc): enforce closure evidence completeness
5835c11 fix(ai-sdlc): block contradictory and unverified merge closure
5813aa2 feat(ai-sdlc): add evidence provenance and verification model
f36f032 test(ai-sdlc): fix cross-platform phase5 symlink escape harness
```

Authoritative validation history: [../archive/release-validation/h1-h13-commit-inventory.md](../archive/release-validation/h1-h13-commit-inventory.md)

---

## 3. Release diff summary

| Metric | Value |
|--------|-------|
| Files changed | 204 |
| Insertions | +24,406 |
| Deletions | −606 |
| Merge conflicts (simulated) | **None** |

### Functional areas

| Area | Changes |
|------|---------|
| Orchestration | Evidence model, gate policy, merge reconciliation, closure eligibility, grooming, duplicate workflow, PR candidate, ~40 new modules + tests |
| Setup | Framework compatibility, setup migration, greenfield route, bootstrap finalize/reconcile, operator status |
| Schemas | `workflow-state`, `setup-state`, `evidence-record`; gate/event registries expanded |
| Policies | `gates.rego` updates aligned with gate policy module |
| Prompts | Provenance/evidence guidance in 10 prompts |
| Governance | Internal production candidate baseline (10 docs) |
| Fixtures | Existing-project and greenfield delivery boundary disposable fixtures |
| Commands | 5 new Cursor bootstrap operator commands |
| Makefile | Release-candidate target, bootstrap/evidence operator targets |
| Docs | Operating model alignment (4 files), adoption guides |

### Unexpected files

None identified. All changes align with H1–H13 hardening and S1 stabilization scope.

### Live pilot state

**Not included.** No `.cursor/ai-sdlc/` live workspace state on the framework branch. Disposable fixtures only under `ai-sdlc/examples/disposable-fixtures/`.

### Secrets scan

| Finding | Classification |
|---------|----------------|
| Documentation references to tokens/API keys (MCP setup) | **Accepted** — guidance only |
| Test fixtures with fake tokens/passwords | **Accepted** — sentinel values |
| `fetch_jira_issue.py` env var handling | **Accepted** — no logging of secrets |
| `greenfield_spec_common.py` secret scanner | **Accepted** — security control |
| No `BEGIN PRIVATE KEY`, real credentials, or `.env` values | **Clean** |

### Local runtime paths

All reusable tests and fixtures use in-repo disposable paths or temporary directories. Optional live workspace checks require `AI_SDLC_SAMPLE_WORKSPACE_ROOT` and are skipped in CI when unset.

No developer-specific absolute paths remain in active framework guidance.

---

## 4. Architecture authority model

| Concern | Authority |
|---------|-----------|
| Current workflow state | Canonical workflow YAML (`.cursor/ai-sdlc/workflow-state/{ISSUE}/{ISSUE}.yaml`) |
| Audit history | `lifecycle-events.jsonl` (append-only) |
| Human-readable projections | Generated Markdown (derived only) |
| Delivery readiness | Phase 4 setup-state (`readiness.delivery_readiness`) |
| Merge truth | `merge_reconciliation` block |
| Closure eligibility | `assess_closure_eligibility()` outcome |
| Gate decisions | Gate records + evidence records in workflow YAML |
| Developer attestation | `record_developer_attestation` — separate from AI review |

**Critical separations enforced:**
- merge readiness ≠ merge
- G-PR-MERGE ≠ merge
- completion candidate ≠ delivery readiness
- AI review ≠ developer attestation

Full reference: [architecture-baseline.md](architecture-baseline.md)

---

## 5. Test evidence

### Candidate branch (`838bdbe`, clean tree)

| Command | Result |
|---------|--------|
| `make ai-sdlc-release-candidate-test` | **PASS** (18/18 suites) |
| `make ai-sdlc-guard-framework-clean` | **PASS** |

Release summary: `ai-sdlc/tests/results/release-candidate-summary.json` — all suites passed.

### Merge simulation (`main` + `--no-commit --no-ff`)

| Check | Result |
|-------|--------|
| Auto-merge | **PASS** — no conflicts |
| Functional suites (16 + conformance) | **PASS** (with OPA binary copied to worktree) |
| Framework guard in `--no-commit` state | **FAIL (expected)** — uncommitted merge simulation state |
| Aggregate RC in `--no-commit` state | **FAIL (expected)** — includes framework-guard post-check |

**Interpretation:** Merge content is clean. Post-merge validation on committed `main` (authorized merge procedure §21) is expected to PASS when tree is clean and OPA is installed.

### Existing-project delivery boundary fixture

- Path: `ai-sdlc/examples/disposable-fixtures/existing-project-delivery-boundary/`
- State: PROSPECTIVE Tier 2, G-PLAN current, merge READY, LOCAL_UNPUSHED_CANDIDATE, G-PR-MERGE approved, **CLOSURE_BLOCKED** (not merged)
- Tests: `test_existing_project_boundary_fixture.py`, `test_existing_project_remediation.py` — **PASS** in orchestration suite

### Greenfield delivery boundary fixture

- Path: `ai-sdlc/examples/disposable-fixtures/greenfield-delivery-boundary/`
- State: Greenfield first feature, bootstrap complete, Phase 4 READY, merge READY, local candidate, G-PR-MERGE approved, **CLOSURE_BLOCKED**
- Tests: `test_greenfield_boundary_fixture.py`, `test_greenfield_bootstrap_remediation.py` — **PASS** in orchestration suite

---

## 6. Known limitations and open risks

### Known limitations (acceptable for limited rollout)

- No enterprise IAM/SSO
- No provider webhook merge reconciliation
- No centralized telemetry or multi-team dashboard
- Local-only managed bootstrap (no network, no remote git)
- OPA binary gitignored — must install per environment
- Single-team pilot evidence only

### Open risks

| ID | Risk | Severity | Mitigation |
|----|------|----------|------------|
| R1 | Operator bypasses gates via manual YAML edit | P1 | Runbook prohibits; guard + training |
| R2 | Local unpushed candidate metadata inaccurate | P2 | `correct-pr-registration`; operator attestation |
| R3 | Setup refresh migration on complex legacy overlay | P2 | Dry-run mandatory; MIGRATION_REQUIRED blocks |
| R4 | OPA missing in CI/dev causes false conformance failure | P2 | Document `make ai-sdlc-install-opa`; CI installs OPA |
| R5 | Multi-team concurrent adoption unproven | P2 | Limit to 2 teams; weekly review |

No open P0 defects identified.

---

## 7. Review questions (human sign-off required)

**Do not represent silence as approval.**

| # | Question | Reviewer assessment | Approved |
|---|----------|---------------------|----------|
| 1 | Are authority boundaries acceptable? | _Pending human review_ | ☐ |
| 2 | Are non-waivable gates appropriate? | _Pending human review_ | ☐ |
| 3 | Is the closure model sufficiently strict? | _Pending human review_ | ☐ |
| 4 | Are local-only bootstrap constraints acceptable for internal rollout? | _Pending human review_ | ☐ |
| 5 | Are existing-project and greenfield delivery routes sufficient evidence for controlled adoption? | _Pending human review_ | ☐ |
| 6 | Are the remaining P1/P2 gaps acceptable for limited rollout? | _Pending human review_ | ☐ |
| 7 | Is the version ready for `0.6.0` promotion? | _Pending human review_ | ☐ |

### Architecture review

**Status:** Prepared — **not approved** (awaiting human reviewer)

### Security review

**Status:** Prepared — scan clean; limitations documented — **not approved**

### Release review

**Status:** Prepared — diff reviewed, RC PASS on candidate — **not approved**

---

## 8. Version promotion plan (NOT APPLIED)

| Field | Value |
|-------|-------|
| Current version | `0.6.0-dev` |
| Target version | `0.6.0` |
| Applied | **NO** |
| Recommended timing | **Option A — before merge** (final commit on candidate branch) |

### Rationale for Option A

Repository convention uses candidate branch as release line; S1 baseline documents promotion at tag/merge time. A dedicated pre-merge commit on `feature/end-to-end-pilot-hardening` allows reviewers to inspect exact version diff before merge to `main`. Option B (promotion on `main` during merge) splits release history across branches.

### Files to change for `0.6.0-dev` → `0.6.0`

| File | Change |
|------|--------|
| `ai-sdlc/framework-version.yaml` | `version: "0.6.0"`, `release_channel: internal-production-candidate` (or `stable` per policy) |
| `ai-sdlc/README.md` | Header version reference |
| `ai-sdlc/governance/internal-production-candidate/README.md` | Version label |
| `ai-sdlc/governance/internal-production-candidate/architecture-baseline.md` | Version reference |
| `ai-sdlc/governance/internal-production-candidate/release-maturity-backlog.md` | Candidate version row |
| `ai-sdlc/examples/disposable-fixtures/greenfield-delivery-boundary/setup-state.fragment.yaml` | `framework_version: "0.6.0"` |
| `ai-sdlc/tools/setup/test_framework_compatibility.py` | Test fixtures expecting `0.6.0-dev` → `0.6.0` |

**Do not change** (unless policy requires bump): `schema_bundle_version` (1.0), `policy_bundle_version` (1.1), `prompt_catalog_version` (1.0), `overlay_template_version` (1.1) — these are bundle identifiers, not release semver.

### Proposed version commit (after authorization only)

```bash
# On feature/end-to-end-pilot-hardening, after merge authorization
# Apply file changes above, then:
make ai-sdlc-release-candidate-test
make ai-sdlc-guard-framework-clean
git add -A
git commit -m "$(cat <<'EOF'
chore(ai-sdlc): promote internal production candidate to v0.6.0

EOF
)"
```

---

## 9. Merge strategy

| Field | Value |
|-------|-------|
| Strategy | Standard merge commit (`--no-ff`) |
| Rationale | Preserves H1–H13 commit history and audit trail |
| Squash | **Not recommended** unless explicitly requested |
| Authorization present | **NO** |
| Merge executed | **NO** |

### Exact command (after authorization + version promotion + RC PASS)

```bash
cd <project-root>
git checkout main
git merge --no-ff feature/end-to-end-pilot-hardening \
  -m "$(cat <<'EOF'
Merge branch 'feature/end-to-end-pilot-hardening'

Internal Production Candidate v0.6.0 — H1–H13 hardening and S1 baseline.

EOF
)"
make ai-sdlc-release-candidate-test
make ai-sdlc-guard-framework-clean
```

Push and tag require **separate** authorization.

---

## 10. Pre-merge checklist

All items must be complete before merge. **Current status:**

| Item | Status |
|------|--------|
| Human architecture review complete | ☐ Pending |
| Security review complete | ☐ Pending |
| Release diff reviewed | ☑ Prepared (this package) |
| No secrets detected | ☑ Scan clean |
| No live pilot state included | ☑ Confirmed |
| Simulated merge clean | ☑ No conflicts |
| Release-candidate passes on candidate | ☑ PASS |
| Release-candidate passes in merged simulation | ☑ Functional suites PASS; guard expected fail in `--no-commit` |
| Version-promotion approach approved | ☐ Pending (Option A recommended) |
| Release notes approved | ☐ Pending |
| Rollback plan approved | ☐ Pending |
| Rollout teams identified | ☐ Pending |
| Support owner identified | ☐ Pending |
| Authorization to merge recorded | ☐ **NOT PRESENT** |

**Merge blocked** until authorization checklist complete.

---

## 11. Rollback plan

### Level 1 — Before rollout (pre-adoption)

Revert merge commit on `main`:

```bash
git revert -m 1 <merge-commit-sha>
make ai-sdlc-release-candidate-test   # on reverted main
```

### Level 2 — After limited project setup refresh

1. Stop new workflow starts on affected projects.
2. Preserve existing workflow state and `lifecycle-events.jsonl`.
3. Revert framework merge commit.
4. Run `make ai-sdlc-existing-refresh-dry-run ROOT=<workspace>` on each consuming project.
5. Avoid destructive overlay downgrade; continue in-flight workflows only if compatibility allows.
6. Communicate rollback to rollout teams.

### Level 3 — Active workflow defect

1. Stop affected workflow at current gate (do not advance).
2. Preserve canonical state and event history.
3. Record incident with workflow ID, framework commit, state revision.
4. Use supported recovery commands per [support-runbook.md](support-runbook.md).
5. **Do not** manually edit YAML.
6. Fall back to human-led SDLC where framework recovery insufficient.

### Rollback triggers

- False verified merge or closure
- Unsafe filesystem mutation outside allowed roots
- Provider authority fabrication (synthetic PR URLs, etc.)
- Manual YAML repair required for recovery
- Data loss or unrecoverable state corruption
- Non-waivable gate bypass
- Release-candidate suite regression on `main`

---

## 12. Limited internal rollout plan

### Scope

| Parameter | Value |
|-----------|-------|
| Projects | 2–3 internal |
| Teams | 2 delivery teams |
| Duration | 4–8 weeks |

### Recommended project mix

1. **Existing-project** — Tier 1 or Tier 2 change on supported repo
2. **Greenfield** — internal tool or utility repo
3. **Optional** — QA/test-automation workflow pilot

### Exclusions (initial phase)

- Production-critical emergency changes
- Regulated client data environments
- Payment systems
- High-risk infrastructure changes
- Multi-repository enterprise programs
- External customer self-service usage

### Entry criteria (per project)

- Project owner assigned
- Engineering lead assigned
- QA actor assigned
- Repository supported (local git, Cursor, Make)
- Setup compatibility CURRENT or refreshable
- `make ai-sdlc-framework-setup-refresh` dry-run PASS
- No unsupported provider dependency
- Human gate approvals agreed
- No manual YAML editing planned
- Support owner identified

### Operating model

| Role | Responsibility |
|------|----------------|
| Rollout owner | Coordinates adoption, weekly review |
| Framework maintainer | RC validation, defect triage, authorized fixes |
| Project operator | Executes Make/Cursor commands per stage-router |
| Engineering approver | G-PLAN, G-SEC as required |
| Product approver | G-GROOM sign-off |
| QA approver | QA execution evidence |
| Support escalation owner | P0/P1 response per runbook |

**Support runbook:** [support-runbook.md](support-runbook.md)

### Review cadence

- Weekly rollout review
- Per-workflow observation log
- Weekly defect triage
- Release-candidate validation after each framework fix

---

## 13. Metrics and stop criteria

### Required metrics

```
workflow starts
workflows completing Phase 0
DoR failure rate
gate rejection rate
time in each phase
manual workaround count
direct-state-edit count (target: 0)
evidence recognition failures
merge-readiness blockers
bootstrap recovery count
projection failures
closure contradictions
P0/P1 defect count
operator satisfaction (qualitative)
delivery lead time
```

**Baseline availability:** Not yet established — collect during weeks 1–2; do not claim productivity improvements without baseline.

**Reporting cadence:** Weekly rollup to rollout owner; P0 immediate notification.

### Stop criteria (pause rollout)

**P0 (immediate stop):**
- False verified merge or closure
- Unsafe filesystem mutation
- Provider authority fabrication
- Manual YAML repair required
- Data loss
- Unrecoverable state corruption
- Non-waivable gate bypass
- More than one unresolved P0

**P1 (pause if repeated across two projects):**
- Repeated revision conflicts
- Release-candidate suite regression
- Repeated merge-readiness blockers from framework defects

**Stop authority:** Rollout owner + framework maintainer (joint decision); P0 may be invoked by any project operator immediately.

### Escalation

| Severity | Response |
|----------|----------|
| P0 | Immediate rollout stop; framework owner within 4h |
| P1 | Workflow blocked; framework owner response required |
| P2 | Documented workaround only when safe |
| P3 | Backlog |

Every P0/P1 must include: reproducible command, issue/workflow ID, framework commit, state revision, evidence refs, expected vs actual behavior, safe stopping point.

---

## 14. Push and tag boundary

| Operation | Authorized | Executed |
|-----------|------------|----------|
| Merge to main | **NO** | **NO** |
| Push to remote | **NO** | **NO** |
| Tag `v0.6.0` | **NO** | **NO** |

Local merge authorization does not imply push or tag authorization.

---

## 15. Related artifacts

- [RELEASE-NOTES-v0.6.0.md](RELEASE-NOTES-v0.6.0.md)
- [h1-h13-commit-inventory.md](h1-h13-commit-inventory.md)
- [architecture-baseline.md](architecture-baseline.md)
- [test-release-baseline.md](test-release-baseline.md)
- [operations-and-security.md](operations-and-security.md)
- [release-maturity-backlog.md](release-maturity-backlog.md)

---

## 16. Recommendation

**Grant merge authorization only after:**

1. Human reviewer completes questions 1–7 above.
2. Version promotion Option A is approved and applied (separate authorized commit).
3. Pre-merge checklist all items checked.
4. Rollout teams and support owner named.

**Next phase after authorization:** Execute §21 authorized merge procedure → limited internal rollout (§12–§13).

**If authorization denied:** Address review findings on candidate branch; re-run Phase R1 preparation.
