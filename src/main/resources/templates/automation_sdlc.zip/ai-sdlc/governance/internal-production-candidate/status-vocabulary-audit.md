# Status Vocabulary Audit

Audit of status vocabularies across schemas and runtime. Stable domain-specific vocabularies are documented, not redesigned.

## Domain table

| Domain | Canonical values | Legacy values | Normalization | Issues |
|--------|------------------|---------------|---------------|--------|
| Workflow stage | `REQUIREMENT` … `COMPLETE`, `BLOCKED`, `CANCELLED` (34 values) | None | Uppercase in YAML | None — schema/runtime aligned |
| Implementation status | `not_started`, `in_progress`, `committed_local`, `pr_opened`, `ready_for_merge`, `deployed` | Mixed case in old pilots | Lowercase snake_case | None |
| Implementation mode | `PROSPECTIVE`, `RETROSPECTIVE_VALIDATION`, `IMPORTED_EXISTING`, `ALREADY_MERGED`, `PARTIALLY_IMPLEMENTED` | `UNKNOWN` | Uppercase | Runtime infers mode when absent |
| Merge readiness | `READY`, `READY_WITH_WAIVERS`, `BLOCKED`, `STALE`, `NOT_EVALUATED` | None | Uppercase | None |
| Merge reconciliation | `NOT_EVALUATED`, `MERGE_REPORTED`, `MERGE_VERIFIED`, `MERGE_REPORTED_UNVERIFIED`, `LEGACY_MERGED_UNVERIFIED`, blocking set | Legacy merged states | Uppercase | None |
| Closure outcome | `CLOSURE_BLOCKED`, `CLOSURE_ELIGIBLE`, `MERGE_RECONCILIATION_REQUIRED`, `CLOSED_VERIFIED`, etc. | `LEGACY_CLOSURE_UNVERIFIED` | Uppercase | None |
| Gate approval | `not_required`, `pending`, `approved`, `rejected`, `expired` | Boolean-only `approved: true` (H9 legacy) | Lowercase in gate records | Legacy fixtures test migration path |
| Grooming question (canonical) | `OPEN`, `RESOLVED`, `ANSWERED`, `DEFERRED`, `NOT_APPLICABLE`, `SUPERSEDED`, `REOPENED` | Lowercase in `open_questions` markdown projection | `normalize_open_question_status()` | **Intentional dual representation** (H13 f58b737) — not a defect |
| Contradiction resolution | `OPEN`, `RESOLVED`, `ACCEPTED_WITH_WAIVER`, `SUPERSEDED` | Lowercase `open` in old records | `.upper()` in validation | Runtime normalizes on validate |
| Setup lifecycle | `not_started` … `delivery_ready`, `failed`, `reset_required` | None | Lowercase snake_case | None |
| Framework compatibility | `CURRENT`, `MIGRATION_REQUIRED`, `POLICY_DRIFT_DETECTED`, `INCOMPATIBLE`, `UNSUPPORTED` | None | Uppercase | None |
| Readiness sub-status | `READY`, `BLOCKED`, `STALE`, `NOT_EVALUATED` | None | Uppercase | None |
| Managed bootstrap run | `pending`, `running`, `failed_recoverable`, `completed_candidate`, `manual_recovery_required`, etc. | None | Lowercase snake_case | None |
| Evidence verification | `VERIFIED`, `UNVERIFIED`, `PARTIALLY_VERIFIED`, `CONTRADICTED` | `LEGACY_UNCLASSIFIED` source | Uppercase | None |
| PR candidate type | `LOCAL_UNPUSHED_CANDIDATE`, `PROVIDER_PR`, `MANUAL_EXTERNAL_PR` | Synthetic local URLs (removed H12) | Enum in registration | None |
| Push status | `NOT_PUSHED`, `PUSHED`, `UNKNOWN` | Omitted `pushed: true` default | Explicit on register | Fixed H12 f9f5fcd |

## Fixes applied (S1)

No schema redesign performed. One documentation clarification:

- Grooming `open_questions[].status` uses lowercase for markdown compatibility while `grooming.questions[].status` uses canonical uppercase — both are valid; `sync_grooming_questions()` maintains consistency.

## Clear inconsistencies reviewed and accepted

| Item | Resolution |
|------|------------|
| ACP handoff approval `pending` vs workflow gate `pending` | Same lowercase enum — aligned |
| CI status `GREEN`/`RED`/`PENDING` vs merge readiness | Different domains — no merge |
| Phase 5 completion candidate status vs Phase 4 delivery_readiness | Documented authority split in architecture baseline |

## Normalization entry points

- `evidence_common.normalize_evidence_record()` — evidence records
- `grooming_model.normalize_open_question_status()` — grooming questions
- `framework_compatibility.py` — COMPATIBILITY_STATUSES, READINESS_STATUSES
- `closure_eligibility.py` — CLOSURE_OUTCOMES, CLOSURE_STATUSES
