# Support Runbook — Internal Production Candidate

Operator and support scenarios. **Manual YAML repair instructions: NO.**

## File location

This runbook: `ai-sdlc/governance/internal-production-candidate/support-runbook.md`

Related: [operator-command-inventory.md](operator-command-inventory.md), [operations-and-security.md](operations-and-security.md)

## Scenarios

### 1. Operator does not know next step
```bash
make ai-sdlc-stage-router ROOT=<workspace> ISSUE=<issue>
```
Read recommended command and prompt. Do not edit workflow YAML.

### 2. Merge readiness BLOCKED
```bash
make ai-sdlc-evaluate-merge-readiness ROOT=<workspace> ISSUE=<issue> FORMAT=json
```
Address each `blocking_reason`. Common fixes:
- `ai-sdlc-record-developer-attestation WRITE=1`
- `ai-sdlc-record-qa-execution WRITE=1`
- `ai-sdlc-record-verification-result WRITE=1`

### 3. Local candidate without PR URL
```bash
make ai-sdlc-register-pr ROOT=<workspace> ISSUE=<issue> \
  REPO_ID=<repo> SOURCE_BRANCH=<branch> TARGET_BRANCH=main \
  COMMIT_SHA=<sha> WRITE=1
```
Omit PR URL. Framework sets `LOCAL_UNPUSHED_CANDIDATE`. Then approve G-PR-MERGE with artifact evidence ref, not synthetic URL.

### 4. Closure blocked despite G-PR-MERGE approved
G-PR-MERGE ≠ merge. After human merge:
```bash
make ai-sdlc-close-merge ROOT=<workspace> ISSUE=<issue> WRITE=1 ...
make ai-sdlc-generate-closure-report ROOT=<workspace> ISSUE=<issue>
```

### 5. Duplicate workflow detected at intake
```bash
make ai-sdlc-intake-operator-status ROOT=<workspace> ISSUE=<issue>
make ai-sdlc-consolidate-duplicate-workflow ROOT=<workspace> ISSUE=<issue> WRITE=1
```

### 6. G-PLAN stale after spec change
Update artifacts via prompts, then:
```bash
make ai-sdlc-approve-gate ROOT=<workspace> ISSUE=<issue> GATE=G-PLAN WRITE=1 ...
```

### 7. Bootstrap failed recoverable
Inspect `bootstrap-executions/run-*/`, fix scaffold, resume:
```bash
make ai-sdlc-managed-execute ROOT=<workspace> ... WRITE=1
make ai-sdlc-managed-finalize ROOT=<workspace> RUN_ID=<id> WRITE=1
```

### 8. Setup/framework version drift
```bash
make ai-sdlc-existing-refresh-dry-run ROOT=<workspace>
make ai-sdlc-framework-setup-refresh ROOT=<workspace> WRITE=1
make ai-sdlc-validate-setup-readiness ROOT=<workspace>
```

### 9. Framework guard failure during product work
Uncommitted changes in `ai-sdlc/**` — commit or stash framework work. For framework development: `FRAMEWORK_DEV=1 make ai-sdlc-guard-framework-clean`.

### 10. Release validation failure
```bash
make ai-sdlc-release-candidate-test
```
Inspect `ai-sdlc/tests/results/release-candidate-summary.json` for failing suite; run individual target.

## Escalation

- P0: Closure verified without merge evidence → stop; run `assess_closure_eligibility` via closure report.
- P1: Data loss in transaction → preserve `lifecycle-events.jsonl`; report with run-id.
- P2: Doc/operator confusion → stage-router output + this runbook.

## Explicitly prohibited

- Editing `workflow-state.yaml` by hand to bypass gates
- Registering synthetic PR URLs
- Treating AI review as developer sign-off
- Treating completion candidate as delivery readiness
