# Test and Release Baseline

## Required release targets (16)

Decision: **16 required targets** for Internal Production Candidate validation — orchestration mega-suite plus 15 focused suites. Individual targets are preserved; `ai-sdlc-release-candidate-test` aggregates them.

| # | Target | Scope | Required |
|---|--------|-------|----------|
| 1 | `ai-sdlc-orchestration-test` | ~80 unit modules: orchestration, setup, delivery boundary fixtures | **YES** |
| 2 | `ai-sdlc-standard-process-test` | SOP-G-001..004 documentation guards | **YES** |
| 3 | `ai-sdlc-prompt-check` | Prompt catalog lint | **YES** |
| 4 | `ai-sdlc-prompt-boundary-test` | Prompt stage boundary policy | **YES** |
| 5 | `ai-sdlc-stage-eligibility-test` | Stage eligibility rules | **YES** |
| 6 | `ai-sdlc-flow-alignment-test` | Lifecycle flow alignment | **YES** |
| 7 | `ai-sdlc-before-pilot-consistency-test` | Before-pilot consistency BP-G-* | **YES** |
| 8 | `ai-sdlc-start-boundary-test` | /sdlc-start safety | **YES** |
| 9 | `ai-sdlc-schema-check` | JSON schema validation | **YES** |
| 10 | `ai-sdlc-conformance-protected` | OPA policy conformance (protected profile) | **YES** |
| 11 | `ai-sdlc-phase4-test` | Bootstrap completion, reconciliation, Phase 4 | **YES** |
| 12 | `ai-sdlc-phase5-2-test` | Managed local bootstrap execution | **YES** |
| 13 | `ai-sdlc-phase5-3-test` | Operational hardening, lease concurrency | **YES** |
| 14 | `ai-sdlc-phase5-4-e2e-test` | Disposable managed bootstrap E2E | **YES** |
| 15 | `ai-sdlc-phase5-final-closure-test` | Phase 5 final closure | **YES** |
| 16 | `ai-sdlc-greenfield-e2e-test` | Greenfield E2E + H11 integration | **YES** |

## Optional (not in release aggregate)

| Target | Scope |
|--------|-------|
| `ai-sdlc-phase4c-test` | Existing refresh (subset of orchestration) |
| `ai-sdlc-phase4e-test` | Architecture closure |
| `ai-sdlc-phase5-1-test` | Managed bootstrap preview |
| `ai-sdlc-phase5-1-closure-test` | Phase 5.1B closure |
| `ai-sdlc-greenfield-h11-test` | Included via greenfield-e2e |
| `ai-sdlc-overlay-check` | Example workspace smoke |
| `ai-sdlc-policy-check` | Policy lint (schema-check covers bindings) |
| `ai-sdlc-conformance` | Non-protected conformance |

## Release candidate target

```bash
make ai-sdlc-release-candidate-test
```

Implementation: `ai-sdlc/tools/conformance-runner/run_release_candidate_test.py`

**Includes:**
- All 16 required suites (sequential, fail-fast per suite with full output preserved)
- Post-checks: `ai-sdlc-guard-framework-clean`, framework compatibility unit tests
- Machine-readable: `ai-sdlc/tests/results/release-candidate-summary.json`, `release-candidate.junit.xml`

**Constraints:**
- No network
- No mutation of pilot/project state (tests use temp dirs)
- Non-zero exit on any suite failure
- Git cleanliness: warns if dirty (FRAMEWORK_DEV); does not fail aggregate

## Setup and upgrade validation scenarios

Covered by existing tests (see `test_setup_state_migration.py`, `test_framework_compatibility.py`, `test_validate_setup_readiness.py`):

| Scenario | Test coverage | Expected outcome |
|----------|---------------|------------------|
| New install | `test_validate_setup_readiness` minimal overlay | READY or guided BLOCKED |
| Compatible overlay | `test_framework_compatibility` CURRENT | Refresh optional |
| Migration required | `test_setup_state_migration` | Clear MIGRATION_REQUIRED; no silent destructive migration |
| Incompatible overlay | `test_framework_compatibility` INCOMPATIBLE | Blocks with explicit errors |
| Dry-run refresh | `test_phase4c_operational` dry-run | No mutations |
| Write refresh | `test_setup_state_migration` idempotent | Transactional write |
| Repeat refresh | migration idempotency tests | Idempotent |
| Legacy readable | legacy gate boolean fixtures | Migration path documented |
| Unsupported version | INCOMPATIBLE status | Blocks |
| Policy/prompt/schema drift | `test_framework_compatibility` POLICY_DRIFT | Detected, not silent |
| Version binding current | manifest + binding tests | Matches `framework-version.yaml` |

## Regression fixtures

| Fixture | Path | Boundary state |
|---------|------|----------------|
| Existing-project delivery boundary | `examples/disposable-fixtures/existing-project-delivery-boundary/` | PROSPECTIVE Tier 2, merge READY, LOCAL_UNPUSHED, G-PR-MERGE approved, CLOSURE_BLOCKED |
| Greenfield delivery boundary | `examples/disposable-fixtures/greenfield-delivery-boundary/` | Greenfield first feature, merge READY, local candidate, CLOSURE_BLOCKED |

Tests: `test_existing_project_boundary_fixture.py`, `test_greenfield_boundary_fixture.py` (included in orchestration via existing test discovery paths).
