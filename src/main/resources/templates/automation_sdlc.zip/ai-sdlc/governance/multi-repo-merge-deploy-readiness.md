# Multi-Repo Merge and Deploy Readiness

This document defines the rules and checklists for determining when a
cross-repo change is ready to merge and ready to deploy.

For single-repo changes, the standard gate model in `approval-gates.md` applies.
This document extends that model for changes spanning two or more repositories.

---

## Core Principles

1. **Each repo has its own PR.** A cross-repo change is not a single mega-PR.
   Each affected repository gets its own pull request. PRs link to a parent tracking issue.

2. **All PRs must be ready before any merges.** No partial merging. If one repo's
   PR is not ready, the entire change waits.

3. **Merges execute in deployment order.** The deployment sequence defined in
   `ai-sdlc/workspace-config.yaml` → `deployment_order` governs merge order.

4. **Actual merge and deploy are always manual.** AI agents and automation may
   produce readiness assessments; humans execute merges and deployment triggers.

5. **A cross-repo change is not complete until all repos are merged, deployed, and
   post-deploy smoke tests pass across all affected repos.**

---

## Merge Readiness Checklist

Use this checklist before merging any repo in a cross-repo change.

### Pre-merge: all affected repos

- [ ] Parent tracking issue exists and lists all affected repos and their PRs.
- [ ] Each affected repo has an open PR linked to the parent issue.
- [ ] All affected repo PRs are approved (per each repo's CODEOWNERS and tier approval rules).
- [ ] All affected repo CI pipelines are green.
- [ ] No unresolved must-fix review comments across any affected repo PR.
- [ ] Work tier is confirmed and all tier-required gates are passed (G-PLAN, G-SEC where applicable).

### Pre-merge: API contracts

- [ ] If any API contract changed: provider repo's PR includes the updated contract definition.
- [ ] If any API contract changed: all consumer repos' PRs are updated and reviewed together.
- [ ] Breaking contract changes are confirmed as Tier 3+ and security champion has reviewed.
- [ ] API backward compatibility validated: new backend must serve both old and new frontend
      if they deploy separately (expand, then migrate, then contract pattern).

### Pre-merge: database changes

- [ ] If database schema changes: migration is additive and non-destructive, or a destructive
      migration is confirmed as Tier 4 with rollback plan.
- [ ] Migration tested against a non-production environment with production-representative data.
- [ ] Rollback procedure documented and tested.
- [ ] Backend repo is compatible with both pre- and post-migration schema
      (for zero-downtime deploys).
- [ ] DBA or data owner review obtained if required by `workspace-config.yaml` approval rules.

### Pre-merge: shared library changes

- [ ] Shared library PR is approved and CI green.
- [ ] All consumer repos have updated their dependency to the new version.
- [ ] Consumer repo PRs are reviewed with the library change in context.
- [ ] No consumer is pinned to a version that will be broken by the library change.

### Pre-merge: infrastructure changes

- [ ] Infrastructure PR reviewed by SRE.
- [ ] `terraform plan` or equivalent output reviewed and attached to PR.
- [ ] No destructive resource changes without explicit approval.
- [ ] Rollback plan documented.

---

## Merge Order

Once all pre-merge checks pass, execute merges in this order:

| Step | Repo type | Condition to proceed to next step |
|------|-----------|----------------------------------|
| 1 | Infrastructure | IaC apply successful; endpoints healthy |
| 2 | Database / migrations | Migrations applied; rollback tested; DB healthy |
| 3 | Shared library | Package published; version available in registry |
| 4 | Backend / API | API health check passes; smoke tests green |
| 5 | Frontend / consumer | Frontend accessible; core flows validated |

Repos not involved in the change are skipped. Repos at the same stage with no
dependency between them may merge simultaneously.

**Do not skip steps or merge out of order.** If deployment order cannot be followed,
escalate to Tier 4 and require SRE co-sign on the revised plan.

---

## Deploy Readiness Checklist

Use this checklist before triggering any deployment in a cross-repo change.

### Pre-deploy: all affected repos

- [ ] All affected repo PRs are merged to their respective default/protected branches.
- [ ] Deployment order plan confirmed with SRE.
- [ ] Change ticket or equivalent record created and approved.
- [ ] Rollback plan documented for each affected repo.
- [ ] On-call or deployment window confirmed.

### Pre-deploy: observability

- [ ] Dashboards and alerts identified for each affected repo's deployment.
- [ ] Monitoring window defined (duration, who monitors).
- [ ] Alert thresholds reviewed and set appropriately for the change.

### Pre-deploy: smoke tests

- [ ] Post-deploy smoke tests defined for each affected repo.
- [ ] Smoke test execution method documented (manual steps, automated script, or both).
- [ ] Smoke test pass criteria defined.

### Pre-deploy: rollback triggers

- [ ] Rollback trigger criteria defined: what observable condition initiates rollback.
- [ ] Rollback responsible owner named for each affected repo.
- [ ] Maximum acceptable time-to-rollback defined.

---

## Deploy Execution Order

Execute deployments in the same order as merges (see Merge Order above).

After each stage:
1. Verify the deployment is healthy (health check, smoke test).
2. Confirm no increase in error rate or latency in dashboards.
3. Only proceed to the next stage after the current stage is confirmed healthy.

If a stage fails:
1. Do not proceed to the next stage.
2. Assess whether rollback is needed for the current stage.
3. Notify the on-call owner and SRE.
4. Document the failure before any remediation action.

---

## Post-Deploy Verification

After all repos are deployed:

- [ ] End-to-end smoke test across the full system (not just individual repos).
- [ ] Core user flows validated in the production environment.
- [ ] Error rates and latency normal for all affected repos.
- [ ] Feature flags adjusted if applicable.
- [ ] Parent tracking issue updated with deploy confirmation and verification evidence.
- [ ] Any outstanding observability or documentation follow-ups filed as issues.

---

## Database-Specific Rules

Database changes require stricter sequencing because they are the hardest to roll back.

### Expand-migrate-contract pattern

For zero-downtime schema changes:

1. **Expand:** deploy a migration that adds new columns or tables without removing old ones.
   Backend serves both old and new schema. Frontend unchanged.
2. **Migrate:** deploy backend update that writes to new schema. Read from both.
3. **Contract:** after all consumers are updated, remove old columns in a follow-up migration.

Each step is a separate deployment. Each step is a separate Tier 3 change unless the
full migration is classified as Tier 4.

### Destructive migration rules

A destructive migration (drop table, drop column, truncate, irreversible data transform) is **Tier 4** and requires:

- Written rollback procedure (not just a plan — a tested procedure).
- DBA or data owner sign-off.
- SRE co-sign.
- Staged rollout in staging before production.
- Backup verified immediately before execution.
- Deployment window with reduced traffic or maintenance mode if possible.

### Migration ownership

The repo that owns the database schema owns migration execution.
See `workspace-config.yaml` → `database_ownership` for repo-to-database mapping.

---

## API Contract-Specific Rules

### Backward compatibility rule

Backend API changes must be backward-compatible with the current production frontend
for the duration of the rolling deploy. Deploy the new backend first with both old
and new API versions supported, then deploy the frontend, then optionally deprecate
the old API version.

### Breaking change escalation

Any API contract change that removes or renames a field, changes a response type,
or removes an endpoint is a **breaking change** and is Tier 3 minimum. Steps required:

1. Create a versioned new endpoint or field before removing the old one.
2. Update all known consumers in the same change set.
3. Get security champion review if the contract carries auth tokens or PII.
4. Document the deprecation timeline for the old version.

### Contract verification

Before merging backend changes that modify API contracts:
- Run contract tests against all known consumers if contract testing is configured.
- If no contract tests exist, flag as a RECOMMENDED gap and perform manual consumer review.

---

## AI Agent Role in Readiness Assessment

AI agents and automation tools may:

- Evaluate and report merge readiness checklist status.
- Identify which repos are affected by a proposed change.
- Verify API contract compatibility analysis.
- Draft deployment order plans.
- Generate post-deploy smoke test scripts.
- Surface missing checklist items.

AI agents and automation tools must **not**:

- Trigger or approve merges to protected branches.
- Trigger or approve production deployments.
- Execute database migrations.
- Execute infrastructure apply commands.
- Override any approval gate without documented human exception.

See `governance/human-in-the-loop-policy.md` for the authoritative human-in-the-loop boundary.

---

## Audit Events for Cross-Repo Changes

| Event | Audit ID |
|-------|---------|
| Cross-repo change parent issue created | `AUD-EVT-CROSSREPO-ISSUE-001` |
| All affected repo PRs approved | `AUD-EVT-CROSSREPO-MERGE-READY-001` |
| First merge in sequence executed | `AUD-EVT-CROSSREPO-MERGE-START-001` |
| All merges complete | `AUD-EVT-CROSSREPO-MERGE-COMPLETE-001` |
| Deployment started for a repo | `AUD-EVT-CROSSREPO-DEPLOY-START-001` |
| All repos deployed and verified | `AUD-EVT-CROSSREPO-DEPLOY-COMPLETE-001` |
| Rollback triggered | `AUD-EVT-CROSSREPO-ROLLBACK-001` |

---

## References

- Work tier cross-repo rules: `ai-sdlc/work-tiers.md` → Cross-Repo Tier Classification
- Workspace configuration: `ai-sdlc/workspace-config.yaml`
- Workspace context: `ai-sdlc/workspace-context.md`
- Single-repo approval gates: `ai-sdlc/governance/approval-gates.md`
- Human-in-the-loop policy: `ai-sdlc/governance/human-in-the-loop-policy.md`
- Gate registry: `ai-sdlc/registry/gate-registry.yaml`
- Event registry: `ai-sdlc/registry/event-registry.yaml`
