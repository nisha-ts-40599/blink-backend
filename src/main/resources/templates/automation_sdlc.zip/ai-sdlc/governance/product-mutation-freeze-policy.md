# Product Mutation Freeze Policy

Workspace operators may declare a voluntary product write freeze without
framework code changes.

## Canonical overlay file

`.cursor/ai-sdlc/governance/product-freeze.yaml`

## Behavior

When `status: active`, the product mutation guard denies agent and CLI writes
under `quarantine_paths` even if implementation authorization would otherwise
pass.

## Evidence preservation

Use `make ai-sdlc-snapshot-workflow-evidence ISSUE=<id> WRITE=1` before
remediation. Snapshots are stored under
`.cursor/ai-sdlc/audit/snapshots/<snapshot-id>/`.

## Lift freeze

Set `status: inactive` or remove the file after formal resolution. Record the
decision in lifecycle events or change ticket evidence.
