# Prompt Stage-Boundary Policy

**Status:** Active
**Applies to:** All AI-SDLC prompt files under `ai-sdlc/prompts/`
**Extends:** `ai-sdlc/governance/ai-instruction-governance.md`, `ai-sdlc/governance/human-in-the-loop-policy.md`

---

## Core Principle

```text
The user request defines the desired outcome.
The active workflow state defines the permitted responsibility.
Imperative wording must not change the active stage.
```

A user input such as "Fix this bug", "Implement this feature", or "Deploy this now"
expresses the **desired outcome**. It does not authorize the active prompt to skip
grooming, planning, approval, implementation, QA, PR, or release stages.

The **workflow state** — artifacts present, gates approved, readiness validated,
work tier, and stage-router position — defines what a prompt is permitted to do.

---

## Universal Stage-Boundary Rules

### 1. Active workflow state is authoritative

Every prompt must consult the current workflow-state before performing any action.
The workflow state is the ground truth for the current stage, artifact completeness,
gate approvals, and readiness levels.

```bash
make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>
make ai-sdlc-validate-artifacts ROOT=<root> ISSUE=<issue>
```

### 2. Stage-router evidence determines eligibility

A prompt is eligible for its stage only when the stage-router confirms the stage is
active and required entry evidence is present. A prompt must not infer eligibility
from the content of the user request alone.

### 3. Imperative language never grants stage authorization

Action-oriented verbs (`fix`, `implement`, `deploy`, `merge`, `update`, `migrate`,
`refactor`, `create`, `remove`, `release`) describe the user's goal. They do not:

- select the active workflow stage;
- authorize skipping a required gate;
- imply that prior-stage evidence exists;
- grant permission to produce downstream artifacts;
- enable a prompt to approve its own output.

**Required interpretation:** capture the verb as the requested outcome; perform
only the work this prompt is authorized to perform in the active stage.

### 4. Each prompt owns one primary responsibility

Every operational prompt is assigned exactly one primary SDLC responsibility:
the work it is designed and authorized to perform. It must not silently perform
work belonging to a different stage.

### 5. Prompts may read prior-stage artifacts but cannot silently rewrite them

A prompt may read artifacts produced by earlier stages to inform its own output.
It must not overwrite those artifacts except through an explicit revision route
(e.g., `grooming-revision` for the requirement document, `fix-review-comments`
for review-addressed changes).

### 6. Prompts cannot create downstream evidence

A prompt may not produce artifacts that belong to a later stage. Examples:

- `clarify-requirement` may not produce implementation evidence or test results.
- `technical-plan` may not produce QA evidence or merge records.
- `pr-review` may not produce QA validation results.
- `qa-validation` may not produce implementation commits.

### 7. Prompts cannot approve their own work

No prompt may approve a gate that validates its own output. Gate approval is
always human-executed. Supporting prompts may prepare a readiness summary for
human review but must not issue the approval record.

```text
AI → prepare readiness summary
Human → execute: make ai-sdlc-approve-gate GATE=<gate> DECISION=approved WRITE=1
```

### 8. Prompts stop at human gates

When the workflow reaches a required human gate, the active prompt:

1. produces the gate readiness summary;
2. clearly names the gate and the human approval command;
3. stops;
4. does not continue into the next stage.

Required human gates include (but are not limited to):
`G-GROOM`, `G-BOOTSTRAP`, `G-BOOTSTRAP-EXEC`, `G-PLAN`, `G-SEC`, `G-QA`,
`G-PR-MERGE`, `G-DEPLOY`, `G-CUTOVER`, `G-ROLLBACK`, `G-PROD-MIGRATION`,
`G-POST-MIGRATION`.

See `ai-sdlc/governance/approval-gates.md` for the complete gate register.

### 9. Prompts return control to the router after completion

After producing the current-stage artifact, every operational prompt must:

1. emit a structured handoff (stage result summary);
2. direct the developer to run the stage router;
3. stop.

```bash
make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>
```

The stage-router is the sole authority for recommending the next eligible action.

### 10. Downstream mutations require runtime eligibility, not prompt wording

Write operations that mutate workflow state, implementation, or environment
(e.g., `make ai-sdlc-approve-gate WRITE=1`, `make ai-sdlc-close-merge WRITE=1`,
bootstrap execution) must be validated against current workflow state before they
are permitted. The text of the user request does not constitute authorization.

---

## Prompt Type Definitions

| Type | Description | Stage authorization |
|------|-------------|-------------------|
| `single_stage_operational` | Performs one primary SDLC responsibility | The assigned stage only |
| `supporting_artifact_prompt` | Produces a supporting artifact consumed by the invoking stage | No independent stage authority |
| `read_only_analysis` | Reads and reports; produces no write mutations | No stage authority |
| `gate_capture` | Prepares gate evidence for human approval | Prepares only; does not approve |
| `approved_multi_stage_orchestrator` | Coordinates setup lifecycle across phases | Setup lifecycle only; must not collapse grooming and implementation |
| `router` | Determines next action from workflow state | Read-only routing recommendation |

---

## Stage Boundary Section Requirement

Every prompt file under `ai-sdlc/prompts/` must include a `## Stage Boundary` section
that declares:

- active stage (or `ALL` for router/support prompts);
- prompt type;
- primary responsibility;
- allowed operations;
- prohibited downstream work;
- completion behaviour;
- handoff mechanism.

The section must be present, parseable, and testable by `make ai-sdlc-prompt-boundary-test`.

---

## Action-Oriented Language Interpretation Rule

When a user message contains imperative action verbs, every prompt must interpret
it as follows:

```text
Verb received: <fix | implement | deploy | merge | ...>
Interpretation: this describes the desired outcome.
Current stage: <from workflow state>
Permitted action: <what this prompt is authorized to produce>
Next: capture the intent, produce the authorized artifact, hand off to the router.
```

The prompt must NOT:
- perform work belonging to a later stage;
- assume that stating the verb means prior stages are complete;
- treat the urgency of the request as authorization to bypass gates.

---

## Structured Handoff Requirement

Every operational prompt must produce a handoff at completion:

```text
Stage result:
  current_stage:       <stage name>
  responsibility:      <what was completed>
  status:              complete | blocked | needs_revision | needs_human_approval
  produced_artifacts:  [list]
  blocking_findings:   [list or none]
  gate_status:         <gate name> = pending_human_approval | not_required
  next_command:        make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>
  stop:                true
```

---

## Relationship to Existing Governance

| Policy | Relationship |
|--------|-------------|
| `ai-instruction-governance.md` | This policy extends and operationalizes Section 3 (Agent Scope Constraints) |
| `human-in-the-loop-policy.md` | This policy enforces the gate-stop rule at the prompt level |
| `approval-gates.md` | Gate register; referenced for which gates are human-only |
| `enterprise-engineering-guardrails.md` | Implementation scope guardrails; complement to this policy |
| `framework-protection-rule.md` | Defines when framework files may be modified; orthogonal to this policy |
| `risk-rules.md` | Defines tier requirements that determine gate applicability |

---

## Enforcement

- **Structural:** `make ai-sdlc-prompt-boundary-test` validates that every prompt declares its stage boundary.
- **Prompt-level:** `## Stage Boundary` section in each prompt instructs the AI agent directly.
- **Runtime:** workflow-state tools (`validate-artifacts`, `stage-router`, `approve-gate`) enforce state before mutations.
- **Prompt check:** `make ai-sdlc-prompt-check` (existing) validates placeholder and structural compliance.

Gaps between prompt-level and runtime enforcement are recorded in
`docs/operating-model/prompt-boundary-gap-register.md`.
