# Public Reference and Data Safety

These rules apply to **all AI-SDLC phases**: requirement grooming, specification,
impact analysis, planning, implementation, testing, review, documentation, and release.

They complement `enterprise-engineering-guardrails.md` and `human-in-the-loop-policy.md`.

---

## 1. Allowed uses of public references

Public sources may inform **patterns and standards only**:

- High-level product or workflow patterns (not exact UX copy or layouts)
- Public standards (HTTP, OAuth, WCAG, ISO references, etc.)
- Open-source architecture patterns (summarized, not copied)
- Public API conventions and compatibility expectations
- UX and accessibility expectations at a guideline level
- Public security best practices (OWASP categories, CWE classes, etc.)

Public references are **advisory**. Client-specific expectations must come from the
client, product owner, SME, Jira, approved internal docs, or sanitized stakeholder input.

---

## 2. Prohibited uses of public references

Do **not** use public sources to:

- Copy proprietary competitor content, marketing text, or screen copy
- Reproduce copyrighted UI text, visual designs, or proprietary workflows
- Copy non-permissive source code into project artifacts
- Infer or expose private customer data
- Scrape, store, or summarize restricted or paywalled data without authorization
- Include trade secrets, confidential requirements, or internal-only URLs in artifacts

---

## 3. Open-source references

- Use only publicly accessible repositories and documentation
- Prefer permissive or clearly compatible licenses
- Cite repository or source name in notes; link to be verified by a human
- **Summarize patterns** — do not paste implementation code unless license and
  attribution have been reviewed by a human
- Do not assume an open-source pattern fits production constraints without review

---

## 4. Competitor and market references

- Use only public pages, public docs, public demos, or publicly observable behavior
- Summarize **patterns**, not exact content, branding, visuals, or proprietary flows
- Do not replicate protected branding, text, visuals, or workflows
- Market research findings must not be invented — use search instructions or
  placeholders until a human provides verified sources

---

## 5. Customer, client, and production data

- Do not expose customer names, personal data, credentials, tokens, internal URLs,
  private tickets, private logs, or unsanitized screenshots in prompts or artifacts
- Anonymize examples (`User A`, `Tenant-123`, `example.com`)
- Avoid pasting production data into prompts, requirement docs, or test fixtures
- Sanitize stack traces and log excerpts before use as prompt input

---

## 6. Requirement grooming specifics

- Public references inform clarifying questions and pattern notes only
- Assumptions derived from public data must be labeled **assumption**
- Repo inspection is **read-only** via approved Filesystem MCP or local review —
  no code changes during grooming
- Do not claim root cause for bugs without code or log evidence
- Groomed requirements must separate: facts, assumptions, open questions, and
  advisory public-reference notes

---

## 7. Rules across all SDLC phases

| Rule | Applies to |
|------|------------|
| Do not generate code from proprietary or unverified references | implement-step, generate-tests |
| Do not include secret values in artifacts | all phases |
| Do not expose private repo contents outside approved tools | all phases |
| Do not auto-update Jira, GitHub, Confluence, or production systems | all phases |
| Human review required for architecture, security, merge, and deploy decisions | planning, review, release |
| Public-reference notes must be high-level summaries with source names to verify | clarify, spec, plan, docs |

---

## 8. Prompt and artifact compliance

When a prompt includes the data-safety rule, agents must:

1. Follow this document and `enterprise-engineering-guardrails.md`
2. Mark unsupported claims as assumptions or open questions
3. Refuse to fabricate competitor analysis, customer quotes, or production metrics
4. Flag privacy, copyright, or licensing concerns in the **Privacy/copyright review**
   section of groomed requirements

---

## References

- Engineering guardrails: `ai-sdlc/governance/enterprise-engineering-guardrails.md`
- Human-in-the-loop policy: `ai-sdlc/governance/human-in-the-loop-policy.md`
- Requirement template: `ai-sdlc/templates/requirement-template.md`
- Grooming prompt: `ai-sdlc/prompts/clarify-requirement.prompt.md`
