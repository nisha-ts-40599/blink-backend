# Risk Rules

Risk rules **automatically elevate** scrutiny, tier, or required gates when patterns match. They complement discretionary classification in `work-tiers.md`.

## Elevation Triggers

Match any → treat as **minimum Tier 3** unless documented exception approved by security and engineering leadership.

| Rule ID | Pattern | Min Tier | Required Gate IDs | Rationale |
|---------|---------|----------|-------------------|-----------|
| R-AUTH-001 | Authentication/session/token semantics change | 3 | G-PLAN, G-SEC | Account takeover blast radius |
| R-AUTHZ-001 | Authorization policy broadening | 3 | G-PLAN, G-SEC | Privilege escalation |
| R-CRYPTO-001 | Cryptographic algorithm/key/TLS change | 4 | G-PLAN, G-SEC, G-PR-MERGE | Integrity/confidentiality failure risk |
| R-DB-001 | Additive schema/index change | 2 | G-PLAN | Data model risk limited |
| R-DB-002 | Destructive or wide schema/data migration | 4 | G-PLAN, G-SEC, G-REL-PROD | Data loss/lock risk |
| R-SHARED-001 | Shared library used by multiple services changed | 3 | G-PLAN | Cross-service contract risk |
| R-API-001 | Public API breaking or coordinated migration | 3 | G-PLAN, G-PR-MERGE | Consumer breakage risk |
| R-INFRA-001 | Production infra/IAM/network topology change | 4 | G-PLAN, G-SEC, G-REL-PROD | Platform blast radius |
| R-MULTI-001 | Multi-service coordinated release | 3 | G-PLAN | Orchestration failure risk |
| R-COMP-001 | Compliance/security control posture change | 4 | G-PLAN, G-SEC, G-REL-PROD | Regulatory exposure |
| R-PRODDATA-001 | Sensitive production data write/transform | 3 | G-PLAN, G-SEC | Data correctness/privacy risk |
| R-EGRESS-001 | New external egress/dependency | 3 | G-PLAN, G-SEC | Supply-chain and exfiltration risk |
| R-FLAG-001 | Global feature-flag default change | 3 | G-PLAN, G-PR-MERGE | Wide blast radius |

## Automatic Actions on Match

1. **Orchestrator** annotates issue with matched rule IDs.
2. **Security Agent** is added to review path.
3. **G-SEC** and **G-PLAN** gates apply per `approval-gates.md`.
4. CI must include **dependency**, **secret**, and **SAST** stages if not already mandatory for the repository.
5. Classification artifact records `evaluated_rules`, `resulting_tier`, and `required_gate_ids`.

## Default Up-Tier Conditions

Up-tier to Tier 3 minimum when:

- Any Rule ID starting with `R-AUTH`, `R-SHARED`, `R-API`, `R-MULTI`, `R-EGRESS`, or `R-PRODDATA` matches.
- Rollback procedure is undefined.

Up-tier to Tier 4 when:

- Any Rule ID starting with `R-CRYPTO`, `R-INFRA`, `R-COMP`, or `R-DB-002` matches.
- Migration is irreversible or rollback cannot be proven.

## De-escalation

De-escalation below triggered minimum tier requires:

- Written rationale disproving applicability, **or**
- Architectural mitigation (for example feature fully isolated behind safe default-off flag with proven rollback).

Recorded on the issue with approver identities.

## Conflict Resolution

1. Highest severity matched rule determines minimum tier.
2. Rule conflicts are resolved by Engineering Lead + Security Champion.
3. Conflict resolution must produce audit event `AUD-EVT-RISK-CONFLICT-RESOLVED`.

## Mandatory Human Escalation

Escalate immediately when:

- Rule is Tier 4 and approvals are pending over SLA.
- Security and engineering evaluations disagree on triggered rule set.
- Break-glass is requested to bypass a required gate.

Escalations must include `ESC-RISK-001` (classification conflict) or `ESC-RISK-002` (approval timeout) identifiers.

## Risk Register Linkage

For Tier 4, maintain explicit linkage between issue, threat model delta, and rollback drill record in the release artifact store.
