# AI-SDLC v4 Threat Model — Human Review (Phase 5f)

Framework version: **4.0.0**
Release channel: **stable**
Status: **stable release (Phase 5i certified); not a production-main merge authorization**

Canonical machine-readable source: [`../threat-model.yaml`](../threat-model.yaml)

## Scope

| In scope | Out of scope |
|----------|--------------|
| Framework orchestration and governance tooling | Product application repositories |
| Workspace overlay evidence (`.cursor/ai-sdlc`) | MCP credential storage in operator environments |
| Managed bootstrap adapters | OS-level network sandboxing (accepted limitation) |
| CI tier enforcement and supply-chain verification | Manual IDE edits outside Cursor hooks |

## Preserved authorities

Mutation guard, MCP permission policy, role/gate/SoD/waiver/authorization, guided handoff and execution-plan enforcement, journey matrix bounded execution, release integrity verification, workspace migration/rollback, lock/recovery authorities, and local audit evidence remain authoritative. Security controls may block unsafe behavior but must not bypass these authorities.

## Threat catalog

### T-PATH-001 — Path traversal

| Field | Value |
|-------|-------|
| Asset | Workspace overlay and product boundary paths |
| Actor | Malicious or misconfigured operator input |
| Attack path | Relative `..` segments escape allowed roots |
| Existing controls | `path_security.validate_workspace_relative_path` |
| Phase 5f action | Orchestration path helper + temp-path integration |
| Evidence / test | `test_path_security_orchestration.py` |
| Residual risk | Sibling/external repo roots lack symlink hardening |
| Owner | platform_owner |
| Review cadence | each RC |
| Status | mitigated |

### T-PATH-002 — Symlink escape

| Field | Value |
|-------|-------|
| Asset | Cache/temp paths under workspace overlay |
| Actor | Local attacker with workspace write access |
| Attack path | Symlink component redirects reads/writes |
| Existing controls | Bootstrap `path_security`; orchestration `path_security` (5f) |
| Phase 5f action | Fail-closed symlink rejection in `sdlc_temp_paths` |
| Evidence / test | `test_path_security_orchestration.py` |
| Residual risk | Orchestration git helpers still use raw subprocess |
| Owner | platform_owner |
| Review cadence | each RC |
| Status | mitigated |

### T-CMD-001 — Command injection

| Field | Value |
|-------|-------|
| Asset | `/sdlc-run` bounded execution |
| Actor | Operator-supplied action parameters |
| Attack path | Shell metacharacters in injection markers |
| Existing controls | `sdlc_run_execution_policy` |
| Phase 5f action | Security regression suite in Fast tier |
| Evidence / test | `test_sdlc_run_execution_security.py` |
| Residual risk | None known in bounded path |
| Owner | platform_owner |
| Review cadence | each RC |
| Status | mitigated |

### T-SEC-001 — Secret exposure in reports

| Field | Value |
|-------|-------|
| Asset | Audit exports and operational reports |
| Actor | Operator or automated export |
| Attack path | Tokens/credential URLs emitted in JSON/CSV |
| Existing controls | `audit_redaction` canonical helper |
| Phase 5f action | Included in security regression + Release tier |
| Evidence / test | `test_audit_redaction.py`, `test_security_regression.py` |
| Residual risk | argv/persistence redaction not fully unified |
| Owner | platform_owner |
| Review cadence | each RC |
| Status | mitigated |

### T-MUT-001 — Unauthorized product mutation

| Field | Value |
|-------|-------|
| Asset | Product source repositories |
| Actor | Ungoverned write path |
| Attack path | Write without authorization/override |
| Existing controls | Product mutation guard + mutation audit |
| Phase 5f action | Integrity checksum coverage for guard modules |
| Evidence / test | `test_product_mutation_guard.py`, integrity verify |
| Residual risk | Manual IDE edits outside hooks |
| Owner | platform_owner |
| Review cadence | each RC |
| Status | mitigated |

### T-SUP-001 — Supply-chain tampering

| Field | Value |
|-------|-------|
| Asset | Conformance runner Python dependencies |
| Actor | Compromised package index or lock drift |
| Attack path | Unpinned or mismatched direct dependency versions |
| Existing controls | `requirements.lock`, `verify_supply_chain.py`, `pip-audit` |
| Phase 5f action | Release tier dependency audit + lock verification |
| Evidence / test | `test_security_regression.py`, `make ai-sdlc-audit` |
| Residual risk | **Transitive dependency hashes not pinned in Phase 5f** |
| Owner | platform_owner |
| Review cadence | each RC |
| Status | partially_mitigated |

### T-CI-001 — CI policy drift

| Field | Value |
|-------|-------|
| Asset | Enforcement tier contract |
| Actor | Maintainer editing CI YAML |
| Attack path | Policy encoded in platform YAML instead of Make tiers |
| Existing controls | `tier-manifest.yaml`, `run_tier_test.py`, adapters |
| Phase 5f action | All adapters invoke canonical Make tier targets only |
| Evidence / test | `test_tier_manifest.py` |
| Residual risk | Adopter repos may still customize templates |
| Owner | platform_owner |
| Review cadence | each RC |
| Status | mitigated |

## CI tier mapping

| Tier | Make target | Typical trigger |
|------|-------------|-----------------|
| Fast | `make ai-sdlc-fast-test` | Every pull request |
| Protected | `make ai-sdlc-protected-test` | PRs targeting protected branches |
| Release | `make ai-sdlc-release-test` | Pre-RC / pre-tag |
| Certification | `make ai-sdlc-certification-test` | Weekly / pre-pilot |

## Residual risks (honest)

1. Manual IDE edits outside Cursor hooks are not intercepted.
2. Container filesystem mutations without hook installation.
3. OS-level network egress from managed bootstrap subprocesses.
4. Transitive Python dependency hashes are not pinned (direct pins only).
5. Integrity bundle covers listed release-critical Python modules, not every tool file.

## Review evidence

- `ai-sdlc/ci/tier-manifest.yaml`
- `ai-sdlc/governance/threat-model.yaml`
- `ai-sdlc/release/checksums.sha256`
- `ai-sdlc/tests/results/tier-*-summary.json`
