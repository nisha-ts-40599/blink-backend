# AWS S3 — AI-SDLC Artifact Storage Setup Guide

**Purpose:** Store AI-SDLC artifacts (context bundles, prompt outputs, technical plans, impact analyses, release readiness reports, pilot metrics) in a shared, versioned, access-controlled S3 bucket. This is not source code storage — it is artifact storage for the AI-assisted delivery pipeline.

**Last updated:** 2026-06-18  
**Priority:** P1 — configure after core pilot (Filesystem + GitHub + ADO) is validated.

> **Security policy:** `ai-sdlc/mcp/mcp-security-guidelines.md` — S3 section  
> **Validation checklist:** `ai-sdlc/adoption/mcp-validation-checklist.md` — AWS S3 section  
> **Env vars:** `ai-sdlc/mcp/mcp-env.example` — AWS section

---

## What goes in S3

| Artifact type | S3 prefix path | Example file |
|---------------|---------------|--------------|
| Workflow state snapshots | `projects/{project-key}/workflow-state/` | `TS-PILOT-001-workflow-state-2026-06-17.yaml` |
| Context bundles | `projects/{project-key}/context-bundles/` | `TS-PILOT-001-context-bundle.json` |
| Prompt outputs | `projects/{project-key}/prompt-outputs/` | `TS-PILOT-001-clarify-requirement-output.md` |
| Technical plans | `projects/{project-key}/technical-plans/` | `TS-PILOT-001-technical-plan.md` |
| Impact analyses | `projects/{project-key}/impact-analysis/` | `TS-PILOT-001-impact-analysis.md` |
| PR review reports | `projects/{project-key}/pr-reviews/` | `TS-PILOT-001-pr-88-review.md` |
| Release readiness | `projects/{project-key}/release-readiness/` | `TS-PILOT-001-release-readiness.md` |
| Pilot metrics | `projects/{project-key}/pilot-metrics/` | `sprint-2026-06-pilot-metrics.json` |

## What does NOT go in S3

- Source code (that belongs in the git repository)
- Secrets, API tokens, credentials, private keys
- PHI / PII (patient records, personal data) **without an approved encryption, access control, and retention policy — not permitted during pilot**
- Database backups or production data exports
- Large binary files (images, videos, compiled binaries)

---

## Recommended bucket name and region

| Setting | Recommended value | Notes |
|---------|-----------------|-------|
| Bucket name | `talentserv-ai-sdlc-pilot-artifacts` | Globally unique; adjust org prefix if taken |
| AWS region | `eu-west-1` (Ireland) or nearest region | Match your team's primary AWS region |
| Versioning | Enabled | Allows recovery of overwritten artifacts |
| Public access | All blocked | Never expose AI-SDLC artifacts publicly |
| Default encryption | SSE-S3 (AES-256) or SSE-KMS | Mandatory — never store unencrypted |
| Object ownership | Bucket owner enforced | Prevents cross-account ACL issues |

---

## Recommended prefix structure

```
s3://talentserv-ai-sdlc-pilot-artifacts/
└── projects/
    └── {project-key}/               e.g. health-platform-api/
        ├── workflow-state/
        ├── context-bundles/
        ├── prompt-outputs/
        ├── technical-plans/
        ├── impact-analysis/
        ├── pr-reviews/
        ├── release-readiness/
        └── pilot-metrics/
```

Use `AI_SDLC_S3_PREFIX=projects/` as the root. Individual project keys are subdirectories. The IAM policy restricts access to this prefix only — no other bucket paths are accessible.

---

## IAM policy — least privilege

Create a dedicated IAM user (not a role for pilot simplicity) with the following inline policy. **Do not use the AWS root account. Do not use AdministratorAccess or any broad managed policy.**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AISDLCArtifactListBucket",
      "Effect": "Allow",
      "Action": ["s3:ListBucket"],
      "Resource": "arn:aws:s3:::talentserv-ai-sdlc-pilot-artifacts",
      "Condition": {
        "StringLike": {
          "s3:prefix": ["projects/*"]
        }
      }
    },
    {
      "Sid": "AISDLCArtifactReadWrite",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:GetObjectVersion"
      ],
      "Resource": "arn:aws:s3:::talentserv-ai-sdlc-pilot-artifacts/projects/*"
    }
  ]
}
```

**Excluded deliberately:**
- `s3:DeleteObject` — no delete permission during pilot
- `s3:DeleteBucket` — no bucket deletion
- `s3:GetBucketAcl` / `s3:PutBucketAcl` — no ACL management
- `s3:PutBucketPolicy` — no bucket policy changes
- Any IAM permissions

---

## Bucket configuration steps

```bash
# 1. Create the bucket
aws s3api create-bucket \
  --bucket talentserv-ai-sdlc-pilot-artifacts \
  --region eu-west-1 \
  --create-bucket-configuration LocationConstraint=eu-west-1

# 2. Block all public access
aws s3api put-public-access-block \
  --bucket talentserv-ai-sdlc-pilot-artifacts \
  --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

# 3. Enable versioning
aws s3api put-bucket-versioning \
  --bucket talentserv-ai-sdlc-pilot-artifacts \
  --versioning-configuration Status=Enabled

# 4. Enable server-side encryption (SSE-S3)
aws s3api put-bucket-encryption \
  --bucket talentserv-ai-sdlc-pilot-artifacts \
  --server-side-encryption-configuration '{
    "Rules": [{
      "ApplyServerSideEncryptionByDefault": {
        "SSEAlgorithm": "AES256"
      },
      "BucketKeyEnabled": true
    }]
  }'

# 5. Create the projects/ prefix (upload a placeholder README)
echo "AI-SDLC artifact storage — see ai-sdlc/mcp/aws-s3-artifact-storage-setup.md" | \
  aws s3 cp - s3://talentserv-ai-sdlc-pilot-artifacts/projects/README.txt
```

---

## Environment variable setup

Set these in your shell or `.env.mcp` (never committed):

```bash
export AWS_ACCESS_KEY_ID=YOUR_AWS_ACCESS_KEY_ID
export AWS_SECRET_ACCESS_KEY=YOUR_AWS_SECRET_ACCESS_KEY
export AWS_REGION=eu-west-1
export AI_SDLC_S3_BUCKET=talentserv-ai-sdlc-pilot-artifacts
export AI_SDLC_S3_PREFIX=projects/
```

Confirm env vars are set:

```bash
echo "Bucket: $AI_SDLC_S3_BUCKET  Region: $AWS_REGION  Prefix: $AI_SDLC_S3_PREFIX"
```

---

## AWS CLI validation commands

Run these to confirm S3 access is working correctly before using with AI-SDLC tools.

```bash
# Read validation: list objects under the allowed prefix
aws s3 ls s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX --region $AWS_REGION
# Expected: list of project directories or README.txt

# Read validation: list a specific project's artifacts
aws s3 ls s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX/health-platform-api/ --region $AWS_REGION

# Write validation: upload a test artifact to allowed prefix
echo "AI-SDLC write test $(date -u)" | \
  aws s3 cp - s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX/health-platform-api/pilot-metrics/write-test.txt
# Expected: upload: - to s3://...

# Verify the upload
aws s3 cp s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX/health-platform-api/pilot-metrics/write-test.txt -
# Expected: "AI-SDLC write test ..."

# Scope restriction test: attempt write OUTSIDE the allowed prefix
aws s3 cp /dev/null s3://$AI_SDLC_S3_BUCKET/not-projects/test.txt 2>&1
# Expected: An error occurred (AccessDenied) when calling the PutObject operation

# Delete restriction test: attempt to delete an object
aws s3 rm s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX/health-platform-api/pilot-metrics/write-test.txt 2>&1
# Expected: An error occurred (AccessDenied) when calling the DeleteObject operation
# If delete succeeds: add an explicit Deny for s3:DeleteObject to the IAM policy

# Verify versioning is enabled
aws s3api get-bucket-versioning --bucket $AI_SDLC_S3_BUCKET --region $AWS_REGION
# Expected: {"Status": "Enabled"}

# Verify encryption is enabled
aws s3api get-bucket-encryption --bucket $AI_SDLC_S3_BUCKET --region $AWS_REGION
# Expected: SSEAlgorithm: AES256

# Verify public access is blocked
aws s3api get-public-access-block --bucket $AI_SDLC_S3_BUCKET --region $AWS_REGION
# Expected: all four flags true
```

---

## Uploading AI-SDLC artifacts manually

Until an S3 MCP is configured for Cursor, artifacts are uploaded manually via AWS CLI:

```bash
# Upload a context bundle
aws s3 cp ai-sdlc/examples/context-bundles/TS-PILOT-001-context-bundle.json \
  s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX/health-platform-api/context-bundles/TS-PILOT-001-context-bundle.json

# Upload a technical plan (after generating via AI prompt)
aws s3 cp /tmp/TS-PILOT-001-technical-plan.md \
  s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX/health-platform-api/technical-plans/TS-PILOT-001-technical-plan.md

# Upload pilot metrics
aws s3 cp ai-sdlc/examples/prefill-inputs/TS-PILOT-001-validation-report.md \
  s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX/health-platform-api/pilot-metrics/TS-PILOT-001-validation-report.md

# List all artifacts for a project
aws s3 ls s3://$AI_SDLC_S3_BUCKET/$AI_SDLC_S3_PREFIX/health-platform-api/ --recursive --human-readable
```

---

## Using S3 artifacts via Cursor (future: when S3/AWS MCP is available)

When an AWS S3 MCP is configured for Cursor, these queries will allow reading artifacts directly in chat:

```
# Read a technical plan stored in S3:
Read the file at s3://talentserv-ai-sdlc-pilot-artifacts/projects/health-platform-api/technical-plans/TS-PILOT-001-technical-plan.md

# List artifacts for a work item:
List objects under s3://talentserv-ai-sdlc-pilot-artifacts/projects/health-platform-api/ for issue TS-PILOT-001

# Read pilot metrics:
Read s3://talentserv-ai-sdlc-pilot-artifacts/projects/health-platform-api/pilot-metrics/sprint-2026-06-pilot-metrics.json
```

Write-block safety test for S3 MCP (run when MCP is configured):
```
Delete any object in the bucket s3://talentserv-ai-sdlc-pilot-artifacts
```
Expected: error or refusal — IAM policy denies `s3:DeleteObject`.

```
Write to s3://talentserv-ai-sdlc-pilot-artifacts/not-projects/test.txt
```
Expected: error — IAM policy only allows writes under `projects/*`.

---

## Key security reminders for S3

1. Never use AWS root account credentials. Use a dedicated IAM user.
2. Never put PHI, PII, secrets, or credentials in the pilot bucket.
3. Always use versioning — it enables recovery of overwritten artifacts.
4. Always use encryption — SSE-S3 (AES-256) is the minimum.
5. Block all public access — AI-SDLC artifacts should never be publicly readable.
6. No delete permission during pilot — add an explicit IAM deny if needed.
7. Rotate the IAM access key after the pilot is complete.
8. Scope the IAM policy to `projects/*` only — no other paths.
9. Review the bucket's content before decommissioning — ensure no sensitive data was accidentally uploaded.

---

## After the pilot

When the pilot completes:

1. Rotate the IAM access key (`AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY`)
2. Review the bucket for any files that should not be there
3. Decide whether to graduate S3 to a production artifact store with proper lifecycle policies
4. If graduating: move to IAM role-based access (instance profile or OIDC) rather than long-lived keys
5. Consider enabling S3 Object Lock for immutable audit artifact retention
