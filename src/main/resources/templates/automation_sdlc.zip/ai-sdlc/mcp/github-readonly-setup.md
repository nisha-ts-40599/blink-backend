# GitHub Read-Only MCP Setup

Connecting Cursor to GitHub via the Model Context Protocol (MCP) eliminates the most common friction in AI-SDLC prompt usage: manually pasting repository context, issue bodies, and PR diffs into every chat.

With GitHub read MCP active, Cursor can:

- Read any file from the repository on demand
- Load issue context directly into `clarify-requirement.prompt.md`
- Read PR diffs directly into `pr-review.prompt.md`
- Check CI workflow run status for merge-readiness checks
- Traverse the repository structure for `impact-analysis.prompt.md` and `technical-plan.prompt.md`

**This integration is read-only. No write access is configured or needed.**

For the permission model and full security policy, see `ai-sdlc/mcp/mcp-permissions.md` and `ai-sdlc/mcp/mcp-security-guidelines.md`.

---

## Prerequisites

- [Node.js](https://nodejs.org/) installed (v18 or later recommended) — `node --version` to verify
- `npx` available in your PATH — `npx --version` to verify
- A GitHub account with access to the target repository

---

## Step 1 — Create a Fine-Grained GitHub PAT

**Fine-grained PATs are required for true read-only access.** Classic PATs cannot grant read-only `repo` scope — the `repo` scope always includes write access. Fine-grained PATs let you specify exact permissions per repository.

### Navigate to the PAT creation page

**GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**

### Required permissions

| Permission | Level | What it enables |
|------------|-------|----------------|
| **Metadata** | Read-only | Auto-granted — repo name, description, topics, visibility |
| **Contents** | Read-only | Read file contents, directory trees, commits, branches, tags |
| **Issues** | Read-only | List issues, read issue body, comments, labels, milestones |
| **Pull requests** | Read-only | Read PR diffs, review comments, check run status, PR files |
| **Actions** | Read-only | Read workflow run results, job logs, check run outcomes |

### Repository access

Select **Only select repositories** and add only the repos this token is used for. Never select **All repositories** unless managing a large workspace where repo-by-repo selection is impractical.

### Token expiration

Set to **90 days maximum**. Add a calendar reminder to rotate before expiry. Expired tokens cause silent MCP failures.

---

## Why fine-grained PAT, not classic PAT

| PAT type | Read-only possible? | Risk |
|----------|-------------------|------|
| Fine-grained | Yes — per-permission, per-repo control | Low when scoped correctly |
| Classic (`repo` scope) | No — `repo` includes full write to all private repos | High — grants push, settings, secrets access |
| Classic (`public_repo`) | Only for public repos, but still includes write | Medium |

**Never create a classic PAT with `repo` scope for AI tooling.** If you must use a classic PAT (e.g., GitHub Enterprise with no fine-grained PAT support), create a dedicated machine user account with minimal repository access and create the classic PAT on that account.

---

## Step 2 — Configure .cursor/mcp.json

`.cursor/mcp.json` is gitignored and must never be committed. It exists only on your local machine.

Copy `.cursor/mcp.example.json` to `.cursor/mcp.json`:

```bash
cp .cursor/mcp.example.json .cursor/mcp.json
```

Edit `.cursor/mcp.json` and replace the placeholder:

```json
{
  "mcpServers": {
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "github_pat_YOUR_ACTUAL_TOKEN_HERE"
      }
    }
  }
}
```

Token format by type:
- Fine-grained PAT: begins with `github_pat_`
- Classic PAT: begins with `ghp_`

**Restart Cursor after saving** `.cursor/mcp.json` for the MCP server to load.

---

## Step 3 — Verify the setup

Run these checks in order. Each confirms a different layer of the integration.

### Check 1 — Server is loading

Open Cursor → Settings (or the MCP panel). Confirm `github` appears in the list of active MCP servers with a connected/green indicator.

If the server shows as failed or missing:
- Confirm `node` and `npx` are in the PATH Cursor uses (may differ from your terminal PATH on macOS)
- Confirm `.cursor/mcp.json` is valid JSON (no trailing commas, no comment fields)
- Check the Cursor logs / Output panel for MCP startup errors

### Check 2 — Token is valid

In a Cursor chat:

```
Using the GitHub MCP tool, what is the default branch and description
of the [your-org]/[your-repo] repository?
```

Expected: the repo name and description are returned.
- **401 response**: token is invalid or expired — regenerate it
- **404 response**: token does not have access to this repo — check repository access in PAT settings
- **No MCP tool called**: MCP is not active — restart Cursor

### Check 3 — Read permissions are working

```
Using GitHub MCP, list the 5 most recently updated open issues
in [your-org]/[your-repo].
```

Expected: a list of issues with numbers, titles, labels, and dates — read directly from GitHub without manual paste.

### Check 4 — Write access is blocked (expected)

```
Using GitHub MCP, create a test issue titled "MCP write test"
in [your-org]/[your-repo].
```

Expected: a 403 Forbidden response or permission denied error. **This failure is correct.** It confirms the token's read-only scope is enforced by the GitHub API. The MCP server presents write tools to the model, but the token prevents execution.

---

## Example prompts that use GitHub MCP

Once verified, use these prompts in daily AI-SDLC workflow. Substitute your org and repo names.

### List open issues

```
Use GitHub MCP to list all open issues in [your-org]/[your-repo].
For each issue show: number, title, labels, created date, and assignee if set.
Sort by most recently updated first.
```

### Summarize recent pull requests

```
Use GitHub MCP to list the last 10 pull requests (open and closed)
in [your-org]/[your-repo].
For each PR show: number, title, state, author, target branch, and merge date
if merged. Highlight any that are open and have failing CI checks.
```

### Identify modules and repo structure

```
Use GitHub MCP to read the root directory of [your-org]/[your-repo],
then read each top-level directory to one level deep.
From this structure, identify the main functional modules and describe
what each one is responsible for.
```

### Identify architecture from source code

```
Use GitHub MCP to:
1. Read the README.md
2. Read [project-context.md path for your repo]
3. List all files in the governance directory if one exists
4. Read the main build or configuration file (Makefile, package.json, etc.)

Describe the overall architecture: main components, how they interact,
what the governance model looks like, and any notable patterns.
```

### Power a full AI-SDLC prompt without manual paste

```
Use GitHub MCP to read issue #[number] in [your-org]/[your-repo].
Also read [path-to-project-context.md] in the same repo.

Now act as a senior product engineer and run the clarify-requirement prompt:

You are a senior product engineer helping refine a requirement before
specification and estimation.

Fill {{REQUIREMENT}} from the issue body you just read.
Fill {{PROJECT_CONTEXT}} from the project-context.md you just read.

Produce:
- Restatement
- Questions for stakeholders
- Draft acceptance criteria
- Non-goals
- Risks / assumptions
```

This is the target daily usage pattern — the AI reads both files from GitHub, then runs the prompt. No manual paste.

---

## Multi-repo workspace setup

For a workspace spanning multiple repos, the same `.cursor/mcp.json` configuration works as long as the fine-grained PAT was created with access to all target repos.

When running cross-repo prompts (e.g., `clarify-requirement` for a change touching UI + backend + DB):

```
Use GitHub MCP to read:
- [org]/ui-repo: path/to/project-context.md
- [org]/api-service: path/to/project-context.md
- [org]/db-migrations: path/to/project-context.md

Also read the workspace-context.md from [org]/automation_sdlc or your workspace repo.

Then run the clarify-requirement prompt with the combined context.
```

---

## Security reminders

- `.cursor/mcp.json` is gitignored — it must never be committed
- The token value must never appear in source code, prompts, or commit messages
- Rotate the token every 90 days
- If you suspect a token was exposed, revoke it immediately in GitHub Settings and generate a new one
- The MCP server runs locally as an `npx` subprocess — it does not send your token to any third party; it uses the token to call the GitHub API directly
- Pin the `@modelcontextprotocol/server-github` package version once your team standardises on a specific version (see `mcp-security-guidelines.md` for supply chain guidance)

---

## Reference

- MCP permission model: `ai-sdlc/mcp/mcp-permissions.md`
- MCP security guidelines: `ai-sdlc/mcp/mcp-security-guidelines.md`
- MCP config template (write-capable, future): `ai-sdlc/mcp/mcp-config.template.yaml`
- Operator workflow: [`docs/operating-model/current-sdlc-flow.md`](../../docs/operating-model/current-sdlc-flow.md)
- Example config: `.cursor/mcp.example.json`
