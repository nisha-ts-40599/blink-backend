# MCP Configuration Notes

**Purpose:** Practical notes for setting up, validating, and troubleshooting each MCP server in the AI-SDLC pilot.

> **Template file:** `.cursor/mcp.example.json` — copy to `.cursor/mcp.json` (local only, never commit).  
> **Env vars:** `ai-sdlc/mcp/mcp-env.example` — copy to `.env.mcp` (never commit) or set in shell.  
> **Security policy:** `ai-sdlc/mcp/mcp-security-guidelines.md`  
> **Validation queries:** `ai-sdlc/adoption/mcp-validation-checklist.md`

---

## Local setup process

```bash
# 1. Copy the example config
cp .cursor/mcp.example.json .cursor/mcp.json

# 2. Set your tokens (option A: export in shell)
export GITHUB_PERSONAL_ACCESS_TOKEN="ghp_..."
export ADO_MCP_AUTH_TOKEN="..."

# 3. Or use a local .env.mcp file (never commit):
cp ai-sdlc/mcp/mcp-env.example .env.mcp
# Edit .env.mcp with real values
# Source it: source .env.mcp

# 4. Restart Cursor to pick up new MCP config

# 5. In Cursor chat, run validation queries from mcp-validation-checklist.md
#    ONE MCP AT A TIME — validate each before enabling the next
```

---

## P0 servers — configure now

### Filesystem
- No auth. Set `${workspaceFolder}` (Cursor fills this automatically).
- Test: `List the files and directories in the project root.`
- If this fails, confirm the workspace path is correct in Cursor settings.

### GitHub
- Fine-grained PAT at `https://github.com/settings/tokens?type=beta`.
- Required scopes: `Contents`, `Issues`, `Pull requests`, `Actions`, `Metadata` — all read-only.
- Set `GITHUB_PERSONAL_ACCESS_TOKEN` in shell or `.env.mcp`.
- Write-block test: `Create a new GitHub issue titled "MCP write safety test"` — must fail.

### Azure DevOps
- Personal access token at `https://dev.azure.com/{org}/_usersSettings/tokens`.
- Required scope: **Work Items (Read)** only — no write.
- Org value in config: `{your-ado-org}` — update to match your Azure DevOps organization.
- Set `ADO_MCP_AUTH_TOKEN` in shell.
- Write-block test: `Create an ADO work item titled "MCP write safety test"` — must fail.

---

## P1 servers — configure when ready

### Jira
- API token at `https://id.atlassian.com/manage-profile/security/api-tokens`.
- MCP package: `mcp-atlassian` (verify latest version before installing).
- Required: `ATLASSIAN_SITE_URL` (e.g., `https://yourorg.atlassian.net`), `ATLASSIAN_EMAIL`, `ATLASSIAN_API_TOKEN`.
- Tokens are per-user and have access to all Jira projects the user can see — scope carefully.
- Write-block test: `Create a Jira issue titled "MCP write safety test"` — must fail.

### Confluence
- Shares Atlassian credentials with Jira.
- MCP package: verify available package (e.g., `mcp-confluence`) before installing.
- Test: `Find the architecture overview page for the patient registration service.`
- Write-block test: `Create a Confluence page titled "MCP write safety test"` — must fail.

### Slack
- Create a Slack App at `https://api.slack.com/apps` with only read scopes:
  `channels:history`, `channels:read`, `search:read`, `users:read`.
- Do NOT grant `chat:write`.
- Set `SLACK_BOT_TOKEN` (starts with `xoxb-`) and `SLACK_TEAM_ID`.
- Write-block test: `Send a message to #general saying "MCP write safety test"` — must fail.
- **Important:** Slack context must be manually confirmed before pasting into any prompt.

---

## P2 servers — configure in second expansion

### Microsoft Teams / Outlook
- Azure AD app registration at `https://portal.azure.com`.
- Required Graph API permissions:
  - Teams: `ChannelMessage.Read.All` (read only)
  - Outlook: `Mail.Read` (read only, delegated)
- Do NOT grant `ChannelMessage.Send`, `Mail.Send`, or any write permissions.
- Set `MICROSOFT_TENANT_ID`, `MICROSOFT_CLIENT_ID`, `MICROSOFT_CLIENT_SECRET`.
- Write-block tests: try to send a message/email — must fail.

### MongoDB Atlas
- Create API key at `https://cloud.mongodb.com/` → Organization Access Manager → API Keys.
- Role: **Project Read Only** — never use Project Owner or Data API write role.
- Use a DEV or STAGING cluster connection string only. Do NOT connect production Atlas during pilot.
- Set `MONGODB_URI` (connection string) and `MONGODB_ATLAS_PROJECT_ID`.
- Write-block test: `Insert a document into the patients collection` — must fail.

### Docker Hub
- Personal access token at `https://hub.docker.com/settings/security`.
- Permissions: **Read-only** — no write, no delete.
- Set `DOCKERHUB_USERNAME` and `DOCKERHUB_TOKEN`.
- Write-block test: `Delete the latest tag from the API image` — must fail.

### Render
- API key at `https://dashboard.render.com/u/settings` → API Keys.
- Read-only key if Render offers scope selection — otherwise test write-block carefully.
- Do NOT trigger deploys or service restarts from MCP during pilot.
- Set `RENDER_API_KEY`.
- Write-block test: `Restart the API service on Render` — must fail.

### Vercel
- Token at `https://vercel.com/account/tokens`.
- Team tokens can be scoped to read-only — prefer that over personal tokens.
- Do NOT trigger deployments or change environment variables from MCP.
- Set `VERCEL_TOKEN`.
- Write-block test: `Trigger a new deployment for the health-api project on Vercel` — must fail.

---

## Common issues

| Issue | Fix |
|-------|-----|
| MCP server not appearing in Cursor | Restart Cursor after editing mcp.json |
| Token expired | Regenerate and update mcp.json — check rotation reminder |
| Write-block test succeeds | Token has too many permissions — revoke and regenerate with read-only scope |
| Jira/Confluence: `401 Unauthorized` | Check `ATLASSIAN_EMAIL` matches the account that owns the token |
| ADO: `No data returned` | Confirm work item ID belongs to the configured ADO org |
| MongoDB: connection refused | Confirm IP is allowlisted in Atlas Network Access |
| Slack: `missing_scope` | Add required read scopes to the Slack App and reinstall |
| MCP package install fails | Check node/npm version — most MCP packages require Node 18+ |

---

## Gitignore reminder

Confirm these are in your `.gitignore`:

```
.cursor/mcp.json
.env.mcp
*.env.mcp
```

Never commit real tokens. If you accidentally commit one, rotate it immediately.
