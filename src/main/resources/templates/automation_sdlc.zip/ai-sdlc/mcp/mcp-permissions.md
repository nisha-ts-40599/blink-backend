# MCP Permissions Model (Automation-Grade)

This document defines deterministic permission behavior for MCP-integrated orchestration. It complements `mcp-config.template.yaml` and must be enforced in MCP servers, orchestrators, and service account scopes.

## Core Enforcement Principles

1. **Least privilege by default:** Agents receive only the minimum required tool class for the active workflow step.
2. **Default deny:** Any tool not explicitly mapped to a class and agent profile is denied.
3. **Separation of duties:** Identities that author changes cannot independently approve restricted or destructive actions.
4. **Scoped credentials:** Credentials are server-scoped, environment-scoped, and time-bounded; no shared super-tokens.
5. **Non-repudiation:** Every write/restricted/destructive attempt is fully attributable and auditable.

## Permission Classes

### `read_tools`

- **Purpose:** Non-mutating inspection and evidence gathering.
- **Examples:** `read_repository`, `search_issues`, `read_pipeline_status`, `read_latest_scan`.
- **Approval requirements:** No human approval by default.
- **Logging requirements:** Standard event with actor, tool, target, correlation ID, timestamp, result.
- **Execution restrictions:** Read-only sessions, PII redaction in outputs where policy requires.
- **Escalation rules:** Repeated denied reads or policy anomalies escalate to Orchestrator.

### `write_tools`

- **Purpose:** Reversible scoped mutations in non-protected contexts.
- **Examples:** `create_issue`, `update_draft_page`, `open_pull_request`, `trigger_build_non_production`.
- **Approval requirements:** Ticket reference required; human approval required for Tier 3+ based on policy.
- **Logging requirements:** Elevated event with before/after hash or equivalent state transition.
- **Execution restrictions:** No protected-branch mutation; no production-target execution; token TTL and scope enforced.
- **Escalation rules:** Scope mismatch or policy failure creates exception work item and pauses workflow.

### `restricted_tools`

- **Purpose:** High-impact operations requiring explicit authorization.
- **Examples:** `merge_pull_request`, `approve_production_deployment`, `waive_finding_temporarily`.
- **Approval requirements:** Human approval token mandatory; dual approval for Tier 4 paths.
- **Logging requirements:** Critical event includes approvers, approval token ID, policy decision, and evidence links.
- **Execution restrictions:** Change window checks, runtime attestation, and session recording.
- **Escalation rules:** Missing or invalid approvals cause hard block and alert approver group.

### `destructive_tools`

- **Purpose:** Irreversible or high-blast-radius operations.
- **Examples:** `force_push`, `bulk_delete_issues`, `delete_release_artifact`, `delete_log_indexes`.
- **Approval requirements:** Break-glass only with incident ID, dual control, explicit justification.
- **Logging requirements:** Forensic event with incident ID, snapshot reference, command payload digest, and post-check outcome.
- **Execution restrictions:** Disabled by default; pre-snapshot and post-verification required; dry-run required if supported.
- **Escalation rules:** Any attempted invocation not in break-glass flow triggers immediate security + SRE notification.

## Approval Token Flow (Reference)

1. Orchestrator requests token from approval service with: `ticket_id`, `tool_scope`, `resource_scope`, `requested_by`.
2. Human approver validates context and issues signed token (`single_use=true`, short TTL).
3. MCP server verifies signature, audience, nonce, and scope before execution.
4. On success/failure, MCP emits audit event and invalidates token.

## Break-Glass Procedure

1. Open incident record and assign incident commander.
2. Capture pre-operation snapshot and rollback plan reference.
3. Obtain dual human approvals from distinct groups.
4. Mint break-glass token limited to exact tool/resource/time window.
5. Execute with live session recording.
6. Perform post-operation verification and attach evidence to incident.
7. Run post-incident review and revoke elevated scopes.

## Integration Mapping by Class (Condensed)

| Integration | read_tools | write_tools | restricted_tools | destructive_tools |
|------------|------------|-------------|------------------|-------------------|
| Git / source control | repository reads | branch/PR comments | merge/protection changes | history rewrite/force delete |
| Issue tracker | read/search | create/update/comment | terminal transitions without normal evidence path | bulk purge |
| Documentation | read/search/export | draft create/update | publish in controlled spaces | bulk delete spaces/pages |
| CI/CD | status/logs/artifacts | non-prod triggers/reruns | production approvals/pipeline mutation | artifact purge/prod cancellation |
| Security scanners | finding reads | annotations | waivers/policy modifications | finding history purge |
| Observability | query metrics/logs/traces | draft dashboard updates | alert/SLO policy changes | telemetry data deletion |
| Filesystem MCP | list/read/search | workspace-scoped writes | delete/chmod sensitive paths | write outside workspace / arbitrary delete |

## Agent Profile Baseline

| Agent | Max class by default |
|-------|-----------------------|
| Orchestrator | `restricted_tools` (never `destructive_tools`) |
| Requirement / Documentation / Issue | `write_tools` |
| Repo Analysis / Review / Security (analysis path) | `read_tools` + scoped `write_tools` annotations |
| Planning / Implementation / Test | `write_tools` |
| Release | `restricted_tools` (approval orchestration only) |
| Knowledge Update | `write_tools` |

`destructive_tools` are unavailable to standard agent profiles and require break-glass override.

## Audit Event Examples

```json
{
  "event_type": "mcp.tool.write",
  "class": "write_tools",
  "tool": "open_pull_request",
  "actor": "agent:implementation",
  "correlation_id": "ISSUE-1234",
  "ticket_id": "ISSUE-1234",
  "result": "success"
}
```

```json
{
  "event_type": "mcp.tool.restricted",
  "class": "restricted_tools",
  "tool": "merge_pull_request",
  "actor": "human:release_manager",
  "approval_token_id": "tok_abc123",
  "approver_ids": ["eng_lead_1"],
  "correlation_id": "PR-88",
  "result": "success"
}
```

```json
{
  "event_type": "mcp.tool.destructive",
  "class": "destructive_tools",
  "tool": "force_push",
  "actor": "human:incident_commander",
  "incident_id": "INC-9001",
  "dual_control": true,
  "snapshot_ref": "s3://.../preop.tar.gz",
  "result": "blocked"
}
```

## Machine-Readable References

- MCP authorization policy: `ai-sdlc/policies/mcp-permissions.rego`
- Policy registry: `ai-sdlc/registry/policy-registry.yaml`
- Escalation registry: `ai-sdlc/registry/escalation-registry.yaml`
- Conformance tests: `ai-sdlc/tests/`
