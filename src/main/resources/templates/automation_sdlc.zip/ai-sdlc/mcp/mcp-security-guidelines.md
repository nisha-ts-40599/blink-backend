# MCP Security Guidelines

**Last updated:** 2026-06-18  
**Scope:** AI-SDLC / DeliveryMind AI Pilot — all MCP servers (P0/P1/P2/P3)

> **Practical pilot checklist:** `ai-sdlc/adoption/mcp-validation-checklist.md`  
> **Config template:** `.cursor/mcp.example.json`  
> **Env vars:** `ai-sdlc/mcp/mcp-env.example`

---

## Pilot-level security rules (non-negotiable)

These rules apply to every MCP server during the pilot, without exception:

1. **Read-only during pilot.** No MCP may create, update, delete, or send anything during the pilot phase. Every token must be configured with the minimum read-only scope.
2. **Write-block test before use.** Every MCP must have its write-block safety test run and documented before it is used for real AI-SDLC work. See `mcp-validation-checklist.md`.
3. **Human gates are never auto-filled.** G-PLAN, G-SEC, G-PR-MERGE, and G-DEPLOY must never be populated from MCP data. They are always set via `update_workflow_state.py --add-approval` after a named human posts explicit approval.
4. **Messaging content must be manually confirmed.** Content read from Slack, Teams, or Outlook is supplementary only. It must be reviewed and confirmed by the developer before being used as any prompt input.
5. **No production data during early pilot.** MongoDB Atlas must use DEV/STAGING cluster only. Render/Vercel are for status reads only — no production deploy triggers.
6. **No shared tokens.** Each developer uses their own personal token. No team-wide or admin tokens.
7. **Rotate tokens every 90 days maximum.** Set calendar reminders at token creation time.
8. **Never commit secrets.** `.cursor/mcp.json` must be in `.gitignore`. Real tokens must never appear in any committed file.

---

## Per-MCP security requirements

### P0 — Filesystem

- No auth token required — workspace path only.
- Risk: Local file reads only; cannot exfiltrate data outside the workspace.
- Control: Confirm workspace path is scoped to the project directory only.

### P0 — GitHub

- Fine-grained PAT with **read-only** scopes: `Contents`, `Issues`, `Pull requests`, `Actions`, `Metadata`.
- Do NOT grant: `Administration`, `Secrets`, `Environments`, `Webhooks`, or any write scope.
- Token must be scoped to specific repos — not all repos.
- Expiry: 90 days maximum. No expiry-less tokens.
- Write-block test: `Create a new GitHub issue titled "MCP write safety test"` — must fail.
- If test succeeds: revoke token immediately; check PAT scopes carefully.

### P0 — Azure DevOps

- PAT scoped to: **Work Items (Read)**, **Project and Team (Read)** only.
- Do NOT grant write, build, release, or admin scopes.
- Expiry: 90 days maximum.
- Write-block test: `Create an ADO work item titled "MCP write safety test"` — must fail.
- If test succeeds: revoke token immediately.

### P1 — Jira

- Atlassian API token: read-only access to Jira projects.
- Tokens are per-user and inherit the user's project access — use a dedicated read-only service account if your Jira instance supports it.
- Do NOT use an Atlassian admin account token.
- Tokens do not expire automatically — set a manual rotation reminder.
- Write-block test: `Create a Jira issue titled "MCP write safety test"` — must fail.
- Data sensitivity: Jira issues may contain PHI/PII if your project uses Jira for clinical or patient-related work. Review data sensitivity before enabling.

### P1 — Confluence

- Shares Atlassian credentials with Jira.
- Confluence pages may contain architecture details, security notes, and technical specifications — treat as confidential.
- Write-block test: `Create a Confluence page titled "MCP write safety test"` — must fail.

### P1 — Slack

- Bot token with **read-only** scopes ONLY: `channels:history`, `channels:read`, `search:read`, `users:read`.
- Do NOT grant `chat:write`, `files:write`, or any write scope.
- Slack messages may contain sensitive business discussions. Review before use.
- Content must be manually confirmed before being used as a prompt input.
- Write-block test: `Send a message to any Slack channel saying "MCP write safety test"` — must fail.
- If test succeeds: revoke the bot token; rebuild with correct scopes.

### P2 — Microsoft Teams / Outlook

- Azure AD app registration. Use minimal Graph API permissions:
  - Teams: `ChannelMessage.Read.All` (application permission)
  - Outlook: `Mail.Read` (delegated permission)
- Do NOT grant: `ChannelMessage.Send`, `Mail.Send`, `Mail.ReadWrite`, or any Teams write scope.
- Use a dedicated app registration for MCP only — not shared with other integrations.
- Content (Teams messages, email threads) must be manually confirmed before use.
- Email/message content cannot substitute for workflow-state gate records.
- Rotate the client secret every 90 days.
- Write-block tests: try to send message/email from Cursor chat — must fail.

### P2 — MongoDB Atlas

- API key role: **Project Read Only** — never use Project Owner, Data API, or any write role.
- **Use DEV or STAGING cluster URI only during pilot.** Do NOT connect production Atlas.
- Confirm IP allowlist: only the developer's IP (or Cursor's outbound IP) should be allowed.
- DB schema may reveal data model details — treat as confidential.
- Write-block test: `Insert a document into any collection` — must fail.
- If test succeeds: revoke API key immediately; review Atlas role configuration.

### P2 — Docker Hub

- Personal access token with **read-only** permissions — no push, no delete.
- Prefer a service account or read-only token rather than a personal account with broad access.
- Write-block test: `Delete or push a Docker Hub image tag` — must fail.

### P2 — Render

- API key with read access only.
- Do NOT configure deploy, restart, or any service-mutation action from MCP during pilot.
- Render services may expose deployment logs — check for sensitive data in logs before enabling.
- Write-block test: `Restart or deploy a Render service` — must fail.

### P2 — Vercel

- Token scoped to read — prefer a team token with read-only scope.
- Do NOT configure deployment triggers or environment variable changes.
- Vercel deployment info may include environment variable names — confirm no secrets are visible in deployment metadata before enabling.
- Write-block test: `Trigger a deployment or change an environment variable on Vercel` — must fail.

### P1 — AWS S3 (artifact storage)

S3 is the only integration in the pilot that has **controlled write access**. All other rules still apply, plus:

1. **Dedicated pilot bucket only.** Use `talentserv-ai-sdlc-pilot-artifacts` (or your equivalent). Never use an existing production bucket or a bucket shared with non-AI-SDLC data.
2. **Least-privilege IAM policy.** Grant only `s3:GetObject`, `s3:PutObject`, `s3:GetObjectVersion`, and `s3:ListBucket` scoped to the `projects/*` prefix. See `aws-s3-artifact-storage-setup.md` for the exact policy JSON.
3. **No AWS root credentials.** Use a dedicated IAM user with an inline policy. Never use root account access keys.
4. **No delete permission in pilot.** `s3:DeleteObject` must NOT be in the IAM policy. If artifact cleanup is needed, it must be done by an authorized admin outside the pilot tools.
5. **Public access fully blocked.** Verify all four public access block flags are `true`. AI-SDLC artifacts must never be publicly readable.
6. **Encryption mandatory.** SSE-S3 (AES-256) minimum. SSE-KMS is preferred for regulated environments.
7. **Versioning enabled.** Allows recovery of overwritten artifacts and provides an audit trail.
8. **No PHI/PII/secrets in pilot bucket.** Only AI-SDLC pipeline artifacts (plans, outputs, bundles, metrics) — never patient records, credentials, API tokens, or personal data. If PHI must be stored later, this requires a formal data protection review and explicit governance approval.
9. **IAM key scoped to prefix.** The `s3:ListBucket` condition must restrict to `StringLike: s3:prefix: ["projects/*"]`.
10. **Rotate keys after pilot.** Rotate `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` when the pilot completes. For production, migrate to IAM roles (OIDC or instance profile) rather than long-lived keys.
11. **Validate scope restriction.** Run the AWS CLI scope test (`aws s3 cp /dev/null s3://bucket/not-projects/...`) and confirm it fails with AccessDenied before using S3 for real artifacts.
12. **Validate delete restriction.** Run the delete test (`aws s3 rm`) and confirm it fails. If it succeeds, add an explicit IAM `Deny` for `s3:DeleteObject`.

### P3 — Figma (deferred)

- Personal access token — read-only file content access.
- Figma designs may contain pre-release product designs — treat as confidential.
- Write-block test: `Create a frame in Figma file {ID}` — must fail.

---

## Credential handling

1. **No secrets in any committed file.** `.cursor/mcp.json`, `.env.mcp`, or any file containing tokens must be in `.gitignore`.
2. **Rotate every 90 days.** Set a calendar reminder for each token at creation time.
3. **Separate tokens per developer.** No shared admin tokens or team-wide tokens.
4. **Separate tokens per integration.** One ADO token, one GitHub token, one Atlassian token — not a single combined token.
5. **Use fine-grained tokens where supported.** GitHub fine-grained PATs, Atlassian app passwords scoped to specific projects.
6. **Store real values in:** shell environment, approved password manager (1Password, Bitwarden), or Cursor secret store — never in a file that could be committed.
7. **Immediate revocation protocol:** if any token is accidentally exposed (committed, shared, or logged), revoke it within minutes. Do not wait to confirm if it was actually used.

---

## Data sensitivity rules

| MCP | Data it can expose | Controls needed |
|-----|--------------------|-----------------|
| GitHub | PR diffs, issue bodies, CI logs | Confirm no secrets in PR content before using in prompts |
| Azure DevOps | Work item bodies, comments | May contain PHI if clinical requirements tracked in ADO |
| Jira | Issue descriptions, ACs | May contain PHI/PII in healthcare projects — review before enabling |
| Confluence | Architecture, security docs | Confidential — do not copy wholesale into AI context |
| Slack | Business discussions, decisions | Review content before using in prompts |
| Teams / Outlook | Decision and approval evidence | Manual confirmation required; contains business-sensitive content |
| MongoDB Atlas | DB schema, collection names | Structural only — no actual data documents |
| Render / Vercel | Deploy logs, service names | Check logs for credentials or sensitive request data |

For PHI/PII data (patient records, clinical data):

- Never use production MCPs for features that handle PHI until a data protection review is complete.
- Use DEV/STAGING environments and synthetic data during pilot.
- Check your project-config.yaml `security_model.data_classification` before enabling any data-touching MCP.

---

## Incident response

If any of the following occurs, treat it as a security incident:

1. A write-block safety test **passes** (i.e., the write action succeeds when it should fail)
2. A token is committed to git
3. A token is shared via email, Slack, or another messaging channel
4. An AI prompt appears to have used a token to perform an action (create, update, send, deploy)

**Immediate steps:**

1. Revoke the affected token immediately.
2. Undo any created/modified resource if possible.
3. Regenerate with correct read-only scope.
4. Re-run both read and write-block validation before resuming.
5. Document the incident: date, which MCP, what happened, what was done.
6. Review whether any other developer uses the same credentials — if shared, rotate all copies.

---

These guidelines replace ad-hoc credential guidance. Any MCP usage outside these rules requires an explicit governance decision and documented exception.

## Baseline Policy Controls

1. **Default deny:** Tool invocation is denied unless explicitly assigned to `read_tools`, `write_tools`, `restricted_tools`, or `destructive_tools`.
2. **Least privilege:** Agent profiles get the minimum class and minimum resource scope needed for the current workflow phase.
3. **Scoped credentials:** Credentials are separated by integration, environment, and operation class; avoid shared admin identities.
4. **Class-aware controls:** `restricted_tools` and `destructive_tools` enforce stronger approvals, logging, and runtime controls.

## Credential Handling

1. **No long-lived secrets in prompts:** Inject secrets via platform secret stores referenced only by MCP server configuration.
2. **Short-lived tokens:** Prefer OIDC federation or ephemeral CI tokens over static PATs where supported.
3. **Per-server identities:** Distinct credentials for git, issue tracker, CI, and observability to contain blast radius.
4. **Rotation:** Document rotation cadence and owning team; automate where possible.

## Network Controls

1. **Egress allowlists:** MCP servers should reach only approved SaaS endpoints and internal gateways.
2. **Split horizons:** Agents analyzing untrusted forks must not access internal issue trackers without sanitization workflow.
3. **TLS verification:** Do not disable certificate validation for convenience.
4. **Class segmentation:** Run destructive-capable endpoints in isolated networks and separate runtime pools.

## Server Supply Chain

1. **Pin versions:** Use immutable image digests or locked package versions for MCP server distributions.
2. **Verify provenance:** Prefer signed artifacts from trusted publishers.
3. **Minimal images:** Reduce attack surface of MCP host containers.

## Data Handling

1. **Data classification:** Apply labels from `project-config.security_model.data_classification`; restrict exfiltration of confidential content to external models if policy forbids.
2. **PII redaction:** Configure log and issue integrations to scrub sensitive fields before model consumption when required.
3. **Retention:** Align MCP audit logs with `audit_and_compliance.retention_days`.

## Prompt Injection and Tool Abuse

1. **Instruction hierarchy:** Runtime should prioritize system/developer policy over untrusted content from issues or PRs.
2. **Confirmation for writes:** Require human confirmation for sensitive `write_tools` operations when repo trust is low (for example forked PRs).
3. **Rate limits:** Throttle tool calls per agent session to mitigate automated abuse.
4. **Tool-class guardrails:** Reject attempts to execute `restricted_tools` or `destructive_tools` without valid approval token.

## Approval Token Flow Guidance

1. Orchestrator submits authorization request with `correlation_id`, `ticket_id`, `tool_scope`, and `resource_scope`.
2. Approval service issues signed short-lived token after human approval.
3. MCP server verifies token signature, issuer, audience, nonce, expiry, and exact scope.
4. Token must be single-use; replays are rejected and audited.

### Example (conceptual claims)

```json
{
  "sub": "human:eng_lead",
  "scope": "restricted_tools:merge_pull_request:repo/org/app:pr/123",
  "ticket_id": "ISSUE-123",
  "correlation_id": "PR-123",
  "exp": 1760000000,
  "jti": "token-uuid"
}
```

## Break-Glass Security Procedure

1. Declare incident and obtain incident ID.
2. Capture immutable pre-operation snapshot and rollback plan link.
3. Obtain dual approvals from distinct human roles.
4. Issue break-glass token with explicit destructive tool scope and short TTL.
5. Execute under session recording and enhanced telemetry.
6. Verify post-operation state and attach artifacts to incident record.
7. Revoke elevated access and run post-incident review.

## Incident Response

1. **Kill switch:** Ability to disable MCP servers or revoke tokens independently of the model provider.
2. **Forensics package:** Preserve audit trails for investigations per `governance/audit-log-requirements.md`.
3. **Automated containment:** On unauthorized restricted/destructive attempts, suspend agent profile and rotate credentials.

## Audit Event Requirements by Tool Class

- **`read_tools`:** standard event trail with correlation IDs.
- **`write_tools`:** include before/after state digest and ticket linkage.
- **`restricted_tools`:** include approver IDs and approval token ID.
- **`destructive_tools`:** include incident ID, dual-control evidence, snapshot references, and verification results.

### Audit Examples

```json
{"event_type":"mcp.tool.read","tool":"read_repository","class":"read_tools","correlation_id":"ISSUE-55","result":"success"}
```

```json
{"event_type":"mcp.tool.write","tool":"create_issue","class":"write_tools","ticket_id":"ISSUE-55","result":"success"}
```

```json
{"event_type":"mcp.tool.restricted","tool":"merge_pull_request","class":"restricted_tools","approval_token_id":"tok-1","result":"denied"}
```

```json
{"event_type":"mcp.tool.destructive","tool":"force_push","class":"destructive_tools","incident_id":"INC-77","result":"blocked"}
```

## Compliance Alignment

Map MCP data flows to organizational records of processing and vendor DPAs. Restricted tools in `mcp-permissions.md` must remain off for default agent profiles in regulated environments.
