# Context Aggregator

> The Context Aggregator assembles the complete, validated context required for an agent prompt
> invocation — from workflow state, project context, project config, engineering guardrails, prior
> agent outputs, and artifact references — reducing manual placeholder filling from 8–12 items to
> 2–3 engineer inputs.
>
> **Core script:** `ai-sdlc/tools/orchestration/build_context_bundle.py` (local, no external calls).
> **Prefill tool:** `ai-sdlc/tools/orchestration/context_prefill.py` (report + import modes).
> **Output format:** `ai-sdlc/schemas/context/context-bundle.schema.json`.
> **Prefill input format:** `ai-sdlc/schemas/prefill/prefill-input.schema.json`.
> **Example output:** `ai-sdlc/examples/context-bundles/patient-registration.context-bundle.json`.

---

## Purpose

At Maturity Level 1, engineers manually paste 8–12 pieces of context into each prompt invocation:
project context, requirement text, workflow state, approval records, engineering guardrails, tech stack,
acceptance criteria, prior agent summaries. This is the primary friction in daily usage.

The Context Aggregator eliminates most of this assembly by:
1. Reading the workflow state file to understand the current stage and tier.
2. Loading project-context.md and project-config.yaml automatically.
3. **Auto-detecting and referencing enterprise-engineering-guardrails.md from the repo root.**
4. Extracting prior agent output summaries from the workflow state's `agent_outputs` map.
5. Building the artifact reference list from the workflow state's `artifacts` map.
6. Evaluating gate completeness from the workflow state's `gates` map.
7. Checking context freshness.
8. Flagging sensitive data based on project config data classification.
9. **Producing a per-prompt placeholder coverage report** — showing which placeholders are auto-filled, MCP-readable, manual, or gated.
10. Producing a structured context bundle with a recommended next action.

The result: engineers confirm 2–3 items (current step, repository source files, human notes) instead of assembling everything from scratch.

---

## Context Prefill Tool

`context_prefill.py` complements the context bundle by reducing the copy-paste burden for MCP-readable fields. It operates in two modes:

### Report mode (default, always safe)

```bash
python ai-sdlc/tools/orchestration/context_prefill.py \
  --workflow-state ai-sdlc/workflow-state/PROJ-1234.yaml \
  --target-prompt clarify-requirement \
  --emit-template /tmp/PROJ-1234-prefill-input.json
```

Prints:
- All auto-filled fields (no action needed)
- MCP-readable fields with **exact Cursor queries** (issue ID substituted in)
- Manual fields with developer action guidance
- Human gates with recording instructions

The `--emit-template` flag creates a blank JSON for the developer to fill with Cursor MCP results.

### Import mode (validated merge)

After filling the template with values from Cursor:

```bash
python ai-sdlc/tools/orchestration/context_prefill.py \
  --workflow-state ai-sdlc/workflow-state/PROJ-1234.yaml \
  --target-prompt clarify-requirement \
  --import /tmp/PROJ-1234-prefill-input.json \
  --output /tmp/PROJ-1234-prefill-context.json
```

Safety rules enforced:
- **Issue ID must match** the workflow state — fails closed if mismatched
- **Gate fields (G_PLAN, G_SEC, G_PR_MERGE, G_DEPLOY) are rejected** by schema and runtime
- **Empty values fail** — all imported fields must be non-empty strings
- **Source, timestamp, and fetched_by** are recorded for every imported value
- **No file is modified** — output is a new read-only prefill-context JSON

### Makefile shortcut

```bash
make ai-sdlc-prefill-report                               # clarify-requirement (default)
make TARGET_PROMPT=implement-step ai-sdlc-prefill-report  # different prompt
```

### What remains manual after the context bundle

The context bundle does not call external APIs. Live data still requires developer action in Cursor chat:

| What is still manual / MCP-required | How to get it |
|-------------------------------------|--------------|
| `{{REQUIREMENT}}` (work item body + AC) | Ask Cursor: `Read ADO work item <ID> including description and acceptance criteria.` |
| `{{REPOSITORY_CONTEXT}}` (source files) | Ask Cursor: `Read the relevant source files for <feature/module>.` |
| `{{DIFF_CONTENT}}` (PR diff) | Ask Cursor: `Read the diff for PR #<N>.` |
| `{{RECENT_CI_STATUS}}` (CI run result) | Ask Cursor: `What is the status of the latest CI run on branch <BRANCH>?` |
| `{{CURRENT_STEP}}` (which plan step) | Read `plan_doc` artifact and select the step number |
| `{{MONITORING_SIGNALS}}` / `{{STACK_TRACE}}` | Paste from Grafana/Datadog/CloudWatch manually |
| `{{AUDIT_OUTPUT}}` | Run `make ai-sdlc-audit` locally; paste raw output |
| Human gate approvals | Always human-owned — never auto-filled |

---

## Inputs

| Input | Required | How provided |
|-------|---------|-------------|
| Workflow state YAML | Yes | File path (`--workflow-state`) |
| `project-context.md` | Yes | File path (`--project-context`) |
| `project-config.yaml` | Yes | File path (`--project-config`) |
| `enterprise-engineering-guardrails.md` | Auto | Auto-detected from repo root — no argument needed |
| Target agent name | Yes | CLI argument (`--target-agent`) |
| Target prompt name | Yes | CLI argument (`--target-prompt`) |
| Output path | Yes | CLI argument (`--output`) |
| Human notes | Optional | CLI argument (`--human-notes`) |
| CI status JSON | Optional | CLI argument (`--ci-status`) |

---

## Outputs

A JSON context bundle validated against `schemas/context/context-bundle.schema.json` containing:

- Complete workflow state reference (stage, tier, last updated)
- Project context reference with freshness assessment
- Project config reference with approval roles
- Engineering guardrails reference (`engineering_guardrails_ref`) — path and availability status
- All artifact references with status (present / missing / stale)
- All gate approval references with recorded approvals
- **Placeholder coverage report** (`placeholder_coverage`) — per-prompt breakdown of auto-filled, MCP-readable, manual, and gated placeholders
- CI job references with current status
- Source summaries from prior agent outputs (auto-loaded from workflow state `agent_outputs`)
- Missing context list with severity (blocking / warning / informational)
- Stale context items
- Sensitive data flags (from project config data classification)
- Recommended next action: safe_to_proceed, next agent, next prompt, placeholder map, exact human action

---

## How it reads workflow state

1. Parse the YAML file at `--workflow-state`.
2. Extract: `current_stage`, `work_tier`, `gates`, `artifacts`, `agent_outputs`, `blocked_reasons`, `updated_at`.
3. For each gate, build an `approval_refs` entry with `required`, `approved`, `approver`, `comment_url`.
4. For each artifact in `artifacts`, build an `artifact_refs` entry with `status` = `present` if the path/URL is non-null, else `missing`.
5. For each key in `agent_outputs`, include the summary in `source_summaries` if non-null.
6. If `blocked_reasons` is non-empty, add them to the recommended next action's `blockers` list.

---

## How it reads project-context.md

1. Parse the Markdown file at `--project-context`.
2. Extract `Last reviewed:` header value (expected format: `YYYY-MM-DD`).
3. Calculate days since last review; set `freshness_status`:
   - 0–30 days: `current`
   - 31–60 days: `review_recommended`
   - 61–90 days: `review_required`
   - >90 days: `stale` (adds `blocking` item to `missing_context`)
4. Extract `project name`, first heading after `Project overview`, and tech stack table summary.

---

## How it reads project-config.yaml

1. Parse the YAML file at `--project-config`.
2. Extract `project.identifier`, `approval_roles`, `tier_defaults`, `data_classification`, `compliance`, `rules.extensions`.
3. Build `sensitive_data_flags` from `data_classification`:
   - `restricted` with `phi_access` tier default → add `phi` flag
   - `restricted` with `pii_access` tier default → add `pii` flag
   - Any compliance entry → add `compliance_scope` flag per entry
4. Build `project_config_ref` with extracted approval roles and tier defaults.

---

## How it links prior artifacts

Prior agent outputs are linked from the workflow state `agent_outputs` map into `source_summaries`.
Artifact paths from `artifacts` map are linked as `artifact_refs` with `present`/`missing`/`null` status.

This means: if the planning agent has already run and recorded `planner_summary`, the context bundle
automatically includes that summary as pre-assembled context for the implementation agent — no manual paste.

---

## How it handles missing context

For each field required by the target agent's prompt (defined in the prompt's required placeholders list):
1. Check if the corresponding data is available in the assembled sources.
2. If missing: add to `missing_context` with `severity`:
   - `blocking` if the field is required for the target prompt and safe-to-proceed
   - `warning` if the field is recommended but the prompt can still proceed
   - `informational` if the field is optional context

If any `blocking` missing_context items exist: `recommended_next_action.safe_to_proceed = "no"`.

---

## How it handles stale context

1. Calculate `staleness_days` for `project-context.md` from `last_reviewed` to `generated_at`.
2. If `staleness_days` > 90: add `blocking` missing_context item; set `safe_to_proceed = "no"`.
3. If `staleness_days` > 60: add `review_required` to stale_context; set `safe_to_proceed = "conditional"`.
4. If `staleness_days` > 30: add `review_recommended` to stale_context; no safe_to_proceed impact.

Stale workflow state (not updated in >5 business days): add `warning` item noting the age.

---

## How it handles conflicting context

When the workflow state's `current_stage` does not match the available artifacts
(e.g., stage is `IMPLEMENTING` but no `g_plan_record` artifact is present):

1. Add a `blocking` missing_context item: "Stage is IMPLEMENTING but no G-PLAN record found".
2. Set `safe_to_proceed = "no"`.
3. Set `exact_human_action` to: "Verify G-PLAN record URL and update workflow state before proceeding."

The aggregator never silently resolves conflicts. Every inconsistency is surfaced.

---

## How it handles sensitive data

From `project-config.yaml`:
- If `data_classification` is `restricted` or `confidential` → add relevant flags
- If `compliance` list is non-empty → add `compliance_scope` flag per entry
- If `rules.extensions` contains PHI/PII/PCI rules → add specific flags with handling notes

Sensitive data flags are included in the context bundle as `sensitive_data_flags`. They do not block
processing but must be surfaced to the engineer before agent invocation. The engineer is responsible
for ensuring sensitive data handling requirements are applied.

---

## How it prepares context for each agent

The target agent determines which placeholders are mapped in `required_placeholders`:

| Target agent | Placeholders auto-mapped | Placeholders needing manual input |
|-------------|------------------------|----------------------------------|
| Technical Planning | PROJECT_CONTEXT, WORKFLOW_STATE, prior summaries | SECURITY_MODEL (from config), APPROVAL_RULES |
| Backend Implementation | PROJECT_CONTEXT, WORKFLOW_STATE, CURRENT_STEP (from plan), ENGINEERING_GUARDRAILS | REPOSITORY_CONTEXT (needs code read) |
| Test Agent | PROJECT_CONTEXT, WORKFLOW_STATE, TECH_STACK | REPOSITORY_CONTEXT (test suite structure) |
| PR Review | PROJECT_CONTEXT, WORKFLOW_STATE, ENGINEERING_GUARDRAILS, prior self-review | PR_CONTEXT (needs PR diff) |
| Release Readiness | PROJECT_CONTEXT, WORKFLOW_STATE, approval records | RELEASE_CONTEXT, CI artifacts |
| Stage Router | PROJECT_CONTEXT, WORKFLOW_STATE, PROJECT_CONFIG, artifact_refs, approval_refs | RECENT_CI_STATUS (optional), HUMAN_NOTES |

---

## How this reduces placeholder filling

**Before context aggregator (Level 1 manual):** Engineer opens a prompt, identifies 8–12 placeholders, manually locates and pastes:
- `project-context.md` content (full file)
- Requirement text (from issue)
- Technical plan (from workflow state artifacts)
- Acceptance criteria (from spec)
- Engineering guardrails (from governance doc)
- Prior agent summaries (from issue comments)
- Approval records (from issue comment history)
- Workflow state (from YAML file)

**With context aggregator (Level 1+ local script):** Engineer runs `build_context_bundle.py` with 3 file paths and target prompt. Script produces a bundle with:
- All automatically-assembable context pre-loaded
- Clear list of what still needs manual input (typically: REPOSITORY_CONTEXT and CURRENT_STEP)
- Ready-to-paste summaries from prior agents
- Safe-to-proceed determination with exact human action

**Estimated reduction:** From 8–12 manual paste operations to 2–3 per prompt invocation.

---

## Orchestration helper scripts (gate and transition checking)

The context aggregator works alongside two companion scripts:

**`check_gates.py`** — before running the context bundle, confirm required gates are satisfied:
```bash
python ai-sdlc/tools/orchestration/check_gates.py \
  --workflow-state ai-sdlc/workflow-state/YOUR-ISSUE.yaml
# Exit 0 = safe, Exit 2 = gates missing
```

**`validate_transition.py`** — confirm the target stage is reachable before updating:
```bash
python ai-sdlc/tools/orchestration/validate_transition.py \
  --workflow-state ai-sdlc/workflow-state/YOUR-ISSUE.yaml \
  --target-state IMPLEMENTING
```

**`update_workflow_state.py`** — apply state updates safely after each stage:
```bash
python ai-sdlc/tools/orchestration/update_workflow_state.py \
  --workflow-state ai-sdlc/workflow-state/YOUR-ISSUE.yaml \
  --set-current-stage IMPLEMENTING --write
```

Recommended sequence: `check_gates` → `validate_transition` → run the prompt → `update_workflow_state` → regenerate context bundle.

---

## Level 1 — Manual usage (current)

1. Prepare workflow state file manually.
2. Run `build_context_bundle.py` locally.
3. Review bundle output, check `recommended_next_action`.
4. Supply the 2–3 manually-provided fields (REPOSITORY_CONTEXT, CURRENT_STEP).
5. Invoke the target prompt with the assembled context.

---

## Level 2 — MCP-connected usage (future)

When GitHub MCP is configured:
1. The `REPOSITORY_CONTEXT` placeholder is populated by GitHub code search MCP read.
2. CI status is populated by GitHub Actions status API.
3. Prior PR comments (including AI review, G-PLAN records) are populated from GitHub API.
4. The engineer's remaining input is reduced to: CURRENT_STEP and HUMAN_NOTES only.

---

## Level 3 — Orchestrated usage (future)

When the Orchestrator service is operational:
1. The Orchestrator runs the context aggregator automatically after each stage completion.
2. The bundle is passed to the next agent as part of the ACP handoff envelope.
3. Engineers review the recommended next action and confirm before any agent is invoked.
4. Context bundles are stored in the workflow state directory for audit trail.
