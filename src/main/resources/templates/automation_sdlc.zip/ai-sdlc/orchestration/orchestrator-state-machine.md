# Orchestrator State Machine

> **STATUS: FUTURE** — This document describes a planned orchestration architecture.
> The current runtime implements a subset of this model (5 active states).
> See `workflow-state-model.yaml` for the authoritative active state list.
> Do not treat this document as a description of current runtime behavior.



This state machine defines deterministic control-plane behavior for workflow orchestration.

## Workflow State Set

- `created`
- `ready`
- `in_progress`
- `waiting_for_approval`
- `waiting_for_artifact`
- `retry_scheduled`
- `blocked`
- `escalated`
- `completed`
- `failed`
- `cancelled`
- `emergency_stopped`

## Transition Rules

| From | Event | To | Notes |
|------|-------|----|-------|
| created | inputs_validated | ready | required inputs/artifacts present |
| ready | execution_started | in_progress | owner agent invoked |
| in_progress | approval_required | waiting_for_approval | gate IDs attached |
| in_progress | artifact_missing | waiting_for_artifact | required artifact IDs attached |
| in_progress | retryable_failure | retry_scheduled | retry policy applies |
| retry_scheduled | retry_window_open | in_progress | retry_count incremented |
| in_progress | policy_violation | blocked | human intervention required |
| blocked | escalated | escalated | escalation ID required |
| escalated | resolution_recorded | in_progress | only with resolution artifact |
| in_progress | all_exit_criteria_met | completed | workflow terminal success |
| in_progress | non_retryable_failure | failed | terminal failure |
| any_non_terminal | cancel_requested | cancelled | human/system cancel |
| any_non_terminal | emergency_stop | emergency_stopped | system-wide stop |

## Compensation and Recovery

- On partial failure after artifact writes, run compensation actions:
  - mark stale artifacts as `invalidated`
  - create follow-up recovery issue
  - emit audit event `AUD-EVT-COMPENSATION-001`

## Emergency Stop Behavior

1. Transition all active workflows to `emergency_stopped`.
2. Deny non-read MCP classes globally.
3. Require explicit resume approval and `AUD-EVT-ESTOP-CLEARED-001` for recovery.

## Machine-Readable Model References

- Workflow state model: `ai-sdlc/orchestration/workflow-state-model.yaml`
- Artifact lifecycle model: `ai-sdlc/orchestration/artifact-lifecycle.yaml`
- Approval state model: `ai-sdlc/orchestration/approval-state-model.yaml`
- Transition policy: `ai-sdlc/policies/workflow-transitions.rego`
- Registry mapping: `ai-sdlc/registry/`
