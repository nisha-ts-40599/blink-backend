# Retry and Recovery Model

> **STATUS: FUTURE** — This document describes a planned retry, recovery, and
> rollback model that is more capable than the current runtime implements.
> The current runtime supports bounded step retries (`retry_engine.py`) and
> stub compensation handlers (`compensation_engine.py`).  Rollback orchestration,
> `E-LOCK-CONTENTION` jitter, and rate-limit header handling are not yet built.
> Treat this as a design target, not as a description of current behavior.



This document defines deterministic retry, recovery, compensation, and rollback orchestration behavior.

## Retry Categories

| Category | Error code examples | Retry | Notes |
|----------|---------------------|-------|-------|
| Transient infrastructure | `E-TIMEOUT`, `E-TRANSIENT-UPSTREAM` | yes | exponential backoff |
| Rate limiting | `E-RATE-LIMIT` | yes | honor server reset headers |
| Contention | `E-LOCK-CONTENTION` | yes | jitter required |
| Validation/policy | `E-SCHEMA-INVALID`, `E-POLICY-DENIED` | no | escalate/human fix |
| Approval failures | `E-APPROVAL-REJECTED`, `E-APPROVAL-EXPIRED` | no automatic | human action required |

## Retry Behavior

1. Retry only if workflow `retry_policy` allows and error is retryable.
2. Increment `retry_count` and preserve `idempotency_key`.
3. Emit audit event `AUD-EVT-RETRY-SCHEDULED-001`.
4. If `retry_count` exceeds max, transition to `failed` and escalate.

## Recovery Actions

- Rebuild missing artifacts from upstream immutable references when possible.
- Reopen blocked gate request on approver reassignment.
- Reconcile partially produced artifacts by state transitions to `invalidated` or `superseded`.

## Compensation Behavior

When a multi-step operation partially succeeds:

1. Mark incomplete artifacts invalid.
2. Restore prior baseline if mutation affected non-production environment.
3. Emit compensation event `AUD-EVT-COMPENSATION-001`.
4. Create follow-up issue with incident and artifact references.

## Rollback Orchestration

1. Load `rollback_baseline_artifact`.
2. Validate rollback preconditions (environment, target version, data compatibility).
3. Execute rollback command path.
4. Run post-rollback verification.
5. Emit `AUD-EVT-ROLLBACK-COMPLETED-001`.

## Emergency Stop Behavior

1. Trigger `ESTOP-001` from authorized role.
2. Halt all active workflows (`emergency_stopped` state).
3. Disable non-read MCP tool classes.
4. Preserve forensics package and snapshots.
5. Resume only with incident commander approval and explicit unblock event.
