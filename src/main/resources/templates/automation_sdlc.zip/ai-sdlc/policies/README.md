# Policy-as-Code (OPA/Rego)

This directory contains generic, vendor-neutral policy modules intended for OPA-compatible evaluation.

## Policies

- `gates.rego`: approval gate requirements and production deploy controls.
- `mcp-permissions.rego`: read/write/restricted/destructive MCP class enforcement.
- `risk-classification.rego`: deterministic up-tier logic from impact flags.
- `workflow-transitions.rego`: workflow state transition allow/deny.
- `org-role-mapping.rego`: abstract approver role mapping to org groups.
- `gate-sla.rego`: gate SLA breach detection and escalation recommendation.
- `artifact-integrity.rego`: artifact digest/signature validation decisions.

## Example input

```json
{
  "workflow": {"current_state":"in_progress","next_state":"completed"},
  "work_item": {"risk_tier":3, "plan_approved":true},
  "request": {"action":"deploy_production", "human_approved":true, "approval_token_valid":true},
  "system": {"emergency_stop":false},
  "mcp": {"tool_class":"restricted_tools", "human_approved":true, "approval_token_valid":true},
  "impact": {"auth_security_impact":true, "db_schema_impact":false, "public_api_impact":false}
}
```

## Example decision output

```json
{
  "allow": true,
  "deny_reasons": [],
  "required_gates": ["G-PLAN","G-REL-PROD"],
  "computed_tier": 3
}
```

## Notes

- Policies are intentionally generic and use common input keys.
- Integrators should map runtime payloads into this input shape.
- Policy test wiring is defined in `ai-sdlc/tests/policy-test-matrix.yaml`.
- CI runners can invoke checks via `make ai-sdlc-conformance` and `make ai-sdlc-conformance-strict`.
- Optional local OPA bootstrap helper: `ai-sdlc/tools/install-opa.sh`.
- Protected branch CI should use `make ai-sdlc-conformance-protected` for OPA-required enforcement.
- Conformance failures include machine-readable codes in JSON/JUnit/pretty report outputs.
