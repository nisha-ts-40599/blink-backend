package ai_sdlc.artifact_integrity

import rego.v1

default allow := false

valid_digest if {
  input.digest_algorithm == "sha256"
  regex.match("^[a-fA-F0-9]{64}$", input.digest)
}

valid_digest if {
  input.digest_algorithm == "sha512"
  regex.match("^[a-fA-F0-9]{128}$", input.digest)
}

deny_reasons contains "invalid_or_missing_digest" if not valid_digest

deny_reasons contains "missing_required_signature" if {
  input.signature_required
  input.signature_status != "present"
}

deny_reasons contains "invalid_signature" if {
  input.signature_status == "invalid"
}

allow if count(deny_reasons) == 0
