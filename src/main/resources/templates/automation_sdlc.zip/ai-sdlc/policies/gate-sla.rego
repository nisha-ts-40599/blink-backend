# STATUS: EXPERIMENTAL — This policy has no callers in the current runtime.
# The runtime has no concept of gate age or approval SLA tracking.
# Implement when an approval webhook receiver that tracks gate creation
# timestamps and triggers SLA escalation is built.
package ai_sdlc.gate_sla

import rego.v1

# Example input:
# {
#   "gate": {"gate_id":"G-PLAN","age_minutes":95},
#   "sla": {"G-PLAN":60,"G-SEC":120}
# }

default sla_breached := false

sla_breached if {
  gate_id := input.gate.gate_id
  allowed := input.sla[gate_id]
  input.gate.age_minutes > allowed
}

escalation_recommendation := recommendation if {
  sla_breached
  recommendation := {
    "escalation_required": true,
    "escalation_id": "ESC-GATE-001",
    "reason": "gate_approval_timeout",
  }
}

escalation_recommendation := {"escalation_required": false} if {
  not sla_breached
}
