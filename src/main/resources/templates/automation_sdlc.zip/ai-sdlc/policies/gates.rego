package ai_sdlc.gates

import rego.v1

default allow := false

# required_gates mirrors ai-sdlc/registry/gate-registry.yaml tier rules (H7).
required_gates contains "G-PR-MERGE" if input.work_item.pr_workflow_applicable != false

required_gates contains "G-GROOM" if input.work_item.risk_tier >= 1

required_gates contains "G-PLAN" if input.work_item.risk_tier >= 2

required_gates contains "G-SEC" if input.work_item.risk_tier >= 3

required_gates contains "G-DEPLOY" if {
  input.request.action == "deploy_production"
  input.work_item.deployment_in_scope == true
}

required_gates contains "G-REL-PROD" if input.request.action == "deploy_production"

required_gates contains "G-BOOTSTRAP" if {
  input.work_item.repository_missing == true
  input.work_item.bootstrap_plan_exists == true
}

required_gates contains "G-BOOTSTRAP-EXEC" if input.work_item.managed_bootstrap_execution == true

deny_reasons contains "tier_2_plus_requires_plan_approval" if {
  input.work_item.risk_tier >= 2
  not input.work_item.plan_approved
}

deny_reasons contains "production_deploy_requires_human_approval" if {
  input.request.action == "deploy_production"
  not input.request.human_approved
}

deny_reasons contains "production_deploy_requires_valid_approval_token" if {
  input.request.action == "deploy_production"
  not input.request.approval_token_valid
}

allow if count(deny_reasons) == 0
