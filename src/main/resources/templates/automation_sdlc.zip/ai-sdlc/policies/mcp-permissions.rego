package ai_sdlc.mcp_permissions

import rego.v1

default allow := false

deny_reasons contains "emergency_stop_blocks_non_read_actions" if {
  input.system.emergency_stop
  input.mcp.tool_class != "read_tools"
}

deny_reasons contains "restricted_tools_require_human_approval" if {
  input.mcp.tool_class == "restricted_tools"
  not input.mcp.human_approved
}

deny_reasons contains "restricted_tools_require_approval_token" if {
  input.mcp.tool_class == "restricted_tools"
  not input.mcp.approval_token_valid
}

deny_reasons contains "destructive_tools_require_human_approval" if {
  input.mcp.tool_class == "destructive_tools"
  not input.mcp.human_approved
}

deny_reasons contains "destructive_tools_require_approval_token" if {
  input.mcp.tool_class == "destructive_tools"
  not input.mcp.approval_token_valid
}

deny_reasons contains "destructive_tools_require_break_glass" if {
  input.mcp.tool_class == "destructive_tools"
  not input.mcp.break_glass
}

allow if count(deny_reasons) == 0
