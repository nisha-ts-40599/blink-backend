# STATUS: EXPERIMENTAL — This policy passes through input.config.role_mapping
# unchanged and has zero callers in the current runtime or conformance tests.
# Implement when a real identity provider integration and role-based approval
# workflow are built.
package ai_sdlc.org_role_mapping

import rego.v1

# Example input:
# {
#   "config": {
#     "role_mapping": {
#       "engineering_lead": ["group:eng-leads"],
#       "security_champion": ["group:security"],
#       "sre_or_platform": ["group:sre"]
#     }
#   }
# }

default mapped_roles := {}

mapped_roles := input.config.role_mapping

role_members(role) := members if {
  members := mapped_roles[role]
}
