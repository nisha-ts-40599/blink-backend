package ai_sdlc.risk_classification

import rego.v1

default computed_tier := 1

# Helper rules collect tier conditions without self-reference.
_is_tier4 if input.impact.compliance_impact
_is_tier4 if input.impact.infrastructure_impact
_is_tier4 if input.impact.migration_impact
_is_tier4 if input.impact.production_data_impact == "irreversible"

_is_tier3 if input.impact.auth_security_impact
_is_tier3 if input.impact.db_schema_impact
_is_tier3 if input.impact.public_api_impact
_is_tier3 if input.impact.shared_library_impact
_is_tier3 if input.impact.multi_service_impact

computed_tier := 4 if _is_tier4

computed_tier := 3 if {
  not _is_tier4
  _is_tier3
}

computed_tier := 2 if {
  not _is_tier4
  not _is_tier3
  input.impact.has_standard_change
}
