package ai_sdlc.workflow_transitions

import rego.v1

default allow := false

# valid_transition facts: each line asserts the pair is a permitted transition.
valid_transition("created", "ready")
valid_transition("ready", "in_progress")
valid_transition("in_progress", "completed")
valid_transition("in_progress", "failed")

# Future states — not yet active in the runtime.
# Uncomment when the corresponding state is implemented.
# valid_transition("in_progress", "waiting_for_approval")
# valid_transition("waiting_for_approval", "in_progress")
# valid_transition("in_progress", "waiting_for_artifact")
# valid_transition("waiting_for_artifact", "in_progress")
# valid_transition("in_progress", "retry_scheduled")
# valid_transition("retry_scheduled", "in_progress")
# valid_transition("in_progress", "blocked")
# valid_transition("blocked", "escalated")
# valid_transition("escalated", "in_progress")
# valid_transition("created", "cancelled")
# valid_transition("ready", "cancelled")
# valid_transition("in_progress", "cancelled")

deny_reasons contains "invalid_transition" if {
  not valid_transition(input.workflow.current_state, input.workflow.next_state)
}

deny_reasons contains "emergency_stop_blocks_transition" if {
  input.system.emergency_stop
  input.workflow.next_state != "emergency_stopped"
}

allow if count(deny_reasons) == 0
