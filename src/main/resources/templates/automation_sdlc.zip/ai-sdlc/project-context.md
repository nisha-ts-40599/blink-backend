# Project Context: TalentServ AI-SDLC Pilot

> This document is the canonical `{{PROJECT_CONTEXT}}` value injected into AI-SDLC workflow prompts.
> Keep it accurate and review it quarterly or after major architecture changes.
> Generated from `ai-sdlc/templates/project-context-template.md` for framework self-adoption issue `TS-2` (see `ai-sdlc/workflow-state/TS-2.yaml`).

**last_reviewed:** 2026-06-19

---

## 1. Project Summary

| Field | Value |
|-------|-------|
| **Project name** | TalentServ AI-SDLC Pilot |
| **Identifier** | TS |
| **Description** | Local AI-SDLC framework repository used to validate governed SDLC workflows with Cursor and MCP integrations. |
| **Business domain** | Software delivery governance and AI-assisted SDLC enablement |
| **Primary users** | Engineers, engineering leads, product owners, security reviewers, and pilot evaluators |
| **Team** | TBD |
| **Engineering lead** | TBD |
| **Security champion** | TBD |
| **SRE / platform** | TBD |
| **Product owner** | TBD |

### Core capabilities

- Provide reusable AI-SDLC prompts, workflows, governance rules, schemas, templates, and conformance tooling.
- Validate Jira-first intake, context prefill, stage routing, work classification, and human-gated delivery flow.
- Demonstrate safe MCP-assisted context gathering without autonomous external writes.

### Non-goals

- No production code implementation as part of the first pilot setup task.
- No autonomous Jira, GitHub, Confluence, deployment, infrastructure, authentication, secret, or production data changes.

---

## 2. Architecture

| Field | Value |
|-------|-------|
| **Architecture style** | Documentation and tooling repository for AI-SDLC governance |
| **Deployment model** | Local repository plus GitHub Actions conformance workflow |
| **Cloud provider** | Not applicable for the local pilot artifacts |
| **Infrastructure as code** | Not applicable |
| **Diagram / ADR location** | `ai-sdlc/architecture/`, `ai-sdlc/adr/` |

### Bounded contexts / service boundaries

| Context | Responsibility | Owner |
|---------|----------------|-------|
| AI-SDLC framework | Prompts, governance, schemas, workflows, and conformance tooling | TBD |
| Pilot orchestration | Local workflow state, context bundle, prefill report, and routing flow | TBD |
| MCP integrations | Read-only repository, issue, PR, and documentation context gathering | TBD |

### Key integrations

| System | Interface type | Classification |
|--------|---------------|----------------|
| Jira | MCP read access for issue intake and status context | Internal delivery system |
| Filesystem | MCP read access for local repository files and templates | Local repository |
| GitHub | MCP read access for repository, PR, commit, and available CI context | Internal source control |
| Confluence | MCP read access for process and architecture context when available | Internal documentation |

---

## 3. Technology Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| **Frontend** | Not applicable | - |
| **Backend** | Python tooling and shell/Make targets | Python 3.11 target in CI |
| **Language(s)** | Markdown, YAML, JSON Schema, Rego, Python, shell | Repository-defined |
| **Primary database** | None | - |
| **Cache / secondary store** | None | - |
| **Messaging / events** | None | - |
| **Package manager** | pip for conformance runner dependencies | Repository-defined |
| **Build tool** | Makefile targets | Repository-defined |
| **Container** | None for first pilot | - |

---

## 4. Repository and Module Map

| Path | Role |
|------|------|
| `ai-sdlc/prompts/` | Prompt library for requirement, classification, planning, implementation, review, and release workflows |
| `ai-sdlc/adoption/` | Pilot guides, quick start, MCP readiness, validation checklists, and rollout documentation |
| `ai-sdlc/governance/` | Human gates, risk rules, guardrails, audit, and automation policy |
| `ai-sdlc/workflow-state/` | Per-issue workflow-state YAML files and template |
| `ai-sdlc/tools/orchestration/` | Local context bundle, prefill, gate, transition, and workflow-state helper tools |
| `ai-sdlc/tools/conformance-runner/` | Schema, prompt, and policy conformance runner |
| `ai-sdlc/schemas/` | JSON schemas for framework artifacts |
| `.github/workflows/` | GitHub Actions conformance workflow |

**Default branch:** `main`

**Protected branches:** `main` should require human PR approval and green CI before merge.

**Repository URL:** `https://github.com/AtulTalentServ/automation_sdlc`

---

## 5. SDLC Operating Rules

### Branching

- Branch naming: `feature/<ticket-id>-<slug>` for feature/pilot work.
- All changes to `main` require a pull request.
- Merges to protected branches require human PR approval and green CI.

### Commit messages

Use concise conventional-style messages where practical, for example `docs(ai-sdlc): update project context`.

### PR conventions

- Title format: `<type>(<scope>): <description> [<ticket-id>]` when applicable.
- Required reviewers: TBD by engineering lead.
- Must-pass checks before merge:
  - `Secret Scan (Gitleaks)`
  - `Dependency Audit (pip-audit)`
  - `AI-SDLC Conformance`

### Issue tracker

- System: Jira
- Project key / board: `TS`
- Issue URL base: `https://your-org.atlassian.net/browse/`
- Self-adoption example issue: `TS-2` (see `ai-sdlc/workflow-state/TS-2.yaml`)
- Parent epic (example): `TS-1`

---

## 6. Work Tier Examples

| Tier | Example task in this project | Risk | Required approvals |
|------|------------------------------|------|--------------------|
| **Tier 1** | Add or update local AI-SDLC project context, project config, or workflow-state files without changing behavior | Negligible to low | Optional peer review |
| **Tier 2** | Change CI behavior, branch protection guidance, approval gates, repo policy behavior, or delivery guardrails | Low to moderate | Engineering lead / G-PLAN |
| **Tier 3** | Change security posture, secrets handling, auth-related rules, external egress, or shared delivery controls | Moderate to high | Engineering lead and security champion |
| **Tier 4** | Change production infrastructure, regulated data handling, cryptography, destructive migrations, or deployment authorization | High to critical | Engineering, security, platform/SRE, and product owner |

**Default tier when unclassified:** `2`

---

## 7. Approval Rules

| Role | Maps to | Approves |
|------|---------|----------|
| Engineering lead | TBD | Tier 2+ plans and merge readiness |
| Security champion | TBD | Tier 3+ changes; auth, crypto, secrets, compliance, or security posture changes |
| SRE / platform | TBD | Production deploys and infrastructure changes |
| Product owner | TBD | Scope trade-offs and Tier 4 product/regulatory decisions |

### Gate summary

| Gate | Trigger | Approver |
|------|---------|----------|
| G-PLAN | Tier 2+ before implementation | Engineering lead |
| G-SEC | Tier 3+ or security risk-rule match | Security champion |
| G-PR-MERGE | All merges to protected branch | Human PR reviewers plus green CI |
| G-REL-PROD | Production deploy | SRE/platform plus change record |

---

## 8. CI Commands

| Stage | Command |
|-------|---------|
| Install dependencies | `make ai-sdlc-install` |
| YAML lint | `make ai-sdlc-lint` |
| Prompt quality checks | `make ai-sdlc-prompt-check` |
| AI-SDLC conformance (protected) | `make ai-sdlc-conformance-protected` |
| Context bundle example | `make ai-sdlc-context-bundle-example` |
| Orchestration checks | `make ai-sdlc-orchestration-check` |
| MCP checklist | `make ai-sdlc-mcp-checklist` |
| Security / dependency scan | Gitleaks and pip-audit through GitHub Actions |

**CI/CD system:** GitHub Actions

**Primary pipeline:** `.github/workflows/ai-sdlc-conformance.yml`

---

## 9. Security Rules

| Dimension | Value |
|-----------|-------|
| **Data classification** | Internal pilot delivery metadata |
| **PII processing** | None expected for the first pilot artifacts |
| **Regulatory context** | Not applicable unless future pilot scope introduces regulated data |
| **Secrets management** | Secrets must stay out of repository artifacts and prompt outputs |
| **Agent network policy** | MCP access is read-only unless a human explicitly approves a specific write action |

### Hard security rules for this project

- No credentials, tokens, API keys, or secrets may appear in code, docs, comments, PR descriptions, workflow-state files, project context, or project config.
- `.env.mcp` must not be read, printed, summarized, copied, or exposed.
- External MCP writes are disabled unless a human explicitly approves a specific action in a later request.
- Any change to authentication, secrets, cryptography, infrastructure, production data, or security governance is Tier 3+ unless an engineering lead and security champion approve de-escalation.
- Merge and deployment remain human-triggered only.

---

## 10. Manual vs Automated Boundaries

### AI may automate

- Draft local AI-SDLC documentation and configuration artifacts after human request.
- Read Jira, Filesystem, GitHub, and Confluence context through approved MCP integrations.
- Propose work tier classification, routing, acceptance criteria, and validation plans.
- Run local validation commands only after human confirmation.

### AI assists; human must approve

- Technical plan and work tier classification.
- Any Tier 2+ G-PLAN approval.
- Any Tier 3+ G-SEC approval.
- PR review, merge readiness, and release readiness.

### Must remain manual

- Jira updates, comments, assignment, links, transitions, or issue creation unless explicitly requested.
- Confluence page creation, publication, comments, or edits unless explicitly requested.
- GitHub branch creation, commits, PRs, issue updates, pushes, merges, and workflow reruns unless explicitly requested.
- Merge to `main`.
- Production deployment trigger.
- Secret rotation or environment changes.

### Must never be automated initially

- Merge to default/protected branch.
- Production deploy.
- Secrets or credentials rotation.
- Infrastructure apply.
- Database schema migrations.
- Any operation that reads or exposes `.env.mcp`.

---

## 11. Definition of Done

- [ ] Acceptance criteria evidenced in the issue or PR.
- [ ] `ai-sdlc/project-context.md` includes current project context and `last_reviewed`.
- [ ] `ai-sdlc/project-config.yaml` captures project identity, tooling, approvals, CI, and safety rules.
- [ ] `ai-sdlc/workflow-state/TS-2.yaml` (self-adoption fixture) starts at `REQUIREMENT` and preserves human gates.
- [ ] Local validation commands are run only after human confirmation.
- [ ] No secrets, tokens, `.env.mcp` values, credentials, or sensitive local configuration are included.
- [ ] No external systems are modified automatically.

---

## 12. Prompt Placeholder Values

```
{{PROJECT_CONTEXT}}     -> ai-sdlc/project-context.md
{{PROJECT_CONFIG}}      -> ai-sdlc/project-config.yaml
{{WORKFLOW_STATE}}      -> ai-sdlc/workflow-state/TS-2.yaml (self-adoption fixture; use .cursor/ai-sdlc/ overlay in product workspaces)
{{REQUIREMENT}}         -> Jira issue description and acceptance criteria for YOUR-ISSUE
{{SECURITY_MODEL}}      -> Internal pilot metadata; no secrets; no PII expected; read-only MCP by default
{{APPROVAL_RULES}}      -> Tier 1 optional review; Tier 2 G-PLAN; Tier 3+ G-SEC; all merges human-approved with green CI
{{ENGINEERING_GUARDRAILS}} -> ai-sdlc/governance/enterprise-engineering-guardrails.md
```

---

## 13. MCP Integrations Available

| MCP | Pilot use | Write policy |
|-----|-----------|--------------|
| Filesystem | Read local AI-SDLC repo files, prompts, templates, workflow-state, and examples | Local writes only when explicitly requested |
| Jira | Read issue context (e.g. self-adoption `TS-2` or product `YOUR-ISSUE`), parent epic, issue status, description, and acceptance criteria | No writes unless explicitly requested and supported |
| GitHub | Read repository, PR, commit, issue, and available CI/check context | No branches, commits, PRs, issues, comments, pushes, merges, or reruns unless explicitly requested |
| Confluence | Read available process, architecture, and security context pages when accessible | No page creation, edits, comments, moves, or publishing unless explicitly requested |

---

## Maintenance

| When | What to update |
|------|----------------|
| New pilot issue starts | Workflow-state file, prompt inputs, and issue references |
| Approval roles change | Section 7 and `ai-sdlc/project-config.yaml` |
| CI commands change | Section 8 and `ai-sdlc/project-config.yaml` |
| MCP policy changes | Sections 9, 10, and 13 |
| Quarterly review | All sections and `last_reviewed` |
