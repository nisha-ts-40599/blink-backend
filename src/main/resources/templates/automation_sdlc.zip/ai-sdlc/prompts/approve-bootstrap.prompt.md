# Prompt: Approve Bootstrap Plan (G-BOOTSTRAP)

Record human approval of the bootstrap plan. Bootstrap authorization is distinct
from implementation authorization and from G-SEC.

## Required placeholders

- `{{ISSUE}}`

## Instructions

1. Confirm `/sdlc-next {{ISSUE}}` routed here because G-BOOTSTRAP is the first missing prerequisite.
2. Present the current bootstrap plan package to the assigned principal.
3. Record `approved` or `rejected` only after that human decides. Never pass `WRITE=1` on your own.

```bash
make ai-sdlc-approve-bootstrap ROOT=<workspace-root> ISSUE=<ISSUE-ID> DECISION=<decision> WRITE=1
```

After success: `/sdlc-next {{ISSUE}}`.

## Human action required

A named human must approve G-BOOTSTRAP. This is not implementation authorization and is not G-SEC.

---

## Stage Boundary

**Stage:** BOOTSTRAP_PLANNING
**Prompt type:** gate_capture

**Responsibility:** Present the bootstrap plan package and record a named human G-BOOTSTRAP decision; does not approve the gate.

**Allowed:**
- read bootstrap plan package and `/sdlc-next` routing
- run dry-run approve-bootstrap without `WRITE=1`
- persist the human decision only after the assigned principal supplies it

**Prohibited:**
- self-approve G-BOOTSTRAP or pass `WRITE=1` without a named human decision
- treat G-BOOTSTRAP as implementation authorization or as G-SEC
- execute bootstrap steps or create repositories
- begin implementation of business requirements
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** G-BOOTSTRAP — human-only: make ai-sdlc-approve-bootstrap DECISION=<decision> WRITE=1

**Completion:** present the package, record the human decision when supplied, return a structured handoff, then stop.

**Handoff:** `→ human approves G-BOOTSTRAP → make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`
