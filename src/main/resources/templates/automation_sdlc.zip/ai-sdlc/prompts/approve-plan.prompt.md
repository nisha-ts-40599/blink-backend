# Prompt: Approve Technical Plan (G-PLAN)

Present G-PLAN readiness and record a **human** decision. The command resolves
the required role, assigned principal, evidence package, and artifact hashes.
The AI must never self-approve and must never pass `WRITE=1` on its own.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`

## Instructions

1. Run `/sdlc-next {{ISSUE}}` if G-PLAN is not the first missing prerequisite.
2. Show G-PLAN readiness using a dry-run (`make ai-sdlc-approve-plan` without `WRITE=1`).
3. Ask the assigned principal for an explicit decision: `approved`, `rejected`, or `approved_with_conditions`.
4. Only after that human confirms, re-run with `WRITE=1`. Do not populate GATE, APPROVER, or EVIDENCE_REF unless debug is requested.

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=GATE_APPROVAL GATE=G-PLAN
make ai-sdlc-approve-plan ROOT=<workspace-root> ISSUE=<ISSUE-ID> DECISION=<decision> WRITE=1
```

After success: `/sdlc-next {{ISSUE}}`.

## Human action required

A named human in the required G-PLAN role must supply the decision. The AI must never self-approve.

---

## Stage Boundary

**Stage:** GATE_APPROVAL
**Prompt type:** gate_capture

**Responsibility:** Present G-PLAN readiness and record a named human decision; does not approve G-PLAN.

**Allowed:**
- read workflow-state, G-PLAN package readiness, and assigned principal
- run dry-run approve-plan without `WRITE=1`
- persist the human decision only after the assigned principal supplies it

**Prohibited:**
- self-approve G-PLAN or pass `WRITE=1` without a named human decision
- fabricate approver identity, evidence, or timestamps
- begin implementation or produce product code
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** G-PLAN — human-only: make ai-sdlc-approve-plan DECISION=<decision> WRITE=1

**Completion:** present readiness, record the human decision when supplied, return a structured handoff, then stop.

**Handoff:** `→ human approves G-PLAN → make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`
