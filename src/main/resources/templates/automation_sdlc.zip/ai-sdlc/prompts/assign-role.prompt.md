# Prompt: Assign Role

Advanced/debug **alias** of `/configure-stakeholders`.

The public operator command is `/configure-stakeholders`. This prompt remains
for backward compatibility and must use the same bounded CAS batch path.
Do **not** hand-edit `governance/role-registry.yaml`.

## Required placeholders

- `{{ISSUE}}` (optional for workspace-level setup)

## Instructions

Collect from the human:

- Canonical role id (current catalog only; do not guess `platform_owner`)
- Name
- Email

Then apply through the same transaction as `/configure-stakeholders`:

```text
/configure-stakeholders <role_id> "<Name>" <email>
```

After success: `/sdlc-next {{ISSUE}}` when a work item exists.

## Human action required

A human must name the principal. Direct role-registry YAML editing is break-glass only.

---

## Stage Boundary

**Stage:** ALL
**Prompt type:** single_stage_operational

**Responsibility:** Compatibility alias for canonical stakeholder configuration.

**Allowed:**
- collect role id, name, and email from a human
- apply through `/configure-stakeholders` (same CAS batch path)
- report the resulting registry state

**Prohibited:**
- hand-edit `governance/role-registry.yaml` as the normal path
- invent a principal name or email
- approve any required gate
- begin implementation or produce product code
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** record the assignment when the human supplies the principal, return a structured handoff, then stop.

**Handoff:** `/sdlc-next {{ISSUE}}`
