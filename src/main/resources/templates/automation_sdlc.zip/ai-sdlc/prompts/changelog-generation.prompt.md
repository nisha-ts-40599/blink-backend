# Prompt: Changelog and Release Note Generation

You are a technical writer generating structured release notes from merged PR and issue data.

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{MERGED_PRS}}` — list of merged PR titles, descriptions, and linked issue IDs for the release range
- `{{RELEASE_VERSION}}` — the version being released (semver or date-based)

## Optional placeholders

- `{{PREVIOUS_VERSION}}` — the previous release version, for context
- `{{AUDIENCE}}` — internal / external / both (defaults to both if not specified)
- `{{RELEASE_DATE}}`

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/changelog-draft.md`.
If no issue ID exists, use `.cursor/ai-sdlc/workflow-state/unassigned/changelog-draft.md` and flag that a real issue ID should be created.

## Workflow-state registration

After saving, update workflow state:

```yaml
artifacts:
  release_notes: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/changelog-draft.md"
```

## Post-output handoff

After saving this output:

1. Update the workflow-state `artifacts` entry for the generated artifact.
2. Run:

```bash
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout:

```bash
make ai-sdlc-validate-artifacts ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=.. ISSUE=<ISSUE-ID>
```

3. Do not proceed to the next SDLC stage if required artifacts or gates are missing.

## Evidence handling

- Do not infer live CI, PR, deployment, monitoring, dependency, or audit status.
- Use MCP or approved tool output only when available; otherwise ask the human to paste evidence.
- Mark missing evidence explicitly as **missing evidence** — never fabricate merged PR lists or release scope.
- Do not fabricate approvals or published release status.
- Escalate production, security, or customer-impact uncertainty to human review.

## Instructions

1. Classify each PR or issue into one of: **Feature**, **Fix**, **Performance**, **Security**, **Deprecation**, **Breaking change**, **Internal / non-visible**. Use the PR body, tier label, and R-* risk tags as signals.
2. Draft the changelog in **Keep a Changelog** format (https://keepachangelog.com):
   - Sections: Added, Changed, Fixed, Deprecated, Removed, Security
   - Internal items go under "Internal" and are excluded from the external version
3. For **Breaking changes**, add a migration note: what the user must change and the minimum steps to upgrade.
4. Write each entry in one clear, non-technical sentence from the user's perspective where possible. Technical detail goes in parentheses or a sub-bullet.
5. Flag any PR without a clear user-facing description — these need human review before the changelog is published.

## Output format

**Changelog — vX.Y.Z (YYYY-MM-DD)**

- Added: ...
- Changed: ...
- Fixed: ...
- Security: ...
- Deprecated: ...
- Removed: ...
- Internal: ...

**Migration notes** (if breaking changes exist)

**Items needing human review** (missing or unclear descriptions)


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** MERGED

**Responsibility:** Generate a changelog entry from merge closure evidence.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- re-open merged PRs
- modify merged code

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before changelog-generation, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files are **read-only**; store project artifacts under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user. Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Human action required

The engineering lead or product manager must review and approve the changelog before it is published. Release communications to customers must be reviewed by product management. Marketing or external release notes may require additional review by product and legal.
