# Prompt: Classify Work (Tier / Risk)

You are an engineering risk analyst assisting with work classification. Use only the information provided; flag unknowns explicitly.

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{REQUIREMENT}}`
- `{{SECURITY_MODEL}}`
- `{{APPROVAL_RULES}}`

## Optional placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{ARTIFACTS}}`

## Context value sources

| Placeholder | Preferred source | Auto-populated today | Manual fallback |
|-------------|------------------|----------------------|-----------------|
| `{{PROJECT_CONTEXT}}` | `.cursor/ai-sdlc/project-context.md` | Yes, via bundle/groom-prep | Paste project context |
| `{{REQUIREMENT}}` | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/requirement.md` | Partial (after grooming) | Issue tracker MCP or paste |
| `{{SECURITY_MODEL}}` | project-context security section | Partial (embedded in context) | Paste security constraints |
| `{{APPROVAL_RULES}}` | `.cursor/ai-sdlc/project-config.yaml` | Yes, via bundle | Paste approval roles |

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/classification.md`.
If no issue ID exists, use `.cursor/ai-sdlc/workflow-state/unassigned/classification.md` and flag that a real issue ID should be created.

## Workflow-state registration

After saving, update workflow state. Formal `work_tier` supersedes grooming tier inference (H8). Preserve business AC criterion IDs for Phase 1 traceability — do not invent test strategy or G-PLAN approval.

```yaml
artifacts:
  classification_record: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/classification.md"
work_type: "<work_type>"
work_subtype: "<work_subtype or null>"
modernization:
  enabled: false  # true only for modernization/migration/cloud/data/platform work
  type: null
```

## Post-output handoff

After saving this output:

1. Update the workflow-state `artifacts` entry for the generated artifact.
2. Run:

```bash
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout:

```bash
make ai-sdlc-validate-artifacts ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=.. ISSUE=<ISSUE-ID>
```

3. Do not proceed to the next SDLC stage if required artifacts or gates are missing.

## Issue tracker guidance

Use normalized issue metadata from the configured tracker provider when available (`issue_tracking` in project-config or workspace-config; see `architecture/normalized-issue-model.md`).
If tracker integration is unavailable (`manual`), use manually provided issue details.
Do not assume Jira or ADO.
Do not fabricate issue status, acceptance criteria, approvals, or comments.

## Instructions

1. Propose a **work tier** (1–4) aligned with organizational definitions supplied in context.
2. Explain **rationale** with blast radius, data sensitivity, operational impact, and contract surface.
3. List **required approvals**, **documentation**, **testing**, and **automation posture** appropriate to the tier.
4. Call out **escalation triggers** (for example migrations, auth changes, regulated data).
5. If information is insufficient, output **questions for humans** and a **conservative default tier** with justification.
6. **Do not** enable the modernization lane for normal bug fixes or small features unless the requirement explicitly describes migration/modernization scope.
7. Examples (advisory): PHP→Java migration → `work_type: modernization`, `work_subtype: legacy_stack_migration`, tier floor 3; on-prem→cloud → `cloud_infra` or `modernization`, `on_prem_to_cloud`, tier 3–4; database migration with production data → `data_migration`, tier 4.

## Output format

- **Proposed tier:** (1–4)
- **Work type:** (bug | feature | enhancement | qa_automation | documentation | modernization | migration | cloud_infra | data_migration | security_compliance | platform | tooling)
- **Work subtype:** (when modernization/migration — e.g. legacy_stack_migration, on_prem_to_cloud, database_migration, ui_modernization, monolith_to_microservices)
- **Modernization lane:** enabled yes/no — set `modernization.enabled: true` only for modernization/migration/cloud/data/platform work; leave false or omit for normal bugs/features
- **Modernization type:** (from `modernization_profile.supported_types` when lane applies)
- **Tier floor recommendation:** minimum tier when modernization applies (e.g. legacy stack migration → Tier 3; UI-only → Tier 2–3)
- **Risk summary:** (short paragraph)
- **Evidence bullets:** (bullet list)
- **Required rigor:** (approvals, docs, tests)
- **Open questions:** (bullet list or "none")
- **Recommended default if ambiguous:** (tier + reason)


---

## Stage Boundary

**Stage:** CLASSIFIED
**Prompt type:** single_stage_operational

**Responsibility:** Propose work tier (1–4), work type, and modernization lane activation from the groomed requirement.

**Allowed:**
- read requirement.md (DoR ready) and G-GROOM approval record
- propose tier, work_type, work_subtype, modernization flag
- recommend appropriate rigor for the tier

**Prohibited:**
- self-confirm the tier without human engineering override
- begin impact analysis or technical planning in the same invocation
- modify product code
- approve G-PLAN
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before classify-work, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files (embedded framework repo, `ai-sdlc/prompts/`, `ai-sdlc/tools/`, `ai-sdlc/schemas/`, `ai-sdlc/policies/`, `ai-sdlc/templates/`, and related framework paths) are **read-only**.
- Project SDLC artifacts must be stored under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** using the format in the governance doc — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user (shell, IDE Git UI, MCP, script, or automation). Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Human action required

Tier classification produced by this prompt is **advisory**. The human engineering lead retains authority to override the proposed tier with documented rationale. Disagreement between AI classification and human judgment must be resolved by the engineering lead before implementation begins. See `ai-sdlc/work-tiers.md` for mandatory human escalation conditions.