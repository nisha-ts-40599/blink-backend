# Prompt: Cloud Readiness Assessment

Assess cloud readiness for on-prem to cloud or cloud infra modernization work.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONTEXT}}`
- `{{PROJECT_CONFIG}}`
- `{{RISK_TIER}}`

## Optional placeholders

- `{{REPOSITORY_CONTEXT}}`
- `{{ARTIFACTS}}`
- `{{APPROVAL_RULES}}`

## Instructions

1. Load workspace `.cursor/ai-sdlc/` context (project-config including `modernization_profile`, workflow-state, prior artifacts).
2. Use `templates/cloud-readiness-assessment-template.md` as the output structure.
3. Save primary output to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/cloud-readiness-assessment.md`.
4. Required only for cloud_migration conditional work. Do not plan production cutover execution (Phase 3).
5. Update workflow-state artifact references:

```yaml
artifacts:
  cloud_readiness_assessment: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/cloud-readiness-assessment.md"
```

6. Update `modernization` block when applicable (strategy, status fields, stack summaries).
7. Run `make ai-sdlc-validate-artifacts` and `make ai-sdlc-stage-router` before advancing stage.

## Output format

Follow all required sections in `cloud-readiness-assessment-template.md`. Mark unknowns as **TBD** with owner questions.


## Scope boundaries

- Modernization lane only — do not execute production cutover or post-migration validation (Phase 3).
- Do not modify product code unless explicitly in an approved implementation step.
- Preserve existing behavior unless approved otherwise in the compatibility contract.

## Safety / data guardrails

- Use **sanitized evidence only** — no secrets, credentials, or customer PII.
- Do not assume microservices or full rewrite by default.
- Follow `{{SECURITY_MODEL}}` and project-config guardrails.


---

## Stage Boundary

**Prompt type:** read_only_analysis
**Stage context:** CLASSIFIED

**Responsibility:** Assess cloud migration readiness without modifying infrastructure.

**Authority:** This prompt performs read-only analysis. It produces no write
mutations, cannot approve gates, cannot advance the workflow, and cannot
perform work belonging to a different stage.

**Prohibited:**
- provision cloud resources
- modify infrastructure configuration
- approve G-DEPLOY

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Human action required

- **Do not approve gates without explicit human evidence.**
- Tier, architecture, and migration strategy decisions require human confirmation.
- Never mark gate approvals or `modernization` status fields as approved without human sign-off.


## Workflow-state update

After human review, advance `current_stage` per stage router suggestion (do not self-advance without human confirmation).
