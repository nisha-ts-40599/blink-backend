# Prompt: Compatibility Contract

Define behavior, API, UI, data, and integration compatibility to preserve during migration.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONTEXT}}`
- `{{PROJECT_CONFIG}}`
- `{{RISK_TIER}}`

## Optional placeholders

- `{{REPOSITORY_CONTEXT}}`
- `{{ARTIFACTS}}`
- `{{APPROVAL_RULES}}`

## Instructions

1. Load workspace `.cursor/ai-sdlc/` context (project-config including `modernization_profile`, workflow-state, prior artifacts).
2. Use `templates/compatibility-contract-template.md` as the output structure.
3. Save primary output to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/compatibility-contract.md`.
4. Preserve existing behavior unless explicit human approval records an approved change.
5. Update workflow-state artifact references:

```yaml
artifacts:
  compatibility_contract: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/compatibility-contract.md"
```

6. Update `modernization` block when applicable (strategy, status fields, stack summaries).
7. Run `make ai-sdlc-validate-artifacts` and `make ai-sdlc-stage-router` before advancing stage.

## Output format

Follow all required sections in `compatibility-contract-template.md`. Mark unknowns as **TBD** with owner questions.


## Scope boundaries

- Modernization lane only — do not execute production cutover or post-migration validation (Phase 3).
- Do not modify product code unless explicitly in an approved implementation step.
- Preserve existing behavior unless approved otherwise in the compatibility contract.

## Safety / data guardrails

- Use **sanitized evidence only** — no secrets, credentials, or customer PII.
- Do not assume microservices or full rewrite by default.
- Follow `{{SECURITY_MODEL}}` and project-config guardrails.


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** SPEC_DRAFTED

**Responsibility:** Define backward-compatibility contracts for APIs or services being changed.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- implement contract changes
- approve G-PLAN

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Human action required

- **Do not approve gates without explicit human evidence.**
- Tier, architecture, and migration strategy decisions require human confirmation.
- Never mark gate approvals or `modernization` status fields as approved without human sign-off.


## Workflow-state update

After human review, advance `current_stage` per stage router suggestion (do not self-advance without human confirmation).
