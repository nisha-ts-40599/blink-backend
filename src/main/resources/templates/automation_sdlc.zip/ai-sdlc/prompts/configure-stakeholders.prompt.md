# Prompt: Configure Stakeholders

Configure canonical stakeholder roles through the guarded role-registry
transaction. Do **not** hand-edit `governance/role-registry.yaml`.

Roles and principals remain separate. One human may hold several canonical roles.

This is the **public** stakeholder mutation command. `/assign-role` is an
advanced/debug alias of the same transaction.

## Required placeholders

- `{{ISSUE}}` is **optional** for workspace-level setup after overlay apply
- Include `{{ISSUE}}` when the router invokes this command because a work-item
  gate is blocked (`required_roles` / `REQUIRED_ROLE_UNASSIGNED`)

## Grammar

Roster (preview current catalog-derived assignments):

```text
/configure-stakeholders
```

Single-role convenience (canonical role id, real name, real email):

```text
/configure-stakeholders product_owner "Ada Example" ada@example.com
```

Bounded bulk body:

```text
/configure-stakeholders

product_owner=Ada Example <ada@example.com>
tech_lead=Ada Example <ada@example.com>
```

Rules:

- `role_id` must be a **current** catalog role
- unknown IDs are rejected
- ambiguous legacy IDs such as `platform_owner` are not guessed
- TBD / placeholder / fake values remain pending and cannot satisfy gates
- never infer identity from git config or OS username
- do not fabricate name/email in router-generated commands

All modes use the same parser, SoD preview, bounded CAS transaction, and audit event.

## Instructions

1. Load the canonical role catalog (`ai-sdlc/registry/role-catalog.yaml`).
2. Load the current role registry (`.cursor/ai-sdlc/governance/role-registry.yaml`).
3. Load applicable policy (`sod-policy.yaml` and gate applicability).
4. Show current assignments, missing standard roles, and conditional roles from catalog metadata.
5. Explain why each conditional role is applicable or not applicable from work characteristics.
6. Collect a deterministic proposed assignment set from the human.
7. Preview the exact before/after diff (role, old principal/status, new principal/status, applicability, SoD, expected revision, digest).
8. Evaluate separation of duties on the **entire** proposed batch before apply.
9. Require explicit human confirmation of the exact role set and principal set.
10. Apply through `/configure-stakeholders` (one confirmation → one bounded CAS). Never edit YAML.

Do not expose Make or Python as the normal journey.

After a **workspace-level** success: authoritative NextAction is
`/plan-product-scope`. Pending catalog roles do **not**
block completing this workspace stakeholder step. Do not require
`/confirm-stakeholders` immediately after configure.

After a **gate-blocked** success: `/sdlc-next {{ISSUE}}`.

## Human action required

A human must name each principal. Do not invent people. Do not auto-map
ambiguous legacy roles such as `platform_owner`.

---

## Stage Boundary

**Stage:** ALL
**Prompt type:** single_stage_operational

**Responsibility:** Configure stakeholder assignments through the canonical role registry.

**Allowed:**
- load catalog, registry, and policy
- present current, missing, conditional, and SoD state
- collect a proposed assignment set
- apply the confirmed set through guarded role authority
- run without an ISSUE when the overlay is applied and no work item exists yet

**Prohibited:**
- hand-edit `governance/role-registry.yaml`
- invent a principal or a fake ISSUE
- auto-resolve ambiguous legacy roles
- approve workflow gates
- replace the authoritative NextAction with this command unless the router selected it
- performing downstream-stage work not listed under Allowed

**Completion:** apply the confirmed bounded transaction, return a structured handoff, then stop.

**Handoff:** `/plan-product-scope` after workspace-level configure;
`/sdlc-next {{ISSUE}}` when a work item already exists.
