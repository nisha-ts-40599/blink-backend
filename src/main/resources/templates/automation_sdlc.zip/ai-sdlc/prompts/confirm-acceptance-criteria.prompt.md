# Prompt: Confirm Acceptance Criteria

Record human confirmation of acceptance criteria in canonical workflow state.
Prose that says criteria are confirmed is not enough — machine
`confirmation_status` must become `CONFIRMED` in the same transaction.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`

## Instructions

Collect from the human:

- Confirmed by: `Name:email` (canonical confirmer role: `product_owner` or `business_analyst`)
- Scope: `ALL` or a specific `AC-001`

Normal command:

```text
/confirm-acceptance-criteria {{ISSUE}}
```

Do not require the operator to know an internal Make target for the normal journey.
Advanced/debug only:

```bash
make ai-sdlc-update-ac ROOT=<workspace-root> ISSUE=<ISSUE-ID> \
  AC_ID=ALL CONFIRMED_BY="<Name:email>" WRITE=1
```

After success: `/sdlc-next {{ISSUE}}`.

## Human action required

A named human must confirm acceptance criteria. Do not mark criteria confirmed from AI prose alone.

---

## Stage Boundary

**Stage:** REQUIREMENT
**Prompt type:** single_stage_operational

**Responsibility:** Record human confirmation of acceptance criteria in canonical workflow state.

**Allowed:**
- read workflow-state acceptance-criteria records
- collect confirmer identity and AC scope from a human
- run `make ai-sdlc-update-ac` only after that human confirms

**Prohibited:**
- mark criteria confirmed from AI prose alone
- invent confirmer identity
- approve G-GROOM or any other gate
- begin classification, planning, or implementation
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** persist confirmation when the human supplies identity and scope, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`
