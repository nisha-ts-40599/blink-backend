# Prompt: Confirm Product Scope

Confirm a proposed product-scope revision. Bind confirmation to the exact
proposal digest and current product-scope revision. Do **not** hand-edit YAML.

## Required placeholders

- `{{ISSUE}}` is **optional** (workspace-level)

## Grammar

```text
/confirm-product-scope
```

The operator confirms the exact proposal produced by `/plan-product-scope`.
Stale digest confirmation must fail closed.

## Instructions

1. Load the current PROPOSED product-scope revision and digest.
2. Show the human the proposal (or refresh delta).
3. Require explicit human confirmation of that digest/revision.
4. Apply confirmation through the canonical product-scope mutation service.
5. Preserve previous confirmed history. Increment `product_scope_revision`.
6. Do not start implementation. Do not create external tickets.

If active work is impacted, record invalidation evidence and leave historical
approvals immutable.

## Human action required

A named human must confirm the exact proposal digest. No write occurs without
that confirmation.

---

## Stage Boundary

**Stage:** PRODUCT_SCOPE_CONFIRMATION
**Prompt type:** single_stage_operational

**Responsibility:** Confirm the proposed product-scope revision as canonical backlog authority.

**Allowed:**
- bind confirmation to digest/revision
- persist confirmed product-scope artifacts through the mutation service
- record active-work invalidation pointers
- run without an ISSUE

**Prohibited:**
- confirm a stale proposal
- start `/sdlc-start` automatically
- create tracker tickets
- approve workflow gates
- ignore SoD rules
- hand-edit YAML
- performing downstream-stage work not listed under Allowed

**Completion:** persist the confirmed revision, return a structured handoff, then stop.

**Handoff:** `/sdlc-start <confirmed-work-item-id>`
