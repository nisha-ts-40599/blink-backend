# Prompt: Confirm Stakeholders

Confirm that the current role-registry assignments are still current.
This is freshness confirmation only — not gate approval and not assignment.

## Required placeholders

- `{{ISSUE}}` (optional)

## Instructions

1. Inspect the current role registry.
2. Present current assignments, missing roles, and unresolved legacy roles.
3. Confirm the current assignments against the current registry revision/digest.
4. Record confirmer and timestamp.

Normal command:

```text
/confirm-stakeholders
```

This command MUST NOT:

- invent missing roles
- assign missing principals
- resolve legacy ambiguity automatically
- bypass SoD or applicability
- authorize workflow gates

If assignments need to change, stop and recommend `/configure-stakeholders`.

`/confirm-stakeholders` is **not** required immediately after `/configure-stakeholders`.
Configure already performs human confirmation, revision-bound CAS, and an audit event.
Use this command for existing-workspace freshness: the roster is unchanged.

After success: `/plan-product-scope` at workspace level, or `/sdlc-next {{ISSUE}}` when a work item exists.

## Human action required

A named human must confirm that the current stakeholder assignments are still
current. Confirmation is bound to the current role-registry revision and digest.

This confirmation:

- does not assign missing principals
- does not approve workflow gates
- does not bypass SoD or role applicability
- does not resolve legacy-role ambiguity (including `platform_owner`)

No write occurs unless the human uses the existing guarded confirmation path:

```text
/confirm-stakeholders
```

Persist only through that command's `--write` / `WRITE=1` path. Dry-run is the
default. Do not hand-edit YAML.

---

## Stage Boundary

**Stage:** ALL
**Prompt type:** single_stage_operational

**Responsibility:** Record stakeholder-configuration freshness bound to the current registry revision.

**Allowed:**
- inspect the current role registry
- record a revision-bound confirmation

**Prohibited:**
- invent or assign principals
- migrate ambiguous legacy roles
- approve gates
- hand-edit YAML
- performing downstream-stage work not listed under Allowed

**Completion:** record the confirmation event, return a structured handoff, then stop.

**Handoff:** `/sdlc-next {{ISSUE}}`
