# Prompt: Confirm Repository Topology

Record human topology confirmation on the canonical setup intake:

`.cursor/ai-sdlc/setup/project-initialisation-input.yaml`

Do **not** edit generated `workspace-config.yaml` or repository projections as authority.

## Required placeholders

- `{{ISSUE}}`

## Instructions

Collect from the human:

- Structure: `single-repo` | `monorepo` | `multi-repo`
- Roster (required for multi-repo): repository ids
- Confirmed by: `Name:email`
- Evidence ref: meeting note, ticket, or written confirmation

```bash
make ai-sdlc-confirm-topology ROOT=<workspace-root> \
  STRUCTURE=<structure> CONFIRMED_BY="<Name:email>" \
  EVIDENCE_REF="<ref>" WRITE=1
```

Then run the canonical apply if the human asked to persist overlay projections:

```bash
make ai-sdlc-greenfield-setup-apply ROOT=<workspace-root> \
  INPUT=.cursor/ai-sdlc/setup/project-initialisation-input.yaml
```

After success: `/sdlc-next {{ISSUE}}`.

## Human action required

Topology confirmation requires a named human and evidence. Generated projections are not authority.

---

## Stage Boundary

**Stage:** BOOTSTRAP_PLANNING
**Prompt type:** single_stage_operational

**Responsibility:** Record human topology confirmation on canonical setup intake; generated projections are not authority.

**Allowed:**
- collect structure, roster, confirmer identity, and evidence ref from a human
- write confirmation onto `project-initialisation-input.yaml` via the canonical command
- run greenfield-setup-apply only when the human asked to persist overlay projections

**Prohibited:**
- treat generated `workspace-config.yaml` or repository projections as authority
- invent confirmer identity or evidence
- approve G-BOOTSTRAP or begin implementation
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** record topology confirmation when the human supplies identity and evidence, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`
