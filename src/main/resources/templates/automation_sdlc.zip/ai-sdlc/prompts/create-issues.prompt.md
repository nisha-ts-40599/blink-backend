# Prompt: Create Issues from Specification

You are a delivery lead decomposing a specification into tracker-ready issues.

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{REQUIREMENT}}`
- `{{ACCEPTANCE_CRITERIA}}`
- `{{RISK_TIER}}`
- `{{APPROVAL_RULES}}`

## Optional placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{ARTIFACTS}}`

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/issue-breakdown.md`.
If no issue ID exists, use `.cursor/ai-sdlc/workflow-state/unassigned/issue-breakdown.md` and flag that a real issue ID should be created.

## Workflow-state registration

After saving, update workflow state:

```yaml
artifacts:
  issue_breakdown: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/issue-breakdown.md"
```

## Issue tracker guidance

Use normalized issue metadata from the configured `issue_tracking` provider when available. Supported providers may include Jira, Azure DevOps, GitHub Issues, Linear, generic, or manual. Do not assume any specific tracker.

If tracker integration is unavailable or `provider: manual`, use the issue details supplied by the human or groom-prep bundle. Do not fabricate issue title, description, acceptance criteria, status, labels, comments, or approval records.

AI may draft issue bodies for human review. A human or approved tracker tooling creates or updates tracker issues. Do not create tracker issues unless explicitly requested by a human.

## Instructions

1. Propose a **parent issue** (epic) if beneficial; otherwise a flat list.
2. For each issue, supply: **title**, **description**, **acceptance criteria**, **labels** (including tier), **dependencies**, **estimate hint** (T-shirt only unless org allows points).
3. Ensure every acceptance criterion from the spec is **mapped** to at least one issue or explicitly marked deferred with rationale.
4. Avoid micro-tasks that violate team granularity norms; merge trivial items when sensible.

## Output format

- **Issue list** (each with markdown body ready to paste)
- **Dependency graph** (textual)
- **Deferred items** (if any)


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** REQUIREMENT

**Responsibility:** Draft issue records from groomed requirements or triage findings for human confirmation.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- create issues in the tracker without explicit human confirmation
- begin implementation

**Handoff:** → human confirms and creates issues → /groom-prep

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before create-issues, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files are **read-only**; store project artifacts under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user. Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Human action required

Issue drafts produced by this prompt must be reviewed by the engineering lead or product owner before being created in the project tracker. Acceptance criteria, dependency links, and tier labels must be verified by a human. AI must not create issues in the tracker autonomously.
