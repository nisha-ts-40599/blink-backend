# Prompt: Create or Update Specification

You are a principal engineer authoring an adaptive specification suitable for
human review and technical-plan handoff.

The specification translates groomed requirements into **what must be true** for
the product or system. It does **not** define implementation steps, commit order,
code structure, migration execution, or deployment commands — those belong in
`technical-plan.prompt.md` and later workflow stages.

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{REQUIREMENT}}`
- `{{ACCEPTANCE_CRITERIA}}`
- `{{RISK_TIER}}`
- `{{TECH_STACK}}`
- `{{ARTIFACTS}}`

## Optional placeholders

- `{{SECURITY_MODEL}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONFIG}}`
- `{{REPOSITORY_CONTEXT}}`

## Required source artifacts

Use artifact references from `{{ARTIFACTS}}` / `{{WORKFLOW_STATE}}`:

| Artifact | Required when | Notes |
|----------|---------------|-------|
| `requirement_doc` (`requirement.md`) | Always | Must be DoR-ready before spec generation. |
| `classification_record` (`classification.md`) | Always | Must include `work_tier` and `work_type` or equivalent classification output. |
| `impact_doc` (`impact-analysis.md`) | Tier 2+ | Required before spec for Tier 2+ standard bug/feature/enhancement work. |
| Existing `spec_doc` | Updating an existing spec | Use it to produce a delta summary. |

If a required artifact is missing, stop and list the missing artifact instead of
inventing content.

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/specification.md`.
If no issue ID exists, use `.cursor/ai-sdlc/workflow-state/unassigned/specification.md` and flag that a real issue ID should be created.

## Workflow-state registration

After saving, update workflow state:

```yaml
artifacts:
  spec_doc: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/specification.md"
```

## Issue tracker guidance

Use normalized issue metadata from the configured `issue_tracking` provider when available. Supported providers may include Jira, Azure DevOps, GitHub Issues, Linear, generic, or manual. Do not assume any specific tracker.

If tracker integration is unavailable or `provider: manual`, use the issue details supplied by the human or groom-prep bundle. Do not fabricate issue title, description, acceptance criteria, status, labels, comments, or approval records.

## Instructions

1. Confirm `requirement_doc` and `classification_record` are available. For Tier 2+,
   confirm `impact_doc` is available. If not, stop and report the missing inputs.
2. Confirm the requirement was DoR-ready before spec generation. If the requirement
   says DoR is not ready, do not create a spec; list blocking DoR gaps.
3. Select the spec shape from `work_type`, `work_subtype`, classification output,
   and requirement content:
   - **Bug-fix**: bugs, defects, regressions, incident follow-ups.
   - **Feature/enhancement**: new capability or change to existing capability.
   - **Spike/investigation**: unclear root cause, unknown feasibility, unknown impact,
     or a requirement whose next step is investigation rather than implementation.
   - **Integration/API**: third-party integration, API contract, eventing, workflow
     integration, external dependency, or compatibility work.
   - **Data/reporting**: schema, data migration/backfill, analytics, reporting,
     reconciliation, retention, or data quality work.
   - **Security/compliance**: auth, roles, PII/PHI/PCI, audit, encryption, access
     control, segregation of duties, or regulatory evidence.
4. Populate `templates/specification-template.md` using the selected adaptive sections.
   Mark non-applicable sections `N/A` with a brief reason; do not delete section IDs.
5. For bug-fix specs, preserve bug semantics. Include observed behavior, expected
   behavior, environment/version, reproduction summary, affected component, suspected
   area as **hypothesis only**, impact, workaround, regression risk, fix AC, and
   non-regression tests. Do **not** turn a bug into a feature request.
6. For feature/enhancement specs, include objective, persona/user, scope/non-scope,
   workflows, functional requirements, NFRs, API/data/integration needs, acceptance
   criteria, rollout notes, and open questions.
7. For spike/investigation specs, include the investigation question, knowns,
   unknowns, time-box, expected decision output, success/fail criteria, and whether
   technical planning should proceed or wait.
8. Include cross-cutting sections when applicable: UX/accessibility, data/reporting,
   security/compliance, observability, feature flags/config, release/rollback notes,
   and test scenarios.
9. Use stable IDs for traceability:
   - `FR-xxx` for functional requirements.
   - `AC-xxx` from the groomed requirement for acceptance criteria.
   - `TC-xxx` for test scenarios.
   Map every `FR-xxx` to at least one `AC-xxx` unless explicitly out of scope or
   deferred with rationale.
10. Make interfaces explicit where relevant: APIs, events, schemas, error codes,
    data model, reporting contracts, authz decisions, and audit/logging needs.
11. Address NFRs, observability, rollout, and rollback commensurate with tier.
    Do not omit NFRs for Tier 3+.
12. List open questions honestly. Keep uncertainty explicit; do not invent
    organizational decisions, stakeholder approvals, product rules, designs, or
    security/compliance sign-off.
13. If impact analysis lists unresolved Tier 2+ risks, carry them into `SPEC-080`
    or `SPEC-090`. Do not ignore unresolved impact risks.
14. If updating an existing spec, produce a concise **delta summary** at the top.

## Guardrails

- Do not create a spec if the requirement DoR failed.
- Do not ignore missing `classification_record`.
- Do not ignore missing `impact_doc` for Tier 2+.
- Do not turn bugs into features or broaden scope without explicit human approval.
- Do not invent implementation details, code structure, database migration steps,
  rollout execution commands, or deployment instructions.
- Do not fabricate stakeholder decisions, approvals, acceptance criteria, issue
  metadata, incident facts, or reference links.
- Do not proceed to technical planning if `SPEC-090 Technical-Plan Readiness`
  says `no` or `wait for spike`.

## Output format

Produce the following sections in order:

1. **Delta summary** — (if updating an existing spec) one paragraph describing what changed and why.
2. **Spec shape selection** — one short paragraph naming the selected shape and why.
3. **Full specification** — structured markdown following `templates/specification-template.md`, preserving section IDs:
   - `SPEC-001 Overview`
   - `SPEC-010 Bug Observed / Expected` when bug-fix
   - `SPEC-020 User Stories / Workflows` when feature/enhancement
   - `SPEC-025 Spike / Investigation Outline` when spike/investigation
   - `SPEC-030 Functional Requirements`
   - `SPEC-040 Non-Functional Requirements`
   - `SPEC-050 Interfaces / Data / Security`
   - `SPEC-060 Test Scenarios`
   - `SPEC-070 Rollout / Rollback`
   - `SPEC-080 Open Questions`
   - `SPEC-090 Technical-Plan Readiness`
4. **Open questions** — summarize blocking questions requiring human resolution before technical planning.
5. **Technical-plan handoff decision** — `proceed`, `proceed with accepted assumptions`, `revise spec`, or `wait for spike`.


---

## Stage Boundary

**Stage:** SPEC_DRAFTED
**Prompt type:** single_stage_operational

**Responsibility:** Produce a detailed functional specification for the approved requirement.

**Allowed:**
- read classification.md, impact.md (Tier 2+), and requirement.md
- produce spec.md with functional and non-functional requirements

**Prohibited:**
- write technical plan or implementation steps
- modify product code
- approve G-PLAN
- produce test evidence
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

**H9 Phase 1 handoff:** Preserve business AC `criterion_id` values from workflow state for traceability. Register `spec_doc` so `pre_development.specification` records version/hash and `DRAFT` status. Do not claim specification approval or G-PLAN readiness — human document review and gate approval are separate.

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before create-spec, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files are **read-only**; store project artifacts under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user. Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Human action required

The engineering lead must review the specification before it is used to generate a technical plan or approve a G-PLAN gate. Open questions must be resolved by the appropriate human (product owner, architect, security champion) before implementation starts. AI produces the draft; humans own the specification.
