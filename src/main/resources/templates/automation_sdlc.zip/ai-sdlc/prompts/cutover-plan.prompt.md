# Prompt: Cutover Plan

Draft a production cutover plan for modernization/migration work. Planning only — do not execute production actions.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONTEXT}}`
- `{{PROJECT_CONFIG}}`
- `{{RISK_TIER}}`
- `{{RELEASE_CONTEXT}}`

## Optional placeholders

- `{{ARTIFACTS}}`
- `{{APPROVAL_RULES}}`
- `{{ENVIRONMENT}}`

## Instructions

1. Load workspace `.cursor/ai-sdlc/` context including `cutover_policy` and prior migration artifacts.
2. Use `templates/cutover-plan-template.md` as the output structure.
3. Save output to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/cutover-plan.md`.
4. Update workflow-state artifact reference:

```yaml
artifacts:
  cutover_plan: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/cutover-plan.md"
```

5. Update `cutover` block status fields (`status: planning`) — do not set `executed` or `approved` without human evidence.
6. Run `make ai-sdlc-validate-artifacts` and `make ai-sdlc-stage-router` before advancing stage.

## Scope boundaries

- Cutover-active modernization/migration work only.
- **Do not execute production cutover, traffic switches, database changes, or deployments.**
- Do not modify product infrastructure or run deployment commands.

## Safety / data guardrails

- Sanitized evidence only — no secrets, credentials, or customer PII.
- Document rollback trigger points and no-go conditions explicitly.


---

## Stage Boundary

**Stage:** PLAN_DRAFTED
**Prompt type:** single_stage_operational

**Responsibility:** Produce a detailed cutover plan for migration or deployment.

**Allowed:**
- read migration-strategy.md and rollback-readiness-review.md
- produce cutover-plan.md with sequenced cutover steps

**Prohibited:**
- execute cutover or disable production traffic
- self-approve G-CUTOVER
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** G-CUTOVER — human-only: make ai-sdlc-approve-gate GATE=G-CUTOVER DECISION=approved WRITE=1

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `→ human approves G-CUTOVER → make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

## Human action required

- **Do not approve gates without explicit human evidence.**
- Cutover window and owners require human confirmation.
- Never mark `g_cutover`, `cutover.approved`, or `cutover.executed` without human sign-off.

## Workflow-state update

After human review, advance `current_stage` per stage router suggestion only with human confirmation.
