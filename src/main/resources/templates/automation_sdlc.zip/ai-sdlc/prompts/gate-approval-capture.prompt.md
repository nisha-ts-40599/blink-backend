# Prompt: Gate Approval Capture

Capture **manual** or **MCP-assisted** approval evidence for human gates. Never self-approve.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{APPROVAL_RECORDS}}`

## Optional placeholders

- `{{HUMAN_NOTES}}`
- `{{AVAILABLE_ARTIFACTS}}`
- `{{RISK_TIER}}`

## Instructions

1. Identify which gate(s) need recording (G-PLAN, G-SEC, G-QA, G-PR-MERGE, G-DEPLOY).
2. Extract approval evidence from the human-provided source only — Jira/Slack/Teams/Outlook/PR comment or explicit pasted text.
3. Treat vague approval text (`looks good`, `LGTM`, `+1` without context) as **`needs_confirmation`** — do not mark the gate approved.
4. For **`approved_with_conditions`**, list each condition and set `conditions_met: false` until a human confirms each item.
5. Produce a **gate-review record** draft at `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/gate-review-record.md` with sanitized excerpts only.
6. Propose workflow-state YAML updates — **do not write workflow-state unless the user explicitly asks**.

## Evidence schema

```yaml
gates:
  g_plan:
    required: true
    approved: true
    approver: "Name <email>"
    approved_at: "2026-06-19T12:00:00Z"
    comment_url: "https://..."
    conditions: []
    conditions_met: true
    evidence:
      source_type: jira | slack | teams | outlook | pr | manual
      source_ref: "<safe URL or local artifact path>"
      approved_by: "Name <email>"
      approved_at: "2026-06-19T12:00:00Z"
      decision: approved | rejected | approved_with_conditions | needs_confirmation
      conditions: []
```

## Output format

- **Gate(s) assessed**
- **Decision per gate** (approved / rejected / approved_with_conditions / needs_confirmation)
- **Evidence summary** (sanitized)
- **Proposed workflow-state patch** (YAML block)
- **Human action required** if confirmation is needed


---

## Stage Boundary

**Stage:** VARIES
**Prompt type:** gate_capture

**Responsibility:** Record a human gate approval decision in workflow-state.

**Allowed:**
- read human approval decision, gate name, approver identity, and evidence reference
- persist gate approval record

**Prohibited:**
- self-approve any gate without human authorization input
- fabricate human decisions
- advance the stage without the actual human approval
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** VARIES — gate names from ai-sdlc/governance/approval-gates.md

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-approve-gate GATE=<gate> DECISION=approved WRITE=1 → make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

## Human action required

Only a named human approver may approve gates. AI must never set `approved: true` without explicit human approval text and a verifiable reference.
