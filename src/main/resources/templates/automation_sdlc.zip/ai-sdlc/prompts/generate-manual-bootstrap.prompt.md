# Prompt: Generate Manual Bootstrap Instructions

Render a **manual instruction pack** from an approved bootstrap plan.

**Rendering only — do not execute commands.**

## Required placeholders

- `{{GREENFIELD_SPEC_PATH}}`

## Optional placeholders

- `{{HUMAN_NOTES}}`

## Instructions

1. Validate the bootstrap plan:

```bash
make ai-sdlc-validate-bootstrap-plan PLAN=<plan-path> SPEC={{GREENFIELD_SPEC_PATH}}
```

2. Confirm G-BOOTSTRAP plan approval and approved plan hash match.
3. Generate instructions from the plan (not from free-form planning):

```bash
make ai-sdlc-generate-manual-bootstrap PLAN=<plan-path> OUTPUT=<package>/manual-bootstrap-instructions.md WRITE=1
```

4. Update setup-state with `manual_instruction_ref` (references and hashes only).
5. Transition lifecycle to `instruction_pack_generated`, then `manual_action_required`.
6. Direct user to execute instructions externally and later run existing-* refresh.
7. Do **not** claim actions are complete. Do **not** set readiness true.

The instruction pack is a derived human-readable rendering of `bootstrap-plan.yaml`.

## Output format

1. Validation result for bootstrap plan
2. Path to generated `manual-bootstrap-instructions.md`
3. Instruction hash and source plan hash
4. Setup-state reference updates (references only)
5. Handoff reminder for existing-* refresh


---

## Stage Boundary

**Stage:** BOOTSTRAP_PLANNING
**Prompt type:** single_stage_operational

**Responsibility:** Generate human-executable manual bootstrap instruction pack from an approved bootstrap plan.

**Allowed:**
- read G-BOOTSTRAP-approved bootstrap-plan.yaml
- produce manual-bootstrap-instructions.md

**Prohibited:**
- execute bootstrap steps directly
- create repositories or scaffold without human execution
- claim delivery_ready after generating instructions
- begin implementation of business requirements
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `→ human executes instructions externally → /setup-existing-project refresh → make ai-sdlc-validate-setup-readiness REQUIRE=delivery`

## Human action required

A human must execute all manual bootstrap steps outside AI-SDLC. Manual completion evidence does not grant readiness without existing-* refresh and validation.
