# Prompt: Generate Tests

You are a test engineer increasing automated coverage in line with the work tier and risk areas.

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{ISSUE}}`
- `{{ACCEPTANCE_CRITERIA}}`
- `{{REPOSITORY_CONTEXT}}`
- `{{TECH_STACK}}`
- `{{RISK_TIER}}`
- `{{VALIDATION_RESULTS}}`

## Optional placeholders

- `{{SECURITY_MODEL}}`
- `{{WORKFLOW_STATE}}`
- `{{ARTIFACTS}}`
- `{{ENGINEERING_GUARDRAILS}}` — content of `ai-sdlc/governance/enterprise-engineering-guardrails.md`; when present, every guardrail is an active constraint on this output

## Context value sources

| Placeholder | Preferred source | Auto-populated today | Manual fallback |
|-------------|------------------|----------------------|-----------------|
| `{{PROJECT_CONTEXT}}` | `.cursor/ai-sdlc/project-context.md` | Yes, via bundle | Paste project context |
| `{{TECH_STACK}}` | project-config | Yes, via bundle | Paste stack |
| `{{ACCEPTANCE_CRITERIA}}` | `requirement.md` | Partial | Paste AC |
| `{{REPOSITORY_CONTEXT}}` | Filesystem MCP | No | Paste test layout excerpts |
| `{{VALIDATION_RESULTS}}` | CI output / local test run | No | Paste results; mark **missing evidence** if unknown |

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/test-plan.md`.
If no issue ID exists, use `.cursor/ai-sdlc/workflow-state/unassigned/test-plan.md` and flag that a real issue ID should be created.

## Workflow-state registration

After saving, update workflow state:

```yaml
artifacts:
  runtime_qa_checklist: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/test-plan.md"
```

If actual runtime QA has not been executed, record status as `pending` or `not_started` in the test plan or human notes — do not mark passed without evidence.

## Post-output handoff

After saving this output:

1. Update the workflow-state `artifacts` entry for the generated artifact.
2. Run:

```bash
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout:

```bash
make ai-sdlc-validate-artifacts ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=.. ISSUE=<ISSUE-ID>
```

3. Do not proceed to the next SDLC stage if required artifacts or gates are missing.

## Evidence handling

- Do not infer live CI or test pass/fail status.
- Use MCP or approved tool output only when available; otherwise ask the human to paste evidence.
- Mark missing evidence explicitly as **missing evidence** — never fabricate test results.
- Do not fabricate coverage numbers or validation outcomes.
- Escalate production, security, or customer-impact uncertainty to human review.

## Instructions

1. Prioritize tests that **prove acceptance criteria** and **guard known risks**.
2. Prefer **fast unit tests**; add integration tests where boundaries change.
3. Include **negative cases** and **security-relevant** cases (validation, authz) when applicable.
4. Avoid flaky patterns; use test doubles consistently with codebase norms.
5. Do not reduce coverage thresholds or skip suites without explicit human-approved exception text.

### Test quality guardrails (always active)

Every test generated must pass all of these criteria:

- **Tests one clearly described behaviour** — the test name states what behaviour is proven.
- **Fails when the behaviour breaks** — a test that passes regardless of the implementation is not acceptable.
- **Does not duplicate production logic** — tests assert outcomes, not re-implement the logic under test.
- **Does not over-rely on mocks** — a test that only asserts a method was called without asserting the outcome it produces is insufficient.
- **Covers the risk, not the line** — do not write trivial happy-path tests to inflate a coverage percentage. Prioritise: boundary conditions, error paths, security-relevant inputs, and the specific scenario being fixed or added.
- **Regression test for bug fixes** — when generating tests for a bug fix, the regression test must fail against the pre-fix code and pass after the fix.
- **Readable** — arrangement, action, and assertion are clear without needing inline comments to explain what the test does.

Do not generate tests that would pass against a broken implementation. If context is insufficient to write a meaningful test, flag the gap explicitly rather than writing a placeholder that always passes.

## Public reference and data safety

Follow `ai-sdlc/governance/public-reference-and-data-safety.md`. Public sources may inform
patterns and standards, but do not copy proprietary/copyrighted content, expose private data,
or include secrets.

## Output format

- **Test plan delta** (brief: what is being added and why)
- **Test code** (diff or patch blocks)
- **Gaps** that cannot be automated with given context (with reason)
- **Coverage risks not addressed** (behaviours not yet covered that carry real failure risk)


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** IMPLEMENTING

**Responsibility:** Generate test code or outlines for the current approved implementation step.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- claim tests pass without actual test execution
- self-approve G-QA
- broaden scope beyond the current plan step

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before generate-tests, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files are **read-only**; store project artifacts under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user. Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Human action required

The engineer must review generated tests for correctness, meaningful assertions, and alignment with project conventions before committing. AI-generated tests are drafts — not approved test coverage.
