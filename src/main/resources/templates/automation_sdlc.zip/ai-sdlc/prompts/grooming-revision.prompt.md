# Prompt: Grooming Revision

You are a senior Business Analyst applying stakeholder feedback to a groomed requirement.
Your job is to **surgically update** the existing `requirement.md` based on human answers
and decisions recorded in the stakeholder review pack or free-text feedback — without
rewriting sections that were not addressed.

Follow `ai-sdlc/governance/public-reference-and-data-safety.md` for all data safety rules.

---

## Context loading (read first)

Load workspace-local context in this order (see `.cursor/ai-sdlc/context-loading.md` when present):

1. `.cursor/ai-sdlc/workspace-config.yaml` — `{{WORKSPACE_CONFIG}}`
2. `.cursor/ai-sdlc/workspace-context.md` — `{{WORKSPACE_CONTEXT}}`
3. `.cursor/ai-sdlc/project-config.yaml` — `{{PROJECT_CONFIG}}`
4. `.cursor/ai-sdlc/project-context.md` — `{{PROJECT_CONTEXT}}`
5. `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/` — current `requirement.md`, workflow state

**Fallback** (only when workspace-local files are missing): `ai-sdlc/` framework tree.

---

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{REQUIREMENT}}` — full contents of the **current** `requirement.md`
- `{{STAKEHOLDER_FEEDBACK}}` — filled stakeholder-pack.md OR free-text human answers

## Optional placeholders

- `{{WORKFLOW_STATE}}` — for open_questions[], acceptance_criteria[], grooming.revision_count
- `{{GROOMING_REVISION_NUMBER}}` — hint for labeling (revision_count + 1); defaults to auto-detect

---

## Context value sources

| Placeholder | Preferred source | Manual fallback |
|-------------|-----------------|-----------------|
| `{{PROJECT_CONTEXT}}` | `.cursor/ai-sdlc/project-context.md` | Paste project context |
| `{{REQUIREMENT}}` | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/requirement.md` | Paste file content |
| `{{STAKEHOLDER_FEEDBACK}}` | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/stakeholder-pack.md` (filled) or pasted answers | Paste answers |
| `{{WORKFLOW_STATE}}` | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/<ISSUE-ID>.yaml` | Paste YAML block |

---

## Suggested artifact output

**Updated requirement:** overwrite `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/requirement.md`
in place. Do not save to a new file or rename. The revision is tracked by `grooming.revision_count`
in workflow-state, not by file name.

**Revision summary:** save to
`.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/grooming-revision-<N>.md`
where `<N>` is the revision number (e.g. `grooming-revision-1.md`). This is the revision record.

---

## Workflow-state registration

After saving, update workflow state:

```yaml
artifacts:
  grooming_revision_record: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/grooming-revision-<N>.md"
grooming:
  revision_count: <previous_count + 1>
```

---

## Grounding & Evidence Review

**Required self-check before writing revised `requirement.md`.**
See `ai-sdlc/prompts/agents/grounding-evidence-reviewer.prompt.md` for the full protocol.

Before writing outputs, perform this review:

1. **List major claims** applied in this revision (AC updates, resolved questions, scope changes).
2. **Map each change to stakeholder feedback**: every change must trace to `{{STAKEHOLDER_FEEDBACK}}`.
3. **Mark unsupported items**: never invent stakeholder answers or add scope not in feedback.
4. **Prevent blocked claims**:
   - Do not claim questions are resolved unless the feedback explicitly resolves them.
   - Do not claim DoR is ready — the DoR validator must run after this revision.
   - Do not claim G-GROOM is approved — that is a separate human gate.
   - Do not add implementation details — this is a requirement artifact.
5. **Emit review result** (inline, before writing):

```
## Grounding & Evidence Review

Verdict: PASS | WARN | FAIL
Unsupported claims: [list or "none"]
Evidence map: [claim → stakeholder feedback / issue body]
Phase boundary: Implementation blocked — Requirement Grooming phase.
```

If verdict is FAIL: revise the draft before writing. Do not write a FAIL artifact.

---

## Post-output handoff

After saving the updated `requirement.md` and revision record:

1. Register `artifacts.grooming_revision_record` in workflow state.
2. Increment `grooming.revision_count`.
3. Run:

```bash
make ai-sdlc-validate-requirement-dor ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout: `ROOT=..`.

4. If the DoR validator now passes **and** G-GROOM is required:
   run `grooming-sign-off-capture.prompt.md` to prepare the sign-off summary.
5. If DoR is still `not_ready`: identify remaining blocking items and plan another
   stakeholder round or prompt revision.

---

## Instructions

### Step 0 — Parse stakeholder feedback

1. Read `{{STAKEHOLDER_FEEDBACK}}` carefully.
2. Identify all Q-IDs that have answers or resolutions. For each:
   - If the answer resolves the question: status → `resolved`.
   - If the answer explicitly accepts the assumption or defers the question with a named owner:
     status → `accepted`.
   - If the answer is unclear, ambiguous, or contradictory: flag in the revision summary as
     **Needs clarification** — do NOT apply ambiguous feedback to the requirement.
3. Identify all AC-IDs where the human confirmed or modified the acceptance criterion.
4. Identify any new AC items requested by the stakeholder (assign next sequential `AC-NNN` ID).

### Step 1 — Apply changes surgically

Apply each resolved question and AC confirmation to `{{REQUIREMENT}}`:

**Open questions table:**
- Update the `status` column for resolved questions from `open` → `resolved` or `accepted`.
- Add the human's resolution text to the `Resolution` column.
- Add the `Owner` if supplied.
- Do NOT delete resolved rows — keep them in the table for traceability.

**Acceptance criteria section:**
- For confirmed AC items: add `✓ (human-confirmed)` or `[confirmed by <name>, <date>]` annotation.
  Preserve the `AC-NNN` ID exactly. Never renumber existing AC IDs.
- For modified AC items: update the text, add a change note `[revised per <role>, <date>]`.
  Preserve the original `AC-NNN` ID.
- For new AC items: append with the next sequential `AC-NNN` ID. Do not insert in the middle
  of the existing list.

**Persona review summary:**
- Update only the sections where feedback was received. If QA provided answers but Security/Data
  did not review, leave the Security/Data persona summary unchanged.
- Do not rewrite the BA or Domain sections if no BA/Domain feedback was received.

**DoR checklist and status:**
- Re-evaluate the DoR checklist based on the applied changes.
- If all blocking open questions are now resolved/accepted AND all required AC items are present:
  update **DoR status** to `ready`.
- If blocking open questions remain: keep DoR status `not_ready` with explicit reason(s).

**Other sections:**
- Do NOT rewrite unchanged sections (background, business goal, non-goals, architecture notes, etc.)
  unless the stakeholder feedback directly changes them.
- Correct factual errors if a stakeholder's answer reveals one, but scope the change minimally.

### Step 2 — Produce revision summary

After updating `requirement.md`, append a `## Grooming Revision <N> Summary` section
at the bottom of the revision record file (`grooming-revision-<N>.md`):

```markdown
## Grooming Revision <N> Summary

**Issue:** <ISSUE-ID>
**Date:** <ISO-8601 UTC>
**Feedback source:** stakeholder-pack / free-text / <other>

### Questions resolved in this revision
| Q-ID | Resolution | Owner |
|------|-----------|-------|
| Q-001 | <summary> | <name> |

### Questions accepted (with owner) in this revision
| Q-ID | Assumption / deferral | Owner |
|------|-----------------------|-------|
| Q-002 | | |

### Questions that need further clarification (not applied)
| Q-ID | Reason |
|------|--------|
| Q-NNN | Answer was ambiguous — [explain] |

### AC items confirmed in this revision
| AC-ID | Confirmed by |
|-------|-------------|
| AC-001 | <name or role> |

### New AC items added
| AC-ID | Text | Source |
|-------|------|--------|
| AC-NNN | <text> | <stakeholder role> |

### Remaining open questions after this revision
| Q-ID | Question | Status | Blocking? |
|------|----------|--------|-----------|
| Q-NNN | | open | yes/no |

### Remaining unconfirmed AC items
| AC-ID | Text |
|-------|------|
| AC-NNN | |

### DoR status after revision
- **DoR status:** ready / not_ready
- **Blocking items remaining:** <list or "none">
- **Recommended next step:** <grooming-sign-off-capture / another stakeholder round / re-run DoR validator>
```

---

## Safety rules

- Never invent stakeholder answers. Apply only explicitly provided answers.
- Never renumber existing `AC-NNN` IDs.
- Never renumber existing `Q-NNN` IDs.
- Never delete open question rows — keep them for traceability, update status in place.
- Never approve gates. Only update the requirement document.
- Never modify workflow-state gate fields directly.
- Do not include secrets, tokens, credentials, PII, or production data in any output.
- If `{{STAKEHOLDER_FEEDBACK}}` contains customer data: sanitize before using in the
  requirement artifact. Flag the sanitization in the revision summary.

---


---

## Stage Boundary

**Stage:** REQUIREMENT
**Prompt type:** single_stage_operational

**Responsibility:** Integrate stakeholder feedback into the requirement document and re-validate DoR.

**Allowed:**
- read stakeholder-pack.md answers and current requirement.md
- revise requirement.md with integrated feedback
- re-run DoR validator

**Prohibited:**
- modify product code
- produce classification or implementation evidence
- approve G-GROOM or G-PLAN
- invent test strategy completion or runtime QA execution evidence
- begin technical planning
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-extract-grooming-state WRITE=1 && make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

## Human action required

After applying revisions and saving artifacts, the operator MUST run the validation chain:

**Option A — preferred (run automatically if command execution is available):**

```bash
make ai-sdlc-extract-grooming-state ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
make ai-sdlc-validate-requirement-dor ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

**Option B — fallback (if command execution unavailable, print these exact commands):**

```
⚠ VALIDATION PENDING — run before proceeding:
1. make ai-sdlc-extract-grooming-state ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
2. make ai-sdlc-validate-requirement-dor ROOT=<workspace-root> ISSUE=<ISSUE-ID> WRITE=1
3. make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
State: grooming_revision_applied_but_dor_validation_pending
```

After validation, report:
- Revision number
- AC confirmation status
- Question status counts (open / resolved / accepted / blocking-open)
- DoR status
- G-GROOM required / approved
- **Next correct prompt:**
  - `grooming-stakeholder-pack.prompt.md` or `grooming-revision.prompt.md` if not ready
  - `grooming-sign-off-capture.prompt.md` if DoR ready and signoff missing
  - `make ai-sdlc-approve-gate ROOT=<ROOT> ISSUE=<ISSUE> GATE=G-GROOM ...` if signoff exists and G-GROOM is pending (human gate — do not self-approve)
  - Phase 0 exit → `/classify-work <ISSUE>` (Phase 1 entry) **only** after DoR ready, signoff captured, and G-GROOM approved
- **Implementation blocked** — Requirement Grooming phase

Do **NOT** proceed to classify-work until DoR validator passes and G-GROOM is approved.

Do not post to Jira or modify external systems unless explicitly approved by a human.
Do not modify framework files during product SDLC execution.
