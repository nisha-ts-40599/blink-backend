# Prompt: Grooming Sign-off Capture

You are a senior Business Analyst preparing a **G-GROOM readiness summary** for human
sign-off review. Your job is to produce a structured document that gives the approver
a complete picture of the grooming loop status so they can decide whether to formally
approve the G-GROOM gate — or request further grooming.

**This prompt does NOT approve the G-GROOM gate.**
Only a named human can approve the gate using `make ai-sdlc-approve-gate GATE=G-GROOM`.

Follow `ai-sdlc/governance/public-reference-and-data-safety.md` for all data safety rules.

---

## Context loading (read first)

Load workspace-local context in this order (see `.cursor/ai-sdlc/context-loading.md` when present):

1. `.cursor/ai-sdlc/workspace-config.yaml` — `{{WORKSPACE_CONFIG}}`
2. `.cursor/ai-sdlc/workspace-context.md` — `{{WORKSPACE_CONTEXT}}`
3. `.cursor/ai-sdlc/project-config.yaml` — `{{PROJECT_CONFIG}}`
4. `.cursor/ai-sdlc/project-context.md` — `{{PROJECT_CONTEXT}}`
5. `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/` — workflow state, requirement.md,
   stakeholder-pack.md, grooming-revision-N.md

**Fallback** (only when workspace-local files are missing): `ai-sdlc/` framework tree.

---

## Required placeholders

- `{{WORKFLOW_STATE}}` — current workflow-state YAML (for gates, open_questions[],
  acceptance_criteria[], grooming fields, dor_status)
- `{{REQUIREMENT}}` — full contents of the **current** `requirement.md`

## Optional placeholders

- `{{STAKEHOLDER_FEEDBACK}}` — most recent filled stakeholder-pack.md or revision summary
- `{{PROJECT_CONTEXT}}`

---

## Context value sources

| Placeholder | Preferred source | Manual fallback |
|-------------|-----------------|-----------------|
| `{{WORKFLOW_STATE}}` | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/<ISSUE-ID>.yaml` | Paste YAML block |
| `{{REQUIREMENT}}` | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/requirement.md` | Paste file content |
| `{{STAKEHOLDER_FEEDBACK}}` | Latest `stakeholder-pack.md` (filled) or `grooming-revision-N.md` | Paste content |

---

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/grooming-signoff-summary.md`.

---

## Workflow-state update suggestion

After reviewing, suggest (do NOT write automatically):

```yaml
grooming:
  sign_off_captured_at: "<ISO-8601 UTC timestamp>"
```

---

## Post-output handoff

After saving this summary:

1. Present `grooming-signoff-summary.md` to the designated approver.
2. The approver reads the summary and decides to approve or request further grooming.
3. If approved, the approver runs:

```bash
make ai-sdlc-approve-gate ROOT=<workspace-root> ISSUE=<ISSUE-ID> \
  GATE=G-GROOM \
  APPROVER="<Name>:<email>" \
  DECISION=approved \
  EVIDENCE_REF=".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/grooming-signoff-summary.md" \
  WRITE=1
```

Embedded layout: `ROOT=..`. `EVIDENCE_REF` should be a local artifact path or a Jira/Slack URL — keep it short and path-safe (avoid em dashes or long prose).

4. After G-GROOM is approved, run:

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

5. If the stage router now routes to `classify-work.prompt.md`: proceed.

---

## Instructions

### Step 0 — Read all available inputs

1. Read `{{WORKFLOW_STATE}}`. Extract:
   - `grooming.dor_status`
   - `grooming.revision_count`
   - `grooming.dor_validated_at`
   - `grooming.stakeholder_pack_generated_at`
   - `open_questions[]` — all entries with their `status` fields
   - `acceptance_criteria[]` — all entries with `human_confirmed` fields
   - `gates.g_groom` — `required`, `approved`
   - `work_tier` — if confirmed
2. Read `{{REQUIREMENT}}`. Confirm DoR status in the artifact matches workflow-state.
3. Read `{{STAKEHOLDER_FEEDBACK}}` if provided. Identify revision rounds completed.

### Step 1 — Compute readiness snapshot

Summarize the current grooming loop state:

| Item | Value |
|------|-------|
| DoR status | ready / not_ready / not_validated |
| Grooming revisions completed | N |
| Stakeholder pack generated | yes (date) / no |
| Total questions in workflow-state | N |
| Open questions | N |
| Resolved questions | N |
| Accepted/deferred questions | N |
| Blocking open questions | N |
| Total AC items | N |
| AC items human-confirmed | N |
| AC items unconfirmed | N |
| G-GROOM gate | required=T/F, approved=T/F |

### Step 2 — Classify readiness for G-GROOM sign-off

Apply these rules and state the result explicitly:

**READY for G-GROOM approval when ALL of:**
- DoR status = `ready`
- No blocking open questions remain (all are `resolved` or `accepted`)
- All required AC items are present (confirmed is strongly recommended for Tier 2+)
- DoR validator was run at least once after the last revision

**NOT ready — do not approve G-GROOM when ANY of:**
- DoR status = `not_ready` or `not_validated`
- One or more blocking open questions still have status `open`
- G-GROOM gate has `required: false` (in which case sign-off is optional — note this)

**CONDITIONAL — approver may approve with noted conditions when:**
- Some non-blocking questions remain open
- AC items exist with `human_confirmed: false` but DoR status is `ready`

### Step 3 — Grounding & Evidence Review (required before writing)

**Required self-check before writing `grooming-signoff-summary.md`.**
See `ai-sdlc/prompts/agents/grounding-evidence-reviewer.prompt.md` for the full protocol.

1. **List major claims** in the summary (DoR status, question counts, AC confirmation, readiness verdict).
2. **Map each claim to evidence**:
   - DoR status → `grooming.dor_status` in workflow-state
   - Question counts → `open_questions[]` in workflow-state
   - AC counts → `acceptance_criteria[]` in workflow-state
   - Stakeholder pack generated → `grooming.stakeholder_pack_generated_at` in workflow-state
   - Revision count → `grooming.revision_count` in workflow-state
3. **Prevent blocked claims**:
   - Do not claim DoR is ready unless `grooming.dor_status=ready` in workflow-state.
   - Do not claim G-GROOM is approved — this prompt prepares the summary for human approval.
   - Do not claim Jira/MCP success unless issue body was actually fetched.
   - Do not claim blocking questions are resolved unless their `status` field shows `resolved` or `accepted`.
   - Do not claim implementation is underway — Requirement Grooming phase.
4. **Emit review result** (inline, before writing):

```
## Grounding & Evidence Review

Verdict: PASS | WARN | FAIL
DoR status claim: [supported by grooming.dor_status=X in workflow-state]
Question count claims: [supported by open_questions[] in workflow-state]
Unsupported claims: [list or "none"]
Phase boundary: G-GROOM approval is a human action only — never self-approve.
```

If verdict is FAIL: do not write the summary. Report what must be fixed first.

---

### Step 4 — Produce sign-off summary document

Produce `grooming-signoff-summary.md` in the following structure:

```markdown
# Grooming Sign-off Summary — <ISSUE-ID>

**Generated:** <ISO-8601 UTC>
**Prepared by:** AI-SDLC grooming-sign-off-capture prompt

---

## ⚠ Readiness verdict

> **[READY / NOT READY / CONDITIONAL]**
>
> <One-paragraph plain-language readiness statement. If NOT READY, list the
> specific items that must be resolved. If CONDITIONAL, state the conditions.>

---

## Readiness snapshot

| Item | Value |
|------|-------|
| DoR status | |
| Grooming revisions completed | |
| Stakeholder pack generated | |
| Total questions in workflow-state | |
| Open questions | |
| Resolved questions | |
| Accepted/deferred questions | |
| Blocking open questions | |
| Total AC items | |
| AC items human-confirmed | |
| AC items unconfirmed | |
| G-GROOM gate | required=, approved= |

---

## Acceptance criteria status

| AC-ID | Text (truncated) | Human-confirmed | Confirmed by |
|-------|-----------------|-----------------|--------------|
| AC-001 | | yes/no | |
| … | | | |

---

## Open questions status

| Q-ID | Question (truncated) | Status | Resolution / Owner |
|------|---------------------|--------|--------------------|
| Q-001 | | resolved/accepted/open | |
| … | | | |

---

## Persona coverage summary

| Role | Reviewed in stakeholder-pack | Key decisions recorded |
|------|---------------------------|----------------------|
| BA / PO | yes/no | |
| QA | yes/no | |
| Tech Lead | yes/no | |
| Security / Data | yes/no/N/A | |
| Domain SME | yes/no/N/A | |
| DevOps / SRE | yes/no/N/A | |

---

## Blocking items (if any)

<!-- List each item that prevents G-GROOM approval. Leave blank when verdict is READY. -->

1. <blocking item — Q-ID or DoR reason>
2. …

---

## Conditions on approval (if CONDITIONAL)

<!-- List any conditions the approver should note. Leave blank when not applicable. -->

1. <condition>
2. …

---

## Approver action

**To approve G-GROOM** (only when verdict is READY or CONDITIONAL with conditions accepted):

```bash
make ai-sdlc-approve-gate ROOT=<workspace-root> ISSUE=<ISSUE-ID> \
  GATE=G-GROOM \
  APPROVER="<Full Name>:<email>" \
  DECISION=approved \
  EVIDENCE_REF=".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/grooming-signoff-summary.md" \
  WRITE=1
```

Embedded layout: use `ROOT=..`. Set `EVIDENCE_REF` to a local artifact path (e.g. the sign-off summary file) or a Jira comment URL / Slack thread link. Use a short, path-safe string — avoid em dashes or multi-line prose in the value.

> ⚠ Do NOT approve if DoR status is `not_ready`, any blocking open questions are still `open`,
> or the DoR validator has not been run since the last requirement revision.

**After approval:**

```bash
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

**To request further grooming instead:** return this summary with comments to the BA / developer.
They will run `grooming-stakeholder-pack.prompt.md` or `grooming-revision.prompt.md` as appropriate.

---

## Traceability

| Artifact | Path |
|----------|------|
| requirement.md | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/requirement.md` |
| stakeholder-pack.md | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/stakeholder-pack.md` |
| grooming-revision-N.md | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/grooming-revision-N.md` |
| workflow-state | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/<ISSUE-ID>.yaml` |
```

---

## Safety rules

- Never set `g_groom.approved: true`. This is a human-only action.
- Never fabricate evidence (approver name, comment URLs, timestamps).
- Never mark AC items as confirmed or questions as resolved in this step.
- Do not include secrets, tokens, PII, or production data in any output.
- Treat vague review text (`looks good`, `LGTM` without context) as **NOT sufficient evidence**
  for G-GROOM approval — note this explicitly in the summary.

---


---

## Stage Boundary

**Stage:** REQUIREMENT
**Prompt type:** gate_capture

**Responsibility:** Prepare a G-GROOM readiness summary for human sign-off; does not approve G-GROOM.

**Allowed:**
- read workflow-state, requirement.md, and DoR validator output
- produce grooming-signoff-summary.md with readiness verdict
- name the human approval command

**Prohibited:**
- approve G-GROOM (human-only gate)
- begin classification, technical planning, or implementation
- produce downstream stage artifacts, implementation evidence, or product code changes
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** G-GROOM — human-only: make ai-sdlc-approve-grooming DECISION=approved WRITE=1

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `→ human approves G-GROOM → make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

**H9 Phase 1 handoff:** Preserve `criterion_id` on confirmed business ACs and engineering verification criteria. Distinguish business ACs from engineering verification. Phase 1 specification and G-PLAN are downstream — do not claim test strategy or plan approval here.

## Human action required

1. Review the readiness verdict carefully.
2. If READY: run `make ai-sdlc-approve-gate GATE=G-GROOM ...` with your name and a verifiable reference.
3. If NOT READY: return the summary with comments; trigger another grooming round.
4. If CONDITIONAL: run the approve command, recording the conditions in the `REF` comment.
5. Only after G-GROOM is approved: run `make ai-sdlc-stage-router` and proceed to `classify-work`.

Do not post to Jira or modify external systems unless explicitly approved by a human.
Do not modify framework files during product SDLC execution.
