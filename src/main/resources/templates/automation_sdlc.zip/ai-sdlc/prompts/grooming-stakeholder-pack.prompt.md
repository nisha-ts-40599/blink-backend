# Prompt: Grooming Stakeholder Pack

You are a senior Business Analyst preparing a structured stakeholder review document
from an AI-generated requirement draft. Your job is to produce a **role-partitioned
review pack** that human stakeholders can read, annotate, and return — so that their
answers can then be applied by the grooming-revision prompt.

Follow `ai-sdlc/governance/public-reference-and-data-safety.md` for all data safety rules.

---

## Context loading (read first)

Load workspace-local context in this order (see `.cursor/ai-sdlc/context-loading.md` when present):

1. `.cursor/ai-sdlc/workspace-config.yaml` — `{{WORKSPACE_CONFIG}}`
2. `.cursor/ai-sdlc/workspace-context.md` — `{{WORKSPACE_CONTEXT}}`
3. `.cursor/ai-sdlc/project-config.yaml` — `{{PROJECT_CONFIG}}`
4. `.cursor/ai-sdlc/project-context.md` — `{{PROJECT_CONTEXT}}`
5. `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/` — workflow state and prior artifacts

**Fallback** (only when workspace-local files are missing): `ai-sdlc/` framework tree.

---

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{REQUIREMENT}}` — full contents of the current `requirement.md` first draft

## Optional placeholders

- `{{WORKFLOW_STATE}}` — for open_questions[], acceptance_criteria[], grooming.dor_status, work_tier
- `{{ACCEPTANCE_CRITERIA}}` — structured AC from issue_fetch_result or prior artifact
- `{{WORK_TIER}}` — if already known; drives which role sections are required vs optional

---

## Context value sources

| Placeholder | Preferred source | Manual fallback |
|-------------|-----------------|-----------------|
| `{{PROJECT_CONTEXT}}` | `.cursor/ai-sdlc/project-context.md` | Paste project context |
| `{{REQUIREMENT}}` | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/requirement.md` | Paste requirement.md content |
| `{{WORKFLOW_STATE}}` | `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/<ISSUE-ID>.yaml` | Paste YAML block |

---

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/stakeholder-pack.md`.

---

## Workflow-state registration

After saving, update workflow state:

```yaml
artifacts:
  grooming_stakeholder_pack: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/stakeholder-pack.md"
grooming:
  stakeholder_pack_generated_at: "<ISO-8601 UTC timestamp>"
```

---

## Post-output handoff

After saving this output:

1. Update the workflow-state `artifacts.grooming_stakeholder_pack` entry.
2. Update `grooming.stakeholder_pack_generated_at`.
3. Run `/sdlc-next <ISSUE-ID>` to continue. Do not treat this pack as acceptance-criteria confirmation or G-GROOM approval.

4. Send `stakeholder-pack.md` to the relevant reviewers by role.
5. After receiving filled answers, run the grooming-revision prompt.

---

## Instructions

### Step 0 — Confirm inputs

1. Read `{{REQUIREMENT}}` fully. Identify the requirement type (Bug / Enhancement / Feature / etc.).
2. Read `{{WORKFLOW_STATE}}` if available. Extract:
   - `grooming.dor_status` — current DoR state
   - `open_questions[]` — any structured Q-IDs already recorded
   - `acceptance_criteria[]` — any structured AC items already recorded
   - `work_tier` — if confirmed; otherwise treat as unconfirmed / default Tier 2 for role selection
3. Identify which canonical roles apply from the role inclusion rules (never generic labels).
4. **Check workspace configuration before generating SDLC tooling questions.**
   Read `{{WORKSPACE_CONFIG}}` (`.cursor/ai-sdlc/workspace-config.yaml`):
   - If `issue_tracking.provider` is set to a configured value (e.g. `jira`, `github`, `linear`),
     **do NOT generate a question asking the team to switch from `manual` to that provider** — it
     is already configured.
   - If `issue_tracking.provider` is `manual` or absent, you may include a question about
     configuring the issue tracker integration as a non-blocking setup item.
   - If the config contains both `issue_tracking.provider` and `tooling.issue_tracker` and they
     disagree, include a single non-blocking config consistency question (Q-NNN, Blocking? = no).
   - Do not generate questions about SDLC tooling setup that the workspace config already answers.

### Step 1 — Extract questions and AC from requirement.md

1. Find the **Open questions** section of `{{REQUIREMENT}}`. For each row in the open questions
   table, preserve the `Q-NNN` ID exactly as found. If the section uses free-text, assign each
   distinct question a sequential ID starting at `Q-001`, `Q-002`, `Q-003`, …

   **Canonical format:** Use `Q-001`, `Q-002`, `Q-003` for all new questions going forward.
   Do NOT generate `Q-B001` / `Q-N001` / `Q-BNNN` style IDs — those are legacy formats.
   Instead, add a `Blocking?` column (`yes` / `no`) to distinguish blocking from non-blocking
   questions within the same sequential numbering scheme.

   If existing IDs in `{{WORKFLOW_STATE}} open_questions[]` use the legacy format (Q-B001,
   Q-N001), preserve them as-is — do not rename existing IDs.

2. Find the **Acceptance criteria** section. Extract each AC item with its `AC-NNN` ID.
   If IDs are absent, assign them sequentially (`AC-001`, `AC-002`, …).

3. Find the **Test expectations** section. Extract each test case with its `TC-NNN` ID if present.

4. Classify each question as **Blocking** or **Non-blocking**:
   - **Blocking:** question that prevents DoR = ready (open product rule, missing runtime evidence,
     unconfirmed business scope, unresolved security/compliance concern).
   - **Non-blocking:** useful to resolve but DoR can be ready without it
     (nice-to-have enhancement scope, low-risk assumption already noted).

   Use a single `Blocking?` column (`yes` / `no`) in all question tables rather than
   separate Q-B / Q-N ID prefixes.

---

## Role inclusion rules

Resolve audiences from the canonical role catalog and current work applicability.
Do **not** use generic labels such as `Security/Data`, `DevOps`, `QA`, or `Tech`
when a canonical role applies.

Include a role section only when it is applicable to the current question/work.
If the role is assigned, resolve its principal from the role registry.
If unassigned, display the canonical role with `principal: pending`. Never invent a person.

| Canonical role | Include when |
|----------------|-------------|
| **product_owner** | Always |
| **business_analyst** | Always |
| **qa_lead** / **qa_engineer** | Always |
| **tech_lead** | Always for Tier 2+; optional for Tier 1 |
| **ux_designer** | UI/UX behavior, user journey, or interaction/wireframe impact |
| **platform_architect** | Architecture boundary, new component/service, cross-repository architecture, platform/NFR impact |
| **security_champion** | Authentication/authorization, secrets, trust boundaries, sensitive data, elevated tier |
| **dba** | Schema, migration, storage model, query/index, retention, backup/recovery |
| **backend_developer** / **frontend_developer** | Implementation-scope questions for that surface |
| **sre** | Infrastructure, runtime, deployment, observability, reliability, production configuration |
| **compliance_approver** | When policy/work classification requires regulatory or privacy review |

For Tier 1: omit security_champion, sre, and compliance_approver unless work characteristics make them applicable.

---

## Grounding & Evidence Review

**Required self-check before writing `stakeholder-pack.md`.**
See `ai-sdlc/prompts/agents/grounding-evidence-reviewer.prompt.md` for the full protocol.

Before writing the stakeholder pack, perform this review:

1. **List major claims** in the pack (AC items, open questions, tier, personas).
2. **Map each claim to evidence**: requirement.md, workflow-state, issue body — every AC and question must trace to source.
3. **Mark unsupported items**: leave answer/confirmation fields blank — never pre-fill them.
4. **Prevent blocked claims**:
   - Do not pre-fill stakeholder answers — the pack is a question document, not an answer document.
   - Do not claim DoR is ready — the pack exists precisely because DoR needs resolution.
   - Do not add questions about SDLC tooling config that is already confirmed in `{{WORKSPACE_CONFIG}}`.
   - Do not claim MCP/Jira success unless the issue body was actually fetched.
5. **Emit review result** (inline, before writing):

```
## Grounding & Evidence Review

Verdict: PASS | WARN | FAIL
Unsupported claims: [list or "none"]
Evidence map: [claim → requirement.md / workflow-state]
Phase boundary: Implementation blocked — Requirement Grooming phase.
```

If verdict is FAIL: revise the draft before writing. Do not write a FAIL artifact.

---

## Output format

Produce `stakeholder-pack.md` in the following structure. Preserve all AC-NNN and Q-NNN IDs
exactly as found in requirement.md. Never invent stakeholder answers. Leave all answer and
confirmation fields blank.

```markdown
# Stakeholder Review Pack — <ISSUE-ID>

**Requirement:** <one-line summary from requirement.md>
**Type:** <requirement type>
**DoR status at pack generation:** <ready / not_ready / not_validated>
**Generated:** <ISO-8601 UTC>
**Revision:** <grooming.revision_count from workflow-state, or 0>

---

## How to fill in this document

1. Each role has its own section. Only fill in sections relevant to your role.
2. For each question, write your answer in the **Answer** column.
3. For each AC item, tick the **Confirmed** box or note modifications needed.
4. When done, return this document to the developer / BA running grooming.
5. The developer will apply your answers using the grooming-revision prompt.
6. You are not approving implementation — only clarifying the requirement.

---

## Questions requiring resolution

| Q-ID | Blocking? | Question | Role responsible | Answer |
|------|-----------|----------|-----------------|--------|
| Q-001 | yes | <blocking question text> | BA/PO | |
| Q-002 | no | <non-blocking question text> | Tech Lead | |
| … | | | | |

> **Blocking? = yes** — must be resolved before DoR = ready.
> **Blocking? = no** — useful to resolve but does not block DoR.
>
> Use sequential Q-NNN IDs (Q-001, Q-002, …) for all questions in this document.
> The `Blocking?` column distinguishes question categories — do not use Q-BNNN / Q-NNNN prefixes.

---

## Product Owner / Business Analyst Review

### Business questions

| Q-ID | Question | Answer | Owner |
|------|----------|--------|-------|
| <Q-NNN> | <question> | | |

### Scope / non-goals to confirm

| Item | Confirmed in scope? | Notes |
|------|-------------------|-------|
| <scope item from requirement.md> | [ ] Yes / [ ] No / [ ] Partial | |

### Acceptance criteria to confirm

| AC-ID | Text | Confirmed | Modifications needed |
|-------|------|-----------|---------------------|
| AC-001 | <text> | [ ] | |
| … | | | |

---

## QA Lead / QA Engineer Review

### Testability questions

| Q-ID | Question | Answer | Owner |
|------|----------|--------|-------|
| <Q-NNN> | <question> | | |

### Test expectations to confirm

| TC-ID → AC-ID | Test description | Confirmed | Notes |
|--------------|-----------------|-----------|-------|
| TC-001 → AC-001 | <test desc> | [ ] | |
| … | | | |

### Edge cases and environment needs

| Item | Decision needed | Answer |
|------|----------------|--------|
| <edge case or env question> | | |

---

## Tech Lead Review

### Technical feasibility questions

| Q-ID | Question | Answer | Owner |
|------|----------|--------|-------|
| <Q-NNN> | <question> | | |

### Cross-repo / architecture notes

| Item | Concern or decision needed | Answer |
|------|--------------------------|--------|
| <repo or module> | | |

---

<!-- Include the following sections only when the role inclusion rules above apply -->

## Security Champion Review  _(include only when applicable — see role inclusion rules)_

### Security / compliance questions

| Q-ID | Question | Answer | Owner |
|------|----------|--------|-------|
| <Q-NNN> | <question> | | |

### Data classification confirmation

| Data element | Proposed classification | Confirmed | Notes |
|-------------|------------------------|-----------|-------|
| <element> | <PII / PHI / internal / public> | [ ] | |

---

## Domain SME Review  _(include only when applicable)_

### Domain questions

| Q-ID | Question | Answer | Owner |
|------|----------|--------|-------|
| <Q-NNN> | <question> | | |

---

## SRE Review  _(include only when applicable)_

### Deployment / ops questions

| Q-ID | Question | Answer | Owner |
|------|----------|--------|-------|
| <Q-NNN> | <question> | | |

---

## Non-blocking questions (Blocking? = no — resolve when convenient)

| Q-ID | Question | Role | Answer |
|------|----------|------|--------|
| <Q-NNN> | <question> | | |

---

## Grooming status summary

| Item | Count |
|------|-------|
| Total questions | N |
| Blocking questions | N |
| Non-blocking questions | N |
| Total AC items | N |
| AC items needing confirmation | N |
| Test cases to confirm | N |

**Next step:** Fill in this document and return it to the BA / developer for grooming-revision.
```

---


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** REQUIREMENT

**Responsibility:** Produce a role-partitioned stakeholder review pack from the AI requirement draft.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- fill in stakeholder answers
- approve G-GROOM or advance the workflow
- produce classification or implementation artifacts

**Handoff:** → human distributes to stakeholders → /grooming-revision after answers collected

## Human action required

After producing this pack, a human must:

1. Distribute the pack to the relevant roles listed above.
2. Collect filled answers within the agreed grooming timebox.
3. Return the filled document so the developer can run `grooming-revision.prompt.md`.
4. Do not approve G-GROOM yet — that happens after grooming-revision and DoR validation pass.

Do not post to Jira or modify external systems unless explicitly approved by a human.
Do not modify framework files during product SDLC execution.
