# Prompt: Implementation Evidence Capture

Capture proof that implementation was **applied** in product repos — not narrative-only.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{REPOSITORY_CONTEXT}}`

## Optional placeholders

- `{{VALIDATION_RESULTS}}`
- `{{CURRENT_STEP}}`

## Instructions

1. Resolve the correct **git repo root** before checking diff/status.
2. Record: changed files, `git diff --stat`, branch, staged/uncommitted state or commit hash.
3. List **untracked files separately** from tracked diffs.
4. Never claim implementation complete without file diffs or commit evidence.
5. Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/implementation-evidence.md` using `templates/implementation-evidence-template.md`.
6. Propose `implementation` block update:

```yaml
implementation:
  status: applied_uncommitted | committed_local | pushed
  repos:
    - repo_id: ""
      branch: ""
      local_commit: ""
      files_changed: []
      working_tree_clean: false
  validation:
    syntax: { status: not_run, evidence: "" }
    unit_tests: { status: not_run, evidence: "" }
```

Status values: `passed | failed | not_available | not_run | waived | pending | not_required`.


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** IMPLEMENTING

**Responsibility:** Capture and persist implementation evidence artifacts for the current plan step.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- claim QA complete without qa-validation
- approve G-QA or G-PR-MERGE
- advance to PR without pr-registration

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Human action required

Update workflow-state only when explicitly asked. Do not commit or push without human approval.
