# Finalize greenfield transition

Run only after G-PLAN, G-BOOTSTRAP, bootstrap, first implementation merge, baseline validation, and successful existing-workspace refresh.

```bash
make ai-sdlc-finalize-greenfield-transition ROOT=<workspace-root>
make ai-sdlc-finalize-greenfield-transition ROOT=<workspace-root> WRITE=1
```

On success:

- Writes `.cursor/ai-sdlc/handoffs/greenfield-to-existing.yaml`
- Sets `lifecycle-state.yaml` to `EXISTING_MANAGED`
- Updates `workspace-manifest.yaml` and `setup-state.yaml`
- Sets `/setup-existing-workspace refresh` as the canonical next command

Greenfield apply commands refuse normal execution after transition.
