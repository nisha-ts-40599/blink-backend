# Interactive greenfield setup (include)

This section extends discovery/apply for `/setup-new-workspace` and `/setup-new-project`.
**Discovery never writes files.** Apply runs only after explicit user confirmation.

## Requirement sources

Supported primary sources (same for `/setup-new-workspace` and `/setup-new-project`):

- **Pasted text** — `Requirement:` block in chat or `--requirement-text`; framework persists **only** under `.cursor/ai-sdlc/intake/requirements/{hash}-pasted-requirement.md` with provenance in `intake/requirement-sources/` (never creates workspace-root `docs/` or `requirements/` staging). **Agents must not write pasted requirements to the workspace root before running setup.**
- **Workspace file** — user-owned path (e.g. a file the team already maintains); framework copies a checksum-addressed snapshot into intake and **does not move or delete** the original
- **Issue tracker** — e.g. `PROJECT-123` via configured resolver / authorised fetch (`--issue-id`); manual paste fallback when fetch unavailable
- **YAML template** — optional `.cursor/ai-sdlc/setup/project-initialisation-input.yaml` or explicit `INPUT=` path (legacy root file read-only)

Sessions persist under `.cursor/ai-sdlc/setup/setup-interactive-session.yaml` (or pre-overlay `setup/` before apply). **Repeated slash commands resume** the session; recommendations stay `RECOMMENDED` until confirmed or you accept defaults explicitly.

## Interactive flow

1. Run setup lifecycle guard (`make ai-sdlc-validate-setup-readiness`).
2. Choose **Mode A** (pre-planning) or **Mode B** (pre-approved spec).
3. Collect product/engineering intake (conversation **or** template file).
4. Run read-only capability discovery (no workspace writes unless `PERSIST_SESSION=1` on Make discover):

```bash
make ai-sdlc-greenfield-setup-discover ROOT=<workspace-root> REQUIREMENT_FILE=requirements/product-requirements.md
# or REQUIREMENT_TEXT="..." / ISSUE_ID=PROJ-123 / INPUT=project-initialisation-input.yaml
# Optional resume persistence during chat: PERSIST_SESSION=1
```

5. Present the **Project Initialisation Report** (capabilities, recommendations, blockers, deferred items).
6. User accepts, modifies, or defers each recommendation (**apply is blocked** until blocking fields are confirmed, explicitly deferred where allowed, or non-security defaults accepted).
7. On **apply** confirmation, persist **metadata only** under `.cursor/ai-sdlc/**` (no physical product repos, no remotes, no commits):

```bash
make ai-sdlc-greenfield-setup-apply ROOT=<workspace-root> INPUT=.cursor/ai-sdlc/setup/project-initialisation-input.yaml
# or same primary source as discovery plus ACCEPT_RECOMMENDED_DEFAULTS=1 / USER_INSTRUCTION="..."
make ai-sdlc-validate-project-init-input INPUT=.cursor/ai-sdlc/setup/project-initialisation-input.yaml
```

8. **Apply writes the full canonical overlay** (`workspace-config.yaml`, contexts, `setup-state.yaml`, per-repo metadata when multi-repo) via `make ai-sdlc-greenfield-setup-apply` — agents must not manually author those files in apply mode.
9. Install Cursor commands: `make ai-sdlc-install-cursor-commands ROOT=<workspace-root>`.
10. Persist intake under `.cursor/ai-sdlc/intake/` when discovery uses `PERSIST_SESSION=1` or on apply — never at workspace root.
10. When planning gates allow, generate bootstrap plan and offer:
    - **Managed typed actions** (`create_directory`, `initialize_repository`, `configure_remote`, validation, handoff) via G-BOOTSTRAP-EXEC.
    - **Cursor-executed scaffold** — show exact command, working directory, expected paths, network effects, rollback; require explicit user confirmation before running.
    - **Provider actions** — separate confirmation; use MCP only after capability probe reports `AVAILABLE`.
11. After scaffold: `/setup-existing-workspace refresh` or `/setup-existing-project refresh`, then `make ai-sdlc-validate-setup-readiness REQUIRE=delivery`.
12. Never set `delivery_ready` directly — use authoritative readiness validation only.

**Intake paths:** Legacy read-only fallback `<workspace>/project-initialisation-input.yaml` (migrate with `make ai-sdlc-migrate-workspace-artifacts`). Canonical path: `.cursor/ai-sdlc/setup/project-initialisation-input.yaml`.

## Questionnaire template

- Template: `ai-sdlc/templates/setup/project-initialisation-input.template.yaml`
- Target path: `.cursor/ai-sdlc/setup/project-initialisation-input.yaml`
- Schema: `ai-sdlc/schemas/setup/project-initialisation-input.schema.json`

Allowed field resolutions: explicit, recommended_default, tbd, not_required, deferred.

## Local Git vs provider

- **Local Git** — init, default branch, status, identity check, prepare initial commit (local only).
- **Provider** — remote create, visibility, push, branch protection (MCP or manual instructions).
- If provider MCP is `NOT_CONFIGURED`, continue with local scaffold; record remote as deferred; emit manual connection steps in the report.

## Scaffold execution contract

Each scaffold action must have a record under `.cursor/ai-sdlc/setup/scaffold-records/` conforming to
`ai-sdlc/schemas/setup/scaffold-execution-record.schema.json`.
Status progression: `planned` → `displayed` → `approved` → execution → `completed` or `failed`.
Scaffold is complete only after expected paths exist, install/build/lint/tests succeed, no secrets committed, and refresh reconciles detected commands.

## Documentation

See `ai-sdlc/adoption/interactive-greenfield-setup.md`.
