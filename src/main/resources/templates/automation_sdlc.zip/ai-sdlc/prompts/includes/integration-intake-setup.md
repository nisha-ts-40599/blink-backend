# Tool integration intake (include)

During `/setup-new-workspace` and `/setup-existing-workspace refresh`, collect **capability-oriented** integration answers before assuming any vendor.

## Question flow (high level)

1. **Work and ticket management** — “What tool do you use for tickets, backlog, work items and delivery tracking?”
2. **Documentation and knowledge management** — “What platform do you use for documentation, specifications and knowledge sharing?”
3. **Source-code management** — “What platform hosts and manages your source-code repositories?”
4. **Design and product collaboration** — optional; may answer `none`.
5. **Test automation** — multi-select; MCP usually **not** required (CLI/CI only).
6. **Test management** — separate from test automation.
7. **CI/CD and deployment** — non-secret metadata only.
8. **Communication and notifications** — optional.
9. **Additional tools** — free text; retain custom names as `custom`.

Accept **`none`**, **`manual`**, **`defer`**, and **`not now`** for any category.

Preserve the user's literal answer in `provider_input`. Normalize to `normalized_id` only when confident; otherwise classify as **`custom`** and ask minimal follow-ups — do not reject unknown tools.

## Portable storage

Non-secret integration metadata:

```text
.cursor/ai-sdlc/integrations/
  integration-config.yaml
  capability-registry.yaml
  integration-readiness.yaml
  mcp-generation-report.yaml
  integration-intake.yaml
```

Canonical requirements:

```text
.cursor/ai-sdlc/intake/requirements/
.cursor/ai-sdlc/intake/requirement-sources/
```

Do **not** create a permanent workspace-root `requirements/` directory from framework setup. Migrate duplicates with cleanup plan when SHA-256 matches canonical snapshot.

## MCP and secrets

- Generate **workspace** `.cursor/mcp.json` only after preview/confirmation.
- Use `<framework-root>/scripts/mcp-npx.sh` for MCP server commands.
- Secrets only in `<framework-root>/.env.mcp` (gitignored); update `.env.mcp.example` only.
- Never embed secrets in overlay YAML, setup state, or logs.

```bash
make ai-sdlc-configure-integrations ROOT=<workspace-root>
make ai-sdlc-configure-integrations ROOT=<workspace-root> WRITE=1
```

See `ai-sdlc/adoption/integration-setup-guide.md` and `ai-sdlc/adoption/mcp-configuration-guide.md`.

## Issue publication

Use compact Epic / Story / Task / Bug contexts — reference canonical requirement snapshots from `workflow-state/<ID>/`; do not copy full BRDs into each work-item folder by default.
