# Prompt: Merge Readiness

Assess whether a work item is ready for human merge.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{VALIDATION_RESULTS}}`
- `{{PR_CONTEXT}}`

## Optional placeholders

- `{{RISK_TIER}}`
- `{{APPROVAL_RECORDS}}`

## Instructions

1. Verify implementation evidence, PR URL, PR review output, and G-PR-MERGE readiness.
2. Require G-QA-POST when runtime QA is required — G-QA-PRE is not sufficient.
3. Treat validation `not_available` / `not_run` as **merge blockers** unless explicitly waived with approver. Treat `not_required` and approved `waived` as accepted limitations — not open merge blockers.
4. Prefer structured `implementation.validation.*` statuses (synced from QA artifacts) over prose-only Markdown when available.
5. For Tier 3+, confirm logging/privacy review (`privacy_review.completed`).
6. For Tier 3+ (or sensitive payment/security/data work), confirm `artifacts.rollback_plan` is registered — merge readiness **must fail** if rollback is required and missing.
7. If rollback plan is missing, recommend running `rollback-plan.prompt.md` before merge.
8. Save `merge-readiness.md` using `templates/merge-readiness-template.md`.
9. Never claim merge-ready if runtime QA is pending or rollback_plan is required but absent.


---

## Stage Boundary

**Stage:** MERGE_READY
**Prompt type:** single_stage_operational

**Responsibility:** Assess whether all pre-merge conditions are satisfied and produce a merge-readiness report.

**Allowed:**
- read ai-pr-review.md, qa-validation results, and gate approval records
- produce merge-readiness report with pass/fail verdict per condition

**Prohibited:**
- merge the PR
- self-approve G-PR-MERGE (human-only)
- deploy to production
- treat imperative wording ('merge this') as gate authorization
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** G-PR-MERGE — human-only: make ai-sdlc-approve-gate GATE=G-PR-MERGE DECISION=approved WRITE=1 + human merge

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `→ human approves G-PR-MERGE → human merges → make ai-sdlc-close-merge WRITE=1`

### Action-oriented language interpretation

```
Input:  "Merge this PR." / "Everything looks good, go ahead."

Correct behaviour:
  - assess all pre-merge conditions: qa-validation, ai-pr-review.md, gate approvals
  - produce merge-readiness report with PASS/FAIL per condition
  - if all conditions pass: present G-PR-MERGE human approval command and stop
  - if conditions fail: report blocking findings and route back via stage-router

Prohibited:
  - merge the PR (human action required)
  - self-approve G-PR-MERGE
  - deploy to production
  - treat "everything looks good" as gate authorization
```

"Merge this PR" is the desired outcome. Merge closure requires explicit
human G-PR-MERGE approval plus a human merge action. Imperative wording
and positive review verdicts do not constitute gate authorization.

## Human action required

Merge remains human-only. This prompt produces a checklist for the approver.
