# Prompt: Migration Strategy

Select migration strategy, phases, compatibility approach, and rollback touchpoints.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONTEXT}}`
- `{{PROJECT_CONFIG}}`
- `{{RISK_TIER}}`

## Optional placeholders

- `{{REPOSITORY_CONTEXT}}`
- `{{ARTIFACTS}}`
- `{{APPROVAL_RULES}}`

## Instructions

1. Load workspace `.cursor/ai-sdlc/` context (project-config including `modernization_profile`, workflow-state, prior artifacts).
2. Use `templates/migration-strategy-template.md` as the output structure.
3. Save primary output to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/migration-strategy.md`.
4. Default to strangler fig / phased migration / parallel validation. Discourage big-bang cutover without rollback.
5. Update workflow-state artifact references:

```yaml
artifacts:
  migration_strategy: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/migration-strategy.md"
```

6. Update `modernization` block when applicable (strategy, status fields, stack summaries).
7. Run `make ai-sdlc-validate-artifacts` and `make ai-sdlc-stage-router` before advancing stage.

## Output format

Follow all required sections in `migration-strategy-template.md`. Mark unknowns as **TBD** with owner questions.


## Scope boundaries

- Modernization lane only — do not execute production cutover or post-migration validation (Phase 3).
- Do not modify product code unless explicitly in an approved implementation step.
- Preserve existing behavior unless approved otherwise in the compatibility contract.

## Safety / data guardrails

- Use **sanitized evidence only** — no secrets, credentials, or customer PII.
- Do not assume microservices or full rewrite by default.
- Follow `{{SECURITY_MODEL}}` and project-config guardrails.


---

## Stage Boundary

**Stage:** PLAN_DRAFTED
**Prompt type:** single_stage_operational

**Responsibility:** Define data and service migration strategy for the modernization effort.

**Allowed:**
- read service-decomposition-plan.md or target-architecture.md
- produce migration-strategy.md with phasing and risk mitigation

**Prohibited:**
- execute migration or modify production data
- approve G-PLAN
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

## Human action required

- **Do not approve gates without explicit human evidence.**
- Tier, architecture, and migration strategy decisions require human confirmation.
- Never mark gate approvals or `modernization` status fields as approved without human sign-off.


## Workflow-state update

After human review, advance `current_stage` per stage router suggestion (do not self-advance without human confirmation).
