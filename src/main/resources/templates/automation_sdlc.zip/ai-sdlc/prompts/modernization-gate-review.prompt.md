# Prompt: Modernization Gate Review

Human gate review of modernization artifacts before technical plan.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONTEXT}}`
- `{{PROJECT_CONFIG}}`
- `{{RISK_TIER}}`

## Optional placeholders

- `{{REPOSITORY_CONTEXT}}`
- `{{ARTIFACTS}}`
- `{{APPROVAL_RULES}}`

## Instructions

1. Load workspace `.cursor/ai-sdlc/` context (project-config including `modernization_profile`, workflow-state, prior artifacts).
2. Use `templates/modernization-gate-review-template.md` as the output structure.
3. Save primary output to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/modernization-gate-review.md`.
4. Do not approve gates without explicit human evidence. Record open decisions and approval markers only from human input.
5. Update workflow-state artifact references:

```yaml
artifacts:
  modernization_gate_review: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/modernization-gate-review.md"
```

6. Update `modernization` block when applicable (strategy, status fields, stack summaries).
7. Run `make ai-sdlc-validate-artifacts` and `make ai-sdlc-stage-router` before advancing stage.

## Output format

Follow all required sections in `modernization-gate-review-template.md`. Mark unknowns as **TBD** with owner questions.


## Scope boundaries

- Modernization lane only — do not execute production cutover or post-migration validation (Phase 3).
- Do not modify product code unless explicitly in an approved implementation step.
- Preserve existing behavior unless approved otherwise in the compatibility contract.

## Safety / data guardrails

- Use **sanitized evidence only** — no secrets, credentials, or customer PII.
- Do not assume microservices or full rewrite by default.
- Follow `{{SECURITY_MODEL}}` and project-config guardrails.


---

## Stage Boundary

**Stage:** PLAN_DRAFTED
**Prompt type:** gate_capture

**Responsibility:** Prepare gate review evidence for a modernization milestone gate.

**Allowed:**
- read migration plan artifacts and relevant evidence
- produce modernization-gate-review.md with readiness verdict

**Prohibited:**
- self-approve the modernization gate
- begin the next migration phase without human approval
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** VARIES (modernization lane gate) — human-only: make ai-sdlc-approve-gate GATE=<gate> DECISION=approved WRITE=1

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `→ human approves gate → make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

## Human action required

- **Do not approve gates without explicit human evidence.**
- Tier, architecture, and migration strategy decisions require human confirmation.
- Never mark gate approvals or `modernization` status fields as approved without human sign-off.


## Workflow-state update

After human review, advance `current_stage` per stage router suggestion (do not self-advance without human confirmation).
