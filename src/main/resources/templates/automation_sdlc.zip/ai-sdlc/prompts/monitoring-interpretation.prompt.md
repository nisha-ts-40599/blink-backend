# Prompt: Post-Deploy Monitoring Signal Interpretation

You are an SRE interpreting post-deployment monitoring signals to identify whether a recent deployment is contributing to an anomaly.

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{DEPLOYMENT_SUMMARY}}` — what was deployed, when, to which environment, and the PR or ticket reference
- `{{MONITORING_SIGNALS}}` — alert body, error rate data, latency percentiles, or metric summaries covering the pre- and post-deploy window

## Optional placeholders

- `{{RECENT_CHANGES}}` — list of PRs merged in the recent period (broader than just the deployment)
- `{{BASELINE}}` — normal error rates, latency, and throughput for this service
- `{{DEPENDENCY_STATUS}}` — upstream service status or known incidents from dependencies
- `{{LOG_EXCERPTS}}` — representative error log lines from the anomaly window

## Context value sources

| Placeholder | Preferred source | Auto-populated today | Manual fallback |
|-------------|------------------|----------------------|-----------------|
| `{{PROJECT_CONTEXT}}` | `.cursor/ai-sdlc/project-context.md` | Yes, via bundle | Paste project context |
| `{{DEPLOYMENT_SUMMARY}}` | GitHub/Render/Vercel MCP or release notes | No | Paste deploy details; mark **missing evidence** if unknown |
| `{{MONITORING_SIGNALS}}` | observability MCP or pasted alerts | No | Paste metrics/alerts; mark **missing evidence** if unknown |

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/monitoring-review.md`.
If no issue ID exists, use `.cursor/ai-sdlc/workflow-state/unassigned/monitoring-review.md` and flag that a real issue ID should be created.

## Workflow-state registration

After saving, update workflow state:

```yaml
artifacts:
  monitoring_report: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/monitoring-review.md"
  post_release_verification: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/post-release-verification.md"
```

Save `post-release-verification.md` when post-deploy verification evidence is available; mark **missing evidence** if not yet performed.

## Post-output handoff

After saving this output:

1. Update the workflow-state `artifacts` entry for the generated artifact.
2. Run:

```bash
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout:

```bash
make ai-sdlc-validate-artifacts ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=.. ISSUE=<ISSUE-ID>
```

3. Do not proceed to the next SDLC stage if required artifacts or gates are missing.

## Evidence handling

- Do not infer live deployment, monitoring, or incident status.
- Use MCP or approved tool output only when available; otherwise ask the human to paste evidence.
- Mark missing evidence explicitly as **missing evidence** — never fabricate metric values or alert states.
- Do not fabricate incident severity, rollback outcomes, or SLO comparisons.
- Escalate production, security, or customer-impact uncertainty to human review.

## Instructions

1. Characterise the anomaly: type (error rate, latency, throughput, availability), magnitude vs baseline, first observed time, affected scope (endpoint, region, user segment).
2. Assess the **likelihood that the deployment caused the anomaly**: compare the anomaly start time relative to the deployment, the code paths changed vs the error patterns observed, and any prior incidents with similar signatures.
3. Distinguish between:
   - **Likely deployment-caused**: strong temporal correlation, changed code paths align with error patterns
   - **Possibly deployment-caused**: correlation present but other factors are plausible
   - **Likely unrelated**: no temporal correlation or error patterns do not align with changes
   - **Insufficient data**: cannot determine without more context
4. Identify **specific signals** the human should check next to confirm or rule out the deployment as the cause.
5. If the signals suggest a **critical severity incident** is possible, flag this clearly and recommend immediate human escalation — do not wait for further analysis.

## Output format

- **Anomaly characterisation** (type, magnitude, start time, affected scope)
- **Deployment causation assessment** (likely / possibly / likely unrelated / insufficient data, with reasoning)
- **Supporting evidence** (specific metric or log observations that support the assessment)
- **Recommended next checks** (specific and actionable)
- **Escalation recommendation** (should an incident be declared? if uncertain, say so)


---

## Stage Boundary

**Prompt type:** read_only_analysis
**Stage context:** MERGED

**Responsibility:** Interpret monitoring signals and surface findings for human operational decision.

**Authority:** This prompt performs read-only analysis. It produces no write
mutations, cannot approve gates, cannot advance the workflow, and cannot
perform work belonging to a different stage.

**Prohibited:**
- trigger rollback without human decision
- modify configuration or infrastructure unilaterally

**Handoff:** → human decision → rollback-plan or release-verification

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before monitoring-interpretation, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files are **read-only**; store project artifacts under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user. Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Human action required

An SRE or on-call engineer must review this analysis and decide whether to:
1. Continue monitoring
2. Investigate further
3. Declare an incident and begin the incident response playbook
4. Execute a rollback

AI does not declare incidents, execute rollbacks, or change system state. All actions from this point require a named human decision-maker.
