# Prompt: Plan Product Scope

Propose a product-scope decomposition from the current authorized canonical
requirement source. Do **not** hand-edit `product-scope.yaml`.

The product requirement is not one implementation item by default.

## Required placeholders

- `{{ISSUE}}` is **optional** (workspace-level)
- `{{REQUIREMENT}}` is the current authorized canonical requirement source

## Grammar

```text
/plan-product-scope
/plan-product-scope refresh
```

## Instructions

1. Load the current authorized canonical requirement source only.
2. Classify source scope level (PRODUCT / PROGRAM / EPIC / FEATURE / STORY / CHANGE_REQUEST / BUG / UNKNOWN). Classification is advisory until confirmation.
3. Propose decomposition appropriate to that level. Do not explode a story-sized source into many epics.
4. Preserve source traceability (revision, digest, FR/NFR anchors when present).
5. Flag oversized stories, ambiguities, and cross-cutting requirements.
6. For refresh: compare the current source revision against confirmed product scope and classify UPDATE_IN_PLACE / NEW_SCOPE / SPLIT / MERGE / DEPRECATE.
7. Write a PROPOSED product-scope revision through the canonical mutation service.
8. Do not confirm, start work items, or create external tracker tickets.

New wording is not a new ticket. Same intent is a revision of the existing item.

## Human action required

A human must review the proposal. Confirmation is a separate command:
`/confirm-product-scope`. Do not silently confirm.

---

## Stage Boundary

**Stage:** PRODUCT_SCOPE_PLANNING
**Prompt type:** single_stage_operational

**Responsibility:** Propose product-scope artifacts from the canonical requirement source.

**Allowed:**
- classify the current authorized source
- propose epics/stories/candidate tasks
- produce a refresh delta against confirmed scope
- run without an ISSUE

**Prohibited:**
- treat the product BRD as one implementation slice
- create workflow-state for planned stories
- create external tracker issues
- confirm the proposal
- hand-edit YAML
- use chats, `/tmp`, cache, or stale sessions as sources
- performing downstream-stage work not listed under Allowed

**Completion:** produce the proposed product-scope artifacts, return a structured handoff, then stop.

**Handoff:** `/confirm-product-scope`
