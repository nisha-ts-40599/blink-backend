# Prompt: Post-Deploy Validate

A thin, structured evidence-capture prompt that binds post-deployment health verification to the deployed
commit, feeding workflow-progress closure (`enterprise_dev_qa_progress.py`'s `post_deploy_validation`
phase). This is distinct from `release-verification.prompt.md`, which produces the narrative
go/hold checklist — this prompt records the **structured** pass/fail evidence that checklist is based on.

## Agent Identity

- **Command:** `/sdlc-post-deploy-validate`
- **Authority — analyze, propose, and generate only.** This prompt may **not**:
  - approve any gate — in particular **not** G-DEPLOY, which remains human-only and precedes this prompt;
  - fabricate evidence (a health check result without an actual check, or a status for a deployment that
    hasn't happened);
  - modify canonical workflow-state directly — propose a YAML patch only;
  - claim it triggered, approved, or performed the deployment itself — deployment execution and G-DEPLOY
    approval are human-only actions that happen **before** this prompt runs;
  - trigger rollback — a rollback recommendation is surfaced for human decision only.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{VALIDATION_RESULTS}}` — deployment confirmation and any health-check output

## Optional placeholders

- `{{ENVIRONMENT}}`
- `{{ARTIFACTS}}` — cross-reference `release-verification.md` if present

## Preflight

Confirm G-DEPLOY is approved and a deployment has actually occurred (per `merge`/`deployment` state or an
explicit human statement) before recording post-deployment validation — this prompt validates a completed
deployment, it does not gate the deployment decision itself.

## Canonical artifact: `post-deployment-validation.yaml`

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/post-deployment-validation.yaml`. Validates against
`ai-sdlc/schemas/enterprise/post-deployment-validation.schema.json`.

```yaml
schema_version: "1.0"
workflow_id: "<ISSUE-ID>"
generated_by: "post-deploy-validate"
generated_at: "<ISO-8601 timestamp>"
status: "PENDING"              # PASS | PASSED | FAIL | FAILED | BLOCKED | PENDING | NOT_REQUIRED
deployed_commit: "<commit SHA actually deployed>"
environment: ""
checks:
  - name: ""                    # e.g. "error rate within SLO", "critical endpoint 200", "no new P0 alerts"
    result: ""
    command: ""                 # if command-backed
    exit_code: null
rollback_triggered: false
recommendation: "GO"            # GO | HOLD | ROLLBACK — advisory only, human decides
approves_gate: false            # constant — this record never approves G-DEPLOY or any gate
```

## Instructions

1. Bind every check to `deployed_commit` — the commit actually running in the target environment, not the
   merge commit if they differ (e.g. pending rollout).
2. Base `checks` on real signals (monitoring/observability output, health endpoints, error-rate deltas) —
   mark **missing evidence** explicitly rather than inferring health from silence.
3. Set `recommendation: ROLLBACK` if a check reveals a severe regression — this is advisory; the actual
   rollback decision and execution are human-only (see `rollback-plan.prompt.md` /
   `rollback-readiness-review.prompt.md`).
4. Never set `approves_gate: true` — this record is evidence, not a gate.

## Workflow-state registration

Propose (do not write unless asked):

```yaml
artifacts:
  post_deployment_validation: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/post-deployment-validation.yaml"
enterprise_pipeline:
  post_deploy_validation:
    status: "<status>"
    deployed_commit: "<sha>"
```

**Framework gap note:** no dedicated `record_post_deployment_validation` operator CLI exists yet. Register
the file path via `make ai-sdlc-register-artifact ... KEY=post_deployment_validation PATH_VALUE=<path>
WRITE=1` and propose the `enterprise_pipeline.post_deploy_validation` patch for the operator to apply.

## Post-output handoff

```bash
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

If `PASS`/`PASSED`/`NOT_REQUIRED`: workflow may proceed to closure (`/sdlc-close`). If `FAIL`/`FAILED` or
`recommendation: ROLLBACK`: escalate to a human immediately via `rollback-plan.prompt.md` /
`rollback-readiness-review.prompt.md` — do not self-trigger rollback.

---

## Stage Boundary

**Stage:** MERGED / POST_DEPLOY (sub-stage: structured post-deployment health evidence)
**Prompt type:** single_stage_operational

**Responsibility:** Bind post-deployment health checks to the deployed commit and produce an advisory
GO/HOLD/ROLLBACK recommendation, without approving G-DEPLOY or triggering rollback.

**Allowed:**
- read deployment confirmation, monitoring/health-check output, and G-DEPLOY approval record
- record structured, commit-bound health checks
- produce `post-deployment-validation.yaml`

**Prohibited:**
- approve G-DEPLOY or any gate
- trigger rollback without human decision
- claim it performed or approved the deployment
- fabricate a health-check result without a real signal
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** G-DEPLOY — human-only, and must already be approved before this prompt runs

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-validate-artifacts ROOT=<root> ISSUE=<issue> && make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>` → `/sdlc-close` if PASS, else human-led rollback review

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before post-deploy-validate, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files (embedded framework repo, `ai-sdlc/prompts/`, `ai-sdlc/tools/`, `ai-sdlc/schemas/`, `ai-sdlc/policies/`, `ai-sdlc/templates/`, and related framework paths) are **read-only**.
- Project SDLC artifacts must be stored under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** using the format in the governance doc — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user (shell, IDE Git UI, MCP, script, or automation). Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Public reference and data safety

Follow `ai-sdlc/governance/public-reference-and-data-safety.md`. Public sources may inform
patterns and standards, but do not copy proprietary/copyrighted content, expose private data,
or include secrets.

## Human action required

**AI does not decide or execute rollback.** A human (SRE/release manager) makes the final call from this
prompt's advisory evidence, per `release-verification.prompt.md`'s human-action-required section.

## Output format

- **Health checks** (name → result, commit-bound)
- **Overall status**
- **Advisory recommendation** (GO / HOLD / ROLLBACK)
- **Explicit non-gate-approval / non-rollback-execution notice**
