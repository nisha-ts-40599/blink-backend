# Prompt: Post-Migration Validation Plan

Define validation scope and acceptance criteria after production cutover.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONTEXT}}`
- `{{PROJECT_CONFIG}}`
- `{{RISK_TIER}}`

## Optional placeholders

- `{{ARTIFACTS}}`
- `{{TEST_EXPECTATIONS}}`
- `{{MONITORING_SIGNALS}}`

## Instructions

1. Reference `post_migration_validation_policy.required_checks` from project-config.
2. Use `templates/post-migration-validation-plan-template.md`.
3. Save output to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/post-migration-validation-plan.md`.
4. Update workflow-state:

```yaml
artifacts:
  post_migration_validation_plan: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/post-migration-validation-plan.md"
post_migration_validation:
  required: true
  status: planned
```

## Scope boundaries

- Planning only — do not run production validation tests or modify live systems.

## Safety / data guardrails

- Sanitized test data references only.


---

## Stage Boundary

**Stage:** MERGED
**Prompt type:** single_stage_operational

**Responsibility:** Produce a post-migration validation plan before cutover execution.

**Allowed:**
- read cutover-plan.md and migration context
- produce post-migration-validation-plan.md

**Prohibited:**
- begin post-migration validation without approved plan
- approve G-CUTOVER
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

## Human action required

- Validation owners and acceptance criteria require human confirmation.

## Workflow-state update

Complete before advancing to `CUTOVER_READY` when cutover policy requires it.
