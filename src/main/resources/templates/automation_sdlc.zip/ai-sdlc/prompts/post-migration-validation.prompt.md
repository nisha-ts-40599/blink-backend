# Prompt: Post-Migration Validation

Record post-migration validation results after cutover. Validation documentation only.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONTEXT}}`
- `{{PROJECT_CONFIG}}`
- `{{VALIDATION_RESULTS}}`

## Optional placeholders

- `{{ARTIFACTS}}`
- `{{MONITORING_SIGNALS}}`
- `{{DEPLOYMENT_SUMMARY}}`

## Instructions

1. Reference `post-migration-validation-plan.md` and regression baseline artifacts.
2. Use `templates/post-migration-validation-template.md`.
3. Save output to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/post-migration-validation.md`.
4. Update workflow-state:

```yaml
artifacts:
  post_migration_validation: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/post-migration-validation.md"
post_migration_validation:
  validation_status: passed | failed | partial
  completed_at: <ISO-8601 UTC>
```

5. If rollback is recommended, set `post_migration_validation.rollback_recommended: true` — do not execute rollback.

## Scope boundaries

- **Do not execute production actions, rollbacks, or remediation without human authorization.**
- Record sanitized validation evidence only.

## Safety / data guardrails

- No secrets or customer PII in validation results.


---

## Stage Boundary

**Stage:** MERGED
**Prompt type:** single_stage_operational

**Responsibility:** Execute post-migration validation against the approved validation plan.

**Allowed:**
- read post-migration-validation-plan.md and migration execution state
- validate migration outcomes against plan criteria

**Prohibited:**
- self-approve G-POST-MIGRATION
- modify migrated data without human authorization
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** G-POST-MIGRATION — human-only: make ai-sdlc-approve-gate GATE=G-POST-MIGRATION DECISION=approved WRITE=1

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `→ human approves G-POST-MIGRATION → make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

## Human action required

- **Do not approve `g_post_migration` without explicit human validation sign-off.**
- Rollback recommendation requires human decision — never auto-execute.

## Workflow-state update

After human approval, advance toward `VERIFIED` per stage router.
