# Prompt: PR Registration

Register pull request URL(s) after local commit and PR creation.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PR_CONTEXT}}`

## Instructions

1. Confirm local commit exists and working tree is clean (or document exceptions).
2. Record PR URL in `artifacts.implementation_prs` and `implementation.repos[].pr_url`.
3. Set `implementation.status: pr_opened` when PR exists.
4. Save `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/pr-registration.md` using `templates/pr-registration-template.md`.
5. Advance stage toward `REVIEW_REQUESTED` only when PR URL is registered — not before.


---

## Stage Boundary

**Stage:** PR_OPEN
**Prompt type:** single_stage_operational

**Responsibility:** Record the PR URL and metadata in workflow-state after the developer creates the PR.

**Allowed:**
- read PR URL provided by developer and implementation-step-summary.md
- record PR details in workflow-state

**Prohibited:**
- create the PR in version control
- perform code review
- merge the PR
- approve G-PR-MERGE
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-register-pr ... WRITE=1 && make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

## Human action required

Humans create PRs and provide URLs. AI must not self-merge or mark PR reviewed without explicit approval.
