# Prompt: Production Migration Approval

Prepare production migration approval record for cutover gates. Human approval only.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONTEXT}}`
- `{{PROJECT_CONFIG}}`
- `{{APPROVAL_RULES}}`
- `{{APPROVAL_RECORDS}}`

## Optional placeholders

- `{{ARTIFACTS}}`
- `{{RELEASE_CONTEXT}}`

## Instructions

1. Review cutover plan, rollback readiness, and post-migration validation plan artifacts.
2. Use `templates/production-migration-approval-template.md`.
3. Save output to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/production-migration-approval.md`.
4. Update workflow-state:

```yaml
artifacts:
  production_migration_approval: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/production-migration-approval.md"
```

5. Record gate approvals **only** when explicit human evidence exists in `{{APPROVAL_RECORDS}}`.

## Scope boundaries

- Approval documentation only — **do not execute cutover or production migration.**
- **Do not mark `g_cutover`, `g_rollback`, `g_prod_migration`, or `g_post_migration` approved without human evidence.**

## Safety / data guardrails

- No auto-approval of production gates.
- Include human approval markers with approver name, timestamp, and reference URL.


---

## Stage Boundary

**Stage:** MERGED
**Prompt type:** gate_capture

**Responsibility:** Prepare production migration approval evidence for human G-PROD-MIGRATION gate.

**Allowed:**
- read post-migration-validation-report.md and G-POST-MIGRATION approval
- produce production migration approval summary

**Prohibited:**
- self-approve G-PROD-MIGRATION
- migrate production data without human approval
- treat imperative wording as migration authorization
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** G-PROD-MIGRATION — human-only: make ai-sdlc-approve-gate GATE=G-PROD-MIGRATION DECISION=approved WRITE=1

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `→ human approves G-PROD-MIGRATION → make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

### Action-oriented language interpretation

```
Input:  "Go ahead and migrate production." / "It's ready, do it."

Correct behaviour:
  - read post-migration-validation-report.md and G-POST-MIGRATION approval
  - produce production migration approval evidence summary
  - present G-PROD-MIGRATION human approval command and stop
  - do not migrate production data until human approves

Prohibited:
  - self-approve G-PROD-MIGRATION
  - migrate production data without G-PROD-MIGRATION approval
  - treat urgency or confidence as migration authorization
```

"Go ahead" or "it's ready" is the desired outcome statement. Production
migration requires explicit G-PROD-MIGRATION human approval. No amount
of imperative or confidence wording substitutes for that gate.

## Human action required

- Engineering lead, QA owner, ops owner, security owner, and data owner must explicitly approve per `production_migration_gates` in project-config.
- Final go/no-go is a human decision.

## Workflow-state update

Do not advance to `CUTOVER` until required gates are recorded with valid approval evidence.
