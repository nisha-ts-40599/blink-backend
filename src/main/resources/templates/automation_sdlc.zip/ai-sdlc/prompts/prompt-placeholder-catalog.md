# Prompt Placeholder Catalog (Canonical)

This catalog defines the only approved placeholders for reusable prompts in `ai-sdlc/prompts/*.prompt.md`.

## Canonical Placeholders

| Placeholder | Meaning |
|-------------|---------|
| `{{PROJECT_CONTEXT}}` | Project/business/system context from configuration and docs |
| `{{PROJECT_INTENT}}` | What a new (greenfield) project or workspace is meant to do: domain, users, value delivered, rough scope; used in setup prompts for net-new projects |
| `{{GREENFIELD_SPEC_PARTIAL}}` | Optional partial YAML draft of `greenfield-project-spec` supplied by the user during normalization |
| `{{GREENFIELD_SPEC_PATH}}` | Path to the canonical validated `greenfield-project-spec.yaml` artifact |
| `{{TECH_STACK}}` | Runtime/framework/language/tooling stack details |
| `{{REQUIREMENT}}` | Requirement statement or requirement document excerpt |
| `{{REQUIREMENT_TYPE}}` | Grooming category: Bug, Enhancement, New feature, New product, Modernization/migration, QA/test automation, Cloud/devops/platform, Documentation/process/tooling |
| `{{WORK_TIER}}` | Current or inferred work tier (1–4); drives review depth, gate requirements, and stakeholder coverage for the active issue |
| `{{STAKEHOLDER_FEEDBACK}}` | Human-provided or simulated stakeholder feedback — typically the filled `stakeholder-pack.md` or free-text answers — applied during grooming revision or sign-off assessment |
| `{{GROOMING_REVISION_NUMBER}}` | Current grooming revision number hint used when generating or labelling a grooming revision artifact (e.g. `revision_count + 1`); defaults to auto-detect when omitted |
| `{{ISSUE}}` | Issue details including scope and links |
| `{{ACCEPTANCE_CRITERIA}}` | Acceptance criteria list or checklist |
| `{{CURRENT_BEHAVIOR}}` | Observed or existing behavior before the change |
| `{{EXPECTED_BEHAVIOR}}` | Desired behavior after the change or fix |
| `{{EDGE_CASES}}` | Known or suspected edge cases and corner cases |
| `{{TEST_EXPECTATIONS}}` | Expected test coverage, types, and quality gates for the requirement |
| `{{PUBLIC_REFERENCE_NOTES}}` | High-level public pattern notes; source names/links to be verified by human — no proprietary copy |
| `{{REPOSITORY_CONTEXT}}` | Codebase structure, modules, and relevant source context |
| `{{SECURITY_MODEL}}` | Security model, data classification, controls, compliance constraints |
| `{{APPROVAL_RULES}}` | Approval policy and gate rules |
| `{{WORKFLOW_STATE}}` | Current workflow stage, gates, and execution state |
| `{{PROJECT_CONFIG}}` | Content of `project-config.yaml` — prefer `.cursor/ai-sdlc/project-config.yaml`; fallback `ai-sdlc/project-config.yaml` |
| `{{AVAILABLE_ARTIFACTS}}` | List of artifact paths/URLs currently recorded in the workflow state for the active issue |
| `{{APPROVAL_RECORDS}}` | Gate approval records: gate ID, approver name, approval timestamp, and comment URL for each recorded gate |
| `{{RECENT_CI_STATUS}}` | Current CI job statuses (pass/fail/pending) for the active PR or branch — from GitHub Actions or equivalent |
| `{{CURRENT_BLOCKERS}}` | Active blocked_reasons from the workflow state file, or known blocking conditions noted by the engineer |
| `{{HUMAN_NOTES}}` | Optional free-text context provided by the engineer about the current situation, decisions, or exceptions |
| `{{ARTIFACTS}}` | Referenced artifacts and their statuses/links |
| `{{RISK_TIER}}` | Classified tier (`1`, `2`, `3`, `4`) |
| `{{CURRENT_STEP}}` | Current implementation or workflow step detail |
| `{{VALIDATION_RESULTS}}` | CI/test/scan/review outputs and summaries |
| `{{PR_CONTEXT}}` | Pull request metadata, description, diff summary, comments |
| `{{RELEASE_CONTEXT}}` | Release candidate, environment, deployment, and verification context |
| `{{ENGINEERING_GUARDRAILS}}` | Content of `ai-sdlc/governance/enterprise-engineering-guardrails.md`; when present in a prompt, every guardrail in that document is an active constraint on AI output |
| `{{BUG_REPORT}}` | Issue body, user report, or incident description for bug triage |
| `{{STACK_TRACE}}` | Full stack trace or error log excerpt for bug or incident analysis |
| `{{RECENT_CHANGES}}` | Recent merged PRs, commits, or deployment notes for a relevant time window |
| `{{ENVIRONMENT}}` | Target or affected environment: staging / production / region / instance |
| `{{AFFECTED_COMPONENT}}` | Known affected service, module, or endpoint |
| `{{REPRODUCTION_STEPS}}` | Steps to reproduce a bug or failure |
| `{{MONITORING_SIGNALS}}` | Alert body, error rate data, latency percentiles, or metric summaries |
| `{{AUDIT_OUTPUT}}` | Raw output of npm audit, pip-audit, trivy, Dependabot alerts, or equivalent |
| `{{DEPENDENCY_MANIFEST}}` | Relevant portion of package.json, requirements.txt, pom.xml, or equivalent |
| `{{EXISTING_MITIGATIONS}}` | Known WAF rules, network isolation, or other controls relevant to exploitability |
| `{{MERGED_PRS}}` | List of merged PR titles, descriptions, and linked issue IDs for a release range (changelog generation) |
| `{{IMPLEMENTATION_PRS}}` | Merged PRs that implemented the feature or service being documented (runbook drafts) |
| `{{IMPLEMENTATION_EVIDENCE}}` | Implementation diff/commit evidence from `implementation-evidence.md` or workflow-state `implementation` block |
| `{{RELEASE_VERSION}}` | Version being released: semver or date-based label |
| `{{PREVIOUS_VERSION}}` | Previous release version for context |
| `{{AUDIENCE}}` | Changelog or communication audience: internal / external / both |
| `{{RELEASE_DATE}}` | Planned or actual release date |
| `{{RUNBOOK_SUBJECT}}` | Feature, service, process, or incident type the runbook covers |
| `{{ARCHITECTURE_CONTEXT}}` | Services, dependencies, data flows, and infrastructure relevant to a runbook |
| `{{MONITORING_SETUP}}` | Alert names, dashboards, and metric names relevant to a runbook or incident |
| `{{PREVIOUS_INCIDENTS}}` | Prior incident notes or postmortems for the service or failure class |
| `{{RUNBOOK_TYPE}}` | Runbook type: operational / incident-response / both |
| `{{DEPLOYMENT_SUMMARY}}` | What was deployed, when, to which environment, and the PR or ticket reference |
| `{{BASELINE}}` | Normal error rates, latency, and throughput for the service being monitored |
| `{{DEPENDENCY_STATUS}}` | Upstream service status or known dependency incidents during the analysis window |
| `{{LOG_EXCERPTS}}` | Representative error log lines from the anomaly window |

## Workspace Placeholders

These placeholders are used in workspace-level prompts that span multiple repositories.
They complement the single-repo placeholders above.

| Placeholder | Meaning |
|-------------|---------|
| `{{WORKSPACE_CONTEXT}}` | Full workspace context — prefer `.cursor/ai-sdlc/workspace-context.md`; fallback `ai-sdlc/workspace-context.md` |
| `{{WORKSPACE_CONFIG}}` | Machine-readable workspace map — prefer `.cursor/ai-sdlc/workspace-config.yaml`; fallback `ai-sdlc/workspace-config.yaml` |
| `{{REPOSITORY_MAP}}` | Structured list of repos in the workspace with identifiers, roles, and paths |
| `{{AFFECTED_REPOSITORIES}}` | List of specific repos affected by the current change or issue being analyzed |
| `{{CROSS_REPO_DEPENDENCIES}}` | Dependency table subset relevant to the current change (source, target, type, contract) |
| `{{API_CONTRACTS}}` | API contract table for contracts affected by the current change (provider, consumers, schema) |
| `{{DEPLOYMENT_ORDER}}` | Ordered deployment sequence for the repos affected by the current change |
| `{{MERGE_READINESS_CONTEXT}}` | Current state of merge readiness checklist across all affected repo PRs |
| `{{DEPLOYMENT_READINESS_CONTEXT}}` | Current state of deployment readiness checklist across all affected repos |

### Workspace placeholder usage rules

- Use `{{WORKSPACE_CONTEXT}}` for prompts that reason across the full system (impact analysis, cross-repo planning).
- Use `{{PROJECT_CONTEXT}}` (single-repo) for prompts scoped to a single repository's implementation.
- Use `{{AFFECTED_REPOSITORIES}}` to narrow workspace context to only the repos involved in the current change.
- Never substitute `{{WORKSPACE_CONTEXT}}` for `{{PROJECT_CONTEXT}}` when running a repo-scoped prompt — they have different levels of detail.
- `{{MERGE_READINESS_CONTEXT}}` and `{{DEPLOYMENT_READINESS_CONTEXT}}` are runtime values; populate from the current PR/issue state, not from static config.

## Rules

1. Use only placeholders listed above.
2. Every prompt must include:
   - **Required placeholders**
   - **Optional placeholders**
   - **Expected output format**
3. Keep prompts generic and project-agnostic.
4. Do not embed secrets or credentials in placeholder values.
5. For workspace-level prompts, prefer `{{WORKSPACE_CONTEXT}}` over pasting per-repo context separately.
6. For repo-scoped prompts, use `{{PROJECT_CONTEXT}}` from `.cursor/ai-sdlc/repos/<repo-id>/project-context.md` or `.cursor/ai-sdlc/project-context.md` (single-repo). Fallback: `ai-sdlc/projects/<repo-id>/project-context.md`.
7. Load context in the order defined by `.cursor/ai-sdlc/context-loading.md` when present.
