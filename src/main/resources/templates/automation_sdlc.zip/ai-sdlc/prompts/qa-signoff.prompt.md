# Prompt: QA Sign-Off

Capture **sanitized** QA evidence after runtime verification. Mark **G-QA** approved only when human QA approval is explicit.

## Required placeholders

- `{{ISSUE}}`
- `{{ACCEPTANCE_CRITERIA}}`
- `{{WORKFLOW_STATE}}`

## Optional placeholders

- `{{VALIDATION_RESULTS}}`
- `{{REPRODUCTION_STEPS}}`
- `{{ENVIRONMENT}}`
- `{{RISK_TIER}}`

## Suggested artifact outputs

| Artifact | Purpose |
|----------|---------|
| `runtime-repro.md` | Sanitized runtime reproduction steps and results |
| `qa-validation.md` | Test-case matrix (TC-001–TC-005 style) mapped to acceptance criteria |

Save under `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/`.

## Instructions

1. Link each test case to one or more acceptance criteria IDs.
2. Record **pass/fail/blocked** with evidence references — no production PII, credentials, or customer data.
3. If runtime reproduction failed, document blockers; do **not** approve G-QA.
4. Propose `gates.g_qa` updates only when QA lead approval text is explicit — **never self-approve**.
5. Update workflow-state **only when the user explicitly asks**.

## Output format

- **Test case matrix** (TC-xxx → AC mapping)
- **Runtime repro summary**
- **Sanitized evidence paths**
- **Proposed G-QA gate patch** (if human approval is explicit)
- **Blockers** (if any)


---

## Stage Boundary

**Stage:** QA_PENDING
**Prompt type:** gate_capture

**Responsibility:** Prepare QA sign-off evidence summary for human G-QA approval.

**Allowed:**
- read qa-validation report and test evidence
- produce qa-signoff-summary.md with verdict

**Prohibited:**
- self-approve G-QA
- advance to PR review without human gate approval
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** G-QA — human-only: make ai-sdlc-approve-gate GATE=G-QA DECISION=approved WRITE=1

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `→ human approves G-QA → make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

## Human action required

QA sign-off requires a named QA approver. Vague approval must be treated as `needs_confirmation`.
