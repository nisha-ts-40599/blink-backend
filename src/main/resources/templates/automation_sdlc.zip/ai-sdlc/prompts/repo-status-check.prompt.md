# Prompt: Repo Status Check

Detect git repository topology under the workspace. **Workspace root may not be a git root.**

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`

## Optional placeholders

- `{{AFFECTED_REPOSITORIES}}`
- `{{WORKSPACE_CONTEXT}}`

## Instructions

1. Identify product **git repo root(s)** — do not assume workspace root is a git repository.
2. Run or recommend:

```bash
make ai-sdlc-repo-status ROOT=<workspace-root>
```

3. Record per repo: branch, upstream, clean/dirty, **staged**, **modified**, **untracked**, latest commit, unpushed commits.
4. Save sanitized snapshot to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/repo-status.md` using `templates/repo-status-template.md`.
5. Distinguish **workspace overlay artifacts** (`.cursor/ai-sdlc/**`) from **product repo changes**.

## Output format

- Repo topology table
- Untracked files called out separately
- Proposed `repo_status_snapshot` YAML block (optional)


---

## Stage Boundary

**Prompt type:** read_only_analysis
**Stage context:** ALL

**Responsibility:** Report current repository status (branches, remotes, CI state) without making any changes.

**Authority:** This prompt performs read-only analysis. It produces no write
mutations, cannot approve gates, cannot advance the workflow, and cannot
perform work belonging to a different stage.

**Prohibited:**
- modify repository state
- merge branches
- approve gates

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Human action required

Git status reflects the engineer's machine. Human must confirm paths and branches before registering evidence.
