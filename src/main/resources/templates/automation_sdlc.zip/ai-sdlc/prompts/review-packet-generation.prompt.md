# Prompt: Review Packet Generation

Generate a **short review packet** for distributed teams awaiting gate decisions.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{AVAILABLE_ARTIFACTS}}`
- `{{RISK_TIER}}`

## Optional placeholders

- `{{APPROVAL_RECORDS}}`
- `{{HUMAN_NOTES}}`
- `{{AFFECTED_REPOSITORIES}}`

## Instructions

Produce a concise packet (≤ 1 page) containing:

1. **Summary** — what is being reviewed and why now
2. **Artifact index** — links/paths to requirement, plan, spike notes, QA evidence
3. **Decisions needed** — which gate(s) and what question each approver must answer
4. **Suggested approval phrase** — explicit wording the approver should post (not vague LGTM)
5. **Risk tier** and **risk profile** (payment-sensitive, PII-adjacent, spike required)
6. **Affected repos** and change scope
7. **Gate owner** — role/name expected to approve (from project-config approval rules)

## Output format

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/review-packet.md` when asked, or return inline markdown.

Do not modify workflow-state unless explicitly requested.


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** REVIEW_REQUESTED

**Responsibility:** Assemble a review packet for human or AI PR review.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- perform the review itself
- approve G-PR-MERGE

**Handoff:** → /pr-review

## Human action required

Review packets support human gate decisions only. The approver must post explicit approval — AI must not self-approve or advance gates.
