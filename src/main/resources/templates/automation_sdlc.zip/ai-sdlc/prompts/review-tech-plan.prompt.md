# Prompt: Review Technical Plan

Record a **named human** review of the current technical plan. Bind reviewer
identity to the plan digest and update `pre_development.technical_plan.status`
in the same transaction.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`

## Instructions

1. Run stage preflight. If ineligible, stop and run `/sdlc-next {{ISSUE}}`.
2. Collect the named reviewer, role, decision, and rationale from the human.
3. Record the review with `WRITE=1` only after that human supplies the decision.

```bash
make ai-sdlc-validate-stage ROOT=<workspace-root> ISSUE=<ISSUE-ID> EXPECTED_STAGE=PLAN_REVIEW
make ai-sdlc-record-human-review ROOT=<workspace-root> ISSUE=<ISSUE-ID> \
  KIND=technical_plan REVIEWER="<Full Name>:<email>" ROLE=engineering_lead \
  DECISION=<decision> RATIONALE="<text>" WRITE=1
```

Allowed decisions: `approved`, `approved_with_assumptions`, `needs_revision`.

After success: `/sdlc-next {{ISSUE}}`.

## Human action required

Do **not** invent a reviewer. Do **not** use an internal utility identity as
reviewer. Do **not** pass `WRITE=1` unless the named human supplied the decision.

---

## Stage Boundary

**Stage:** PLAN_REVIEW
**Prompt type:** single_stage_operational

**Responsibility:** Record a named human review of the current technical plan; this is not a gate approval.

**Allowed:**
- run stage preflight for PLAN_REVIEW
- collect reviewer identity, role, decision, and rationale from a human
- persist the review with `WRITE=1` only after that human supplies the decision

**Prohibited:**
- invent a reviewer identity
- use an internal utility identity as reviewer
- approve G-PLAN or treat plan review as gate approval
- begin implementation or produce product code
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** record the human review when supplied, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`
