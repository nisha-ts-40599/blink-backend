# Prompt: Rollback Plan

Produce a **rollback plan** for merge readiness. This documents how to revert the change if post-deploy validation fails — it does **not** authorize rollback execution.

## Context loading

Load workspace-local `.cursor/ai-sdlc/` context first (see `context-loading.md` when present):
project-config (including `rollback_policy`), project-context, workflow-state, and implementation evidence.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{RISK_TIER}}`
- `{{PROJECT_CONFIG}}`

## Optional placeholders

- `{{REPOSITORY_CONTEXT}}`
- `{{IMPLEMENTATION_EVIDENCE}}`
- `{{PR_CONTEXT}}`
- `{{APPROVAL_RULES}}`

## Instructions

1. Determine whether rollback is required using `rollback_policy` and workflow-state tier / `risk_profile` / `work_type`.
2. Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/rollback-plan.md` using `templates/rollback-plan-template.md`.
3. Register the artifact in workflow-state:

```yaml
artifacts:
  rollback_plan: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/rollback-plan.md"
```

4. Propose `rollback` block updates when evidence is available:

```yaml
rollback:
  required: true
  status: draft
  type: git_revert
  owner: ""
  approved: false
  executed: false
  validation_status: not_run
  data_cleanup_required: false
  data_cleanup_approved: false
```

5. Use **sanitized evidence only** — no secrets, credentials, or customer PII in the plan.
6. Ask for missing operational details (revert command, previous build ID, feature flag name) but still produce a draft with clearly marked **TBD** sections.
7. For Tier 3+ production-impacting work, specify concrete rollback triggers and post-rollback validation steps.
8. When rollback type is `database_restore`, `manual_data_correction`, identity/auth rollback, or payment correction, mark **Human approval required** in the plan.

## Rollback types (from project-config)

Use values from `rollback_policy.rollback_types` when present, for example:

- `git_revert`, `redeploy_previous_build`, `feature_flag_disable`, `config_revert`
- `database_restore`, `traffic_switchback`, `manual_data_correction`


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** PLAN_DRAFTED

**Responsibility:** Produce a rollback strategy document supporting the technical plan.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- execute rollback
- approve G-PLAN or G-ROLLBACK
- begin implementation

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Human action required

- **Never** approve rollback execution automatically.
- **Never** approve merge, deploy, or G-PR-MERGE gates from this prompt.
- **Never** mark `rollback.approved: true` without explicit human sign-off.
- Database restore, production data cleanup, identity/auth rollback, payment data correction, and customer-facing cutover reversal require named human approvers per `rollback_policy.approval_required_for`.
- Update workflow-state only when the human explicitly requests it.
