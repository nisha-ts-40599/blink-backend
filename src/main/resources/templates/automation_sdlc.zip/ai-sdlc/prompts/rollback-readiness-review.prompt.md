# Prompt: Rollback Readiness Review

Review rollback readiness before production cutover. Readiness review only — not rollback execution.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONTEXT}}`
- `{{PROJECT_CONFIG}}`
- `{{RISK_TIER}}`

## Optional placeholders

- `{{ARTIFACTS}}`
- `{{APPROVAL_RULES}}`

## Instructions

1. Confirm `rollback_plan` artifact exists and is current.
2. Use `templates/rollback-readiness-review-template.md`.
3. Save output to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/rollback-readiness-review.md`.
4. Update workflow-state:

```yaml
artifacts:
  rollback_readiness_review: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/rollback-readiness-review.md"
```

5. Do not set `rollback.executed` or approve `g_rollback` without human evidence.

## Scope boundaries

- Rollback **readiness** review only — distinct from rollback execution.
- **Do not execute rollback, database restore, or production rollback commands.**

## Safety / data guardrails

- Sanitized evidence only.
- Document data cleanup readiness and time-to-rollback estimates.


---

## Stage Boundary

**Prompt type:** read_only_analysis
**Stage context:** PLAN_DRAFTED

**Responsibility:** Review and assess rollback readiness before cutover or release.

**Authority:** This prompt performs read-only analysis. It produces no write
mutations, cannot approve gates, cannot advance the workflow, and cannot
perform work belonging to a different stage.

**Prohibited:**
- execute rollback
- approve G-ROLLBACK or G-CUTOVER

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Human action required

- **Do not approve `g_rollback` without explicit human approval evidence.**
- **Do not approve rollback execution automatically.**

## Workflow-state update

Advance stage only after human confirms readiness decision.
