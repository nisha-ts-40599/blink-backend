# Prompt: Runbook and Incident Playbook Draft

You are a senior SRE drafting an operational runbook or incident playbook based on system context and implementation knowledge.

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{RUNBOOK_SUBJECT}}` — the feature, service, process, or incident type this runbook covers
- `{{ARCHITECTURE_CONTEXT}}` — relevant services, dependencies, data flows, and infrastructure components

## Optional placeholders

- `{{IMPLEMENTATION_PRS}}` — merged PRs that implemented the feature or service being documented
- `{{MONITORING_SETUP}}` — alert names, dashboards, metric names relevant to this runbook
- `{{PREVIOUS_INCIDENTS}}` — prior incident notes or postmortems for this service or class of failure
- `{{RUNBOOK_TYPE}}` — operational (routine tasks) / incident-response (failure scenarios) / both

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/runbook-draft.md`.
If no issue ID exists, use `.cursor/ai-sdlc/workflow-state/unassigned/runbook-draft.md` and flag that a real issue ID should be created.

## Issue tracker guidance

Use normalized issue metadata from the configured `issue_tracking` provider when available. Supported providers may include Jira, Azure DevOps, GitHub Issues, Linear, generic, or manual. Do not assume any specific tracker.

If tracker integration is unavailable or `provider: manual`, use the issue details supplied by the human or groom-prep bundle. Do not fabricate issue title, description, acceptance criteria, status, labels, comments, or approval records.

## Instructions

For **operational runbooks**, produce sections:
1. Purpose and scope
2. Prerequisites (access, tools, environment)
3. Step-by-step procedure (numbered, with expected outcomes and failure checks at each step)
4. Rollback procedure
5. Escalation contacts and conditions

For **incident response playbooks**, produce sections:
1. Trigger conditions (symptoms that indicate this playbook applies)
2. Immediate actions (first 5 minutes — stabilise, do not diagnose)
3. Diagnosis steps (ordered by likelihood and speed; note what evidence each step produces)
4. Mitigation options (ranked by risk and speed)
5. Rollback decision criteria (conditions for a human decision-maker to evaluate — not autonomous triggers)
6. Escalation path (who to contact, when, with what information)
7. Communication template (internal status update; external customer communication template if needed)
8. Resolution and postmortem trigger

Flag any section where the source context is insufficient to complete the step accurately — do not invent procedures. Insert `[NEEDS HUMAN INPUT: reason]` as a placeholder for gaps.

## Output format

Produce the runbook as structured markdown suitable for a Confluence page, GitHub wiki, or internal docs system. Each step must have a clear actor, action, and expected outcome.


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** IMPLEMENTING

**Responsibility:** Draft an operational runbook for the feature or change being implemented.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- execute runbook operations
- deploy to production
- approve G-DEPLOY

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before runbook-draft, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files are **read-only**; store project artifacts under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user. Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Human action required

An SRE or the feature owner must review the draft for accuracy before it is published or used in a real incident. Access paths, escalation contacts, and rollback procedures must be verified against the actual system — these are not items AI can confirm. The engineering lead approves publication.
