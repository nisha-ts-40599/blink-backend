# Prompt: Security Assessment (Modernization)

Produce a **security and identity assessment** for security/identity modernization work. This documents risks and controls — it does **not** approve security gates or execute changes.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PROJECT_CONTEXT}}`
- `{{PROJECT_CONFIG}}`
- `{{SECURITY_MODEL}}`
- `{{RISK_TIER}}`

## Optional placeholders

- `{{REPOSITORY_CONTEXT}}`
- `{{ARTIFACTS}}`
- `{{APPROVAL_RULES}}`

## Instructions

1. Load workspace `.cursor/ai-sdlc/` context including `modernization_profile`, workflow-state, and prior modernization artifacts.
2. Use `templates/security-assessment-template.md` as the output structure.
3. Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/security-assessment.md`.
4. Cover identity provider, roles/permissions, secrets, audit/logging, compliance, and migration-specific risks.
5. Use **sanitized evidence only** — no secrets, credentials, tokens, or customer PII.
6. Update workflow-state:

```yaml
artifacts:
  security_assessment: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/security-assessment.md"
```

7. Run `make ai-sdlc-validate-artifacts` and `make ai-sdlc-stage-router` before advancing stage.

## Output format

Follow all required sections in `security-assessment-template.md`. Mark unknowns as **TBD** with owner questions.

## Scope boundaries

- Assessment only — no production cutover, IAM changes, or gate execution (Phase 3).
- Do not modify product code unless explicitly in an approved implementation step.
- Preserve existing security behavior unless explicit human approval records a change.

## Safety / data guardrails

- Use **sanitized evidence only**.
- Do not assume microservices or rewrite by default.
- Follow `{{SECURITY_MODEL}}` and project-config guardrails.


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** CLASSIFIED

**Responsibility:** Produce a security risk assessment for a classified Tier 3+ work item.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- self-approve G-SEC (human-only)
- modify product code
- create implementation evidence

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Human action required

- **Do not approve G-SEC or any security gate without explicit human evidence.**
- Never mark security controls as approved from this prompt.
- Security migration decisions require named human approvers per `approval_rules`.
- Do not self-advance workflow stage — human confirms after review.

## Workflow-state update

After human review, advance `current_stage` per stage router suggestion (do not self-advance without human confirmation).
