# Prompt: Self-Review (Pre-PR)

You are the implementer performing a critical self-review before requesting peers.

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{ISSUE}}`
- `{{ACCEPTANCE_CRITERIA}}`
- `{{SECURITY_MODEL}}`
- `{{PR_CONTEXT}}`
- `{{VALIDATION_RESULTS}}`

## Optional placeholders

- `{{REPOSITORY_CONTEXT}}`
- `{{RISK_TIER}}`
- `{{ARTIFACTS}}`
- `{{ENGINEERING_GUARDRAILS}}` — content of `ai-sdlc/governance/enterprise-engineering-guardrails.md`; when present, every guardrail is an active review criterion

## Context value sources

| Placeholder | Preferred source | Auto-populated today | Manual fallback |
|-------------|------------------|----------------------|-----------------|
| `{{PROJECT_CONTEXT}}` | `.cursor/ai-sdlc/project-context.md` | Yes, via bundle | Paste project context |
| `{{PR_CONTEXT}}` | GitHub/Git MCP or pasted diff | No | Paste branch diff summary |
| `{{VALIDATION_RESULTS}}` | CI MCP or local test output | No | Paste results; mark **missing evidence** if unknown |
| `{{ACCEPTANCE_CRITERIA}}` | `requirement.md` | Partial | Paste AC |

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/self-review.md`.
If no issue ID exists, use `.cursor/ai-sdlc/workflow-state/unassigned/self-review.md` and flag that a real issue ID should be created.

**H10:** This prompt produces **AI implementation review** (`implementation.reviews.ai_implementation_review`), not developer self-review attestation. Record reviewer model and reviewed commit. Developer attestation requires explicit human identity via a separate developer review step — AI output must not populate `developer_self_review` or `developer_attestation`.

## Workflow-state registration

After saving, update workflow state:

```yaml
artifacts:
  self_review_output: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/self-review.md"
```

## Post-output handoff

After saving this output:

1. Update the workflow-state `artifacts` entry for the generated artifact.
2. Run:

```bash
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout:

```bash
make ai-sdlc-validate-artifacts ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=.. ISSUE=<ISSUE-ID>
```

3. Do not proceed to the next SDLC stage if required artifacts or gates are missing.

## Evidence handling

- Do not infer live CI, PR, or test status.
- Use MCP or approved tool output only when available; otherwise ask the human to paste evidence.
- Mark missing evidence explicitly as **missing evidence** — never fabricate validation results.
- Do not fabricate approvals or merge readiness.
- Escalate production, security, or customer-impact uncertainty to human review.

## Instructions

1. Verify **acceptance criteria** coverage traceability.
2. Hunt for **edge cases**, **null paths**, **error handling**, and **off-by-one** issues.
3. Check **security**: injection, SSRF, path traversal, authz gaps, secret handling, PII logging.
4. Check **performance** hot paths and unnecessary N+1 or blocking I/O.
5. List **must-fix** vs **nice-to-have** items honestly.

### Engineering guardrail review checklist (always active)

For each item below, note any violation as a must-fix finding:

- [ ] **Scope discipline**: the diff contains only the approved change. No unrequested refactoring, no bundled unrelated fixes, no speculative abstraction.
- [ ] **Layer violations**: business logic has not leaked into controllers or infrastructure; data access has not leaked into the domain.
- [ ] **Design pattern justification**: any new pattern introduced has a stated justification in the code or PR description. No pattern added speculatively.
- [ ] **DRY violations**: no significant logic is duplicated where extraction would be safe and reduce maintenance risk.
- [ ] **YAGNI violations**: no feature, configuration option, or extension point exists without a current requirement.
- [ ] **New dependency justification**: any new dependency is justified in the PR body with the problem it solves and the license.
- [ ] **API contract safety**: if an API surface changed, the change is backward-compatible or a breaking-change notice is in the PR body.
- [ ] **Database safety**: if a migration is present, a rollback script exists and high-risk operations are flagged.
- [ ] **Error handling completeness**: errors are handled at the correct layer; no silent swallowing; structured types used consistently.
- [ ] **Observability**: significant state transitions are logged at INFO or above with correlation IDs where the codebase uses them; no PII in logs.

### Logging / privacy review (Tier 3+)

When `{{RISK_TIER}}` is 3 or higher, answer explicitly:

- [ ] Does new code call paths that log full request/response payloads?
- [ ] Could logs include identifiers, contact data, financial amounts, credentials, tokens, auth headers, API keys, secrets, or raw request bodies?
- [ ] Are new logs outcome-only and sanitized?
- [ ] Are runtime QA artifacts and screenshots free of production sensitive data?
- [ ] If logging is unsafe, is there a masking fix or an approved waiver?

Record `privacy_review.completed: true` in workflow-state when satisfied.

- [ ] **Test quality**: tests prove behaviour — not just method calls. Coverage of negative cases and boundaries is proportionate to the risk.
- [ ] **Documentation**: any changed behaviour has updated documentation in the same PR, or a follow-up issue is open and linked.
- [ ] **Configuration discipline**: no secrets hardcoded; new config keys are documented.
- [ ] **Reviewability**: the diff is understandable without a separate explanation document.

Security findings are always must-fix. There are no advisory security findings.


---

## Stage Boundary

**Prompt type:** supporting_artifact_prompt
**Stage context:** IMPLEMENTING

**Responsibility:** Perform AI-assisted pre-PR self-review of the current implementation diff.

**Authority:** This prompt does not own a workflow stage independently.
It produces supporting evidence consumed by the stage that invoked it.
It cannot approve gates, advance the workflow, or perform work belonging
to a different stage.

**Prohibited:**
- approve the PR
- self-approve G-PR-MERGE
- produce QA gate evidence

**Handoff:** make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before self-review, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files (embedded framework repo, `ai-sdlc/prompts/`, `ai-sdlc/tools/`, `ai-sdlc/schemas/`, `ai-sdlc/policies/`, `ai-sdlc/templates/`, and related framework paths) are **read-only**.
- Project SDLC artifacts must be stored under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** using the format in the governance doc — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user (shell, IDE Git UI, MCP, script, or automation). Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Public reference and data safety

Follow `ai-sdlc/governance/public-reference-and-data-safety.md`. Public sources may inform
patterns and standards, but do not copy proprietary/copyrighted content, expose private data,
or include secrets.

## Human action required

AI self-review is an advisory quality gate, not a substitute for human PR review. A human engineer must independently review the diff before merge. "Ready for PR" from this prompt means the AI considers the diff structurally complete — it does not replace the human reviewer's independent judgment. All must-fix items flagged here must be resolved before requesting human review.

## Output format

- **Must-fix** (numbered, with guardrail reference if applicable)
- **Nice-to-have** (bullets)
- **Test gaps**
- **Guardrail flags outside scope** (violations observed in existing code not changed in this PR — note only, do not fix)
- **Ready for PR?** yes / no — reason
