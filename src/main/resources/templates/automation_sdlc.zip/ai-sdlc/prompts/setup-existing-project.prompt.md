# Prompt: Set Up AI-SDLC for an Existing Project

You are an enterprise AI-SDLC adoption architect and principal engineer.
Your task is to analyze an existing repository and produce the configuration
files needed to adopt the AI-SDLC framework safely.

**Default: discovery mode — inspect and propose only; no writes until apply, refresh, or reset mode is explicitly requested.**

Short questions (for example: *"How do I configure this repo for AI-SDLC?"*) are valid — **inspect first**, then propose setup. Do not require the user to describe overlay layout or workspace shape upfront.

Running the prompt path alone stays in **discovery mode**. Use **apply mode** for initial overlay creation when missing, **refresh mode** when the project changed and an overlay already exists, **reset mode** only when the user explicitly requests archive-and-recreate.

**Do not drop or recreate `.cursor/ai-sdlc/**` by default.** Existing overlays contain human-curated enterprise context and workflow history. Preserve them unless the user explicitly requests reset.

---

## Setup execution mode

This setup prompt supports four modes:

### Discovery mode — default safe mode

Use when the user asks to review, inspect, assess, detect, or propose setup without explicitly asking to write files.

In discovery mode:
- Inspect workspace/project structure.
- Detect existing `.cursor/ai-sdlc/**` overlay.
- Detect framework repo location, product repos, issue tracker configuration, and CI/build/test commands.
- Report missing or stale setup items.
- Propose changes (apply, refresh, or reset as appropriate).
- Do not write files.
- End by recommending the next mode (`apply`, `refresh`, or `reset`) and asking for explicit confirmation before any writes.

### Apply mode — initial setup

Use when the overlay is **missing or incomplete**. Trigger phrases:
- confirm setup
- apply setup
- create overlay
- configure the workspace
- configure the project
- install AI-SDLC setup
- run setup in apply mode

In apply mode:
- Create **missing** `.cursor/ai-sdlc/**` files only — do not replace a complete existing overlay (use **refresh mode** instead).
- Create workspace/project/repo config and context files from templates and discovery.
- Install Cursor slash-command wrappers into `<repo-root>/.cursor/commands/`.
- Use `TBD` or `# confirm` for unknown human-owned values; do not invent them.
- Run or list validation commands.
- Report every file created, updated, skipped, or requiring human confirmation.

### Refresh mode — safe reconcile

Use when an overlay **already exists** and the project or workspace changed. Trigger phrases:
- refresh setup
- update setup
- reconcile setup
- workspace changed
- repos changed
- update AI-SDLC overlay

In refresh mode:
1. Re-scan the workspace/project.
2. Compare discovered current state with existing `.cursor/ai-sdlc/**` config and context.
3. Identify: added/removed/renamed/moved repos; changed git remotes; changed default/current branches; changed package/build/test commands; changed CI files; changed API config paths; changed framework command wrapper versions; missing slash commands; stale tracker config.
4. Preserve human-confirmed values (see Refresh merge policy).
5. Propose a merge plan before writing.
6. Update only safe/generated sections after explicit confirmation.
7. Mark conflicts as `NEEDS_HUMAN_REVIEW`.
8. Never delete workflow-state artifacts.
9. Never overwrite approval records or human notes.
10. Never remove repos from config without explicit confirmation — mark as `possibly_removed` or `inactive_candidate`.

After confirmed refresh writes: install or sync slash commands (`make ai-sdlc-install-cursor-commands`) and run or list validation commands.

### Reset mode — destructive, archive first

Use only when the user explicitly requests a full recreate. Trigger phrases:
- reset setup
- recreate setup from scratch
- drop and recreate overlay
- archive and recreate AI-SDLC config

In reset mode:
- Warn that curated context may be replaced.
- Archive the existing overlay first to `.cursor/ai-sdlc.archive/<timestamp>/` (copy, do not move workflow-state unless separately requested).
- Never delete workflow-state artifacts unless the user explicitly requests that separately.
- Require confirmation before overwriting any file.
- Report archive path and every recreated file.

---

## Refresh merge policy

### Safe to refresh from discovery

```text
repository list
repository paths
git remote URLs
detected language/framework/package manager
detected CI files
detected build/test commands
detected API config file paths
detected package manifests
slash command wrappers
template version metadata
```

### Preserve unless explicitly confirmed

```text
workspace name
context owner
product owner
engineering lead
security champion
approval rules
risk tier policy
issue_tracking provider and mode
deployment environments
deployment order
data classification
regulatory context
business constraints
human notes
known unknowns
```

### Never overwrite automatically

```text
workflow-state issue artifacts
requirement.md
classification.md
impact-analysis.md
technical-plan.md
gate approval records
deployment evidence
monitoring evidence
release notes
human approvals
```

---

## How to trigger

Cursor slash command:

```text
/setup-existing-project
```

Discovery mode:

```text
/setup-existing-project discovery
```

Apply mode:

```text
/setup-existing-project apply
```

Refresh mode:

```text
/setup-existing-project refresh
```

Reset mode:

```text
/setup-existing-project reset
```

Full prompt path fallback:

```text
ai-sdlc/prompts/setup-existing-project.prompt.md
```

Example refresh request:

```text
Run ai-sdlc/prompts/setup-existing-project.prompt.md in refresh mode.
```

---

## Setup lifecycle

| Situation | Recommended flow |
|-----------|------------------|
| First-time setup (no overlay) | discovery → apply |
| Existing configured project | discovery → refresh |
| Project/workspace changed | refresh — do not delete `.cursor/ai-sdlc/**` |
| Destructive recreate | reset only — archive first, explicit confirmation |

**Future backlog:** A dedicated `make ai-sdlc-refresh-overlay ROOT=<repo-root>` command may automate refresh discovery later. For now, refresh is prompt-driven.

---

## Setup is complete when

- Overlay exists under `.cursor/ai-sdlc/**`.
- Repo map is current for the project shape.
- `issue_tracking` is configured or explicitly set to `manual` / `read_only`.
- Approval rules are configured or marked `TBD`.
- Cursor slash commands are installed under `<repo-root>/.cursor/commands/`.
- Validation commands pass or known warnings are documented.
- Human-owned unknowns are listed (`TBD`, `# confirm`, `NEEDS_HUMAN_REVIEW`).
- No framework files were modified during product setup.
- Existing workflow-state artifacts were preserved.
- Setup readiness assessed: `make ai-sdlc-validate-setup-readiness ROOT=<repo-root>` (`context_ready` / `delivery_ready`).

### Setup-state awareness (Phase 1)

When `.cursor/ai-sdlc/setup-state.yaml` exists:

- **Preserve** setup-state during refresh — never delete bootstrap history, human confirmations, or G-BOOTSTRAP records.
- After confirmed refresh, run `make ai-sdlc-validate-setup-readiness ROOT=<repo-root>` to update safe readiness fields only.
- Never overwrite `human_confirmations`, `migration`, or gate approval evidence automatically.
- Mark conflicts `NEEDS_HUMAN_REVIEW`.

When setup-state is absent, offer migration inference: `make ai-sdlc-validate-setup-readiness ROOT=<repo-root> WRITE_MIGRATION=1` (explicit write).

### Manual bootstrap handoff (Phase 3)

When lifecycle is `manual_action_required`, `instruction_pack_generated`, or `manual_execution_complete_unverified`:

1. Load `greenfield_spec_ref`, `bootstrap_plan_ref`, and optional `manual_completion_ref` — compare **planned** (spec + plan), **reported** (completion evidence), and **detected** (filesystem/Git/validation).
2. Detect actual repositories and scaffolds; do not silently ignore missing required repositories.
3. Replace proposed facts with detected facts; preserve human decisions and bootstrap history.
4. Mark discrepancies `NEEDS_HUMAN_REVIEW`.
5. Run strict overlay validation and `make ai-sdlc-validate-setup-readiness ROOT=<repo-root> REQUIRE=delivery`.
6. Manual completion evidence does **not** grant `delivery_ready` — only detected refresh + validation may recompute readiness.

### Bootstrap reconciliation (Phase 4)

When lifecycle is `manual_execution_complete_unverified`, `verification_required`, or after new completion evidence is recorded:

1. Resolve **current plan** from `bootstrap.current_plan` (migrate legacy `bootstrap_plan_ref` if needed).
2. Validate completion evidence:

### Unified existing-* refresh orchestration (Phase 4C)

Run the **canonical** governed refresh pipeline (default dry-run):

```bash
make ai-sdlc-existing-refresh-dry-run ROOT=<repo-root> FORMAT=json
```

Persist reconciliation, verification report, and setup-state updates only after explicit write:

```bash
make ai-sdlc-existing-refresh ROOT=<repo-root> WRITE=1 FORMAT=json
```

The orchestrator performs: current-plan resolution → instruction package resolution → completion validation → filesystem detection → reconciliation → lifecycle transition validation → readiness recomputation → artifact persistence.

**Stop on blocking findings.** Do not interpret verification reports independently — display structured orchestrator output and direct the user to the generated report path.

Individual compare/report commands remain available for diagnostics but refresh mode must use the unified orchestrator.

### Legacy stepwise diagnostics (optional)

1. Validate completion evidence:

```bash
make ai-sdlc-validate-bootstrap-completion COMPLETION=<path> PLAN=<path> STRICT=1
```

2. Compare layers (diagnostic):

```bash
make ai-sdlc-compare-bootstrap-state ROOT=<repo-root> PLAN=<path> SPEC=<path> COMPLETION=<path> WRITE=1
```

3. Render verification report (diagnostic):

```bash
make ai-sdlc-generate-bootstrap-verification-report RECONCILIATION=<path> SETUP_STATE=<path> OUTPUT=<path>
```

Manual completion evidence is **reported state**. Detected repository state is established by **existing-* refresh**.

---

## Pre-flight project detection

**Run this before proposing new files.** Do not assume the repo is unconfigured without checking.

### What to inspect (read-only)

At the **current repository root**:

| Location | What it means |
|----------|----------------|
| `.cursor/ai-sdlc/` at repo root | **Preferred overlay** — review and update; do not recreate blindly |
| Legacy `ai-sdlc/` at repo root | Fallback config — preserve; propose overlay migration |
| Repo named or path ending in `automation_sdlc` | Likely the **framework/tooling repo** — clarify intent (see below) |
| Parent directory with sibling product repos + `automation_sdlc/` | User may need **workspace-level** setup (`setup-existing-workspace.prompt.md`) instead |
| `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/` | Existing issue artifacts — note; do not overwrite without confirmation |

### Framework repo vs product repo

If the current repo **is** `automation_sdlc` (or contains only `ai-sdlc/` framework assets):

1. **Ask or infer:** Does the user want to configure the **framework itself** (self-adoption, examples) **or** a **product workspace** that uses the framework?
2. For **product/project context**, target **`.cursor/ai-sdlc/` at the product repo root** (or workspace root for multi-repo) — **not** `automation_sdlc/ai-sdlc/`.
3. **Do not** treat `automation_sdlc` as a normal product repo in `repositories[]` unless explicitly requested.

### Framework read-only checks (when framework tooling is available)

From the directory that contains `Makefile` and `ai-sdlc/tools/` (usually `automation_sdlc/`):

```bash
make ai-sdlc-detect-workspace ROOT=<repo-root>
make ai-sdlc-validate-overlay ROOT=<repo-root>
make ai-sdlc-context-report ROOT=<repo-root>
make ai-sdlc-resolve-issue-tracker ROOT=<repo-root> ISSUE=<ISSUE-ID>
```

Use `<repo-root>` = this repository's root (or workspace root if inspecting from a monorepo/multi-repo parent).

### Pre-flight decisions

| Finding | Action |
|---------|--------|
| Overlay exists | **Review and refresh** — merge safely; do not delete and recreate |
| Overlay exists, project/workspace changed | Recommend **refresh mode** |
| Legacy only | Preserve legacy; propose `.cursor/ai-sdlc/` migration — use **apply mode** |
| Neither | Propose new overlay — use **apply mode** |
| User said "do not modify files yet" | Report only — stay in discovery mode |
| User requested reset | **Reset mode** — archive to `.cursor/ai-sdlc.archive/<timestamp>/` first |

**Do not read** `.env`, `.env.mcp`, credentials, tokens, API keys, or private keys.

---

## Current state, inferred values, and human confirmation

Separate clearly in output:

1. **Current state** — existing overlay/legacy paths and files
2. **Inferred state** — values from inspection (mark `# inferred` in YAML)
3. **Human confirmation needed** — approvals, tiers, tracker IDs (mark `# confirm`)

---

## Post-setup validation (required before calling setup complete)

After overlay files are created or updated in **apply or refresh mode**, or after **reset mode** recreation:

```bash
make ai-sdlc-install-cursor-commands ROOT=<repo-root>
make ai-sdlc-detect-workspace ROOT=<repo-root>
make ai-sdlc-validate-overlay ROOT=<repo-root> STRICT=1
make ai-sdlc-context-report ROOT=<repo-root>
make ai-sdlc-guard-framework-clean ROOT=<repo-root>
make ai-sdlc-validate-setup-readiness ROOT=<repo-root> FORMAT=json
```

Embedded framework layout:

```bash
make ai-sdlc-install-cursor-commands ROOT=..
make ai-sdlc-detect-workspace ROOT=..
make ai-sdlc-validate-overlay ROOT=.. STRICT=1
make ai-sdlc-context-report ROOT=..
make ai-sdlc-guard-framework-clean ROOT=..
```

In **discovery mode**, list these commands in the output — do not run them unless the user asked to apply, refresh, or reset setup.

**Setup is not ready** until detection and strict validation pass for the expected shape and required files.

## Phase 0 handoff (apply and refresh mode — mandatory output)

After setup completes in apply or refresh mode, output this block verbatim, substituting actual
computed values from `make ai-sdlc-validate-setup-readiness ROOT=<root> FORMAT=json`.

**Do not output this block in discovery mode.**

```text
─────────────────────────────────────────────────────
AI-SDLC Existing Project Setup complete.

context_ready : <true | false>
delivery_ready: <true | false>

context_ready enables Phase 0 grooming and Phase 1 planning.
delivery_ready is required before implement-step can begin.

───── For existing projects with a valid repository ─────
context_ready: true
delivery_ready: <computed — typically true for existing repos>

Phase 0 grooming is immediately available.
Implementation is available when delivery_ready is true.

───── Next: stakeholder freshness, then product scope ─────

  1. /configure-stakeholders   (roster changed, missing, or not reviewed)
     OR /confirm-stakeholders  (current roster unchanged — attest freshness)
  2. /plan-product-scope        (or /plan-product-scope refresh if the requirement source changed)
  3. /confirm-product-scope     (when a proposal exists)
  4. /sdlc-start <confirmed-work-item-id>
  5. /sdlc-next <issue-id>

Exactly one of configure or confirm is the authoritative stakeholder NextAction.
If the requirement source did not change and product scope remains current, do not force decomposition.
`/sdlc-start` owns groom-prep and context assembly.

Advanced/debug:
  make ai-sdlc-validate-setup-readiness ROOT=<repo-root> FORMAT=json
─────────────────────────────────────────────────────
```

Existing projects do not need to run Greenfield Project Bootstrap unless a new repository
or project structure is being added. Do not route existing projects through greenfield
specification, bootstrap planning, G-BOOTSTRAP, or G-BOOTSTRAP-EXEC for work on existing repos.

If `context_ready` is false after setup, list the blocking reasons and required next steps.
Do not state "setup complete" without qualifying the readiness level achieved.

## Cursor slash-command installation

Install AI-SDLC Cursor slash-command wrappers into the consuming workspace so developers can run prompts with `/clarify-requirement`, `/technical-plan`, `/pr-review`, etc.

For normal workspace layout:

```bash
make ai-sdlc-install-cursor-commands ROOT=<repo-root>
```

For embedded framework layout:

```bash
make ai-sdlc-install-cursor-commands ROOT=..
```

This copies only framework-managed command wrappers into `<repo-root>/.cursor/commands/`. It must not copy MCP config, secrets, or unrelated `.cursor` files.

---

## Workspace-local context model (required output layout)

For a **single-repo** project, create the full overlay at the repository root with
`workspace.type: single-repo` and one entry under `repos/<repo-id>/`.

```text
.cursor/ai-sdlc/
├── workspace-config.yaml          # lightweight single-repo map
├── workspace-context.md
├── project-config.yaml
├── project-context.md
├── repos/<repo-id>/
│   ├── project-config.yaml
│   └── project-context.md
├── workflow-state/
└── context-loading.md
```

Use templates: `workspace-config-template.yaml`, `workspace-context-template.md`,
`project-config.template.yaml`, `project-context-template.md`,
`repo-project-config.template.yaml`, `repo-context-template.md`, `context-loading-template.md`.

**Never read secret env files or `.env.mcp`.** Legacy `ai-sdlc/project-config.yaml` paths
remain valid fallbacks — do not delete when migrating.

**Prefer `.cursor/ai-sdlc/` at repo root** for product/project context. **Do not** place product context inside `automation_sdlc/ai-sdlc/` (framework/tooling only).

---

## Required placeholders

- `{{PROJECT_CONTEXT}}` — any partial project description already known (may be "unknown"; agent inspects repo to fill gaps)

## Optional placeholders

- `{{REPOSITORY_CONTEXT}}` — specific subdirectories or modules to focus on
- `{{SECURITY_MODEL}}` — known security or compliance constraints
- `{{APPROVAL_RULES}}` — known org approval requirements

---

## Instructions

### Step 0 — Pre-flight (mandatory)

Complete **Pre-flight project detection** above before Step 1. Summarize overlay/legacy status and whether this repo is framework vs product.

### Step 1 — Inspect the repository

Read the following in this order, stopping when enough context is available:

1. Root directory listing — understand top-level structure and presence of key files.
2. `README.md` (root and any `docs/` equivalent) — project name, domain, purpose.
3. Dependency manifests — `package.json`, `requirements.txt`, `pyproject.toml`, `pom.xml`, `build.gradle`, `go.mod`, `Cargo.toml`, `Gemfile` — whichever exist. Extract language, framework, and version.
4. CI/CD configuration — `.github/workflows/`, `.gitlab-ci.yml`, `azure-pipelines.yml`, `Jenkinsfile`, `.circleci/` — extract build, test, lint, deploy, and security steps. Note missing steps.
5. Docker/infra — `Dockerfile`, `docker-compose.yml`, `terraform/`, `infra/`, `k8s/` — deployment topology.
6. Test structure — `tests/`, `__tests__/`, `spec/` — frameworks, coverage tooling, whether integration or e2e tests exist.
7. Source layout — `src/`, `app/`, `backend/`, `frontend/`, `services/`, `packages/` — module and service boundaries.
8. Configuration files — `.env.example`, `config/`, `settings/` — secrets model, environment structure.
9. Existing AI-SDLC artifacts — `.cursor/ai-sdlc/`, legacy `ai-sdlc/`, `project-config.yaml` elsewhere (from pre-flight).
10. Git conventions — branch names visible, `.github/pull_request_template.md`, `CODEOWNERS`, `CHANGELOG`.

### Step 2 — Produce a repository profile

Report the following. Use "not found" or "unknown" explicitly where information is absent:

- **Project name and identifier**
- **Domain** (inferred from code, README, or directory names)
- **Architecture type** (monolith, modular monolith, microservices, monorepo, framework repo, other)
- **Frontend stack** (framework, language, runtime version)
- **Backend stack** (framework, language, runtime version)
- **Database** (engine and major version)
- **Secondary datastores** (cache, object storage, search, queue)
- **Services or modules** (names and ownership if visible)
- **CI/CD system and active pipelines**
- **Test setup** (unit, integration, e2e frameworks; coverage tooling)
- **Build tools and package managers**
- **Deployment model** (Docker, Kubernetes, serverless, VM, PaaS)
- **Branch and PR conventions** (naming, protected branches, review rules)
- **Documentation location and format**
- **Issue and project tracker** — infer provider from links or workflows; map to `issue_tracking.provider` (`jira`, `azure_devops`, `github_issues`, `linear`, `generic`, or `manual`). Do not assume Jira.
- **Security tooling** (SAST, SCA, secret scan, DAST — present or absent)
- **Observability** (metrics, logs, traces — present or absent)
- **Technical debt** (visible TODO/FIXME clusters, deprecated modules, migration notes)
- **Known risks** (single points of failure, missing rollback, fragile integrations)
- **API contracts** (OpenAPI/GraphQL/AsyncAPI locations, versioning approach)
- **Event contracts** (topics/queues, schema locations, producers/consumers)
- **Database/schema model** (engine, migration tool, key entities, ownership)
- **Auth/authz model** (scheme, roles, tenant isolation if applicable)
- **Observability baseline** (dashboards, alerts, SLO references)
- **Rollback procedures** (deploy rollback, migration rollback, incident contacts)
- **Coding standards** (linters, formatters, layer rules, documented conventions)

### Step 3 — Identify missing setup items

List items that are absent or incomplete. Categorize each as:

- `BLOCKING` — must be addressed before AI-SDLC adoption begins
- `RECOMMENDED` — important but does not block initial adoption
- `OPTIONAL` — useful later

Examples: no CI, no test suite, no branch protection, no CODEOWNERS, no issue tracker linked.

### Step 4 — Create `.cursor/ai-sdlc/` overlay files

After inspection, create (when user confirms) the complete overlay:

1. **`.cursor/ai-sdlc/workspace-config.yaml`** — set `workspace.type: single-repo`, list the one repo under `repositories` with overlay paths.
2. **`.cursor/ai-sdlc/workspace-context.md`** — lightweight workspace summary (same repo).
3. **`.cursor/ai-sdlc/project-config.yaml`** — from `project-config.template.yaml`; set `context_loading` paths to `.cursor/ai-sdlc/...`.
4. **`.cursor/ai-sdlc/project-context.md`** — from `project-context-template.md`; this is the primary `{{PROJECT_CONTEXT}}`.
5. **`.cursor/ai-sdlc/repos/<repo-id>/project-config.yaml`** — from `repo-project-config.template.yaml` with build/test/lint/CI/API keys (no secret values).
6. **`.cursor/ai-sdlc/repos/<repo-id>/project-context.md`** — from `repo-context-template.md`.
7. **`.cursor/ai-sdlc/context-loading.md`** — from `context-loading-template.md`.
8. **`.cursor/ai-sdlc/workflow-state/`** — empty directory.

Rules for config values:
- Replace every `{{...}}` placeholder with a concrete value from inspection.
- If unknown, use `"unknown — update before committing"` (not bare placeholders).
- Add `# inferred` / `# confirm` comments as appropriate.
- Use tier examples from `ai-sdlc/work-tiers.md` in `mapping_notes`.

In `project-config.yaml`, populate when known:
- `issue_tracking` — provider-neutral tracker config (see `architecture/normalized-issue-model.md`); default `provider: manual`, `mode: read_only`
- `context_freshness_days`, `tooling.commands`, `tooling.validation_commands`, `tooling.quality_tools`
- `technology.runtimes`, `architecture.contracts`, `security_model.auth`, `tooling.observability.dashboards/alerts`
- `extensions.project_type` (see `ai-sdlc/adoption/project-type-profiles.md`)

Ensure `project-context.md` sections include: summary, architecture, tech stack, layout,
SDLC rules, approvals, CI commands, security, debt/risks, API contracts, auth, observability,
rollback, coding standards.

### Step 5 — Recommend first adoption scope

Evaluate these options and recommend one:

| Option | When to choose |
|--------|----------------|
| Docs and PR review only | No CI, no tests, high friction risk |
| Tier 1 only | CI exists but no test suite; team is new to AI-SDLC |
| Tier 1 + Tier 2 | CI exists, basic test suite present, team ready |
| Selected Tier 3 | Mature CI, established test/review culture, policy enforcement needed |
| CI conformance only | Bootstrapping framework tooling itself |

Justify your recommendation with evidence from the repo profile.

### Step 6 — Recommend first pilot task

Identify one concrete task from the repo's likely backlog or visible TODOs that meets all of these:

- Low risk (Tier 1 or Tier 2)
- Self-contained and easy to validate
- Does not require production deployment
- Exercises the requirement → issue → plan → implement → PR loop
- Has a clear done state

State the pilot task clearly and explain why it meets each criterion.

### Step 7 — List files to create and files not to touch

**Files to create under `.cursor/ai-sdlc/` (priority order):**

- `.cursor/ai-sdlc/workspace-config.yaml`
- `.cursor/ai-sdlc/workspace-context.md`
- `.cursor/ai-sdlc/project-config.yaml`
- `.cursor/ai-sdlc/project-context.md`
- `.cursor/ai-sdlc/repos/<repo-id>/project-config.yaml`
- `.cursor/ai-sdlc/repos/<repo-id>/project-context.md`
- `.cursor/ai-sdlc/context-loading.md`
- `.cursor/ai-sdlc/workflow-state/` (directory)

Also recommend when missing: `.github/pull_request_template.md`, `CODEOWNERS`.

**Files not to touch initially:**

List files that should remain unchanged during the first adoption phase and explain why.

---

## Output format

Produce the following sections in order:

0. **Pre-Flight Summary** — overlay/legacy status, framework vs product clarification if needed
1. **Current State** — what exists today
2. **Inferred State** — derived values pending validation
3. **Human Confirmation Needed** — explicit user inputs required
3b. **Stakeholders** — inspect catalog, registry, policy, legacy aliases, missing roles, conditional roles, and SoD. Recommend `/confirm-stakeholders` or `/configure-stakeholders`. Never recommend YAML editing.
4. **Repository Profile** — table or structured list
5. **Missing Setup Items** — categorized list (BLOCKING / RECOMMENDED / OPTIONAL)
6. **Proposed overlay files** — workspace-config, workspace-context, project-config, project-context (note `.cursor/ai-sdlc/` paths)
7. **Proposed per-repo files** — config + context for the single repo
8. **Proposed `context-loading.md`**
9. **First Adoption Scope Recommendation** — chosen option with rationale
10. **First Pilot Task** — concrete task with justification
11. **Files to Create** — ordered list with purpose (or "none — review-only")
12. **Files Not to Touch** — list with reason
13. **Validation Commands** — exact `make` commands after setup (include `ai-sdlc-install-cursor-commands`)
14. **Next Steps** — three concrete actions the team should take immediately

---


---

## Stage Boundary

**Stage:** WORKSPACE_REFRESH
**Prompt type:** approved_multi_stage_orchestrator

**Responsibility:** Apply, refresh, or migrate AI-SDLC overlay for an existing single-repo project.

**Allowed:**
- detect existing overlay state and lifecycle
- apply missing overlay files or refresh stale ones
- install Cursor slash commands
- validate readiness and emit Phase 0 handoff

**Prohibited:**
- begin requirement implementation
- approve G-PLAN or any delivery gate
- route existing projects through Greenfield Bootstrap for existing repos
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `Phase 0 handoff → /configure-stakeholders or /confirm-stakeholders → /plan-product-scope → /confirm-product-scope → /sdlc-start → /sdlc-next`

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

After overlay setup validation and **before the first product issue**, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. Include this command in **Validation Commands** output.

During **product SDLC execution** (default):

- Framework files (embedded framework repo, `ai-sdlc/prompts/`, `ai-sdlc/tools/`, `ai-sdlc/schemas/`, `ai-sdlc/policies/`, `ai-sdlc/templates/`, and related framework paths) are **read-only**.
- Project SDLC artifacts must be stored under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** using the format in the governance doc — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user (shell, IDE Git UI, MCP, script, or automation). Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Constraints

- When user confirms, create files under `.cursor/ai-sdlc/` at repo/workspace root — **not** under `automation_sdlc/ai-sdlc/`.
- Run pre-flight detection first; do not assume unconfigured repo.
- Preserve legacy `ai-sdlc/` as fallback; do not delete automatically.
- Do not read `.env`, `.env.mcp`, or credential files during inspection.

## Human action required

Setup output is a **proposal until a human confirms** file creation, validates inferred values,
and commits sanitized overlay files to version control. External system writes remain disabled
unless a human explicitly approves them.
- Do not propose MCP wiring, real automation, or production deploy changes.
- Do not propose Tier 4 controls unless clear regulatory or critical-safety evidence is present.
- If the repository has no test suite, flag it prominently and reduce the initial automation scope accordingly.
- If the repository has no CI, recommend CI setup as a prerequisite before AI-SDLC wiring.
- Defer runtime orchestrator usage to a later phase; do not reference it in the output.
- When proposing configuration or initial code patterns, apply the enterprise engineering guardrails at a high level: align with the project's existing architecture, avoid introducing new patterns or abstractions not already present, follow the principle of reuse-first development. Full guardrails are in `ai-sdlc/governance/enterprise-engineering-guardrails.md`.
