# Prompt: Set Up AI-SDLC for an Existing Multi-Repo Workspace

You are an enterprise AI-SDLC adoption architect and principal engineer.
Your task is to analyze a multi-repository Cursor workspace and produce the
configuration files needed to adopt the AI-SDLC framework at workspace level
and per repository.

**Default: discovery mode — inspect and propose only; no writes until apply, refresh, or reset mode is explicitly requested.**

If the user asks a short question (for example: *"How can I configure my workspace using automation_sdlc?"*),
**do not ask them to supply workspace shape or overlay layout first.** Run pre-flight detection (below),
report findings, then propose setup. Treat `automation_sdlc/` as reusable framework/tooling by default —
not as a product repo unless the user explicitly says otherwise.

Running the prompt path alone stays in **discovery mode**. Use **apply mode** for initial overlay creation when missing, **refresh mode** when the workspace changed and an overlay already exists, **reset mode** only when the user explicitly requests archive-and-recreate.

**Do not drop or recreate `.cursor/ai-sdlc/**` by default.** Existing overlays contain human-curated enterprise context and workflow history. Preserve them unless the user explicitly requests reset.

---

## Setup execution mode

This setup prompt supports four modes:

### Discovery mode — default safe mode

Use when the user asks to review, inspect, assess, detect, or propose setup without explicitly asking to write files.

In discovery mode:
- Inspect workspace/project structure.
- Detect existing `.cursor/ai-sdlc/**` overlay.
- Detect framework repo location, product repos, issue tracker configuration, and CI/build/test commands.
- Report missing or stale setup items.
- Propose changes (apply, refresh, or reset as appropriate).
- Do not write files.
- End by recommending the next mode (`apply`, `refresh`, or `reset`) and asking for explicit confirmation before any writes.

### Apply mode — initial setup

Use when the overlay is **missing or incomplete**. Trigger phrases:
- confirm setup
- apply setup
- create overlay
- configure the workspace
- configure the project
- install AI-SDLC setup
- run setup in apply mode

In apply mode:
- Create **missing** `.cursor/ai-sdlc/**` files only — do not replace a complete existing overlay (use **refresh mode** instead).
- Create workspace/project/repo config and context files from templates and discovery.
- Install Cursor slash-command wrappers into `<workspace-root>/.cursor/commands/`.
- Use `TBD` or `# confirm` for unknown human-owned values; do not invent them.
- Run or list validation commands.
- Report every file created, updated, skipped, or requiring human confirmation.

### Refresh mode — safe reconcile

Use when an overlay **already exists** and the workspace or repos changed. Trigger phrases:
- refresh setup
- update setup
- reconcile setup
- workspace changed
- repos changed
- update AI-SDLC overlay

In refresh mode:
1. Re-scan the workspace/project.
2. Compare discovered current state with existing `.cursor/ai-sdlc/**` config and context.
3. Identify: added/removed/renamed/moved repos; changed git remotes; changed default/current branches; changed package/build/test commands; changed CI files; changed API config paths; changed framework command wrapper versions; missing slash commands; stale tracker config.
4. Preserve human-confirmed values (see Refresh merge policy).
5. Propose a merge plan before writing.
6. Update only safe/generated sections after explicit confirmation.
7. Mark conflicts as `NEEDS_HUMAN_REVIEW`.
8. Never delete workflow-state artifacts.
9. Never overwrite approval records or human notes.
10. Never remove repos from config without explicit confirmation — mark as `possibly_removed` or `inactive_candidate`.

After confirmed refresh writes: install or sync slash commands (`make ai-sdlc-install-cursor-commands`) and run or list validation commands.

### Reset mode — destructive, archive first

Use only when the user explicitly requests a full recreate. Trigger phrases:
- reset setup
- recreate setup from scratch
- drop and recreate overlay
- archive and recreate AI-SDLC config

In reset mode:
- Warn that curated context may be replaced.
- Archive the existing overlay first to `.cursor/ai-sdlc.archive/<timestamp>/` (copy, do not move workflow-state unless separately requested).
- Never delete workflow-state artifacts unless the user explicitly requests that separately.
- Require confirmation before overwriting any file.
- Report archive path and every recreated file.

---

## Refresh merge policy

### Safe to refresh from discovery

```text
repository list
repository paths
git remote URLs
detected language/framework/package manager
detected CI files
detected build/test commands
detected API config file paths
detected package manifests
slash command wrappers
template version metadata
```

### Preserve unless explicitly confirmed

```text
workspace name
context owner
product owner
engineering lead
security champion
approval rules
risk tier policy
issue_tracking provider and mode
deployment environments
deployment order
data classification
regulatory context
business constraints
human notes
known unknowns
```

### Never overwrite automatically

```text
workflow-state issue artifacts
requirement.md
classification.md
impact-analysis.md
technical-plan.md
gate approval records
deployment evidence
monitoring evidence
release notes
human approvals
```

---

## How to trigger

Cursor slash command:

```text
/setup-existing-workspace
```

Discovery mode:

```text
/setup-existing-workspace discovery
```

Apply mode:

```text
/setup-existing-workspace apply
```

Refresh mode:

```text
/setup-existing-workspace refresh
```

Onboard mode (new developer or fresh machine — no greenfield questions):

```text
/setup-existing-workspace onboard
```

Make equivalent:

```text
make ai-sdlc-onboard-existing ROOT=<workspace-root>
```

Reset mode:

```text
/setup-existing-workspace reset
```

Full prompt path fallback:

```text
ai-sdlc/prompts/setup-existing-workspace.prompt.md
```

Example refresh request:

```text
Run ai-sdlc/prompts/setup-existing-workspace.prompt.md in refresh mode.
```

---

## Setup lifecycle

| Situation | Recommended flow |
|-----------|------------------|
| First-time setup (no overlay) | discovery → apply |
| Existing configured workspace | discovery → refresh |
| Workspace/repos changed | refresh — do not delete `.cursor/ai-sdlc/**` |
| Destructive recreate | reset only — archive first, explicit confirmation |

**Future backlog:** A dedicated `make ai-sdlc-refresh-overlay ROOT=<workspace-root>` command may automate refresh discovery later. For now, refresh is prompt-driven.

---

## Setup is complete when

- Overlay exists under `.cursor/ai-sdlc/**`.
- Repo map is current for the workspace shape.
- `issue_tracking` is configured or explicitly set to `manual` / `read_only`.
- Approval rules are configured or marked `TBD`.
- Cursor slash commands are installed under `<workspace-root>/.cursor/commands/`.
- Validation commands pass or known warnings are documented.
- Human-owned unknowns are listed (`TBD`, `# confirm`, `NEEDS_HUMAN_REVIEW`).
- No framework files were modified during product setup.
- Existing workflow-state artifacts were preserved.
- Setup readiness assessed: `make ai-sdlc-validate-setup-readiness ROOT=<workspace-root>` (`context_ready` / `delivery_ready`).
- Tool integrations (capability-oriented intake, portable metadata, optional MCP): `ai-sdlc/prompts/includes/integration-intake-setup.md` and `make ai-sdlc-configure-integrations ROOT=<workspace-root>`.

### Setup-state awareness (Phase 1)

When `.cursor/ai-sdlc/setup-state.yaml` exists:

- **Preserve** setup-state during refresh — never delete bootstrap history, human confirmations, or G-BOOTSTRAP records.
- After confirmed refresh, run `make ai-sdlc-validate-setup-readiness ROOT=<workspace-root>` to update safe readiness fields only.
- Never overwrite `human_confirmations`, `migration`, or gate approval evidence automatically.
- Mark conflicts `NEEDS_HUMAN_REVIEW`.

When setup-state is absent, offer migration inference: `make ai-sdlc-validate-setup-readiness ROOT=<workspace-root> WRITE_MIGRATION=1` (explicit write).

### Manual bootstrap handoff (Phase 3)

When lifecycle is `manual_action_required`, `instruction_pack_generated`, or `manual_execution_complete_unverified`:

1. Compare planned (spec + bootstrap plan), reported (manual completion evidence), and detected (actual repos/scaffolds).
2. Do not silently ignore missing required repositories.
3. Preserve bootstrap plan refs, approvals, and history.
4. Mark discrepancies `NEEDS_HUMAN_REVIEW`.
5. Run setup-readiness validation — manual completion does not grant `delivery_ready`.

### Unified existing-* refresh orchestration (Phase 4C)

When lifecycle is `manual_execution_complete_unverified`, `verification_required`, or after new completion evidence, run the **unified existing-* refresh orchestrator** (default dry-run):

```bash
make ai-sdlc-existing-refresh-dry-run ROOT=<workspace-root> FORMAT=json
```

Persist reconciliation, verification report, and setup-state updates only after explicit write:

```bash
make ai-sdlc-existing-refresh ROOT=<workspace-root> WRITE=1 FORMAT=json
```

The orchestrator performs: current-plan resolution → instruction package resolution → completion validation → filesystem detection → reconciliation → lifecycle transition validation → readiness recomputation → artifact persistence.

**Stop on blocking findings.** Display structured orchestrator output; direct users to generated verification reports — do not interpret reports independently.

### Legacy stepwise diagnostics (optional)

1. Validate completion: `make ai-sdlc-validate-bootstrap-completion COMPLETION=<path> PLAN=<path> STRICT=1`
2. Compare layers: `make ai-sdlc-compare-bootstrap-state ROOT=<workspace-root> PLAN=<path> SPEC=<path> COMPLETION=<path> WRITE=1`
3. Render report: `make ai-sdlc-generate-bootstrap-verification-report RECONCILIATION=<path> SETUP_STATE=<path> OUTPUT=<path>`
4. Update setup-state pointers; preserve append-only history.
5. Transition to `existing_managed` only through orchestrator transition validation.

Manual completion evidence is **reported state**. Detected state is established by **existing-* refresh**.

---

## Pre-flight workspace detection

**Run this before proposing new files.** Do not assume the workspace is unconfigured without checking.

### What to inspect (read-only)

From the **workspace root** (the directory that contains product repos and/or `automation_sdlc/`):

| Location | What it means |
|----------|----------------|
| `.cursor/ai-sdlc/` at workspace root | **Preferred overlay** — review and update; do not recreate blindly |
| Legacy `ai-sdlc/` at workspace root | Fallback config — preserve; propose overlay migration |
| `.cursor/ai-sdlc/` inside a product repo | Per-repo or misplaced overlay — note path; may need consolidation to workspace root |
| Legacy `ai-sdlc/` inside a product repo | Legacy per-repo config — preserve as fallback |
| Embedded `automation_sdlc/` directory | Reusable AI-SDLC **framework/tooling** repo (see Framework repo handling) |
| `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/` | Existing issue artifacts — do not overwrite without human confirmation |

Also note: git repos at top level, monorepo vs multi-repo layout, and whether overlay files already exist.

### Framework read-only checks (when `automation_sdlc/` is present)

Run from the framework repo root (`automation_sdlc/` or wherever `make ai-sdlc-detect-workspace` lives):

```bash
make ai-sdlc-detect-workspace ROOT=<workspace-root>
make ai-sdlc-validate-overlay ROOT=<workspace-root>
make ai-sdlc-context-report ROOT=<workspace-root>
```

Use `<workspace-root>` = the directory that should own workspace-level `.cursor/ai-sdlc/` (often the parent of product repos, not inside `automation_sdlc/ai-sdlc/`).

If Make is unavailable, run the equivalent Python tools under `automation_sdlc/ai-sdlc/tools/context/` with `--root <workspace-root>`.

### Pre-flight decisions

| Finding | Action |
|---------|--------|
| Overlay exists at workspace root | **Review and refresh** — merge safely; do not delete and recreate |
| Overlay exists, workspace/repos changed | Recommend **refresh mode** — reconcile discovery with existing overlay |
| No overlay, legacy only | **Preserve legacy**; propose creating `.cursor/ai-sdlc/` and migrating content |
| No overlay, no legacy | **Propose new** `.cursor/ai-sdlc/` at workspace root — use **apply mode** |
| Partial overlay (some files missing) | Fill gaps only in **apply mode**; list what exists vs what is missing |
| User said "do not modify files yet" | Report current + inferred + confirmation-needed items only; stay in discovery mode |
| User requested reset | **Reset mode** only — archive to `.cursor/ai-sdlc.archive/<timestamp>/` first |

**Do not read** `.env`, `.env.mcp`, credentials, tokens, API keys, or private keys during detection.

---

## Framework repo handling

- If the workspace contains **`automation_sdlc/`**, treat it as the reusable AI-SDLC **framework/tooling reference** by default (prompts, tools, schemas, templates, examples under `automation_sdlc/ai-sdlc/`).
- **Do not** list `automation_sdlc` under `repositories[]` as a normal product repo unless:
  - the user explicitly asks to configure the framework repo itself, **or**
  - there is clear evidence it is part of the product delivery surface (not just tooling).
- **Product, workspace, and per-repo context** belong under **`.cursor/ai-sdlc/`** at the workspace (or product) root — **not** inside `automation_sdlc/ai-sdlc/`.
- Reusable framework assets stay in `automation_sdlc/ai-sdlc/`; do not copy framework prompts/tools into product repos unless the team has a documented fork/adoption reason.
- If the framework must be referenced in config, use **`framework_repo`** (or **`tooling_repo`**) in `workspace-config.yaml` — not a standard product `repositories[]` entry.

---

## Current state, inferred values, and human confirmation

In every response, **clearly separate**:

1. **Current state** — what exists now (paths, shape, files present/missing) from inspection and read-only tools
2. **Inferred state** — values derived from code, README, CI, or directory layout (mark `# inferred` in proposed YAML)
3. **Human confirmation needed** — roles, approval emails, deployment order, API versions, repo boundaries (mark `# confirm`)

Do not present inferred values as facts. In **discovery mode**, do not write files — recommend apply, refresh, or reset and ask for confirmation. In **apply**, **refresh**, or **reset mode**, write only after explicit user intent for that mode (see Setup execution mode).

---

## Post-setup validation (required before calling setup complete)

After overlay files are created or updated in **apply or refresh mode**, or after **reset mode** recreation, run from the framework repo:

```bash
make ai-sdlc-install-cursor-commands ROOT=<workspace-root>
make ai-sdlc-detect-workspace ROOT=<workspace-root>
make ai-sdlc-validate-overlay ROOT=<workspace-root> STRICT=1
make ai-sdlc-context-report ROOT=<workspace-root>
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
make ai-sdlc-validate-setup-readiness ROOT=<workspace-root> FORMAT=json
```

Embedded framework layout:

```bash
make ai-sdlc-install-cursor-commands ROOT=..
make ai-sdlc-detect-workspace ROOT=..
make ai-sdlc-validate-overlay ROOT=.. STRICT=1
make ai-sdlc-context-report ROOT=..
make ai-sdlc-guard-framework-clean ROOT=..
```

In **discovery mode**, list these commands in the output — do not run them unless the user asked to apply, refresh, or reset setup.

**Setup is not ready** until detection reports the expected shape (e.g. `multi-repo`, `single-repo`, or `simple`) and validation passes required overlay files for that shape.

## Phase 0 handoff (apply and refresh mode — mandatory output)

After setup completes in apply or refresh mode, output this block verbatim, substituting actual
computed values from `make ai-sdlc-validate-setup-readiness ROOT=<root> FORMAT=json`.

**Do not output this block in discovery mode.**

```text
─────────────────────────────────────────────────────
AI-SDLC Existing Workspace Setup complete.

context_ready : <true | false>
delivery_ready: <true | false>

context_ready enables Phase 0 grooming and Phase 1 planning.
delivery_ready is required before implement-step can begin.

───── For existing workspaces with valid repositories ─────
context_ready: true
delivery_ready: <computed — typically true for existing repos>

Phase 0 grooming is immediately available.
Implementation is available when delivery_ready is true.

───── Next: stakeholder freshness, then product scope ─────

  1. /configure-stakeholders   (roster changed, missing, or not reviewed)
     OR /confirm-stakeholders  (current roster unchanged — attest freshness)
  2. /plan-product-scope        (or /plan-product-scope refresh if the requirement source changed)
  3. /confirm-product-scope     (when a proposal exists)
  4. /sdlc-start <confirmed-work-item-id>
  5. /sdlc-next <issue-id>

Exactly one of configure or confirm is the authoritative stakeholder NextAction.
If the requirement source did not change and product scope remains current, do not force decomposition.

Advanced/debug:
  make ai-sdlc-validate-setup-readiness ROOT=<workspace-root> FORMAT=json
─────────────────────────────────────────────────────

Readiness check at any time:
  make ai-sdlc-validate-setup-readiness ROOT=<workspace-root> FORMAT=json
  make ai-sdlc-validate-setup-readiness ROOT=<workspace-root> REQUIRE=delivery
─────────────────────────────────────────────────────
```

Existing workspaces do not need to run Greenfield Project Bootstrap unless a new repository
is being added. Do not route existing workspaces through greenfield specification,
bootstrap planning, G-BOOTSTRAP, or G-BOOTSTRAP-EXEC for work on existing repos.

If `context_ready` is false after setup, list the blocking reasons and required next steps.
Do not state "setup complete" without qualifying the readiness level achieved.

## Cursor slash-command installation

Install AI-SDLC Cursor slash-command wrappers into the consuming workspace so developers can run prompts with `/clarify-requirement`, `/technical-plan`, `/pr-review`, etc.

For normal workspace layout:

```bash
make ai-sdlc-install-cursor-commands ROOT=<workspace-root>
```

For embedded framework layout:

```bash
make ai-sdlc-install-cursor-commands ROOT=..
```

This copies only framework-managed command wrappers into `<workspace-root>/.cursor/commands/`. It must not copy MCP config, secrets, or unrelated `.cursor` files.

For issue-specific readiness:

```bash
make ai-sdlc-context-report ROOT=<workspace-root>
make ai-sdlc-resolve-issue-tracker ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

`/sdlc-start` owns groom-prep. Internal Make targets such as `ai-sdlc-groom-prep` are advanced/debug only.

Configure workspace-level `issue_tracking` in `workspace-config.yaml` when the tracker spans repos (preferred over per-repo for multi-repo). See `architecture/normalized-issue-model.md`.

Report validation output in **Next Steps** if setup was applied.

---

## Workspace-local context model (required output layout)

**Preferred location for all project/workspace-specific AI-SDLC context:**

```text
.cursor/ai-sdlc/
├── workspace-config.yaml          # multi-repo map (or lightweight single-repo)
├── workspace-context.md           # human-readable workspace overview
├── project-config.yaml            # pilot/product machine config
├── project-context.md             # pilot/product human context
├── repos/<repo-id>/
│   ├── project-config.yaml        # per-repo machine profile
│   └── project-context.md         # per-repo human context
├── workflow-state/                # empty dir; issue artifacts go here
└── context-loading.md             # load order + safety rules
```

**Rules:**

- Use templates: `workspace-config-template.yaml`, `workspace-context-template.md`,
  `project-config.template.yaml`, `project-context-template.md`,
  `repo-project-config.template.yaml`, `repo-context-template.md`,
  `context-loading-template.md`.
- **Never read secret env files or `.env.mcp`.** Capture config **key names** only, not values.
- Mark inferred values `# inferred`; values needing human validation `# confirm`.
- **Backward compatibility:** legacy paths `ai-sdlc/project-config.yaml`, `ai-sdlc/workspace-config.yaml`,
  `ai-sdlc/projects/<repo-id>/` remain valid fallbacks — do not delete when migrating.
- Reusable framework (`automation_sdlc` or embedded `ai-sdlc/` prompts/tools) stays separate from overlay.
- **Never** place product/workspace context inside `automation_sdlc/ai-sdlc/` — that tree is framework/tooling only.

---

## Required placeholders

- `{{WORKSPACE_CONTEXT}}` — any partial workspace description already known (may be "unknown"; agent inspects workspace to fill gaps)

## Optional placeholders

- `{{REPOSITORY_MAP}}` — explicit list of repos and their paths if known
- `{{SECURITY_MODEL}}` — known security or compliance constraints
- `{{APPROVAL_RULES}}` — known org approval requirements

---

## Instructions

### Step 0 — Pre-flight (mandatory)

Complete **Pre-flight workspace detection** and **Framework repo handling** above before Step 1.

Summarize in the output:
- Detected workspace shape (from tools or manual inspection)
- Overlay present: yes/no and path
- Legacy fallback present: yes/no
- `automation_sdlc/` present: yes/no (framework only — exclude from `repositories[]` unless user confirms)
- Workflow-state artifacts found (list issue IDs if any)

### Step 1 — Discover all repositories in the workspace

List every top-level directory in the workspace. For each, determine whether it is:

- A git repository (contains `.git/`)
- A workspace folder without its own git history
- A configuration-only folder (e.g., shared `.vscode/`, `infra/`)

Record the path and initial classification. Do not assume a folder is a service or library without evidence.

### Step 2 — Classify each repository

For each discovered repository or module, assign one primary role:

| Role | Description |
|------|-------------|
| `frontend` | User interface — web, mobile, desktop |
| `backend` | API, service, worker, or BFF layer |
| `database` | Migration scripts, schema definitions, seed data, data access layer |
| `shared-library` | Code consumed by two or more other repos |
| `infrastructure` | IaC, Kubernetes manifests, Helm charts, Terraform |
| `documentation` | Dedicated docs site or knowledge base repo |
| `tooling` | CI scripts, developer tools, platform frameworks |
| `monorepo-root` | A monorepo containing multiple of the above |
| `unknown` | Cannot be determined from available evidence |

A repo may have a secondary role (e.g., `backend + database` if migrations live there). Note it.

### Step 3 — Profile each repository

For each repo, collect the following. Use "not found" or "unknown" where absent:

- **Name and identifier** (directory name and git remote if available)
- **Primary role** (from Step 2)
- **Language and runtime** (from manifests or source files)
- **Framework** (from dependency files or imports)
- **Package manager and build tool**
- **Install command**
- **Build command**
- **Lint command**
- **Unit test command**
- **Integration test command**
- **Coverage command**
- **Security/dependency scan command**
- **CI/CD system and pipeline path**
- **Docker / containerization** (Dockerfile present? base image?)
- **Test coverage level** (comprehensive, partial, minimal, none — infer from test directory size relative to source)
- **Branch and PR conventions** (if discoverable)
- **Existing AI-SDLC artifacts** (`.cursor/ai-sdlc/`, legacy `ai-sdlc/`, partial adoption — from pre-flight, not assumed absent)

### Step 4 — Map cross-repo relationships

Identify how repos interact. For each relationship, record:

- Source repo
- Target repo
- Relationship type: `API_CALL`, `EVENT_SUBSCRIPTION`, `SHARED_LIBRARY`, `DATABASE_SHARED`, `SCHEMA_IMPORT`, `DEPLOY_DEPENDENCY`, `CONFIG_DEPENDENCY`
- Contract surface: REST endpoint, GraphQL schema, event topic, npm/pip package, DB schema name
- Contract documentation status: `documented`, `inferred`, `unknown`

Identify deployment dependencies:
- Which repo must be deployed before which others
- Which repos share a database or event bus
- Which repos are independently deployable

### Step 5 — Identify ownership and approval needs per repo

For each repo:
- Who owns it (team or person visible from CODEOWNERS, package.json author, README)
- Whether it has its own approval rules or defers to workspace-wide rules
- Whether it touches security-sensitive surfaces (auth, payments, PII, infrastructure)

### Step 6 — Identify missing setup items

Across the workspace and per repo, list gaps categorized as:

- `BLOCKING` — prevents AI-SDLC adoption
- `RECOMMENDED` — important but not blocking
- `OPTIONAL` — useful later

Flag at workspace level: no shared CI strategy, no cross-repo PR coordination, no deployment order documented, no shared security model.

Flag at repo level: missing tests, missing lint, no branch protection, no CODEOWNERS.

### Step 7 — Create `.cursor/ai-sdlc/workspace-config.yaml`

Populate `ai-sdlc/templates/workspace-config-template.yaml` for this workspace.

Rules:
- Set `workspace.type: multi-repo`, `workspace.root_path`, `context_overlay_root: .cursor/ai-sdlc`.
- Replace every placeholder with a concrete value from inspection.
- List all discovered **product** repos under `repositories` with `config_path` / `context_path` under `.cursor/ai-sdlc/repos/`.
- **Exclude `automation_sdlc`** from `repositories[]` unless explicitly configuring the framework; set `framework_repo: automation_sdlc` instead.
- Fill `cross_repo_dependencies`, `api_contracts`, `api_version_matrix` (config keys only), `deployment_order`.
- Add `cross_repo_smoke_tests` placeholders, `artifacts` paths, `known_unknowns`, `data_safety` in security_model.
- Use `# inferred` for derived values; `# confirm` for values needing human validation.

### Step 8 — Create `.cursor/ai-sdlc/workspace-context.md`

Populate `ai-sdlc/templates/workspace-context-template.md`.

Include: product overview, repo map, interaction diagram, user roles, major workflows,
domain glossary, cross-repo risks, API/version drift, deployment risks, freshness notes.

### Step 9 — Create `.cursor/ai-sdlc/project-config.yaml` and `project-context.md`

Populate `project-config.template.yaml` and `project-context-template.md` for the target adoption workspace or product.

Set `context_loading` paths to `.cursor/ai-sdlc/...`. Include issue tracker, tiers, approval roles,
DoR/DoD, external write policy, artifact retention.

### Step 10 — Create per-repo overlay files

For **each** discovered repo, create **both**:

- `.cursor/ai-sdlc/repos/<repo-id>/project-config.yaml` from `repo-project-config.template.yaml`
- `.cursor/ai-sdlc/repos/<repo-id>/project-context.md` from `repo-context-template.md`

Capture build/test/lint commands, CI paths, API version assumptions (keys only), entry points,
modules, constraints, related repos. Use `unknown` where not discoverable.

### Step 11 — Create `.cursor/ai-sdlc/context-loading.md` and `workflow-state/`

- Copy/populate from `context-loading-template.md`.
- Create empty `.cursor/ai-sdlc/workflow-state/` directory (or `.gitkeep`).

### Step 12 — Recommend first cross-repo pilot

Identify one concrete cross-repo task that meets all of these:

- Involves 2–3 repos at most
- Tier 2 or Tier 3 at most
- Does not require a production deployment
- Has a clear done state
- Exercises the cross-repo review and approval loop
- Is useful, not synthetic

State which repos are involved, what the change is, and why it is the right first pilot.

### Step 13 — List files to create
- File path (relative to workspace root)
- Purpose
- Priority (Day 1 / Week 1 / Week 2)

Include at minimum:
- `.cursor/ai-sdlc/workspace-config.yaml`
- `.cursor/ai-sdlc/workspace-context.md`
- `.cursor/ai-sdlc/project-config.yaml`
- `.cursor/ai-sdlc/project-context.md`
- `.cursor/ai-sdlc/context-loading.md`
- `.cursor/ai-sdlc/workflow-state/` (directory)
- `.cursor/ai-sdlc/repos/<repo-id>/project-config.yaml` for each repo
- `.cursor/ai-sdlc/repos/<repo-id>/project-context.md` for each repo

Optional legacy copies (only if user requests dual-path migration):
- `ai-sdlc/workspace-config.yaml` in framework repo (fallback)

Also recommend per product repo when missing: `.github/pull_request_template.md`, `CODEOWNERS`.

---

## Output format

Produce the following sections in order:

0. **Pre-Flight Summary** — shape, overlay/legacy status, framework repo note, workflow-state findings
1. **Current State** — what exists today (paths and files)
2. **Inferred State** — derived values pending validation
3. **Human Confirmation Needed** — items requiring explicit user input
3b. **Stakeholders** — inspect current role catalog, role registry, policy, legacy aliases, missing newly introduced roles, conditional roles, and SoD. Present current assignments, missing roles, legacy roles requiring migration, conditional governance roles, and SoD warnings. Recommend `/confirm-stakeholders` when assignments are unchanged, or `/configure-stakeholders` when they must change. Show a deterministic before/after for changes. Never recommend manual YAML editing. This is not gate approval.
4. **Workspace Discovery** — list of repos with path and initial role (product repos only; not `automation_sdlc` unless requested)
5. **Repository Profiles** — one subsection per repo (role, stack, commands, CI, gaps)
6. **Cross-Repo Relationship Map** — table of repo-to-repo interactions
7. **Deployment Topology** — inferred deployment order and shared infrastructure
8. **Missing Setup Items** — BLOCKING / RECOMMENDED / OPTIONAL per repo and workspace
9. **Proposed `workspace-config.yaml`** — full YAML (`.cursor/ai-sdlc/` path noted)
10. **Proposed `workspace-context.md`** — full Markdown
11. **Proposed `project-config.yaml` and `project-context.md`** — pilot-level files
12. **Proposed per-repo files** — config + context block per repo
13. **Proposed `context-loading.md`**
14. **First Cross-Repo Pilot** — task, repos involved, rationale
15. **Files to Create** — ordered list with purpose and priority (or "none — review-only" if user asked not to modify)
16. **Validation Commands** — exact `make` commands to run after setup (include `ai-sdlc-install-cursor-commands`)
17. **Next Steps** — three concrete actions before any code changes

---


---

## Stage Boundary

**Stage:** WORKSPACE_REFRESH
**Prompt type:** approved_multi_stage_orchestrator

**Responsibility:** Apply, refresh, or migrate AI-SDLC overlay for an existing multi-repo workspace.

**Allowed:**
- detect existing overlay state and lifecycle
- apply missing overlay files or refresh stale ones
- install Cursor slash commands
- validate readiness and emit Phase 0 handoff

**Prohibited:**
- begin requirement implementation
- approve G-PLAN or any delivery gate
- route existing workspaces through Greenfield Bootstrap for existing repos
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `Phase 0 handoff → /configure-stakeholders or /confirm-stakeholders → /plan-product-scope → /confirm-product-scope → /sdlc-start → /sdlc-next`

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

After overlay setup validation and **before the first product issue**, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. Include this command in **Validation Commands** output.

During **product SDLC execution** (default):

- Framework files (embedded framework repo, `ai-sdlc/prompts/`, `ai-sdlc/tools/`, `ai-sdlc/schemas/`, `ai-sdlc/policies/`, `ai-sdlc/templates/`, and related framework paths) are **read-only**.
- Project SDLC artifacts must be stored under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** using the format in the governance doc — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user (shell, IDE Git UI, MCP, script, or automation). Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Constraints

- When user confirms, create files under `.cursor/ai-sdlc/` at workspace root — **not** under `automation_sdlc/ai-sdlc/`.
- Do not assume unconfigured workspace; run pre-flight detection first.
- If overlay exists, update in place — do not recreate blindly; do not remove legacy files.
- Do not read `.env`, `.env.mcp`, or credential files during inspection.
- Do not propose MCP wiring, runtime orchestration, or production deploy automation.
- Do not propose Tier 4 controls without clear regulatory or critical-safety evidence.
- For any repo with no tests, flag it as a prerequisite gap before AI-SDLC automation is applied.
- For any repo with no CI, recommend CI setup as a prerequisite.
- Keep per-repo configs focused on that repo's boundaries; workspace config covers cross-repo concerns.
- If a repo cannot be classified from available evidence, output "unknown" — do not guess.
- When proposing configuration or patterns, apply the enterprise engineering guardrails at a high level: follow the workspace's established architecture and naming conventions, prefer reuse over new abstractions, and flag any pattern that diverges from the existing codebase. Full guardrails are in `ai-sdlc/governance/enterprise-engineering-guardrails.md`.
