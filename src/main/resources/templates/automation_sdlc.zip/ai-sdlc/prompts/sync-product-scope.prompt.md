# Prompt: Sync Product Scope

Preview or apply external tracker mapping for **confirmed** internal product
scope. Internal IDs remain canonical. Tracker IDs are integration references.

## Required placeholders

- `{{ISSUE}}` is **optional** (workspace-level)

## Grammar

```text
/sync-product-scope
```

Always preview first. External create/update requires explicit human approval.

## Instructions

1. Load confirmed product scope. Unconfirmed scope cannot sync.
2. Preview external create/update/deprecate operations against `tracker-mapping.yaml`.
3. Preserve internal IDs when a tracker is introduced later.
4. Require human approval before any external mutation.
5. Persist mapping only after approval. Do not delete tracker issues on DEPRECATE.

`/plan-product-scope` never performs external writes.

## Human action required

A human must approve the previewed sync operations. No external write occurs
without that approval.

---

## Stage Boundary

**Stage:** PRODUCT_SCOPE_SYNC
**Prompt type:** single_stage_operational

**Responsibility:** Map confirmed internal product-scope IDs to external tracker identities after approval.

**Allowed:**
- preview sync operations
- persist mapping after explicit approval
- run without an ISSUE

**Prohibited:**
- sync unconfirmed scope
- create new internal IDs because a tracker appeared later
- let tracker mapping become product-scope authority
- delete external issues blindly
- hand-edit `tracker-mapping.yaml`
- performing downstream-stage work not listed under Allowed

**Completion:** return the preview or persist the approved mapping, then stop.

**Handoff:** `/sdlc-next {{ISSUE}}` when a work item exists, otherwise `/sdlc-start <confirmed-work-item-id>`
