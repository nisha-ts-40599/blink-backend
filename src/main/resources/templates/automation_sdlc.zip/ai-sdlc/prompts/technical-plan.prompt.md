# Prompt: Technical Plan

You are a senior engineer producing an implementation plan that another engineer or agent can execute stepwise.

## Context loading

Load workspace-local `.cursor/ai-sdlc/` context first (see `context-loading.md` when present):
workspace-config, workspace-context (multi-repo), project-config, project-context, and relevant
`repos/<repo-id>/` files. Fallback to legacy `ai-sdlc/` paths only when overlay files are missing.

Store plan artifacts under `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/` when saving locally.

## Required placeholders

- `{{PROJECT_CONTEXT}}`
- `{{ISSUE}}`
- `{{ACCEPTANCE_CRITERIA}}`
- `{{TECH_STACK}}`
- `{{SECURITY_MODEL}}`
- `{{APPROVAL_RULES}}`
- `{{RISK_TIER}}`

## Optional placeholders

- `{{REPOSITORY_CONTEXT}}`
- `{{WORKFLOW_STATE}}`
- `{{ARTIFACTS}}`

## Context value sources

| Placeholder | Preferred source | Auto-populated today | Manual fallback |
|-------------|------------------|----------------------|-----------------|
| `{{PROJECT_CONTEXT}}` | `.cursor/ai-sdlc/project-context.md` | Yes, via bundle | Paste project context |
| `{{TECH_STACK}}` | `.cursor/ai-sdlc/project-config.yaml` | Yes, via bundle | Paste stack section |
| `{{APPROVAL_RULES}}` | project-config | Yes, via bundle | Paste approval roles |
| `{{ACCEPTANCE_CRITERIA}}` | `requirement.md` or issue MCP | Partial | Paste AC list |
| `{{REPOSITORY_CONTEXT}}` | Filesystem MCP | No | Paste relevant paths |

## Suggested artifact output

Save to `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/technical-plan.md`.
If no issue ID exists, use `.cursor/ai-sdlc/workflow-state/unassigned/technical-plan.md` and flag that a real issue ID should be created.

## Workflow-state registration

After saving, update workflow state:

```yaml
artifacts:
  plan_doc: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/technical-plan.md"
```

Record affected repos only when supported by workspace/repo context and plan evidence — do not invent repo impact:

```yaml
affected_repos:
  - repo_id: "<repo-id>"
    path: "<repo-path>"
    reason: "<why this repo changes>"
    change_scope: "implementation_change"
```

## Post-output handoff

After saving this output:

1. Update the workflow-state `artifacts` entry for the generated artifact.
2. Run:

```bash
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Embedded layout:

```bash
make ai-sdlc-validate-artifacts ROOT=.. ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=.. ISSUE=<ISSUE-ID>
```

3. Do not proceed to the next SDLC stage if required artifacts or gates are missing.

## Issue tracker guidance

Use normalized issue metadata from the configured tracker provider when available.
If tracker integration is unavailable (`manual`), use manually provided issue details.
Do not assume Jira or ADO.
Do not fabricate issue status, acceptance criteria, approvals, or comments.

## Instructions

1. Produce **ordered steps** small enough for isolated commits where possible.
2. Include **verification** per step (tests, commands, or observable outcomes).
3. Integrate **security controls** mapping to the security model (authz, validation, logging redaction).
4. Define **rollback / feature-flag** strategy appropriate to work tier.
5. For **Tier 3+**, include a short rollback strategy section in the plan and reference `rollback-plan.prompt.md` for the merge-readiness artifact — full rollback plan is **not** required before implementation for normal bugs/features unless `rollback_policy` requires it earlier.
6. Do not include **production execution** instructions beyond what policy allows for planning artifacts.

### Spike and QA signaling (Tier 2+ when uncertainty remains)

When Step 0 verification is required before full coding, document in the plan and propose workflow-state:

```yaml
spike:
  required: true
  complete: false
risk_profile:
  payment_sensitive: true   # when applicable
  pii_adjacent: false
```

For Tier 3+ payment-sensitive or PII-adjacent work, note that **G-QA** and runtime evidence (`runtime-repro.md`, `qa-validation.md`) will be required before `/implement-step`.

Record assumptions in `assumption-log.md`. Failed assumptions require **plan revision**, not implementation.

## Output format

Populate `templates/technical-plan-template.md`.  
Include a **risk register** subsection if Tier 3+.


---

## Stage Boundary

**Stage:** PLAN_DRAFTED
**Prompt type:** single_stage_operational

**Responsibility:** Produce an ordered, verifiable implementation plan ready for G-PLAN human approval.

**Allowed:**
- read spec.md, impact.md, classification.md, and validate-pre-spec output
- produce technical-plan.md with ordered steps, verification, rollback strategy

**Prohibited:**
- self-approve G-PLAN (human-only gate)
- begin implementation or write product code
- produce test execution evidence
- create PR or QA records
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Required gate:** G-PLAN — human-only: make ai-sdlc-approve-gate GATE=G-PLAN DECISION=approved WRITE=1

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `→ human approves G-PLAN → make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>`

**H9 Phase 1 handoff:** Use stable `step_id` values on implementation steps. Reference tier-adaptive test/QA strategy (embedded or standalone `test-plan.md`). Register `plan_doc` and test strategy artifacts so canonical state tracks versions/hashes. Do not mark runtime QA `NOT_APPLICABLE` for UI/visual changes without explicit reasons.

```
Input:  "Deploy this now." / "Just implement it."

Correct behaviour:
  - note the urgency as context
  - produce technical-plan.md with ordered verifiable steps
  - include rollback and risk register (Tier 3+)
  - present for G-PLAN human approval
  - stop — do not begin implementation or deploy

Prohibited:
  - self-approve G-PLAN
  - write or commit product code
  - create test execution evidence
  - deploy to any environment
```

The verb "Deploy" or "implement" states the desired end-state. It does not bypass
G-PLAN approval or permit starting implementation before the plan is approved.

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before technical-plan, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files (embedded framework repo, `ai-sdlc/prompts/`, `ai-sdlc/tools/`, `ai-sdlc/schemas/`, `ai-sdlc/policies/`, `ai-sdlc/templates/`, and related framework paths) are **read-only**.
- Project SDLC artifacts must be stored under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** using the format in the governance doc — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user (shell, IDE Git UI, MCP, script, or automation). Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Public reference and data safety

Follow `ai-sdlc/governance/public-reference-and-data-safety.md`. Public sources may inform
patterns and standards, but do not copy proprietary/copyrighted content, expose private data,
or include secrets.

## Human action required

The technical plan produced by this prompt is a draft for engineering lead review. It must be approved at the **G-PLAN gate** before implementation begins. Production execution steps, infra changes, and deployment instructions are not part of this plan and must be handled separately by the authorized human approver.

Human gate approvals must be recorded in workflow-state `gates` by an authorized approver — AI must not approve gates. Optionally link a review record:

```yaml
artifacts:
  gate_review_record: ".cursor/ai-sdlc/workflow-state/<ISSUE-ID>/gate-review-record.md"
```
