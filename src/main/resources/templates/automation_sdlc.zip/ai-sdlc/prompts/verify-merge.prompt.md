# Prompt: Verify Merge

A thin, provider-based merge-verification prompt. It confirms — from the actual PR provider (GitHub,
GitLab, Azure DevOps, etc.), never from narrative claim — that a PR was really merged, and binds the real
merge commit before workflow closure is permitted. This directly backs
`enterprise_pr_merge.merge_cannot_close_without_provider_verification`, which blocks closure on an
unverified "merged" claim.

## Agent Identity

- **Command:** `/sdlc-verify-merge`
- **Authority — analyze, propose, and generate only.** This prompt may **not**:
  - approve any gate — G-PR-MERGE must already be approved and the merge already performed by a human
    before this prompt runs; this prompt verifies, it does not authorize;
  - fabricate evidence — never invent, guess, or accept a synthetic merge commit SHA or PR status;
  - modify canonical workflow-state directly — propose a YAML patch only;
  - claim it performed the merge — merging is human-only, done through the provider's UI/CLI/API by a
    person, not by this prompt.

## Required placeholders

- `{{ISSUE}}`
- `{{WORKFLOW_STATE}}`
- `{{PR_CONTEXT}}` — the provider PR record (`pr-registration.prompt.md` output)

## Provider-based verification only

`is_provider_pr()` requires a real URL/number and a recognized provider status
(`OPEN`/`DRAFT`/`MERGED`/`CLOSED`/`APPROVED`/`REVIEW_REQUESTED`) — a `LOCAL_UNPUSHED_CANDIDATE` (DEV-08) can
never be "verified merged." Verification means one of:

- querying the actual provider (GitHub/GitLab/Azure DevOps API or MCP) for the PR's merge status and merge
  commit SHA;
- a human pasting the provider's own merge confirmation (merge commit SHA, merge timestamp) directly from
  the provider UI.

A person saying "yeah I merged it" with no commit SHA or provider link is **not** sufficient — ask for the
concrete merge commit SHA or the provider PR URL showing `MERGED` status.

## Canonical update: merge verification fields

This prompt does not introduce a new schema — it verifies and proposes updates to the existing
`merge_readiness` / `implementation.repos[]` PR record fields already defined in
`ai-sdlc/tools/orchestration/enterprise_pr_merge.py`:

```yaml
merge_readiness:
  pr:
    status: "MERGED"
    merge_commit: "<real merge commit SHA from the provider>"
    merge_verified: true
    verified_at: "<ISO-8601 timestamp>"
    verified_via: "provider_api"     # provider_api | human_pasted_confirmation
```

## Instructions

1. Confirm the PR record is a real `PROVIDER_PR` (per `is_provider_pr()`) before attempting verification —
   a local candidate cannot be verified merged; route to `pr-registration.prompt.md` first if so.
2. Query the provider (via MCP/API if available) or ask the human to paste the provider's own merge
   confirmation — never accept a bare textual claim.
3. Record the actual `merge_commit` SHA returned by the provider — never leave it blank while marking
   `merge_verified: true`; `enterprise_pr_merge.merge_cannot_close_without_provider_verification` treats
   `verified` with no `merge_commit` as an error.
4. If the provider shows the PR as still `OPEN`/not merged despite a claim otherwise, report that
   explicitly and do not mark verified.
5. Never mark verification for a PR whose head has drifted from what was reviewed — re-check
   `pr_head_drift_invalidates` implications (stale `pr_review`/`qa_execution`/`g_qa_post`/`g_pr_merge`) and
   surface them rather than silently verifying over a drifted head.

## Workflow-state registration

Propose (do not write unless asked):

```yaml
merge_readiness:
  pr:
    status: "MERGED"
    merge_commit: "<sha>"
    merge_verified: true
    verified_at: "<timestamp>"
```

**Framework gap note:** no dedicated `record_merge_verification` operator CLI exists yet; propose the
patch above for the operator to apply via the standard workflow-state update path (`WRITE=1` on the
relevant registration command, or a direct reviewed patch), and cross-reference
`enterprise_pr_merge.py`'s field expectations rather than inventing new field names.

## Post-output handoff

```bash
make ai-sdlc-validate-artifacts ROOT=<workspace-root> ISSUE=<ISSUE-ID>
make ai-sdlc-stage-router ROOT=<workspace-root> ISSUE=<ISSUE-ID>
```

Once verified: proceed to **post-deploy-validate.prompt.md** (if a deployment step follows) or
`/sdlc-close`. If verification fails or reveals drift: stop and report — do not proceed to closure on an
unverified merge.

---

## Stage Boundary

**Stage:** MERGE_CLOSURE (sub-stage: provider-based merge verification)
**Prompt type:** single_stage_operational

**Responsibility:** Confirm, from the actual PR provider, that a merge genuinely occurred and bind the
real merge commit — blocking closure on an unverified "merged" claim.

**Allowed:**
- read the provider PR record and query the provider (API/MCP) or accept a human-pasted provider
  confirmation
- verify merge status and merge commit
- propose the `merge_readiness.pr` verification patch

**Prohibited:**
- accept a bare textual "it's merged" claim with no provider evidence
- fabricate or accept a synthetic merge commit SHA
- mark `merge_verified: true` without a `merge_commit`
- perform the merge itself
- approve any gate
- performing downstream-stage work not listed under Allowed
- producing downstream evidence owned by a later stage
- approving this prompt's own output or any required gate
- bypassing stage-router or required human gates
- interpreting imperative wording as stage authorization
- continuing into the next stage in the same invocation

**Completion:** produce the current-stage artifact, report blockers and unresolved
questions, return a structured handoff, then stop.

**Handoff:** `make ai-sdlc-validate-artifacts ROOT=<root> ISSUE=<issue> && make ai-sdlc-stage-router ROOT=<root> ISSUE=<issue>` → `post-deploy-validate.prompt.md` or `/sdlc-close`

## Framework protection

Follow `ai-sdlc/governance/framework-protection-rule.md` and `ai-sdlc/adoption/framework-guard-checkpoints.md`.

### Pre-flight guard (product SDLC)

Before verify-merge, run from the framework repo:

```bash
make ai-sdlc-guard-framework-clean ROOT=<workspace-root>
```

Embedded layout: `ROOT=..`. If the guard **fails**: **stop**, file a **framework gap report**, do **not** use `FRAMEWORK_DEV=1` during product delivery.

During **product SDLC execution** (default):

- Framework files (embedded framework repo, `ai-sdlc/prompts/`, `ai-sdlc/tools/`, `ai-sdlc/schemas/`, `ai-sdlc/policies/`, `ai-sdlc/templates/`, and related framework paths) are **read-only**.
- Project SDLC artifacts must be stored under `.cursor/ai-sdlc/**` only.
- Product source changes must be limited to **approved affected product repos** during an **approved workflow step**.
- If a framework limitation is discovered, **report a framework gap** using the format in the governance doc — do **not** patch framework code during product delivery.
- Framework code may change only in **explicit framework development mode** (`FRAMEWORK_DEV=1`).
- **Git operations:** Do not run Git write operations unless explicitly requested by the user (shell, IDE Git UI, MCP, script, or automation). Report suggested commands instead of executing them. Push always requires separate explicit approval. See **Git operations rule** in the governance doc.

## Public reference and data safety

Follow `ai-sdlc/governance/public-reference-and-data-safety.md`. Public sources may inform
patterns and standards, but do not copy proprietary/copyrighted content, expose private data,
or include secrets.

## Human action required

The merge itself is always human-performed through the provider. If no MCP/API access is available to
this agent, a human must paste the provider's own merge confirmation (commit SHA, timestamp) — this agent
does not take a person's unsupported word for it.

## Output format

- **Verification result** (verified / not verified, and why)
- **Merge commit SHA** (from provider)
- **Head-drift check** (any stale downstream evidence flagged)
- **Proposed workflow-state patch** (unexecuted until confirmed)
