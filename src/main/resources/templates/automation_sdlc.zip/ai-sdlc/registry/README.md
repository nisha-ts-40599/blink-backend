# Central Registry

This directory centralizes machine-readable IDs used across workflows, ACP, governance, and policies.

- `artifact-registry.yaml`: artifact types and retention classes.
- `event-registry.yaml`: audit event IDs and severities.
- `gate-registry.yaml`: approval gates and tier applicability.
- `escalation-registry.yaml`: escalation IDs, ownership, SLAs.
- `policy-registry.yaml`: policy IDs and enforcement points.

Use these registries as source-of-truth for automation wiring and static validation.
