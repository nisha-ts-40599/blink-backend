# AI-SDLC 4.0.0-rc.1 Release Notes

**Release channel:** `internal-release-candidate`  
**Stable:** no — this is a Phase 5a release-candidate baseline, not production-ready.  
**Source baseline:** Phase 4 commit `62bbd6b`, tag `ai-sdlc-v4-integrated-journey`  
**Distribution:** repository-distributed (git tag / framework path copy or submodule)

Stable version `4.0.0` and tag `ai-sdlc-v4.0.0` are reserved for Phase 5i production release certification.

## Summary

Phase 5a introduces a reproducible release-candidate baseline for the generic AI-SDLC framework without changing runtime orchestration behavior. This release packages version metadata, integrity verification, and a compatibility matrix so adopters can pin and verify a known framework bundle.

## What changed in 5a

- Framework version bumped to **4.0.0-rc.1** with `stable: false`
- Release channel set to **internal-release-candidate**
- Immutable release manifest at `ai-sdlc/release/manifest.yaml`
- Compatibility matrix at `ai-sdlc/release/compatibility-matrix.yaml`
- Deterministic SHA-256 checksum generation and verification tooling
- Updated governance baseline manifest for Phase 4 integrated journey certification
- Makefile targets: `ai-sdlc-release-checksums`, `ai-sdlc-release-verify`, `ai-sdlc-release-manifest-test`

## What did not change

- `/sdlc-run` planner and executor behavior
- Journey matrix semantics and action handlers
- Mutation guard, role/gate/SoD/waiver authorities
- Handoff consumption and execution-plan enforcement
- Migration tooling (Phase 5b)
- Global `sdlc_run_execution` remains disabled in `framework-release-status.yaml`

## Capabilities certified at source baseline (Phase 4)

- Integrated guided delivery journey (17-action E2E certification)
- Journey recovery, bounded actions, idempotency, and retry semantics
- Action ID normalization and alias-aware handoff matching
- Phase 1–4 governance authorities preserved

## Known limitations carried forward

- Production certification uses canonical handoffs for all delivery actions (Phase 5c complete)
- Workspace migration orchestrator not yet unified (Phase 5b)
- Production pilot not yet authorized (Phase 5h/5i)
- Installable pip wrapper deferred post-pilot

## Install and verify

```bash
# Install framework dependencies
make ai-sdlc-install

# Verify release manifest, compatibility matrix, and checksum integrity
make ai-sdlc-release-verify

# Regenerate checksums after intentional bundle changes (maintainers only)
make ai-sdlc-release-checksums WRITE=1
```

## Pin framework in a workspace (existing flow)

```bash
make ai-sdlc-framework-setup-refresh ROOT=<workspace> DRY_RUN=1
make ai-sdlc-framework-setup-refresh ROOT=<workspace> WRITE=1
```

## Upgrade from 2.0.0 governance baseline

1. Pin framework to tag/commit for `4.0.0-rc.1` or current branch baseline
2. Run `make ai-sdlc-framework-setup-refresh ROOT=<workspace> DRY_RUN=1`
3. Review compatibility report; complete guided-handoff migration when Phase 5b tooling is available
4. Do not assume production-ready status until Phase 5i stable release

## Distribution note

Phase 5 remains **repository-distributed**. An optional installable Python wrapper may be evaluated after a successful internal pilot; it is not part of this release-candidate.

## Reserved for Phase 5i

- Stable version: `4.0.0`
- Stable tag: `ai-sdlc-v4.0.0`
- Production-ready marking and pilot authorization
