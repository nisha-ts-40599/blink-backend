# AI-SDLC 4.0.0 Release Notes

**Release channel:** `stable`
**Stable:** yes — Phase 5i stable release certification complete on branch `feature/prompt-cleanup`.
**Tag (pending):** `ai-sdlc-v4.0.0` at commit `9cc5a18`
**Distribution:** repository-distributed (git tag / framework path copy or submodule)

This release promotes the framework from **4.0.0-rc.1** (`internal-release-candidate`) after Phase 5i Release and Certification aggregates **PASS** on first attempt. Historical RC evidence remains in `RELEASE-NOTES-4.0.0-rc.1.md` and compatibility-matrix entry `4.0.0-rc.1`.

## Certification status (Phase 5i)

| Aggregate | Result | Notes |
| --- | --- | --- |
| Release | **PASS** (first attempt) | Includes overlay-check, orchestration, release integrity |
| Certification | **PASS** (first attempt) | Protected tier 21/21 suites |
| E2E workspace isolation | **Resolved (Phase 5j)** | PID-guarded `release_owned_temp_dir`; regression in `test_e2e_workspace_isolation.py` |

Certification fingerprints (pre-stable metadata, RC channel):

- `checksums.sha256`: `df74c43ab08a2b7f73ecd1ac53d9e481e51ff03d3b2b10e1873d61d1f16ddfa2`
- `baseline-standard`: `0c213e225981242ef0534392fed13653c343c258d8e030af880e6890a52b7ee4`
- `baseline-certification`: `3541e39c20767db48954fd3f773453590a12500b823b981439043ef22890fbc5`

Stable transition refreshes checksums after metadata-only changes. Performance baselines remain **Phase 5g historical measurement evidence** captured at commit `f4fcc62` under RC identity (`4.0.0-rc.1` / `internal-release-candidate` / `stable: false`); stable 4.0.0 inherits these baselines for regression comparison without relabeling capture provenance.

## Release scope

Phase 5 (5a–5i) delivers a repository-distributed generic AI-SDLC framework with:

- **5a** — Release manifest, compatibility matrix, deterministic checksum integrity
- **5b** — Workspace backup, rollback, unified migration orchestrator
- **5c** — Concurrent execution, crash recovery, lock registry hardening
- **5d** — Checksum scope expansion, guided handoff enforcement
- **5e** — Operational health, audit export, retention, redaction
- **5f** — CI tier enforcement, security hardening, threat model
- **5g** — Performance benchmark harness and baselines
- **5h** — Operator guidance, reason-code runbook, pilot readiness package
- **5i** — Release/Certification aggregates; E2E workspace-isolation fix

**No runtime orchestration, authorization, role, gate, handoff, mutation, locking, migration, recovery, security, audit, or pilot semantics changed in this stable metadata transition.**

## Governance model

Preserved authorities (unchanged at stable promotion):

- Product mutation guard and MCP permission policy
- Canonical role registry, gate authorization, separation of duties, fallback waivers
- Guided handoff and execution-plan binding; delivery journey matrix bounded execution
- Journey recovery registry; action ID normalization
- Release integrity verification; workspace migration and rollback
- Lock and recovery authorities; local audit evidence

Global `sdlc_run_execution` remains **disabled** in `framework-release-status.yaml`. Stable certification does not authorize production-main merge.

## Canonical operator journey

1. **Entry:** `/sdlc-run ISSUE` (planner/executor; prompts advisory, guards authoritative)
2. **Setup:** `make ai-sdlc-install`; `make ai-sdlc-framework-setup-refresh ROOT=<ws> DRY_RUN=1`
3. **Verify:** `make ai-sdlc-release-verify`
4. **Operate:** Follow `ai-sdlc/adoption/operator-guide.md` and `operator-quick-start.md`
5. **Recover:** `ai-sdlc/adoption/recovery-runbook.md`; reason codes in `reason-code-runbook.md`
6. **Pilot:** `pilot-plan.md`, `pilot-readiness-checklist.md`, dry-run via `make ai-sdlc-pilot-dry-run`

## Migration and rollback

**From 4.0.0-rc.1 or 2.0.0:**

```bash
make ai-sdlc-migrate-workspace MODE=ASSESS ROOT=<ws> TARGET=4.0.0
make ai-sdlc-migrate-workspace MODE=DRY_RUN ROOT=<ws> TARGET=4.0.0
# After review:
make ai-sdlc-migrate-workspace MODE=APPLY ROOT=<ws> TARGET=4.0.0 WRITE=1
```

**Rollback (overlay-only, canonical Make path):**

```bash
make ai-sdlc-rollback-workspace ROOT=<ws> BACKUP=<archive.tar.gz> WRITE=1
```

Direct `restore_workspace()` API defaults `safety_snapshot=True`; canonical rollback uses external `BACKUP` via Make.

## Handoff enforcement

Canonical handoffs required for delivery actions (Phase 5c). Synthetic handoffs prohibited in production paths. Execution-plan binding and consumed-handoff lookup remain authoritative.

## Concurrency and crash recovery

Lock registry, journey recovery, and idempotent action semantics certified in Phase 5c/5d. E2E tests use owned workspace isolation (Phase 5i fix) to prevent cross-test temp-dir races.

## Audit and health

Health reports, JSON audit export, retention assessment, and redaction tooling (Phase 5e). Evidence under workspace overlay `.cursor/ai-sdlc/`.

## Security and CI enforcement

CI tiers (`fast`, `protected`, `release`, `certification`) via `tier-manifest.yaml` and `run_tier_test.py`. Threat model v4 documents T-PATH, T-CMD, T-SUPPLY, T-AUTH controls. Path security regression suite; `requirements.lock` supply-chain pin.

## Performance certification

Benchmark profiles `smoke`, `standard`, `certification` with deterministic harness v1.0.0. Baselines are inherited Phase 5g evidence (`source_commit: f4fcc62`, RC capture identity); medians unchanged.

Verify: `make ai-sdlc-performance-benchmark-test`

## Pilot-readiness package

Adoption docs under `ai-sdlc/adoption/`: operator guides, recovery runbook, pilot plan, metrics, rollback triggers, readiness checklist. Dry-run: `make ai-sdlc-pilot-dry-run`.

Pilot requires explicit marker; framework branch remains `feature/prompt-cleanup` until main merge policy allows otherwise.

## Install and verify

```bash
make ai-sdlc-install
make ai-sdlc-release-verify
make ai-sdlc-schema-check
make ai-sdlc-fast-test   # PR-tier feedback
```

Regenerate checksums after intentional bundle changes (maintainers only):

```bash
make ai-sdlc-release-checksums WRITE=1
```

## Known accepted residuals

Tested limitations documented; not resolved by stable metadata alone:

- Manual IDE edits outside Cursor agent hooks are not intercepted
- Container or CI filesystem mutations without hook installation
- OS-level network egress from managed bootstrap (accepted out-of-scope)
- Integrity bundle excludes general Python tool source outside scoped paths
- T-CMD-002 partial subprocess enforcement in orchestration git helpers
- `safety_snapshot=True` default on direct `restore_workspace()` API
- Installable pip wrapper deferred post-pilot
- Production-main merge gated separately from stable framework certification
- Intermittent `FileNotFoundError` under `.test-tmp/e2e-workspaces/` when multiple long-running Certification/Make processes share the same worktree concurrently (Phase 5j: PID-guarded release prevents cross-process deletion; residual requires separate worktrees or serialized cert runs on one checkout)

## Lineage

| Milestone | Commit / tag |
| --- | --- |
| Phase 4 integrated journey | `62bbd6b` · `ai-sdlc-v4-integrated-journey` |
| RC baseline | `4.0.0-rc.1` · `internal-release-candidate` |
| Phase 5i certification | `9cc5a18` · pending `ai-sdlc-v4.0.0` |

## Upgrade from 4.0.0-rc.1

1. Pin framework to tag `ai-sdlc-v4.0.0` (once created) or commit `9cc5a18`
2. Run migration assess/dry-run commands above
3. Re-run `make ai-sdlc-release-verify` in workspace
4. Review pilot-readiness checklist before live pilot issues

Do not treat stable certification as unlimited production guarantee beyond tested evidence above.
