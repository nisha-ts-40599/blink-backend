# Interactive Greenfield Setup — Final Validation Report

**Date:** 2026-07-28  
**Branch:** `feature/prompt-cleanup`  
**Base commit (before uncommitted hardening):** `c20adddd53ee59c65d9068490b840804515a19e2`  
**Validation type:** Read-only product workspace; framework hardening applied locally (uncommitted).

---

## 1. Pre-overlay input handling

| Check | Result |
|-------|--------|
| Discovery on empty workspace (no `.cursor/ai-sdlc/`) | **PASS** — `run_discovery` does not create directories |
| Input at `<workspace>/project-initialisation-input.yaml` | **PASS** — `resolve_init_input_path()` prefers pre-overlay path before overlay path |
| Apply normalizes into overlay | **PASS** — writes `.cursor/ai-sdlc/setup/project-initialisation-input.yaml`; records `source_input` in report |
| Circular dependency (input only inside overlay) | **REMOVED** — Make default `INPUT=project-initialisation-input.yaml` resolved relative to `ROOT` |

**Evidence:** `test_pre_overlay_input_without_cursor_directory`, `test_apply_normalizes_pre_overlay_to_standard_path`, `input_paths.py`, `run_greenfield_interactive_setup.py`.

**Operator sequence:** Fill pre-overlay YAML → `make ai-sdlc-greenfield-setup-discover ROOT=<ws>` → `/setup-new-workspace apply` (overlay) → `make ai-sdlc-greenfield-setup-apply ROOT=<ws>` (normalizes intake + reports).

---

## 2. Discovery strictly read-only

**Procedure:** Empty temp workspace with only `project-initialisation-input.yaml`; `find` tree before/after `make ai-sdlc-greenfield-setup-discover`.

**Result:** **PASS** — `diff` before/after identical (`DISCOVERY_NO_WRITE: OK`).

**Unit tests:** `test_discovery_mode_makes_no_writes`, `test_discovery_twice_deterministic_report_id`.

No Git repository required in product workspace for discovery; Git status N/A.

---

## 3. MCP detection scope and statuses

**Inspected locations (read-only, server names only):**

1. `<workspace-root>/.cursor/mcp.json`
2. `<framework-root>/.cursor/mcp.json` when framework root resolves from workspace

**Not inspected:** Cursor user-global MCP config, OS secret store, environment variable **values**.

**Statuses used:** `CONFIGURED_IN_WORKSPACE`, `CONFIGURED_IN_FRAMEWORK_REPO`, `NOT_CONFIGURED_IN_CHECKED_SCOPE`, `UNKNOWN_GLOBAL_STATUS`, `DEFERRED_BY_USER`, `NOT_REQUIRED`.

**Never emitted:** tokens, env values, MCP command arguments with secrets.

Report includes `mcp_inspection_scope` block documenting checked vs not-checked paths.

**Evidence:** `integration_probe.py`, `test_provider_mcp_available_when_configured`, `test_no_secrets_in_reports`.

---

## 4. Scaffold artifact bindings

Scaffold records written on apply include `artifact_bindings` (issue, requirement, technical_plan, greenfield_spec, bootstrap_plan, approvals when present) via `artifact_bindings.py`.

**Stale hash blocking:** `validate_artifact_bindings()` / `assert_scaffold_execution_allowed()` return blocking errors when bound hashes drift.

**Evidence:** `test_stale_artifact_binding_blocks_execution`, schema extension `scaffold-execution-record.schema.json`.

**Gap:** Bindings populate from disk at apply time; issue/requirement/plan hashes appear only after Phase 0/1 artifacts exist. Execution correctly blocks until bindings match or user re-approves.

---

## 5. Idempotency

| Action | Result |
|--------|--------|
| Discovery twice | **PASS** — same deterministic `report_id` (fingerprint from init + recommendations) |
| Greenfield setup apply twice | **PASS** — no duplicate scaffold filenames; manual input YAML preserved when `preserve_existing` |
| Stale recommendations | **PASS** — second apply with changed fingerprint sets `stale_recommendations` on report |
| Deferred/unresolved merge | **PASS** — merges lists without dropping unique entries on re-apply |

**Evidence:** `test_apply_twice_no_duplicate_scaffold_records`, `test_custom_workspace_files_preserved_on_idempotent_apply`.

---

## 6. Local-only fallback

**Scenario:** Git available, no provider MCP in workspace, Figma skipped, Confluence deferred.

**Result:** **PASS**

- Setup continues (discovery/apply)
- `local_git.status` = `AVAILABLE`
- `provider_git.remote_creation_deferred` = true when no provider in checked scope
- `provider_completion_claimed` = false
- `later_connection_instructions` in report / markdown

**Evidence:** `test_git_installed_without_provider_mcp`, `test_local_git_fallback_provider_deferred`, `test_user_skips_figma_confluence`.

---

## 7. Mobile + backend recommendation scenario

**Input:** Android/iOS, API, one team, shared contracts, Flutter + Java + Python skills, PostgreSQL.

**Result:** **PASS**

- Monorepo + `apps/mobile` layout
- Flutter mobile (`approval_status: pending`)
- `backend_comparison` includes Spring Boot vs FastAPI
- PostgreSQL recommended

**Evidence:** `test_mobile_backend_stack_recommendation_scenario`.

---

## 8. Separated-repository scenario

**Input:** Independent mobile/backend teams, independent deployment, separate access controls.

**Result:** **PASS** — multi-repo, `proposed_repositories` with creation order 1→2→3 and `depends_on`.

**Evidence:** `test_separated_teams_multi_repo_names_and_order`.

---

## 9. Scaffold safeguards

| Requirement | Result |
|-------------|--------|
| Exact command, cwd, network, expected paths, rollback in records | **PASS** |
| User confirmation required | **PASS** — `requires_user_confirmation`, policy flags |
| Discover/apply run no scaffold/git/remote commands | **PASS** — `scaffold_execution_policy` |
| No initial commit / remote / push by tooling | **PASS** |

**Evidence:** `test_scaffold_safeguards_no_auto_execute`, `test_scaffold_command_displayed_before_execution`.

---

## 10. Test results (mandatory targets)

| Target | Result |
|--------|--------|
| `make ai-sdlc-greenfield-h11-test` | **PASSED** (67 tests, includes 27 interactive setup tests) |
| `make ai-sdlc-orchestration-test` | **PASSED** |
| `make ai-sdlc-prompt-boundary-test` | **PASSED** (after renaming include to `greenfield-interactive-setup.md`) |
| `make ai-sdlc-prompt-check` | **PASSED** |
| `make ai-sdlc-conformance` | **PASSED** (13 passed, 6 skipped) |
| `make ai-sdlc-conformance-protected` | **PASSED** |
| `make ai-sdlc-release-candidate-test` | **FAILED** — `framework-guard` (uncommitted framework changes); also `ai-sdlc-flow-alignment-test`, `ai-sdlc-genericity-check`, `ai-sdlc-local-candidate-promotion-test` exit 2 on dirty tree |
| `git diff --check` | **PASSED** (no conflict markers/whitespace errors) |

**Note:** User requested `make ai-sdlc-release-candidate` — target is `ai-sdlc-release-candidate-test`.

**Commit policy:** Do **not** commit until release-candidate suite passes on a committed tree (or explicit `FRAMEWORK_DEV=1` policy acceptance).

---

## 11. Files changed (summary)

**New:** `ai-sdlc/tools/setup/greenfield_interactive/*`, schemas (init input/report/scaffold record), template, tests, CLI, adoption guide, prompt include.

**Modified:** Makefile (discover/apply targets), setup prompts, SOP, quick-start, managed bootstrap doc, greenfield spec guide, operator inventory.

---

## 12. Remaining limitations

- Full overlay (`workspace-config`, `setup-state`, context) still created by `/setup-new-* apply`, not solely by `greenfield-setup-apply`.
- MCP probe does not network-test servers (`UNREACHABLE` reserved for future health checks).
- Provider MCP presence does not imply remote creation completed — always `provider_completion_claimed: false` until human/MCP execution + reconciliation.
- Artifact bindings for issue/requirement/plan populate after those workflow artifacts exist.

---

## 13. Safe for first real project?

**Yes, with the documented operator sequence**, for:

- Pre-overlay questionnaire and discovery on an empty product directory
- Recommendation review and explicit apply
- Standard overlay + bootstrap gates unchanged
- Cursor-assisted scaffold with display/confirm and stale-artifact blocking

**Before production framework release:** commit hardening, re-run `make ai-sdlc-release-candidate-test` on clean committed framework tree.

---

## 14. Hardening applied in this review

- Pre-overlay input resolution and normalization
- MCP status precision + inspection scope documentation
- Deterministic report IDs; stale recommendation detection on re-apply
- Scaffold artifact bindings + stale hash validation
- Multi-repo repository order; backend Spring vs FastAPI comparison when both skill sets present
- Path resolution fix for macOS `/private` temp prefixes
