# AI-SDLC Global Rules

Rules define the **constraints and principles** that govern all AI-assisted work across projects.
They are project-agnostic by design. Project-specific overrides and extensions are loaded from
`project-config.yaml`.

## Rule categories

| Category | Description |
|----------|-------------|
| **Mandatory global** | Applied to all projects with no override permitted. Violations are CI failures or hard blocks. |
| **Project-overridable** | Applied by default; projects may tighten or relax within defined bounds via `project-config.yaml`. |
| **Project-extended** | Not applied by default; projects may add these rules to their config for additional rigor. |
| **Non-overridable human governance** | Human accountability rules. No configuration, no maturity level, no business pressure overrides them. |

## How rules are loaded

At Level 1 (current), rules are embedded in prompts and the engineering guardrails document.
Engineers apply them manually as part of prompt invocation.

At Level 2+, the context aggregator loads applicable rules from `rules/global-rule-index.md`
and project-specific overrides from `project-config.yaml` before assembling agent context.

## Rule index

See `global-rule-index.md` for the full catalog.

## Adding a new rule

1. Determine the category (mandatory / overridable / extended / governance).
2. Check if an existing rule already covers the intent.
3. Add to `global-rule-index.md` with rationale, scope, and project override bounds.
4. If the rule is referenced in a prompt, update `prompts/prompt-placeholder-catalog.md` if a new placeholder is needed.
5. Run `make ai-sdlc-prompt-check` to verify consistency.

## Relationship to engineering guardrails

`governance/enterprise-engineering-guardrails.md` is the human-readable, narrative version of
the coding-quality subset of these rules. `rules/global-rule-index.md` is the structured,
machine-readable index that agents and the rule engine use for lookup and enforcement.
