# Global Rule Index

All rules are project-agnostic. See `rules/README.md` for category definitions and override
model. See `governance/enterprise-engineering-guardrails.md` for narrative guidance on
coding-quality rules.

---

## A. Enterprise Engineering Quality Rules

### RULE-EQ-001 — Enterprise Engineering Guardrails (mandatory global)

**Rule:** All AI-generated or AI-assisted code must comply with `governance/enterprise-engineering-guardrails.md`.
**Applies to:** All code changes at all tiers.
**Enforcement:** Checklist in `prompts/self-review.prompt.md` and `prompts/pr-review.prompt.md`; PR template checklist.
**Override:** Not overridable. Projects may add stricter rules.
**Human gate:** Engineering lead reviews guardrail checklist on Tier 3+ PRs.

---

### RULE-EQ-002 — Reuse-First Principle (mandatory global)

**Rule:** Before creating new code, exhaustively check for existing components, utilities, patterns, or libraries that already solve the problem. New code is only justified when no reusable alternative exists.
**Applies to:** All implementation stages.
**Enforcement:** Embedded in `prompts/implement-step.prompt.md`; skill SKL-008.
**Override:** Not overridable.
**Project extension:** Projects may specify a component registry URL for targeted reuse checks.

---

### RULE-EQ-003 — Minimal Safe Change (mandatory global)

**Rule:** A change should do exactly what is required — no more. No bundled refactoring, dependency upgrades, style changes, or unrelated improvements unless they are the explicit scope of the work.
**Applies to:** All implementation and bug-fix stages.
**Enforcement:** Embedded in `prompts/implement-step.prompt.md`, `prompts/bug-triage.prompt.md`, `prompts/fix-review-comments.prompt.md`.
**Override:** Not overridable. Separate PRs for separate concerns.
**Exception process:** Request a separate scope expansion issue if related refactoring is genuinely necessary.

---

### RULE-EQ-004 — Architecture Alignment (mandatory global)

**Rule:** All changes must align with the existing architectural patterns documented in `project-context.md`. New patterns require an ADR before implementation.
**Applies to:** All tiers; ADR requirement is mandatory for Tier 3+.
**Enforcement:** Architecture Review Agent; `prompts/self-review.prompt.md` checklist.
**Override:** Not overridable for ADR requirement on durable decisions.
**Project extension:** Projects may define additional architectural constraints in `project-context.md`.

---

### RULE-EQ-005 — No Unnecessary Refactoring (mandatory global)

**Rule:** Refactoring is not permitted inside a feature or bug-fix PR unless it directly enables the required change and is noted in the technical plan.
**Applies to:** All implementation stages.
**Enforcement:** `prompts/implement-step.prompt.md`; `prompts/pr-review.prompt.md` must-fix check.
**Override:** Not overridable.

---

### RULE-EQ-006 — SOLID Principles (project-overridable)

**Rule:** Code should adhere to Single Responsibility, Open/Closed, Liskov Substitution, Interface Segregation, and Dependency Inversion principles where applicable to the language and paradigm.
**Applies to:** Object-oriented and service-oriented code.
**Enforcement:** Advisory check in `prompts/pr-review.prompt.md`.
**Override:** Projects may define the specific SOLID application in `project-context.md` (e.g., functional-first projects may adapt or not apply OOP-specific rules).

---

### RULE-EQ-007 — DRY / KISS / YAGNI (mandatory global)

**Rule:** Don't repeat yourself (DRY); keep code simple (KISS); don't build features that are not currently needed (YAGNI).
**Applies to:** All implementation stages.
**Enforcement:** Embedded in `prompts/implement-step.prompt.md`; skill SKL-009.
**Override:** DRY and KISS are not overridable. YAGNI may be relaxed for platform/infrastructure code with explicit justification.

---

### RULE-EQ-008 — Design Patterns Only When Justified (project-overridable)

**Rule:** Design patterns are applied only when the specific problem the pattern solves is present. Pattern-first design is prohibited.
**Applies to:** All implementation stages.
**Enforcement:** Advisory in `prompts/pr-review.prompt.md`.
**Override:** Projects may list pre-approved patterns in `project-context.md` that are applied by convention.

---

## B. Security Rules

### RULE-SEC-001 — Secure Coding (mandatory global)

**Rule:** All code must follow OWASP Top 10 mitigations relevant to the language and framework. Input validation, output encoding, authentication, authorization, and secret handling are non-negotiable.
**Applies to:** All implementation stages.
**Enforcement:** `prompts/pr-review.prompt.md` must-fix criteria; Gitleaks (CI); SAST/CodeQL (when configured).
**Override:** Not overridable. Projects may add stricter controls.
**Human gate:** Security champion reviews for Tier 3+ or whenever RULE-SEC-001 findings are present.

---

### RULE-SEC-002 — No Secrets in Code (mandatory global)

**Rule:** Secrets, credentials, tokens, and connection strings must never appear in source code, commit history, or any artifact stored in version control.
**Applies to:** All code and configuration files.
**Enforcement:** Gitleaks CI job; `prompts/self-review.prompt.md` checklist.
**Override:** Not overridable.
**Human gate:** Any Gitleaks finding is a hard CI block; secret rotation is human-only.

---

### RULE-SEC-003 — Risk Rule Elevation (mandatory global)

**Rule:** The presence of any risk trigger (PII, auth, payment, external API, data deletion, infrastructure, security model change) automatically elevates minimum tier to Tier 2 and requires explicit justification to remain below Tier 3.
**Applies to:** Work Classification, Technical Planning.
**Enforcement:** `prompts/classify-work.prompt.md`; skill SKL-005; `governance/risk-rules.md`.
**Override:** Not overridable by AI. Engineering lead may override tier classification with written justification.
**Human gate:** Tier elevation override requires named engineering lead approval.

---

## C. Test Quality Rules

### RULE-TEST-001 — Test Quality Over Test Count (mandatory global)

**Rule:** Tests must verify behaviour, not implementation. A test that passes for the wrong reason is worse than no test. Coverage threshold is a floor, not a goal.
**Applies to:** Test generation stage.
**Enforcement:** `prompts/generate-tests.prompt.md`; skill SKL-011.
**Override:** Not overridable.
**Project extension:** Projects set coverage thresholds in `project-config.yaml`.

---

### RULE-TEST-002 — Regression Test Required for Every Bug Fix (mandatory global)

**Rule:** Every bug fix must include a regression test that fails before the fix and passes after.
**Applies to:** Bug fix implementation.
**Enforcement:** `prompts/bug-triage.prompt.md`; `prompts/generate-tests.prompt.md`.
**Override:** Not overridable.

---

### RULE-TEST-003 — Test Conventions (project-overridable)

**Rule:** Tests follow the project's documented test conventions (naming, structure, assertion style, fixture management).
**Applies to:** Test generation.
**Enforcement:** Advisory in `prompts/generate-tests.prompt.md`.
**Override:** Each project defines test conventions in `project-context.md`.

---

## D. API Quality Rules

### RULE-API-001 — API Contract Stability (mandatory global)

**Rule:** No breaking change to a public API without a version increment. Breaking changes require an ADR and communication plan.
**Applies to:** API changes at all tiers.
**Enforcement:** `prompts/pr-review.prompt.md` must-fix check; skill SKL-013.
**Override:** Not overridable.
**Human gate:** Breaking API changes require engineering lead approval in G-PLAN.

---

### RULE-API-002 — OpenAPI Documentation Currency (mandatory global)

**Rule:** OpenAPI specifications must be updated in the same PR as the corresponding API changes. Stale specs are a must-fix finding.
**Applies to:** All API implementation PRs.
**Enforcement:** `prompts/update-docs.prompt.md`; skill SKL-014; PR review must-fix check.
**Override:** Not overridable.

---

## E. Database Migration Rules

### RULE-DB-001 — Migration Discipline (mandatory global)

**Rule:** Every database migration must include: (1) an up migration, (2) a down (rollback) migration, (3) a backward compatibility assessment, and (4) a data volume risk estimate for large tables.
**Applies to:** All database schema changes.
**Enforcement:** Database Migration Agent; skill SKL-015; `prompts/implement-step.prompt.md` (DB step).
**Override:** Not overridable.
**Human gate:** Production migration execution is always human-run; destructive migrations require G-SEC.

---

### RULE-DB-002 — Zero-Downtime by Default (project-overridable)

**Rule:** Database migrations must be compatible with zero-downtime deployments (backward-compatible schema, expand/contract pattern for removals).
**Applies to:** Production-targeting database changes.
**Enforcement:** Database Migration Agent; skill SKL-015.
**Override:** Projects with maintenance windows may relax via `project-config.yaml` with documented justification.

---

## F. Dependency Rules

### RULE-DEP-001 — Dependency Discipline (mandatory global)

**Rule:** Dependency upgrades should be minimal (prefer patch/minor over major); each CVE or vulnerability is addressed in its own PR; transitive dependencies are reviewed on major upgrades; license review is performed on new or major-upgraded dependencies.
**Applies to:** All dependency changes.
**Enforcement:** `prompts/cve-triage.prompt.md`; pip-audit CI job; skill SKL-017.
**Override:** Not overridable for one-CVE-per-PR rule.
**Project extension:** Projects may add license allowlist/blocklist to `project-config.yaml`.

---

## G. Documentation Rules

### RULE-DOC-001 — Documentation Discipline (mandatory global)

**Rule:** Documentation must be updated in the same PR as the corresponding code change. New capabilities require new documentation. Removed capabilities require documentation removal. Stale documentation is a must-fix finding.
**Applies to:** All PRs with user-facing or API-facing changes.
**Enforcement:** `prompts/update-docs.prompt.md`; skill SKL-022; PR template checklist.
**Override:** Not overridable.

---

### RULE-DOC-002 — Context Freshness (mandatory global)

**Rule:** `project-context.md` must be reviewed and updated at minimum every 90 days. Agents must not proceed if `project-context.md` is older than 90 days without a freshness acknowledgement.
**Applies to:** All agent invocations; all projects.
**Enforcement:** Skill SKL-021; Orchestrator prerequisite check.
**Override:** Not overridable for the 90-day block. Projects may set a stricter cadence.

---

## H. Observability Rules

### RULE-OBS-001 — Observability Discipline (project-overridable)

**Rule:** New services, new endpoints, and significant new features must include appropriate observability: structured logging, relevant metrics, distributed tracing instrumentation, and alerting rules where applicable.
**Applies to:** Implementation of new capabilities.
**Enforcement:** Advisory in `prompts/pr-review.prompt.md`; `prompts/monitoring-interpretation.prompt.md`.
**Override:** Projects define observability requirements in `project-context.md`; minimum level is project-set.

---

## I. Human Governance Rules

> These rules are **non-overridable at any maturity level**. No configuration change, no tier
> classification, and no automation path removes them.

### RULE-GOV-001 — Human Gate Rules (non-overridable)

**Rule:** The four approval gates — G-PLAN, G-SEC, G-PR-MERGE, and G-DEPLOY — require written, named-human approval before the workflow advances. No AI agent approves any gate.
**Reference:** `governance/approval-gates.md`, `governance/human-in-the-loop-policy.md`

---

### RULE-GOV-002 — No Autonomous Merge (non-overridable)

**Rule:** No AI agent or automated system merges code to any protected branch. Merge requires explicit human action.
**Reference:** `governance/human-in-the-loop-policy.md`

---

### RULE-GOV-003 — No Autonomous Production Deployment (non-overridable)

**Rule:** No AI agent or automated system executes a production deployment. Deployment requires explicit human authorization (G-DEPLOY).
**Reference:** `governance/human-in-the-loop-policy.md`

---

### RULE-GOV-004 — MCP Access Rules (non-overridable bounds)

**Rule:** Agents receive only the minimum MCP access required for their role. Write access is never granted to protected branches. Destructive actions require break-glass process.
**Reference:** `mcp/mcp-permissions.md`, `mcp/mcp-security-guidelines.md`

---

### RULE-GOV-005 — Artifact Traceability Rules (mandatory global)

**Rule:** Every artifact produced by an agent must be traceable to: (1) the issue that triggered the work, (2) the handoff contract that requested it, (3) the agent that produced it, and (4) the timestamp and schema version.
**Reference:** `governance/audit-log-requirements.md`, `acp/acp-handoff-contracts.md`

---

## Rule Override Model

```
project-config.yaml
└── rules:
    overrides:
      RULE-EQ-006: { apply: false, justification: "Functional-first codebase" }
      RULE-DB-002: { relax_zero_downtime: true, justification: "Maintenance window available" }
    extensions:
      - id: "RULE-EXT-001"
        name: "Healthcare data handling"
        description: "All PHI fields must be encrypted at rest using AES-256"
        applies_to: ["IMPLEMENTING", "PR_OPEN"]
        enforcement: "pr-review checklist item"
```

Only `project-overridable` and `project-extended` rules may appear in the `rules.overrides`
and `rules.extensions` sections. Mandatory global and non-overridable governance rules cannot
appear in overrides.
