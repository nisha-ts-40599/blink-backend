# AI-SDLC Runtime (v0.4)

> **Reference implementation — not for production use.**
>
> This runtime is a local demonstration of the AI-SDLC orchestration model.
> All external adapters are mock implementations. No real side effects occur.
> The runtime writes only to the local filesystem under `runtime-data/`.
>
> **Do not connect this runtime to production systems, real APIs, or CI pipelines
> that execute against live environments.**
>
> Use this runtime to explore the framework's architecture and observe its behavior
> locally. For real adoption, use the prompts, workflows, and conformance tooling —
> not this orchestrator.

---

## Status Legend

The runtime has four tiers of capability:

| Symbol | Meaning |
|--------|---------|
| ✅ Implemented | Runs and produces real output |
| ⚠️ Mocked | Logic is present but side effects are local/simulated |
| 🔬 Experimental | Code exists but is not wired to any enforced path |
| 🔮 Future | Documented or stubbed; not yet built |

---

## What Is Implemented (✅)

- **Workflow loading** — parses markdown files; extracts YAML header and steps
- **Explicit action_key dispatch** — `executable_steps` in workflow YAML header routes each step to a named executor; prose inference is a fallback with warning
- **Sequential step execution** — steps run in order; each produces artifacts and audit events
- **Gate enforcement** — `validate_approval_gate` raises `PolicyEnforcementError` in `protected` profile when policy denies; dev profile emits advisory warnings
- **Policy engine** — evaluates OPA/Rego when available; local fallback for transitions, gates, and MCP class checks
- **Atomic state persistence** — single `runtime-state.json` written via temp+rename; crash-safe
- **Failed-state persistence** — `failed` state is persisted with audit event and run_error field
- **Resume/recovery** — `--resume <run-id>` skips completed steps; reads from `runtime-state.json`
- **Bounded step retry** — configurable via `--max-retries` and `--retry-delay` (exponential backoff)
- **Compensation recording** — on terminal step failure, records compensation intent and emits audit event
- **Artifact integrity validation** — SHA-256 digest + JSON Schema validation on every `put`
- **ACP handoff emission** — emits `ImplementationResultHandoff` on workflow completion; validates against schema
- **Idempotency cache** — per-run; step text hash used as key component for resilience to step reordering
- **Correlation ID** — auto-generated in dev profile if absent; required in protected profile
- **Audit log** — append-only JSONL; every record includes `run_id`, `timestamp`, `event_id`, `event_type`
- **Runtime metrics** — workflow duration, per-step timing, retry/compensation counts persisted to `metrics.json`
- **Policy traces** — optional OPA evaluation traces persisted under `policy-traces/` when `--trace-policies`
- **Conformance preflight** — optional; runs conformance runner before execution via `--preflight-conformance`
- **Test scenario harness** — `--test-scenario` activates failure injection and artifact corruption for demos (not for production)

---

## What Is Mocked (⚠️)

These components use local stubs.  Real behavior requires replacing adapters.

| Component | Mock behavior | Real behavior requires |
|-----------|---------------|----------------------|
| `MockIssueTracker` | Writes issues to `mock-issues.json` | GitHub/Jira/Linear API adapter |
| `MockGitProvider` | Writes PRs to `mock-prs.json` | GitHub/GitLab/Bitbucket API adapter |
| `MockDocumentStore` | Writes docs to `mock-docs.json` | Confluence/Notion/Git docs adapter |
| `ApprovalEngine` (dev) | Returns `simulated-approved` for all gates | Real approval via webhook or issue comment |
| `CompensationEngine` | Records compensation intent as JSON artifact | Real reversal: close issue, close PR, revert doc |
| OPA subprocess calls | 2 subprocess invocations per policy check | OPA server HTTP API for production load |

---

## What Is Experimental (🔬)

- `policies/org-role-mapping.rego` — passes through input; no callers
- `policies/gate-sla.rego` — correct logic; no SLA clock integrated
- `schemas/governance/risk-classification.schema.json` — no runtime validation path
- ACP payload schemas for unused handoff types (requirement, impact-analysis, technical-plan, pr-review, release-readiness) — defined but not emitted or validated

---

## What Is Future (🔮)

- Waiting-for-approval state: workflow pauses until external webhook fires
- Rollback orchestration: load rollback baseline, execute reversal, verify
- Emergency stop signal: external persistent flag (not input payload boolean)
- Cross-run artifact lineage graph
- Audit log integrity chain
- Real compensation (adapter rollback methods)
- LLM adapter for prompt execution
- Approval token generation and validation
- Dual-control enforcement for Tier 4
- Distributed idempotency (Redis/DynamoDB)
- OPA server mode (REST API)

---

## Directory Layout

```
runtime/
├── orchestrator.py          # CLI entry point; coordinates all components
├── workflow_engine.py       # Loads and parses workflow markdown files
├── step_executors.py        # Registry of action_key → executor functions
├── policy_engine.py         # OPA + local fallback policy evaluation
├── approval_engine.py       # Gate pre-check (simulated in dev profile)
├── artifact_store.py        # Local artifact persistence + integrity validation
├── handoff_engine.py        # ACP handoff emission + schema validation
├── audit_logger.py          # Append-only JSONL audit logger
├── idempotency_store.py     # Per-run idempotency cache
├── retry_engine.py          # Bounded retry with exponential backoff
├── compensation_engine.py   # Stub compensation handlers (see mock warning)
├── metrics.py               # Runtime metrics collection
├── models.py                # WorkflowStep, WorkflowDefinition, ExecutionContext
├── exceptions.py            # Structured exception hierarchy
├── adapters/
│   ├── mock_issue_tracker.py
│   ├── mock_git_provider.py
│   └── mock_document_store.py
├── tests/
│   └── scenario_helpers.py  # Failure injection harness (--test-scenario only)
└── examples/
    ├── sample-requirement.json
    ├── sample-tier3-change.json
    ├── sample-release-request.json
    ├── sample-gate-denied.json        # Tests gate blocking in protected mode
    ├── sample-retryable-failure.json  # Requires --test-scenario
    ├── sample-terminal-failure.json   # Requires --test-scenario
    └── sample-artifact-invalid.json   # Requires --test-scenario
```

---

## Runtime Data Layout

Each run creates `runtime-data/<run-id>/`:

```
runtime-data/<run-id>/
├── runtime-state.json          # Atomic combined state (workflow state + steps + context)
├── audit-log.jsonl             # Append-only audit events
├── execution-report.json       # Final run report
├── artifact-records.json       # Artifact index
├── artifact-integrity-records.json
├── artifacts/                  # Individual artifact JSON files
├── handoffs.json               # ACP handoff records
├── idempotency.json            # Idempotency cache
├── retry-state.json            # Retry attempt records
├── metrics.json                # Runtime metrics
└── policy-traces/              # OPA evaluation traces (--trace-policies only)
```

---

## Example Commands

**Basic dev run:**
```bash
python ai-sdlc/runtime/orchestrator.py \
  --workflow ai-sdlc/workflows/requirement-to-issue.md \
  --input ai-sdlc/runtime/examples/sample-requirement.json \
  --pretty
```

**Protected profile (gate denial blocks):**
```bash
python ai-sdlc/runtime/orchestrator.py \
  --workflow ai-sdlc/workflows/issue-to-plan.md \
  --input ai-sdlc/runtime/examples/sample-gate-denied.json \
  --branch-profile protected \
  --pretty
```
Expected: exits with code 1; `state: failed`; `block_reason` set.

**Protected profile with approved gates:**
```bash
python ai-sdlc/runtime/orchestrator.py \
  --workflow ai-sdlc/workflows/issue-to-plan.md \
  --input ai-sdlc/runtime/examples/sample-tier3-change.json \
  --branch-profile protected \
  --pretty
```

**Resume a partially completed run:**
```bash
python ai-sdlc/runtime/orchestrator.py \
  --resume <run-id> \
  --pretty
```

**Retry scenario (test harness — not production):**
```bash
python ai-sdlc/runtime/orchestrator.py \
  --workflow ai-sdlc/workflows/requirement-to-issue.md \
  --input ai-sdlc/runtime/examples/sample-retryable-failure.json \
  --max-retries 2 \
  --test-scenario \
  --pretty
```

**With OPA policy evaluation:**
```bash
python ai-sdlc/runtime/orchestrator.py \
  --workflow ai-sdlc/workflows/requirement-to-issue.md \
  --input ai-sdlc/runtime/examples/sample-requirement.json \
  --opa-path ai-sdlc/tools/bin/opa \
  --trace-policies \
  --pretty
```

---

## Extending the Runtime

**Add a real adapter:**
1. Create `adapters/real_issue_tracker.py` implementing the same interface as `MockIssueTracker`.
2. Import and instantiate it in `orchestrator.py` replacing `MockIssueTracker`.
3. Add rollback method to `compensation_engine.compensate_create_issue`.

**Add a new executor:**
1. Add a function `my_action(ctx: Dict[str, Any]) -> Dict[str, Any]` in `step_executors.py`.
2. Register it in `StepExecutorRegistry._registry["my_action"] = my_action`.
3. Add `action_key: my_action` to the relevant workflow's `executable_steps`.

**Add a new workflow:**
1. Copy a workflow markdown file; update the YAML header fields.
2. Add `executable_steps` mapping each step number to an `action_key`.
3. Run with `--workflow path/to/new-workflow.md`.

---

## Known Limitations

- Single-process, sequential — not suitable for concurrent workflow execution.
- Flat filesystem storage — `runtime-data/` grows without bound; add pruning.
- Idempotency is per-run unless a stable `correlation_id` is supplied.
- Compensation handlers are stubs — no real reversals until adapters implement rollback.
- OPA is invoked via subprocess (2 calls per policy check); use OPA server for production load.
- `workflow_id` in handoff envelope must match `^WF-[A-Z]+-[0-9]{3}$` — custom IDs may fail schema validation.
