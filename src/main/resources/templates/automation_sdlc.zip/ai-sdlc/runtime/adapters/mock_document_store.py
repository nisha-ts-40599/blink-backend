from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any, Dict


class MockDocumentStore:
    def __init__(self, run_dir: Path) -> None:
        self.path = run_dir / "mock-docs.json"
        self.docs: Dict[str, Dict[str, Any]] = {}

    def upsert_doc(self, title: str, content: Dict[str, Any]) -> Dict[str, Any]:
        doc_id = f"DOC-{str(uuid.uuid4())[:8]}"
        rec = {"doc_id": doc_id, "title": title, "content": content}
        self.docs[doc_id] = rec
        self._flush()
        return rec

    def _flush(self) -> None:
        with self.path.open("w", encoding="utf-8") as f:
            json.dump(self.docs, f, indent=2)

