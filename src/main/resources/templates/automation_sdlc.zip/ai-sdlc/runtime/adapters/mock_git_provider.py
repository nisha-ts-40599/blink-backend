from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any, Dict


class MockGitProvider:
    def __init__(self, run_dir: Path) -> None:
        self.path = run_dir / "mock-prs.json"
        self.prs: Dict[str, Dict[str, Any]] = {}

    def create_pr(self, branch: str, title: str) -> Dict[str, Any]:
        pr_id = f"PR-{str(uuid.uuid4())[:8]}"
        rec = {"pr_id": pr_id, "branch": branch, "title": title, "status": "open"}
        self.prs[pr_id] = rec
        self._flush()
        return rec

    def _flush(self) -> None:
        with self.path.open("w", encoding="utf-8") as f:
            json.dump(self.prs, f, indent=2)

