from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any, Dict


class MockIssueTracker:
    def __init__(self, run_dir: Path) -> None:
        self.path = run_dir / "mock-issues.json"
        self.issues: Dict[str, Dict[str, Any]] = {}

    def create_issue(self, title: str, body: Dict[str, Any]) -> Dict[str, Any]:
        issue_id = f"ISSUE-{str(uuid.uuid4())[:8]}"
        rec = {"issue_id": issue_id, "title": title, "body": body, "status": "open"}
        self.issues[issue_id] = rec
        self._flush()
        return rec

    def _flush(self) -> None:
        with self.path.open("w", encoding="utf-8") as f:
            json.dump(self.issues, f, indent=2)

