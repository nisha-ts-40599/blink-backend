from __future__ import annotations

from typing import Dict, List

try:
    from .exceptions import ApprovalError
except ImportError:  # script-mode fallback
    from exceptions import ApprovalError


class ApprovalEngine:
    def __init__(self, branch_profile: str) -> None:
        self.branch_profile = branch_profile

    def check(self, gate_ids: List[str], input_approvals: Dict[str, str]) -> Dict[str, str]:
        result: Dict[str, str] = {}
        for gate in gate_ids:
            if self.branch_profile == "dev":
                result[gate] = input_approvals.get(gate, "simulated-approved")
                continue
            status = input_approvals.get(gate, "missing")
            if status != "approved":
                raise ApprovalError(f"Gate {gate} not approved (status={status})")
            result[gate] = status
        return result

