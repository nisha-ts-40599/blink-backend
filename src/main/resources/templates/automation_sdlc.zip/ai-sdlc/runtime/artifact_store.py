from __future__ import annotations

import json
import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

import yaml
from jsonschema import Draft202012Validator

try:
    from .exceptions import ArtifactValidationError
except ImportError:
    from exceptions import ArtifactValidationError


class ArtifactStore:
    def __init__(self, run_dir: Path, repo_root: Path) -> None:
        self.repo_root = repo_root
        self.dir = run_dir / "artifacts"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.index_path = run_dir / "artifact-records.json"
        self._index: Dict[str, Dict[str, Any]] = {}
        self.integrity_path = run_dir / "artifact-integrity-records.json"
        self._integrity: Dict[str, Dict[str, Any]] = {}
        self._schema_registry = self._load_schema_registry()

    def put(self, artifact_id: str, payload: Dict[str, Any], state: str = "produced", schema_key: str = "artifact_integrity") -> Dict[str, Any]:
        payload_bytes = json.dumps(payload, sort_keys=True).encode("utf-8")
        digest = hashlib.sha256(payload_bytes).hexdigest()
        integrity_record = {
            "artifact_id": artifact_id,
            "artifact_type": schema_key,
            "digest_algorithm": "sha256",
            "digest": digest,
            "signature_required": False,
            "signature_status": "not_required",
            "signer": None,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._validate_integrity(integrity_record)
        rec = {
            "artifact_id": artifact_id,
            "state": state,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "path": str((self.dir / f"{artifact_id}.json").as_posix()),
            "schema_key": schema_key,
            "integrity_digest": digest,
        }
        with (self.dir / f"{artifact_id}.json").open("w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        self._index[artifact_id] = rec
        self._integrity[artifact_id] = integrity_record
        self._flush()
        return rec

    def get_index(self) -> Dict[str, Dict[str, Any]]:
        return self._index

    def _flush(self) -> None:
        with self.index_path.open("w", encoding="utf-8") as f:
            json.dump(self._index, f, indent=2)
        with self.integrity_path.open("w", encoding="utf-8") as f:
            json.dump(self._integrity, f, indent=2)

    def _load_schema_registry(self) -> Dict[str, Any]:
        path = self.repo_root / "ai-sdlc" / "schemas" / "schema-registry.yaml"
        with path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f)

    def _validate_integrity(self, integrity_record: Dict[str, Any]) -> None:
        rel_path = self._schema_registry["registry"]["governance"]["artifact_integrity"]
        schema_path = self.repo_root / rel_path
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        validator = Draft202012Validator(schema)
        errors = [e.message for e in validator.iter_errors(integrity_record)]
        if errors:
            raise ArtifactValidationError(f"Artifact integrity schema validation failed: {'; '.join(errors)}")
