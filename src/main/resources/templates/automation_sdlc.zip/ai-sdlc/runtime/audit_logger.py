from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


class AuditLogger:
    """Append-only JSONL audit logger.

    Every emitted record includes the ``run_id`` so logs from multiple
    resumed runs in the same ``run_dir`` can be unambiguously attributed.
    """

    def __init__(self, run_dir: Path, run_id: str = "") -> None:
        self.path = run_dir / "audit-log.jsonl"
        self.run_id = run_id

    def emit(self, event_id: str, event_type: str, payload: Dict[str, Any]) -> None:
        rec = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "run_id": self.run_id,
            "event_id": event_id,
            "event_type": event_type,
            "payload": payload,
        }
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
