"""Compensation engine for ai-sdlc runtime.

IMPORTANT — MOCK/STUB STATUS:
These compensation handlers record the intent to compensate and emit audit events,
but they do NOT perform real reversals.  They write a local JSON artifact
stating that compensation was requested.

Until real adapters implement rollback methods (e.g. ``issues.close_issue()``,
``git.close_pr()``), compensation is audit-logging only, not operational reversal.

When adding a real adapter, add the rollback call here AND pass the adapter
reference in the compensation context dict from orchestrator.py.
"""
from __future__ import annotations

from typing import Any, Callable, Dict

try:
    from .exceptions import CompensationError
except ImportError:
    from exceptions import CompensationError


CompFn = Callable[[Dict[str, Any]], Dict[str, Any]]


def compensate_create_issue(ctx: Dict[str, Any]) -> Dict[str, Any]:
    rec = ctx["artifact_store"].put(
        f"{ctx['step_id']}_compensation_issue",
        {"status": "compensated", "action": "create_issue", "reason": ctx["reason"]},
    )
    ctx["audit_logger"].emit("AUD-COMP-ISSUE-001", "compensation.create_issue", {"artifact_id": rec["artifact_id"]})
    return {"status": "completed", "artifact_id": rec["artifact_id"]}


def compensate_create_pr(ctx: Dict[str, Any]) -> Dict[str, Any]:
    rec = ctx["artifact_store"].put(
        f"{ctx['step_id']}_compensation_pr",
        {"status": "compensated", "action": "create_pr", "reason": ctx["reason"]},
    )
    ctx["audit_logger"].emit("AUD-COMP-PR-001", "compensation.create_pr", {"artifact_id": rec["artifact_id"]})
    return {"status": "completed", "artifact_id": rec["artifact_id"]}


def compensate_create_or_update_documentation(ctx: Dict[str, Any]) -> Dict[str, Any]:
    rec = ctx["artifact_store"].put(
        f"{ctx['step_id']}_compensation_doc",
        {"status": "compensated", "action": "create_or_update_documentation", "reason": ctx["reason"]},
    )
    ctx["audit_logger"].emit("AUD-COMP-DOC-001", "compensation.documentation", {"artifact_id": rec["artifact_id"]})
    return {"status": "completed", "artifact_id": rec["artifact_id"]}


def compensate_noop(ctx: Dict[str, Any]) -> Dict[str, Any]:
    ctx["audit_logger"].emit(
        "AUD-COMP-NOOP-001",
        "compensation.noop",
        {"step_id": ctx["step_id"], "action_key": ctx["action_key"], "reason": ctx["reason"]},
    )
    return {"status": "noop", "artifact_id": None}


class CompensationEngine:
    def __init__(self) -> None:
        self.handlers: Dict[str, CompFn] = {
            "create_issue": compensate_create_issue,
            "create_pr": compensate_create_pr,
            "create_or_update_documentation": compensate_create_or_update_documentation,
        }

    def run(self, action_key: str, context: Dict[str, Any]) -> Dict[str, Any]:
        handler = self.handlers.get(action_key, compensate_noop)
        try:
            return {"handler": handler.__name__, **handler(context)}
        except Exception as e:
            raise CompensationError(str(e)) from e

