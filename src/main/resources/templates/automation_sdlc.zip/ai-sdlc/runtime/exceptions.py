class RuntimeErrorBase(Exception):
    """Base exception for runtime MVP."""


class WorkflowLoadError(RuntimeErrorBase):
    """Workflow file cannot be loaded or parsed."""


class StateTransitionError(RuntimeErrorBase):
    """Workflow transition rejected by policy."""


class ApprovalError(RuntimeErrorBase):
    """Approval gate check failed."""


class PolicyError(RuntimeErrorBase):
    """Policy evaluation error."""


class RetryableRuntimeError(RuntimeErrorBase):
    """Step failed but can be retried deterministically."""


class NonRetryableRuntimeError(RuntimeErrorBase):
    """Step failed and must not be retried."""


class PolicyEnforcementError(NonRetryableRuntimeError):
    """A policy deny decision blocks execution."""


class ArtifactValidationError(NonRetryableRuntimeError):
    """Artifact or handoff failed schema validation."""


class CompensationError(NonRetryableRuntimeError):
    """Compensation execution failed."""


class ResumeStateError(NonRetryableRuntimeError):
    """Resume state is invalid or inconsistent."""

