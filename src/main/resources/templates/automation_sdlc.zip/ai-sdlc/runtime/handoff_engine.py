from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import yaml
from jsonschema import Draft202012Validator

try:
    from .exceptions import ArtifactValidationError
except ImportError:
    from exceptions import ArtifactValidationError


class HandoffEngine:
    def __init__(self, run_dir: Path, repo_root: Path) -> None:
        self.repo_root = repo_root
        self.path = run_dir / "handoffs.json"
        self._handoffs: List[Dict[str, Any]] = []
        self._schema_registry = self._load_schema_registry()

    def emit(
        self,
        correlation_id: str,
        workflow_id: str,
        payload_type: str,
        required_artifacts: List[str],
        produced_artifacts: List[str],
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        now = datetime.now(timezone.utc).isoformat()
        h = {
            "schema_version": "2.0",
            "handoff_id": str(uuid.uuid4()),
            "correlation_id": correlation_id,
            "workflow_id": workflow_id,
            "parent_workflow_id": None,
            "from_agent": "runtime",
            "to_agent": "orchestrator",
            "payload_type": payload_type,
            "payload_schema": f"ai-sdlc.schemas/{payload_type}/v2",
            "status": "completed",
            "retry_count": 0,
            "idempotency_key": f"{workflow_id}:{correlation_id}:{payload_type}",
            "required_artifacts": required_artifacts,
            "produced_artifacts": produced_artifacts,
            "approval_state": {"required": False, "gate_ids": [], "approvals": [], "status": "not_required"},
            "audit_metadata": {
                "event_id": "AUD-HANDOFF-001",
                "actor": "agent:runtime",
                "source_system": "runtime-orchestrator",
                "trace_id": f"trace-{correlation_id}",
            },
            "timestamps": {
                "created_at": now,
                "updated_at": now,
                "due_at": None,
            },
            "error_code": None,
            "escalation_state": {"is_escalated": False, "escalation_id": None, "escalation_reason": None},
            "payload": payload,
        }
        self._validate(h)
        self._handoffs.append(h)
        with self.path.open("w", encoding="utf-8") as f:
            json.dump(self._handoffs, f, indent=2)
        return h

    def list(self) -> List[Dict[str, Any]]:
        return self._handoffs

    def _load_schema_registry(self) -> Dict[str, Any]:
        path = self.repo_root / "ai-sdlc" / "schemas" / "schema-registry.yaml"
        with path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f)

    def _validate(self, handoff: Dict[str, Any]) -> None:
        rel_path = self._schema_registry["registry"]["envelope"]["handoff_envelope"]
        schema_path = self.repo_root / rel_path
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        validator = Draft202012Validator(schema)
        errors = [e.message for e in validator.iter_errors(handoff)]
        if errors:
            raise ArtifactValidationError(f"Handoff envelope schema validation failed: {'; '.join(errors)}")

