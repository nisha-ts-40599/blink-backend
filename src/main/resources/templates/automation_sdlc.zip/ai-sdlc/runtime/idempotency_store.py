from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


class IdempotencyStore:
    def __init__(self, run_dir: Path) -> None:
        self.path = run_dir / "idempotency.json"
        if self.path.exists():
            self.records: Dict[str, Dict[str, Any]] = json.loads(self.path.read_text(encoding="utf-8"))
        else:
            self.records = {}

    def get(self, key: str) -> Optional[Dict[str, Any]]:
        return self.records.get(key)

    def put(self, key: str, step_id: str, action_key: str, result_artifacts: list[str], result: Dict[str, Any]) -> Dict[str, Any]:
        rec = {
            "idempotency_key": key,
            "step_id": step_id,
            "action_key": action_key,
            "result_artifacts": result_artifacts,
            "result": result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self.records[key] = rec
        self._flush()
        return rec

    def _flush(self) -> None:
        with self.path.open("w", encoding="utf-8") as f:
            json.dump(self.records, f, indent=2)

