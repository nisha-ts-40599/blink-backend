from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict


class RuntimeMetrics:
    def __init__(self, run_dir: Path) -> None:
        self.path = run_dir / "metrics.json"
        self.started_at = time.perf_counter()
        self.data: Dict[str, Any] = {
            "workflow_duration_seconds": 0.0,
            "per_step_duration_seconds": {},
            "retry_counts": {},
            "compensation_counts": 0,
            "policy_evaluation_duration_seconds": 0.0,
            "artifact_counts": 0,
            "handoff_counts": 0,
            "warning_counts": 0,
            "failure_counts": 0,
        }

    def step_timing(self, step_id: str, elapsed: float) -> None:
        self.data["per_step_duration_seconds"][step_id] = round(elapsed, 6)

    def add_retry(self, step_id: str, retry_count: int) -> None:
        self.data["retry_counts"][step_id] = retry_count

    def add_policy_time(self, elapsed: float) -> None:
        self.data["policy_evaluation_duration_seconds"] = round(
            self.data["policy_evaluation_duration_seconds"] + elapsed,
            6,
        )

    def inc(self, key: str, n: int = 1) -> None:
        self.data[key] = int(self.data.get(key, 0)) + n

    def finalize(self) -> Dict[str, Any]:
        self.data["workflow_duration_seconds"] = round(time.perf_counter() - self.started_at, 6)
        self.path.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
        return self.data

