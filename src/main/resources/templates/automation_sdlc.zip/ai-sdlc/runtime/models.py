from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal


@dataclass
class WorkflowStep:
    step_id: str
    step_text: str
    action_key: str
    # "explicit" = came from executable_steps YAML header
    # "inferred" = derived by normalize_step_action regex fallback (warns at runtime)
    # "noop"     = explicitly declared as no-op in executable_steps
    action_key_source: Literal["explicit", "inferred", "noop"] = "inferred"


@dataclass
class WorkflowDefinition:
    workflow_id: str
    workflow_name: str
    owner_agent: str
    approval_gates: List[Dict[str, Any]]
    produced_artifacts: List[str]
    required_artifacts: List[str]
    steps: List[WorkflowStep]
    raw_header: Dict[str, Any]


@dataclass
class ExecutionContext:
    run_id: str
    branch_profile: str
    strict: bool
    require_opa: bool
    workflow_file: str
    input_payload: Dict[str, Any]
    current_state: str = "created"
    approvals: Dict[str, str] = field(default_factory=dict)
    artifacts: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    handoffs: List[Dict[str, Any]] = field(default_factory=list)
    policy_decisions: List[Dict[str, Any]] = field(default_factory=list)
