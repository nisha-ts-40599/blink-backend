"""AI-SDLC runtime orchestrator v0.4 (stabilization pass).

IMPORTANT — Reference implementation only.

This orchestrator is a local demonstration of the AI-SDLC workflow execution model.
It is not a production system and should not be used as one.

Operational boundaries:
- All step executors perform ``noop`` operations; no real work is executed.
- All adapters (issue tracker, git provider, document store) are mocks that write
  to local JSON files. No external API calls are made.
- The approval engine returns ``simulated-approved`` for all gates in dev profile.
- This runtime has no connection to any CI system, deployment pipeline, or
  production environment.
- Do not connect this runtime to real external systems.

Intended use: explore the framework's orchestration model and observe its behavior
locally. For real AI-assisted development, use the prompts, workflows, governance
documents, and conformance tooling in ai-sdlc/.

Changes from v0.3:
- Gate enforcement: ``validate_approval_gate`` now raises ``PolicyEnforcementError``
  in protected/strict mode; dev mode emits advisory warnings only.
- Atomic state persistence: single ``runtime-state.json`` written via temp+rename.
- Failed-state persistence: ``failed`` state is persisted with audit event.
- Compensation exception handling: ``CompensationError`` is caught and recorded
  without aborting report generation.
- Explicit action_key support: workflow ``executable_steps`` used preferentially;
  prose inference is a fallback.
- ``correlation_id`` hardening: auto-generated if absent; required in protected mode.
- Idempotency key uses step_text hash rather than positional step_id to survive
  workflow file edits.
- ``--test-scenario``: activates failure-injection harness (not for production).
- Removed ``evaluate_rego_if_available`` (dead code).
- Audit events include ``run_id`` per record.
- ``run.ended`` audit event replaces ``run.completed``; carries actual state.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

if __package__ in (None, ""):
    _runtime_dir = os.path.dirname(os.path.abspath(__file__))
    _adapters_dir = os.path.join(_runtime_dir, "adapters")
    if _runtime_dir not in sys.path:
        sys.path.insert(0, _runtime_dir)
    if _adapters_dir not in sys.path:
        sys.path.insert(0, _adapters_dir)
    from mock_document_store import MockDocumentStore
    from mock_git_provider import MockGitProvider
    from mock_issue_tracker import MockIssueTracker
    from approval_engine import ApprovalEngine
    from artifact_store import ArtifactStore
    from audit_logger import AuditLogger
    from compensation_engine import CompensationEngine
    from exceptions import (
        ApprovalError,
        ArtifactValidationError,
        NonRetryableRuntimeError,
        PolicyEnforcementError,
        ResumeStateError,
        StateTransitionError,
        WorkflowLoadError,
    )
    from handoff_engine import HandoffEngine
    from idempotency_store import IdempotencyStore
    from metrics import RuntimeMetrics
    from models import ExecutionContext
    from policy_engine import PolicyEngine
    from retry_engine import RetryEngine
    from step_executors import StepExecutorRegistry
    from workflow_engine import WorkflowEngine
else:
    from .adapters.mock_document_store import MockDocumentStore
    from .adapters.mock_git_provider import MockGitProvider
    from .adapters.mock_issue_tracker import MockIssueTracker
    from .approval_engine import ApprovalEngine
    from .artifact_store import ArtifactStore
    from .audit_logger import AuditLogger
    from .compensation_engine import CompensationEngine
    from .exceptions import (
        ApprovalError,
        ArtifactValidationError,
        NonRetryableRuntimeError,
        PolicyEnforcementError,
        ResumeStateError,
        StateTransitionError,
        WorkflowLoadError,
    )
    from .handoff_engine import HandoffEngine
    from .idempotency_store import IdempotencyStore
    from .metrics import RuntimeMetrics
    from .models import ExecutionContext
    from .policy_engine import PolicyEngine
    from .retry_engine import RetryEngine
    from .step_executors import StepExecutorRegistry
    from .workflow_engine import WorkflowEngine


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="AI-SDLC runtime orchestrator v0.4")
    p.add_argument("--workflow", help="Path to workflow markdown")
    p.add_argument("--input", help="Path to input JSON")
    p.add_argument("--branch-profile", choices=["dev", "protected"], default="dev")
    p.add_argument("--strict", action="store_true", help="Treat dev-mode advisory warnings as failures")
    p.add_argument("--require-opa", action="store_true")
    p.add_argument("--opa-path", default="", help="Path to OPA binary")
    p.add_argument("--pretty", action="store_true")
    p.add_argument("--output", default="")
    p.add_argument("--resume", default="", help="Resume existing run-id from runtime-data/<run-id>")
    p.add_argument("--force-resume", action="store_true", help="Allow resume even when input payload differs")
    p.add_argument("--preflight-conformance", action="store_true", help="Run conformance checks before workflow execution")
    p.add_argument("--max-retries", type=int, default=0, help="Additional retries per step beyond first attempt")
    p.add_argument("--retry-delay", type=float, default=0.0, help="Base retry delay in seconds (exponential backoff)")
    p.add_argument("--disable-compensation", action="store_true", help="Disable compensation hooks on step failure")
    p.add_argument("--metrics", action="store_true", help="Show metrics summary in pretty output")
    p.add_argument("--trace-policies", action="store_true", help="Persist OPA policy trace artifacts")
    p.add_argument(
        "--test-scenario",
        action="store_true",
        help="Activate failure-injection harness for demo/test scenarios. "
             "Reads 'failure_injection' and 'force_invalid_artifact_on' from input payload. "
             "NOT for production use.",
    )
    return p.parse_args()


def _resolve_correlation_id(input_payload: Dict[str, Any], workflow_path: str, branch_profile: str) -> tuple[str, Dict[str, Any], bool]:
    """Return (correlation_id, updated_payload, was_auto_generated)."""
    correlation_id = input_payload.get("correlation_id")
    if correlation_id:
        return str(correlation_id), input_payload, False

    if branch_profile == "protected":
        raise WorkflowLoadError(
            "correlation_id is required in protected profile. "
            "Supply a stable identifier to enable cross-run idempotency tracking."
        )

    # Dev profile: auto-generate a stable hash from workflow + payload content
    payload_hash = hashlib.sha256(
        json.dumps({"wf": workflow_path, "payload": input_payload}, sort_keys=True).encode()
    ).hexdigest()[:16]
    correlation_id = f"AUTO-{payload_hash}"
    updated = {**input_payload, "correlation_id": correlation_id}
    return correlation_id, updated, True


def transition_or_fail(ctx: ExecutionContext, policy: PolicyEngine, to_state: str) -> Dict[str, Any]:
    decision = policy.validate_transition(ctx.current_state, to_state)
    if not decision["allowed"]:
        raise StateTransitionError(f"Transition {ctx.current_state} -> {to_state} denied: {decision.get('deny_reasons')}")
    ctx.current_state = to_state
    return decision


# ---------------------------------------------------------------------------
# Atomic state persistence
# ---------------------------------------------------------------------------

def _persist_state(run_dir: Path, workflow_state: Dict[str, Any], step_results: List[Dict[str, Any]], request_context: Dict[str, Any]) -> None:
    """Write a single combined runtime-state.json atomically via temp+rename.

    This replaces the former three-file approach and eliminates the window where
    a crash could leave ``workflow-state.json`` and ``step-results.json`` out of
    sync.  The old individual files are no longer written; resume reads only
    ``runtime-state.json``.
    """
    combined = {
        "workflow_state": workflow_state,
        "step_results": step_results,
        "request_context": request_context,
    }
    tmp = run_dir / "runtime-state.json.tmp"
    tmp.write_text(json.dumps(combined, indent=2), encoding="utf-8")
    tmp.rename(run_dir / "runtime-state.json")


def _load_prior_state(run_dir: Path) -> Optional[Dict[str, Any]]:
    """Load combined state file; fall back to legacy individual files for backward compat."""
    combined_path = run_dir / "runtime-state.json"
    if combined_path.exists():
        try:
            return json.loads(combined_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ResumeStateError(f"runtime-state.json is corrupt: {exc}") from exc

    # Legacy fallback (pre-v0.4 runs)
    legacy_state_path = run_dir / "workflow-state.json"
    legacy_steps_path = run_dir / "step-results.json"
    legacy_ctx_path = run_dir / "request-context.json"
    if legacy_state_path.exists():
        try:
            return {
                "workflow_state": json.loads(legacy_state_path.read_text(encoding="utf-8")),
                "step_results": json.loads(legacy_steps_path.read_text(encoding="utf-8")) if legacy_steps_path.exists() else [],
                "request_context": json.loads(legacy_ctx_path.read_text(encoding="utf-8")) if legacy_ctx_path.exists() else {},
            }
        except json.JSONDecodeError as exc:
            raise ResumeStateError(f"Legacy state files are corrupt: {exc}") from exc
    return None


# ---------------------------------------------------------------------------
# Preflight conformance
# ---------------------------------------------------------------------------

def _run_preflight(repo_root: Path, branch_profile: str, run_id: str) -> Dict[str, Any]:
    report_rel = f"ai-sdlc/tests/results/preflight-{run_id}.json"
    cmd = [
        sys.executable,
        str(repo_root / "ai-sdlc" / "tools" / "conformance-runner" / "run_conformance.py"),
        "--branch-profile",
        branch_profile,
        "--output",
        report_rel,
    ]
    if branch_profile == "protected":
        cmd.append("--strict")
    proc = subprocess.run(cmd, cwd=str(repo_root), stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    report_path = repo_root / report_rel
    preflight_report: Dict[str, Any] = {}
    if report_path.exists():
        try:
            preflight_report = json.loads(report_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    warnings: List[str] = []
    if branch_profile == "dev":
        skipped_opa = [
            t.get("test_id")
            for t in preflight_report.get("tests", [])
            if any(i.get("code") == "OPA_MISSING" for i in t.get("issues", []))
        ]
        if skipped_opa:
            warnings.append(f"OPA-required tests skipped in dev profile: {', '.join(filter(None, skipped_opa))}")
    return {
        "status": "passed" if proc.returncode == 0 else "failed",
        "return_code": proc.returncode,
        "report_path": str(report_path),
        "stdout": proc.stdout.decode("utf-8", errors="replace"),
        "stderr": proc.stderr.decode("utf-8", errors="replace"),
        "warnings": warnings,
    }


# ---------------------------------------------------------------------------
# Main run function
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> Dict[str, Any]:  # noqa: C901 — intentionally large; decompose in a future pass
    repo_root = Path(__file__).resolve().parents[2]

    if not args.resume and (not args.workflow or not args.input):
        raise WorkflowLoadError("--workflow and --input are required when not using --resume")

    resumed = bool(args.resume)
    run_id = args.resume if args.resume else datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + str(uuid.uuid4())[:8]
    run_dir = repo_root / "runtime-data" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    prior_state: Optional[Dict[str, Any]] = _load_prior_state(run_dir) if resumed else None
    prior_request: Dict[str, Any] = (prior_state or {}).get("request_context", {})
    prior_wf_state: Dict[str, Any] = (prior_state or {}).get("workflow_state", {})
    prior_step_results: List[Dict[str, Any]] = (prior_state or {}).get("step_results", [])

    if args.input:
        input_payload: Dict[str, Any] = json.loads(Path(args.input).read_text(encoding="utf-8"))
    elif prior_request.get("input_payload"):
        input_payload = prior_request["input_payload"]
    else:
        raise WorkflowLoadError("Input payload missing and no prior request context found")

    workflow_path_str = args.workflow or prior_request.get("workflow_file")
    if not workflow_path_str:
        raise WorkflowLoadError("Workflow path missing and no prior request context found")

    if resumed and prior_request.get("input_payload") and prior_request["input_payload"] != input_payload and not args.force_resume:
        raise ResumeStateError("Resume input differs from original; use --force-resume to continue")

    # Correlation ID resolution (fix7)
    correlation_id, input_payload, auto_corr = _resolve_correlation_id(
        input_payload, workflow_path_str, args.branch_profile
    )

    # Audit logger — run_id included in every record
    audit = AuditLogger(run_dir, run_id)
    if auto_corr:
        audit.emit("AUD-CORR-AUTO-001", "correlation.auto_generated", {"correlation_id": correlation_id})

    # Test scenario harness (fix5)
    if args.test_scenario:
        _runtime_dir = os.path.dirname(os.path.abspath(__file__))
        _tests_dir = os.path.join(_runtime_dir, "tests")
        if _tests_dir not in sys.path:
            sys.path.insert(0, _tests_dir)
        try:
            if __package__ in (None, ""):
                import importlib.util as _ilu
                _spec = _ilu.spec_from_file_location("scenario_helpers", os.path.join(_tests_dir, "scenario_helpers.py"))
                _mod = _ilu.module_from_spec(_spec)
                _spec.loader.exec_module(_mod)
                scenario_helpers = _mod
            else:
                from .tests import scenario_helpers
            audit.emit("AUD-SCENARIO-001", "scenario.harness_active", {"warning": "Test scenario harness is active — not for production use"})
        except Exception as exc:
            raise WorkflowLoadError(f"Could not load scenario_helpers: {exc}") from exc
    else:
        scenario_helpers = None  # type: ignore[assignment]

    ctx = ExecutionContext(
        run_id=run_id,
        branch_profile=args.branch_profile,
        strict=args.strict,
        require_opa=args.require_opa,
        workflow_file=workflow_path_str,
        input_payload=input_payload,
    )
    if prior_wf_state:
        ctx.current_state = prior_wf_state.get("current_state", "created")

    workflow_engine = WorkflowEngine(repo_root)
    policy_engine = PolicyEngine(
        repo_root,
        args.branch_profile,
        require_opa=args.require_opa,
        opa_path=args.opa_path,
        run_dir=run_dir,
        trace_policies=args.trace_policies,
    )
    approval_engine = ApprovalEngine(args.branch_profile)

    # Artifact store: use corrupting variant when --test-scenario is active
    if scenario_helpers is not None:
        artifact_store = scenario_helpers.make_scenario_artifact_store(run_dir, repo_root, input_payload)
    else:
        artifact_store = ArtifactStore(run_dir, repo_root)

    handoff = HandoffEngine(run_dir, repo_root)
    idempotency = IdempotencyStore(run_dir)
    retry_engine = RetryEngine(run_dir, max_attempts=max(1, args.max_retries + 1), retry_delay_seconds=args.retry_delay)
    compensation_engine = CompensationEngine()
    metrics = RuntimeMetrics(run_dir)
    executors = StepExecutorRegistry()
    issues = MockIssueTracker(run_dir)
    git = MockGitProvider(run_dir)
    docs = MockDocumentStore(run_dir)
    adapters = {"issues": issues, "git": git, "docs": docs}

    wf = workflow_engine.load(Path(workflow_path_str))
    step_results: List[Dict[str, Any]] = list(prior_step_results)
    completed_step_ids = {r["step_id"] for r in step_results if r.get("status") in ("completed", "cached")}

    request_context = {
        "workflow_file": workflow_path_str,
        "input_payload": input_payload,
        "branch_profile": args.branch_profile,
    }

    _persist_state(run_dir, {"current_state": ctx.current_state, "workflow_id": wf.workflow_id}, step_results, request_context)
    audit.emit("AUD-RUN-START-001", "run.started", {"run_id": run_id, "workflow_id": wf.workflow_id, "resumed": resumed, "correlation_id": correlation_id})

    validation_errors: List[Dict[str, Any]] = []
    compensation_results: List[Dict[str, Any]] = []
    governance_warnings: List[str] = []
    run_error: Optional[str] = None
    block_reason: Optional[str] = None  # set when failure is a policy/gate denial

    # Preflight conformance
    preflight = None
    if args.preflight_conformance:
        preflight = _run_preflight(repo_root, args.branch_profile, run_id)
        audit.emit("AUD-PREFLIGHT-001", "preflight.conformance", preflight)
        if args.branch_profile == "protected" and preflight["status"] != "passed":
            run_error = "Protected profile requires successful strict preflight conformance"

    # Resume adjustment
    pending_steps_exist = len(completed_step_ids) < len(wf.steps)
    if resumed and ctx.current_state == "completed" and pending_steps_exist:
        ctx.current_state = "in_progress"
        audit.emit("AUD-WF-RESUME-001", "workflow.resume_adjusted", {"reason": "completed_state_with_pending_steps"})
        _persist_state(run_dir, {"current_state": ctx.current_state, "workflow_id": wf.workflow_id}, step_results, request_context)

    # State transitions: created → ready → in_progress
    if not run_error and ctx.current_state == "created":
        try:
            ctx.policy_decisions.append(transition_or_fail(ctx, policy_engine, "ready"))
            audit.emit("AUD-WF-STATE-001", "workflow.state", {"state": ctx.current_state})
            _persist_state(run_dir, {"current_state": ctx.current_state, "workflow_id": wf.workflow_id}, step_results, request_context)
        except StateTransitionError as exc:
            run_error = str(exc)
    if not run_error and ctx.current_state == "ready":
        try:
            ctx.policy_decisions.append(transition_or_fail(ctx, policy_engine, "in_progress"))
            audit.emit("AUD-WF-STATE-001", "workflow.state", {"state": ctx.current_state})
            _persist_state(run_dir, {"current_state": ctx.current_state, "workflow_id": wf.workflow_id}, step_results, request_context)
        except StateTransitionError as exc:
            run_error = str(exc)

    # Action-class policy check from input payload
    if not run_error:
        requested_action_class = input_payload.get("requested_action_class")
        if requested_action_class:
            t0 = time.perf_counter()
            action_decision = policy_engine.check_action_class(
                requested_action_class,
                human_approved=all(v == "approved" for v in input_payload.get("approvals", {}).values()) if input_payload.get("approvals") else False,
                approval_token_valid=bool(input_payload.get("approval_token_valid", False)),
                break_glass=bool(input_payload.get("break_glass", False)),
                emergency_stop=bool(input_payload.get("emergency_stop", False)),
            )
            metrics.add_policy_time(time.perf_counter() - t0)
            ctx.policy_decisions.append(action_decision)
            audit.emit("AUD-POLICY-001", "policy.decision", action_decision)
            if not action_decision["allowed"]:
                run_error = f"Requested action class blocked: {requested_action_class}"
                block_reason = f"action_class_denied:{requested_action_class}"

    # Approval gate pre-check
    if not run_error:
        gate_ids = [g.get("gate_id") for g in wf.approval_gates]
        if gate_ids:
            try:
                ctx.approvals = approval_engine.check(gate_ids, input_payload.get("approvals", {}))
                audit.emit("AUD-GATE-APPROVAL-001", "gate.approved", {"gates": ctx.approvals})
            except ApprovalError as e:
                run_error = str(e)
                block_reason = "approval_gate_denied"
                audit.emit("AUD-GATE-FAILED-001", "gate.failed", {"error": str(e)})

    # Warn about steps using inferred action_keys (not from executable_steps)
    if not run_error:
        inferred_steps = [s for s in wf.steps if s.action_key_source == "inferred"]
        if inferred_steps:
            warn_msg = (
                f"Workflow '{wf.workflow_id}' is missing 'executable_steps' in its YAML header "
                f"or step counts do not match. "
                f"Action keys for {len(inferred_steps)} step(s) are inferred from prose (fragile). "
                f"Add explicit 'executable_steps' to the workflow YAML header for reliable execution."
            )
            audit.emit("AUD-WORKFLOW-WARN-001", "workflow.inferred_action_keys", {"workflow_id": wf.workflow_id, "inferred_count": len(inferred_steps)})
            governance_warnings.append(warn_msg)

    # Step execution loop
    for step in wf.steps:
        if run_error:
            break
        if resumed and step.step_id in completed_step_ids:
            continue

        # Fail fast on unknown action_key in protected mode
        if step.action_key not in ("noop", "default_noop_executor") and not executors.is_known(step.action_key):
            if args.branch_profile == "protected" or args.strict:
                run_error = f"Unknown action_key '{step.action_key}' on step {step.step_id} in protected mode"
                block_reason = "unknown_action_key"
                break
            else:
                governance_warnings.append(f"Unknown action_key '{step.action_key}' on step {step.step_id}; using noop in dev mode")

        audit.emit("AUD-WF-STEP-001", "workflow.step", {
            "step_id": step.step_id,
            "step_text": step.step_text,
            "action_key": step.action_key,
            "action_key_source": step.action_key_source,
        })

        # Idempotency key uses step_text hash for resilience to workflow file edits
        step_text_hash = hashlib.sha256(step.step_text.lower().encode()).hexdigest()[:8]
        idempotency_key = f"{wf.workflow_id}:{step.step_id}:{step_text_hash}:{correlation_id}"
        cached = idempotency.get(idempotency_key)
        if cached:
            step_result: Dict[str, Any] = {
                "step_id": step.step_id,
                "step_text": step.step_text,
                "action_key": step.action_key,
                "action_key_source": step.action_key_source,
                "executor_name": "idempotency_cache",
                "status": "cached",
                "artifacts_produced": cached.get("result_artifacts", []),
                "audit_events": [],
                "warnings": ["Step reused from idempotency cache"],
                "idempotency_key": idempotency_key,
                "idempotency_cache_hit": True,
            }
            step_results.append(step_result)
            _persist_state(run_dir, {"current_state": ctx.current_state, "workflow_id": wf.workflow_id}, step_results, request_context)
            continue

        executor = executors.resolve(step.action_key)
        # Wrap with scenario harness if active
        if scenario_helpers is not None:
            executor = scenario_helpers.wrap_executor_with_scenario(executor, input_payload)

        executor_name = executor.__name__
        started = time.perf_counter()
        try:
            result = retry_engine.run_step(
                step_id=step.step_id,
                action_key=step.action_key,
                executor=executor,
                context={
                    "run_id": run_id,
                    "workflow": {
                        "workflow_id": wf.workflow_id,
                        "workflow_name": wf.workflow_name,
                        "approval_gates": wf.approval_gates,
                        "required_artifacts": wf.required_artifacts,
                        "produced_artifacts": wf.produced_artifacts,
                    },
                    "step": {
                        "step_id": step.step_id,
                        "step_text": step.step_text,
                        "action_key": step.action_key,
                        "action_key_source": step.action_key_source,
                    },
                    "input_payload": input_payload,
                    "artifact_store": artifact_store,
                    "audit_logger": audit,
                    "handoff_engine": handoff,
                    "policy_engine": policy_engine,
                    "adapters": adapters,
                    "branch_profile": args.branch_profile,
                    "strict": args.strict,
                },
            )
        except Exception as exc:
            metrics.inc("failure_counts")
            if isinstance(exc, PolicyEnforcementError):
                block_reason = str(exc)
                audit.emit("AUD-GATE-BLOCKED-001", "gate.blocked", {"step_id": step.step_id, "reason": str(exc)})
            if isinstance(exc, ArtifactValidationError):
                validation_errors.append({"type": "artifact", "step_id": step.step_id, "error": str(exc)})
                audit.emit("AUD-ARTIFACT-VALIDATION-ERR-001", "artifact.validation_failed", {"step_id": step.step_id, "error": str(exc)})

            # Compensation (fix6): wrap so CompensationError does not abort report generation
            if not args.disable_compensation and not isinstance(exc, PolicyEnforcementError):
                try:
                    comp = compensation_engine.run(
                        step.action_key,
                        {
                            "step_id": step.step_id,
                            "action_key": step.action_key,
                            "reason": str(exc),
                            "artifact_store": artifact_store,
                            "audit_logger": audit,
                        },
                    )
                    compensation_results.append({"step_id": step.step_id, "action_key": step.action_key, **comp})
                    if comp.get("status") == "completed":
                        metrics.inc("compensation_counts")
                except Exception as comp_exc:
                    audit.emit("AUD-COMP-FAILED-001", "compensation.failed", {"step_id": step.step_id, "error": str(comp_exc)})
                    compensation_results.append({
                        "step_id": step.step_id,
                        "action_key": step.action_key,
                        "status": "compensation_failed",
                        "error": str(comp_exc),
                    })

            retry_attempts = retry_engine.state.get("steps", {}).get(step.step_id, {}).get("attempts", [{}])
            step_result = {
                "step_id": step.step_id,
                "step_text": step.step_text,
                "action_key": step.action_key,
                "action_key_source": step.action_key_source,
                "executor_name": executor_name,
                "status": "failed",
                "artifacts_produced": [],
                "audit_events": [],
                "warnings": [str(exc)],
                "idempotency_key": idempotency_key,
                "idempotency_cache_hit": False,
                "retry_metadata": {
                    "attempt_number": retry_attempts[-1].get("attempt_number", 1) if retry_attempts else 1,
                    "retry_count": max(0, len(retry_attempts) - 1),
                    "final_attempt": True,
                    "retry_reason": str(exc),
                },
            }
            metrics.step_timing(step.step_id, time.perf_counter() - started)
            step_results.append(step_result)
            run_error = str(exc)
            break

        # Collect advisory warnings from gate executor
        for w in result.get("warnings", []):
            if "[ADVISORY]" in w:
                governance_warnings.append(w)

        step_result = {
            "step_id": step.step_id,
            "step_text": step.step_text,
            "action_key": step.action_key,
            "action_key_source": step.action_key_source,
            "executor_name": executor_name,
            "status": result.get("status", "completed"),
            "artifacts_produced": result.get("artifacts_produced", []),
            "audit_events": result.get("audit_events", []),
            "warnings": result.get("warnings", []),
            "idempotency_key": idempotency_key,
            "idempotency_cache_hit": False,
            "retry_metadata": result.get("retry_metadata", {"attempt_number": 1, "retry_count": 0, "final_attempt": True, "retry_reason": None}),
        }
        metrics.step_timing(step.step_id, time.perf_counter() - started)
        metrics.add_retry(step.step_id, step_result["retry_metadata"]["retry_count"])
        metrics.inc("warning_counts", len(step_result["warnings"]))
        idempotency.put(
            key=idempotency_key,
            step_id=step.step_id,
            action_key=step.action_key,
            result_artifacts=step_result["artifacts_produced"],
            result=step_result,
        )
        step_results.append(step_result)
        _persist_state(run_dir, {"current_state": ctx.current_state, "workflow_id": wf.workflow_id}, step_results, request_context)

    # Workflow-declared artifact production
    for art in wf.produced_artifacts:
        if run_error:
            break
        try:
            rec = artifact_store.put(art, {"workflow_id": wf.workflow_id, "run_id": run_id, "source": "runtime"})
            ctx.artifacts[art] = rec
            metrics.inc("artifact_counts")
        except ArtifactValidationError as exc:
            validation_errors.append({"type": "artifact", "artifact_id": art, "error": str(exc)})
            audit.emit("AUD-ARTIFACT-VALIDATION-ERR-001", "artifact.validation_failed", {"artifact_id": art, "error": str(exc)})
            run_error = str(exc)
            break

    # ACP handoff
    if not run_error:
        try:
            h = handoff.emit(
                correlation_id=correlation_id,
                workflow_id=wf.workflow_id,
                payload_type="ImplementationResultHandoff",
                required_artifacts=wf.required_artifacts,
                produced_artifacts=wf.produced_artifacts,
                payload={"steps_executed": [s.step_text for s in wf.steps], "state": ctx.current_state},
            )
            ctx.handoffs.append(h)
            metrics.inc("handoff_counts")
            audit.emit("AUD-HANDOFF-001", "handoff.emitted", {"handoff_id": h["handoff_id"]})
        except ArtifactValidationError as exc:
            validation_errors.append({"type": "handoff", "error": str(exc)})
            audit.emit("AUD-HANDOFF-VALIDATION-ERR-001", "handoff.validation_failed", {"error": str(exc)})
            run_error = str(exc)

    # Final state transition and persistence (fix4)
    if run_error:
        ctx.current_state = "failed"
        audit.emit("AUD-WF-STATE-001", "workflow.state", {"state": "failed", "run_error": run_error, "block_reason": block_reason})
        _persist_state(
            run_dir,
            {"current_state": "failed", "workflow_id": wf.workflow_id, "run_error": run_error, "block_reason": block_reason},
            step_results,
            request_context,
        )
    elif ctx.current_state != "completed":
        ctx.policy_decisions.append(transition_or_fail(ctx, policy_engine, "completed"))
        audit.emit("AUD-WF-STATE-001", "workflow.state", {"state": ctx.current_state})
        _persist_state(run_dir, {"current_state": ctx.current_state, "workflow_id": wf.workflow_id}, step_results, request_context)

    metrics.add_policy_time(policy_engine.total_eval_seconds)
    metrics.data["artifact_counts"] = len(artifact_store.get_index())
    metrics.data["handoff_counts"] = len(handoff.list())
    metrics_summary = metrics.finalize()

    report: Dict[str, Any] = {
        "run_id": run_id,
        "workflow_id": wf.workflow_id,
        "workflow_name": wf.workflow_name,
        "owner_agent": wf.owner_agent,
        "state": ctx.current_state,
        "branch_profile": ctx.branch_profile,
        "strict": ctx.strict,
        "require_opa": ctx.require_opa,
        "correlation_id": correlation_id,
        "approvals": ctx.approvals,
        "artifacts": artifact_store.get_index(),
        "handoffs": handoff.list(),
        "policy_decisions": ctx.policy_decisions,
        "step_results": step_results,
        "resumed": resumed,
        "idempotency_cache_entries": len(idempotency.records),
        "runtime_data_dir": str(run_dir),
        "conformance_hint": str(repo_root / "ai-sdlc" / "tests" / "results" / "conformance-report.json"),
        "preflight_conformance": preflight,
        "runtime_config": {
            "max_retries": args.max_retries,
            "retry_delay": args.retry_delay,
            "disable_compensation": args.disable_compensation,
            "trace_policies": args.trace_policies,
            "test_scenario": args.test_scenario,
        },
        "validation_errors": validation_errors,
        "run_error": run_error,
        "block_reason": block_reason,
        "governance_warnings": governance_warnings,
        "compensations": compensation_results,
        "policy_trace_refs": policy_engine.trace_refs,
        "metrics": metrics_summary,
    }

    report_path = Path(args.output) if args.output else (run_dir / "execution-report.json")
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    # Emit run.ended (not run.completed) with actual final state
    audit.emit("AUD-RUN-END-001", "run.ended", {"report_path": str(report_path), "state": ctx.current_state})
    return report


def main() -> int:
    args = parse_args()
    try:
        report = run(args)
        if args.pretty:
            print(json.dumps(report, indent=2))
            retries = sum(v for v in report.get("metrics", {}).get("retry_counts", {}).values())
            print("\n=== Runtime v0.4 Summary ===")
            print(f"State       : {report['state']}")
            print(f"Profile     : {report['branch_profile']}")
            print(f"Correlation : {report['correlation_id']}")
            print(f"Steps       : {len(report.get('step_results', []))}")
            print(f"Retries     : {retries}")
            print(f"Compensations: {len(report.get('compensations', []))}")
            print(f"Warnings    : {report.get('metrics', {}).get('warning_counts', 0)}")
            print(f"Failures    : {report.get('metrics', {}).get('failure_counts', 0)}")
            if report.get("block_reason"):
                print(f"Block reason: {report['block_reason']}")
            if report.get("governance_warnings"):
                print(f"Gov warnings: {len(report['governance_warnings'])}")
                for gw in report["governance_warnings"]:
                    print(f"  - {gw}")
            if args.metrics:
                print(f"Metrics file: {Path(report['runtime_data_dir']) / 'metrics.json'}")
        else:
            print(f"Run {report['run_id']} ended; state={report['state']}")
        return 0 if report.get("state") != "failed" else 1
    except (
        WorkflowLoadError,
        StateTransitionError,
        ApprovalError,
        ResumeStateError,
        NonRetryableRuntimeError,
        ArtifactValidationError,
        PolicyEnforcementError,
    ) as exc:
        print(f"Runtime failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
