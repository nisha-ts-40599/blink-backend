from __future__ import annotations

import json
import shutil
import subprocess
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import yaml

try:
    from .exceptions import PolicyError
except ImportError:
    from exceptions import PolicyError


class PolicyEngine:
    def __init__(
        self,
        repo_root: Path,
        branch_profile: str,
        require_opa: bool = False,
        opa_path: str = "",
        run_dir: Path | None = None,
        trace_policies: bool = False,
    ) -> None:
        self.repo_root = repo_root
        self.branch_profile = branch_profile
        self.opa_bin = opa_path or (shutil.which("opa") or "")
        self.opa_available = bool(self.opa_bin and Path(self.opa_bin).exists())
        if require_opa and not self.opa_bin:
            raise PolicyError("OPA required but not installed")
        self.workflow_model = self._load_yaml(repo_root / "ai-sdlc" / "orchestration" / "workflow-state-model.yaml")
        self.trace_policies = trace_policies
        self.trace_dir = (run_dir / "policy-traces") if run_dir else None
        self.trace_refs: list[str] = []
        self.total_eval_seconds = 0.0
        if self.trace_dir:
            self.trace_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _load_yaml(path: Path) -> Dict[str, Any]:
        with path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f)

    def validate_transition(self, current_state: str, next_state: str) -> Dict[str, Any]:
        rego_input = {
            "workflow": {"current_state": current_state, "next_state": next_state},
            "system": {"emergency_stop": False},
        }
        rego = self._eval_allow_and_reasons("data.ai_sdlc.workflow_transitions", rego_input)
        if rego is not None:
            return {
                "policy": "workflow-transition",
                "source": "rego",
                "allowed": rego["allow"],
                "current_state": current_state,
                "next_state": next_state,
                "deny_reasons": rego["deny_reasons"],
                "reason": None if rego["allow"] else "invalid_transition",
            }

        # Local fallback — reads active transitions from workflow-state-model.yaml
        valid_pairs = {(t["from"], t["to"]) for t in self.workflow_model.get("transitions", [])}
        allowed = (current_state, next_state) in valid_pairs
        return {
            "policy": "workflow-transition",
            "source": "fallback",
            "allowed": allowed,
            "current_state": current_state,
            "next_state": next_state,
            "deny_reasons": [] if allowed else ["invalid_transition"],
            "reason": None if allowed else "invalid_transition",
        }

    def check_gate_requirements(self, input_payload: Dict[str, Any], required_gates: list[str]) -> Dict[str, Any]:
        request_action = input_payload.get("request", {}).get("action", "")
        risk_tier = input_payload.get("change_request", {}).get("risk_tier", input_payload.get("risk_tier", 1))
        plan_approved = input_payload.get("approvals", {}).get("G-PLAN") == "approved"
        human_approved = all(v == "approved" for v in input_payload.get("approvals", {}).values()) if input_payload.get("approvals") else False
        rego_input = {
            "work_item": {"risk_tier": risk_tier, "plan_approved": plan_approved},
            "request": {
                "action": request_action,
                "human_approved": human_approved,
                "approval_token_valid": bool(input_payload.get("approval_token_valid", False)),
            },
        }
        rego = self._eval_allow_and_reasons("data.ai_sdlc.gates", rego_input)
        if rego is not None:
            return {
                "policy": "gates",
                "source": "rego",
                "allowed": rego["allow"],
                "required_gates": list(required_gates),
                "deny_reasons": rego["deny_reasons"],
            }
        # Local fallback
        allowed = True
        deny_reasons = []
        if risk_tier >= 2 and not plan_approved:
            allowed = False
            deny_reasons.append("tier_2_plus_requires_plan_approval")
        if request_action == "deploy_production" and not human_approved:
            allowed = False
            deny_reasons.append("production_deploy_requires_human_approval")
        return {
            "policy": "gates",
            "source": "fallback",
            "allowed": allowed,
            "required_gates": list(required_gates),
            "deny_reasons": deny_reasons,
        }

    def check_action_class(
        self,
        action_class: str,
        human_approved: bool = False,
        approval_token_valid: bool = False,
        break_glass: bool = False,
        emergency_stop: bool = False,
    ) -> Dict[str, Any]:
        rego_input = {
            "system": {"emergency_stop": emergency_stop},
            "mcp": {
                "tool_class": action_class,
                "human_approved": human_approved,
                "approval_token_valid": approval_token_valid,
                "break_glass": break_glass,
            },
        }
        rego = self._eval_allow_and_reasons("data.ai_sdlc.mcp_permissions", rego_input)
        if rego is not None:
            return {
                "policy": "mcp-class",
                "source": "rego",
                "allowed": rego["allow"],
                "reason": None if rego["allow"] else "action_class_denied",
                "deny_reasons": rego["deny_reasons"],
            }

        # Local fallback
        deny_reasons = []
        if emergency_stop and action_class != "read_tools":
            deny_reasons.append("emergency_stop_blocks_non_read_actions")
        if action_class == "restricted_tools" and not (human_approved and approval_token_valid):
            deny_reasons.append("restricted_tools_require_human_approval_and_token")
        if action_class == "destructive_tools":
            if not human_approved:
                deny_reasons.append("destructive_tools_require_human_approval")
            if not approval_token_valid:
                deny_reasons.append("destructive_tools_require_approval_token")
            if not break_glass:
                deny_reasons.append("destructive_tools_require_break_glass")
        return {
            "policy": "mcp-class",
            "source": "fallback",
            "allowed": len(deny_reasons) == 0,
            "reason": None if len(deny_reasons) == 0 else "action_class_denied",
            "deny_reasons": deny_reasons,
        }

    def _opa_eval_raw(self, query: str, input_payload: Dict[str, Any]) -> Tuple[Optional[Any], float]:
        started = time.perf_counter()
        if not self.opa_available:
            return None, time.perf_counter() - started
        input_json = json.dumps(input_payload).encode("utf-8")
        rego_dir = str(self.repo_root / "ai-sdlc" / "policies")

        # Prefer --stdin-input (OPA v0.29+); fall back to temp file if unrecognised.
        cmd = ["eval", "--format", "json", "--data", rego_dir, "--stdin-input", query]
        proc = subprocess.run(
            [self.opa_bin] + cmd,
            input=input_json,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        if proc.returncode != 0:
            stderr_text = proc.stderr.decode("utf-8", errors="replace")
            unknown_flag = (
                "unknown flag" in stderr_text
                or "flag provided but not defined" in stderr_text
                or "unrecognized" in stderr_text.lower()
            )
            if unknown_flag:
                import tempfile as _tf, os as _os
                fd, tmp_path = _tf.mkstemp(suffix=".json", prefix="opa_input_")
                try:
                    _os.write(fd, input_json)
                    _os.close(fd)
                    proc = subprocess.run(
                        [self.opa_bin, "eval", "--format", "json", "--data", rego_dir, "--input", tmp_path, query],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        check=False,
                    )
                finally:
                    try:
                        _os.unlink(tmp_path)
                    except OSError:
                        pass
        if proc.returncode != 0:
            return None, time.perf_counter() - started
        payload = json.loads(proc.stdout.decode("utf-8"))
        result = payload.get("result", [])
        if not result:
            return None, time.perf_counter() - started
        expressions = result[0].get("expressions", [])
        if not expressions:
            return None, time.perf_counter() - started
        return expressions[0].get("value"), time.perf_counter() - started

    def _eval_allow_and_reasons(self, package: str, input_payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        allow, t_allow = self._opa_eval_raw(f"{package}.allow", input_payload)
        deny, t_deny = self._opa_eval_raw(f"{package}.deny_reasons", input_payload)
        self.total_eval_seconds += t_allow + t_deny
        fallback_used = allow is None and deny is None
        result = None if fallback_used else {"allow": bool(allow), "deny_reasons": list(deny or [])}
        self._trace(package, input_payload, result, fallback_used)
        return result

    def _trace(self, package: str, input_payload: Dict[str, Any], result: Any, fallback_used: bool) -> None:
        if not (self.trace_policies and self.trace_dir):
            return
        # Only write traces for OPA evaluations, not fallback
        if fallback_used:
            return
        rec = {
            "policy_package": package,
            "query": [f"{package}.allow", f"{package}.deny_reasons"],
            "input": input_payload,
            "result": result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "fallback_used": fallback_used,
        }
        path = self.trace_dir / f"{package.split('.')[-1]}-{uuid.uuid4().hex[:8]}.json"
        path.write_text(json.dumps(rec, indent=2), encoding="utf-8")
        self.trace_refs.append(str(path))
