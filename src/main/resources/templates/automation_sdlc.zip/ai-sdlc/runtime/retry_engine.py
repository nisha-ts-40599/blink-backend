from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List

try:
    from .exceptions import RetryableRuntimeError
except ImportError:
    from exceptions import RetryableRuntimeError


class RetryEngine:
    """Bounded retry with exponential backoff.

    Only ``RetryableRuntimeError`` is retried.  All other exceptions propagate
    immediately as non-retryable failures.
    """

    def __init__(
        self,
        run_dir: Path,
        max_attempts: int = 1,
        retry_delay_seconds: float = 0.0,
    ) -> None:
        self.max_attempts = max(1, max_attempts)
        self.retry_delay_seconds = max(0.0, retry_delay_seconds)
        self.path = run_dir / "retry-state.json"
        if self.path.exists():
            self.state: Dict[str, Any] = json.loads(self.path.read_text(encoding="utf-8"))
        else:
            self.state = {"steps": {}}

    def run_step(
        self,
        step_id: str,
        action_key: str,
        executor: Callable[[Dict[str, Any]], Dict[str, Any]],
        context: Dict[str, Any],
    ) -> Dict[str, Any]:
        attempts: List[Dict[str, Any]] = []
        last_error = None
        for attempt in range(1, self.max_attempts + 1):
            try:
                result = executor({**context, "attempt_number": attempt})
                meta = self._meta(attempt)
                self._record(step_id, action_key, attempts + [{"attempt_number": attempt, "status": "success"}], "success", None)
                return {**result, "retry_metadata": meta}
            except RetryableRuntimeError as e:
                last_error = e
                attempts.append({"attempt_number": attempt, "status": "retryable_failure", "error": str(e)})
                if attempt >= self.max_attempts:
                    self._record(step_id, action_key, attempts, "failed", str(e))
                    raise
                backoff = self.retry_delay_seconds * (2 ** (attempt - 1))
                if backoff > 0:
                    time.sleep(backoff)
            except Exception as e:
                self._record(
                    step_id,
                    action_key,
                    attempts + [{"attempt_number": attempt, "status": "non_retryable_failure", "error": str(e)}],
                    "failed_non_retryable",
                    str(e),
                )
                raise
        if last_error is not None:
            raise last_error
        raise RuntimeError("retry engine reached unreachable state")

    def _meta(self, attempt_number: int) -> Dict[str, Any]:
        return {
            "attempt_number": attempt_number,
            "retry_count": max(0, attempt_number - 1),
            "final_attempt": attempt_number >= self.max_attempts,
            "retry_reason": None,
        }

    def _record(self, step_id: str, action_key: str, attempts: List[Dict[str, Any]], status: str, last_error: str | None) -> None:
        self.state["steps"][step_id] = {
            "step_id": step_id,
            "action_key": action_key,
            "attempts": attempts,
            "status": status,
            "last_error": last_error,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        self.path.write_text(json.dumps(self.state, indent=2), encoding="utf-8")
