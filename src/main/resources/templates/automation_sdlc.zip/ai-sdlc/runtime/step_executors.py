from __future__ import annotations

from typing import Any, Callable, Dict, List

try:
    from .exceptions import PolicyEnforcementError
except ImportError:
    from exceptions import PolicyEnforcementError


ExecutorFn = Callable[[Dict[str, Any]], Dict[str, Any]]


def _emit(audit_logger: Any, bucket: List[Dict[str, Any]], event_id: str, event_type: str, payload: Dict[str, Any]) -> None:
    audit_logger.emit(event_id, event_type, payload)
    bucket.append({"event_id": event_id, "event_type": event_type})


def _is_protected(ctx: Dict[str, Any]) -> bool:
    return ctx.get("branch_profile") == "protected" or ctx.get("strict", False)


def clarify_requirement(ctx: Dict[str, Any]) -> Dict[str, Any]:
    events: List[Dict[str, Any]] = []
    payload = {
        "workflow_id": ctx["workflow"]["workflow_id"],
        "step_text": ctx["step"]["step_text"],
        "requirement": ctx["input_payload"].get("requirement", {}),
    }
    rec = ctx["artifact_store"].put(f"{ctx['step']['step_id']}_clarification", payload)
    _emit(ctx["audit_logger"], events, "AUD-STEP-CLARIFY-001", "step.clarify_requirement", {"artifact": rec["artifact_id"]})
    return {"status": "completed", "artifacts_produced": [rec["artifact_id"]], "audit_events": events, "warnings": []}


def create_or_update_documentation(ctx: Dict[str, Any]) -> Dict[str, Any]:
    events: List[Dict[str, Any]] = []
    doc = ctx["adapters"]["docs"].upsert_doc(
        title=ctx["workflow"]["workflow_name"],
        content={"step": ctx["step"]["step_text"], "input": ctx["input_payload"]},
    )
    rec = ctx["artifact_store"].put(f"{ctx['step']['step_id']}_documentation", doc)
    _emit(ctx["audit_logger"], events, "AUD-STEP-DOC-001", "step.documentation_upsert", {"artifact": rec["artifact_id"]})
    return {"status": "completed", "artifacts_produced": [rec["artifact_id"]], "audit_events": events, "warnings": []}


def create_issue(ctx: Dict[str, Any]) -> Dict[str, Any]:
    events: List[Dict[str, Any]] = []
    issue = ctx["adapters"]["issues"].create_issue(title=ctx["workflow"]["workflow_name"], body=ctx["input_payload"])
    rec = ctx["artifact_store"].put(f"{ctx['step']['step_id']}_issue", issue)
    _emit(ctx["audit_logger"], events, "AUD-STEP-ISSUE-001", "step.issue_created", {"artifact": rec["artifact_id"]})
    return {"status": "completed", "artifacts_produced": [rec["artifact_id"]], "audit_events": events, "warnings": []}


def perform_impact_analysis(ctx: Dict[str, Any]) -> Dict[str, Any]:
    events: List[Dict[str, Any]] = []
    impacts = ctx["input_payload"].get("change_request", {}).get("impacts", [])
    rec = ctx["artifact_store"].put(
        f"{ctx['step']['step_id']}_impact_analysis",
        {"impacts": impacts, "step": ctx["step"]["step_text"]},
    )
    _emit(ctx["audit_logger"], events, "AUD-STEP-IMPACT-001", "step.impact_analysis", {"artifact": rec["artifact_id"]})
    return {"status": "completed", "artifacts_produced": [rec["artifact_id"]], "audit_events": events, "warnings": []}


def create_technical_plan(ctx: Dict[str, Any]) -> Dict[str, Any]:
    events: List[Dict[str, Any]] = []
    plan_payload = {
        "workflow_id": ctx["workflow"]["workflow_id"],
        "risk_tier": ctx["input_payload"].get("change_request", {}).get("risk_tier"),
        "step": ctx["step"]["step_text"],
    }
    rec = ctx["artifact_store"].put(f"{ctx['step']['step_id']}_technical_plan", plan_payload)
    _emit(ctx["audit_logger"], events, "AUD-STEP-PLAN-001", "step.technical_plan", {"artifact": rec["artifact_id"]})
    return {"status": "completed", "artifacts_produced": [rec["artifact_id"]], "audit_events": events, "warnings": []}


def validate_approval_gate(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """Evaluate gate policy.

    Enforcement behaviour depends on execution profile:
    - **protected / strict**: gate denial raises ``PolicyEnforcementError`` and
      blocks workflow execution.
    - **dev (non-strict)**: gate denial records an advisory warning and continues.
      This allows developers to run workflows locally without pre-seeding all
      approvals.  It does NOT constitute actual governance approval.
    """
    events: List[Dict[str, Any]] = []
    required = [g.get("gate_id") for g in ctx["workflow"]["approval_gates"]]
    decision = ctx["policy_engine"].check_gate_requirements(ctx["input_payload"], required)

    if not decision["allowed"]:
        deny_msg = f"Gate requirement denied: {decision.get('deny_reasons', [])}"
        if _is_protected(ctx):
            _emit(
                ctx["audit_logger"],
                events,
                "AUD-GATE-BLOCKED-001",
                "gate.blocked",
                {"step_id": ctx["step"]["step_id"], "deny_reasons": decision.get("deny_reasons", []), "profile": ctx.get("branch_profile")},
            )
            raise PolicyEnforcementError(deny_msg)
        # dev-profile advisory warning
        _emit(
            ctx["audit_logger"],
            events,
            "AUD-GATE-ADVISORY-001",
            "gate.advisory_warning",
            {"step_id": ctx["step"]["step_id"], "deny_reasons": decision.get("deny_reasons", []), "profile": ctx.get("branch_profile")},
        )
        rec = ctx["artifact_store"].put(
            f"{ctx['step']['step_id']}_gate_validation",
            {**decision, "enforcement": "advisory"},
        )
        return {
            "status": "completed",
            "artifacts_produced": [rec["artifact_id"]],
            "audit_events": events,
            "warnings": [f"[ADVISORY] {deny_msg} — not enforced in dev profile"],
        }

    rec = ctx["artifact_store"].put(f"{ctx['step']['step_id']}_gate_validation", decision)
    _emit(ctx["audit_logger"], events, "AUD-STEP-GATE-001", "step.gate_validated", {"artifact": rec["artifact_id"], "allowed": True})
    return {"status": "completed", "artifacts_produced": [rec["artifact_id"]], "audit_events": events, "warnings": []}


def create_pr(ctx: Dict[str, Any]) -> Dict[str, Any]:
    events: List[Dict[str, Any]] = []
    pr = ctx["adapters"]["git"].create_pr(branch="feature/mock", title=f"{ctx['workflow']['workflow_name']} (mock)")
    rec = ctx["artifact_store"].put(f"{ctx['step']['step_id']}_pull_request", pr)
    _emit(ctx["audit_logger"], events, "AUD-STEP-PR-001", "step.pr_created", {"artifact": rec["artifact_id"]})
    return {"status": "completed", "artifacts_produced": [rec["artifact_id"]], "audit_events": events, "warnings": []}


def review_pr(ctx: Dict[str, Any]) -> Dict[str, Any]:
    events: List[Dict[str, Any]] = []
    rec = ctx["artifact_store"].put(
        f"{ctx['step']['step_id']}_pr_review",
        {"review_status": "reviewed", "step": ctx["step"]["step_text"], "workflow": ctx["workflow"]["workflow_id"]},
    )
    _emit(ctx["audit_logger"], events, "AUD-STEP-PR-REVIEW-001", "step.pr_reviewed", {"artifact": rec["artifact_id"]})
    return {"status": "completed", "artifacts_produced": [rec["artifact_id"]], "audit_events": events, "warnings": []}


def verify_release_readiness(ctx: Dict[str, Any]) -> Dict[str, Any]:
    events: List[Dict[str, Any]] = []
    payload = {
        "release_request": ctx["input_payload"].get("release_request", {}),
        "step": ctx["step"]["step_text"],
        "status": "ready_for_nonprod",
    }
    rec = ctx["artifact_store"].put(f"{ctx['step']['step_id']}_release_readiness", payload)
    _emit(ctx["audit_logger"], events, "AUD-STEP-REL-001", "step.release_readiness", {"artifact": rec["artifact_id"]})
    return {"status": "completed", "artifacts_produced": [rec["artifact_id"]], "audit_events": events, "warnings": []}


def post_release_verification(ctx: Dict[str, Any]) -> Dict[str, Any]:
    events: List[Dict[str, Any]] = []
    rec = ctx["artifact_store"].put(
        f"{ctx['step']['step_id']}_post_release_verification",
        {"verification": "passed", "step": ctx["step"]["step_text"]},
    )
    handoff = ctx["handoff_engine"].emit(
        correlation_id=ctx["input_payload"].get("correlation_id", ctx["run_id"]),
        workflow_id=ctx["workflow"]["workflow_id"],
        payload_type="PostReleaseVerificationHandoff",
        required_artifacts=ctx["workflow"]["required_artifacts"],
        produced_artifacts=[rec["artifact_id"]],
        payload={"step_id": ctx["step"]["step_id"], "status": "verified"},
    )
    _emit(
        ctx["audit_logger"],
        events,
        "AUD-STEP-POSTREL-001",
        "step.post_release_verification",
        {"artifact": rec["artifact_id"], "handoff_id": handoff["handoff_id"]},
    )
    return {"status": "completed", "artifacts_produced": [rec["artifact_id"]], "audit_events": events, "warnings": []}


def noop(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """Explicit no-op executor for human-driven steps declared in executable_steps."""
    events: List[Dict[str, Any]] = []
    _emit(
        ctx["audit_logger"],
        events,
        "AUD-STEP-NOOP-001",
        "step.noop_explicit",
        {"step_id": ctx["step"]["step_id"], "step_text": ctx["step"]["step_text"]},
    )
    return {"status": "completed", "artifacts_produced": [], "audit_events": events, "warnings": []}


def default_noop_executor(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """Fallback for steps whose action_key does not match any registered executor.

    In dev profile: records warning and continues.
    In protected profile: this should never be reached — the orchestrator raises
    before calling this executor.
    """
    events: List[Dict[str, Any]] = []
    warning = f"No mapped executor for action '{ctx['step']['action_key']}' (source: {ctx['step'].get('action_key_source', 'unknown')})"
    _emit(
        ctx["audit_logger"],
        events,
        "AUD-STEP-NOOP-001",
        "step.noop_fallback",
        {"step_id": ctx["step"]["step_id"], "step_text": ctx["step"]["step_text"], "warning": warning},
    )
    return {"status": "completed", "artifacts_produced": [], "audit_events": events, "warnings": [warning]}


class StepExecutorRegistry:
    def __init__(self) -> None:
        self._registry: Dict[str, ExecutorFn] = {
            "clarify_requirement": clarify_requirement,
            "create_or_update_documentation": create_or_update_documentation,
            "create_issue": create_issue,
            "perform_impact_analysis": perform_impact_analysis,
            "create_technical_plan": create_technical_plan,
            "validate_approval_gate": validate_approval_gate,
            "create_pr": create_pr,
            "review_pr": review_pr,
            "verify_release_readiness": verify_release_readiness,
            "post_release_verification": post_release_verification,
            "noop": noop,
            "default_noop_executor": default_noop_executor,
        }

    def resolve(self, action_key: str) -> ExecutorFn:
        return self._registry.get(action_key, default_noop_executor)

    def is_known(self, action_key: str) -> bool:
        return action_key in self._registry
