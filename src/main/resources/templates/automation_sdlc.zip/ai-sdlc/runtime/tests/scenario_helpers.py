"""Scenario helpers for ai-sdlc runtime testing and demos.

NOT for production use.  These helpers enable failure injection and artifact
corruption scenarios for local demo and CI scenario validation only.

Activate via the orchestrator's ``--test-scenario`` flag.  Production
payloads never set this flag.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable, Dict, Optional

try:
    from ..exceptions import ArtifactValidationError, NonRetryableRuntimeError, RetryableRuntimeError
    from ..artifact_store import ArtifactStore
except ImportError:
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from exceptions import ArtifactValidationError, NonRetryableRuntimeError, RetryableRuntimeError
    from artifact_store import ArtifactStore


ExecutorFn = Callable[[Dict[str, Any]], Dict[str, Any]]


def _check_failure_injection(ctx: Dict[str, Any]) -> None:
    """Raise configured exception if this step/attempt matches injection config."""
    inj = (ctx.get("input_payload", {}) or {}).get("failure_injection", {})
    action_cfg = inj.get(ctx["step"]["action_key"]) or inj.get(ctx["step"]["step_id"])
    if not isinstance(action_cfg, dict):
        return
    fail_attempts = int(action_cfg.get("fail_attempts", 0))
    mode = str(action_cfg.get("mode", "retryable"))
    attempt = int(ctx.get("attempt_number", 1))
    if attempt <= fail_attempts:
        if mode == "retryable":
            raise RetryableRuntimeError(
                f"[SCENARIO] Injected retryable failure for {ctx['step']['action_key']} attempt {attempt}"
            )
        raise NonRetryableRuntimeError(
            f"[SCENARIO] Injected non-retryable failure for {ctx['step']['action_key']} attempt {attempt}"
        )


class CorruptingArtifactStore(ArtifactStore):
    """ArtifactStore that corrupts the digest for a specific step/action_key.

    Used only in test scenarios activated by ``--test-scenario``.
    """

    def __init__(self, run_dir: Path, repo_root: Path, corrupt_on: Optional[str] = None) -> None:
        super().__init__(run_dir, repo_root)
        self.corrupt_on = corrupt_on  # step_id or action_key to corrupt

    def put(self, artifact_id: str, payload: Dict[str, Any], state: str = "produced", schema_key: str = "artifact_integrity") -> Dict[str, Any]:
        # Check if this artifact_id or the calling step matches corruption target
        if self.corrupt_on and (artifact_id.startswith(self.corrupt_on) or self.corrupt_on in artifact_id):
            # Inject a bad digest by corrupting the payload bytes before hashing
            import hashlib as _hl
            original_bytes = json.dumps(payload, sort_keys=True).encode("utf-8")
            # Force a digest mismatch by writing a fake hash value
            bad_payload = {**payload, "_scenario_corrupted": True}
            # We need to bypass the normal flow — temporarily swap payload bytes
            # to produce an invalid (non-hex) digest that fails schema validation
            corrupt_record = {
                "artifact_id": artifact_id,
                "artifact_type": schema_key,
                "digest_algorithm": "sha256",
                "digest": "CORRUPTED",  # fails ^[a-fA-F0-9]{64,128}$ pattern
                "signature_required": False,
                "signature_status": "not_required",
                "signer": None,
                "timestamp": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
            }
            self._validate_integrity(corrupt_record)  # will raise ArtifactValidationError
        return super().put(artifact_id, payload, state, schema_key)


def wrap_executor_with_scenario(executor: ExecutorFn, input_payload: Dict[str, Any]) -> ExecutorFn:
    """Wrap an executor with failure injection from input_payload.

    The wrapped executor reads ``failure_injection`` from the input payload
    and raises the configured exception type on the configured attempts.
    """
    def wrapped(ctx: Dict[str, Any]) -> Dict[str, Any]:
        _check_failure_injection({**ctx, "input_payload": input_payload})
        return executor(ctx)
    wrapped.__name__ = executor.__name__
    return wrapped


def make_scenario_artifact_store(run_dir: Path, repo_root: Path, input_payload: Dict[str, Any]) -> ArtifactStore:
    """Return a CorruptingArtifactStore if ``force_invalid_artifact_on`` is set,
    otherwise return a plain ArtifactStore.

    Used only when ``--test-scenario`` is active.
    """
    corrupt_on = input_payload.get("force_invalid_artifact_on")
    if corrupt_on:
        return CorruptingArtifactStore(run_dir, repo_root, corrupt_on=str(corrupt_on))
    return ArtifactStore(run_dir, repo_root)
