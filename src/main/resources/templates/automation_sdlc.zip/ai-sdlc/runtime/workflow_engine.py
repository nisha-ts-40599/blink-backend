from __future__ import annotations

import re
import json
from pathlib import Path
from typing import Any, Dict, List

import yaml

try:
    from .exceptions import WorkflowLoadError
    from .models import WorkflowDefinition, WorkflowStep
except ImportError:
    from exceptions import WorkflowLoadError
    from models import WorkflowDefinition, WorkflowStep


class WorkflowEngine:
    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root

    def load(self, workflow_path: Path) -> WorkflowDefinition:
        text = workflow_path.read_text(encoding="utf-8")
        header = self._extract_yaml_header(text)
        self._validate_header_against_schema(header)
        required = ["workflow_id", "workflow_name", "owner_agent", "approval_gates", "produced_artifacts", "required_artifacts"]
        for k in required:
            if k not in header:
                raise WorkflowLoadError(f"Missing workflow header field: {k}")
        steps = self._build_steps(header, text)
        return WorkflowDefinition(
            workflow_id=header["workflow_id"],
            workflow_name=header["workflow_name"],
            owner_agent=header["owner_agent"],
            approval_gates=header.get("approval_gates", []),
            produced_artifacts=header.get("produced_artifacts", []),
            required_artifacts=header.get("required_artifacts", []),
            steps=steps,
            raw_header=header,
        )

    def _validate_header_against_schema(self, header: Dict[str, Any]) -> None:
        schema_path = self.repo_root / "ai-sdlc" / "schemas" / "workflow" / "workflow-header.schema.json"
        if not schema_path.exists():
            return
        try:
            import jsonschema
        except ImportError:
            return
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        jsonschema.Draft202012Validator(schema).validate(header)

    @staticmethod
    def _extract_yaml_header(text: str) -> Dict[str, Any]:
        match = re.search(r"```yaml\s*(.*?)```", text, flags=re.DOTALL)
        if not match:
            raise WorkflowLoadError("No YAML header block found")
        data = yaml.safe_load(match.group(1))
        if not isinstance(data, dict):
            raise WorkflowLoadError("Workflow YAML header is not an object")
        return data

    def _build_steps(self, header: Dict[str, Any], text: str) -> List[WorkflowStep]:
        """Build the step list, preferring explicit ``executable_steps`` from the YAML header.

        If ``executable_steps`` is present and its count matches the markdown
        steps extracted from the body, use the explicit action_keys verbatim.

        If ``executable_steps`` is absent or counts diverge, fall back to
        ``normalize_step_action`` inference (with a warning stored on each step).
        This fallback exists for backward compatibility; it should not be relied
        upon in production workflows.
        """
        explicit: List[Dict[str, Any]] = header.get("executable_steps", [])
        markdown_steps = self._extract_markdown_steps(text)

        if explicit and len(explicit) == len(markdown_steps):
            steps = []
            for i, (md_step, ex_step) in enumerate(zip(markdown_steps, explicit)):
                action_key = str(ex_step.get("action_key", "noop"))
                source = "noop" if action_key == "noop" else "explicit"
                steps.append(
                    WorkflowStep(
                        step_id=f"S{i + 1:03d}",
                        step_text=md_step,
                        action_key=action_key,
                        action_key_source=source,
                    )
                )
            return steps

        # Fallback: regex inference
        steps = []
        for i, step_text in enumerate(markdown_steps):
            action_key = self.normalize_step_action(step_text)
            steps.append(
                WorkflowStep(
                    step_id=f"S{i + 1:03d}",
                    step_text=step_text,
                    action_key=action_key,
                    action_key_source="inferred",
                )
            )
        return steps

    @staticmethod
    def _extract_markdown_steps(text: str) -> List[str]:
        """Extract bold step names from numbered markdown list items."""
        steps: List[str] = []
        for line in text.splitlines():
            m = re.match(r"^\d+\.\s+\*\*(.+?)\*\*", line.strip())
            if m:
                steps.append(m.group(1))
        return steps

    @staticmethod
    def normalize_step_action(step_text: str) -> str:
        """Infer action_key from step prose.  Used only as fallback when
        ``executable_steps`` is missing or mismatched in the workflow header."""
        normalized = step_text.strip().lower()
        normalized = normalized.replace("/", " ").replace("-", " ")
        normalized = re.sub(r"[^a-z0-9\s]", " ", normalized)
        normalized = re.sub(r"\s+", " ", normalized).strip()

        rules = [
            ("clarification", "clarify_requirement"),
            ("specification", "create_or_update_documentation"),
            ("documentation", "create_or_update_documentation"),
            ("knowledge update", "create_or_update_documentation"),
            ("issue decomposition", "create_issue"),
            ("close loop", "create_issue"),
            ("release candidate assembly", "verify_release_readiness"),
            ("impact analysis", "perform_impact_analysis"),
            ("repository analysis", "perform_impact_analysis"),
            ("technical planning", "create_technical_plan"),
            ("approval gate", "validate_approval_gate"),
            ("merge readiness", "validate_approval_gate"),
            ("go no go", "validate_approval_gate"),
            ("pr draft", "create_pr"),
            ("ai review", "review_pr"),
            ("human review", "review_pr"),
            ("post release", "post_release_verification"),
            ("prompt assisted verification", "post_release_verification"),
            ("release scope", "verify_release_readiness"),
            ("operational readiness", "verify_release_readiness"),
        ]
        for needle, action in rules:
            if needle in normalized:
                return action
        return "default_noop_executor"
