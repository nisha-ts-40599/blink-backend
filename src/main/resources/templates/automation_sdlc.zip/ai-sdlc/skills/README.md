# AI-SDLC Reusable Skills

Skills are **focused, reusable reasoning capabilities** that agents invoke during specific SDLC stages.
A skill is not a full agent and not a full prompt. It is a bounded reasoning task with defined inputs,
outputs, and governance rules that can be composed into any agent's workflow.

## What a skill is

- A named, documented reasoning capability
- Project-agnostic by design
- Applicable to one or more SDLC stages
- Referenced by agents and prompts
- Governed by rules from `rules/global-rule-index.md`

## What a skill is not

- A complete agent (agents compose multiple skills)
- A project-specific policy (those live in `project-config.yaml`)
- A runtime function (skills are reasoning patterns, not executable code modules)
- An autonomous action (skills produce outputs for human or agent review)

## Skill catalog

See `skill-catalog.md` for the full catalog of 22 reusable skills.

## How skills are used today (Level 1)

Skills are embedded in prompts as instructions and reasoning steps. Engineers invoke the prompts
manually. The skill reasoning happens inside the LLM context window.

## How skills are used at Level 2+

Agents invoke skills explicitly via their context assembly step. The context aggregator loads
the skill's required context and the agent applies the skill's reasoning pattern to the inputs.

## How to add a new skill

1. Verify the skill does not already exist in `skill-catalog.md`.
2. Define the skill using the template format in `skill-catalog.md`.
3. Specify which existing agents and prompts use it.
4. Specify which rules govern it.
5. Add it to `skill-catalog.md` and update the catalog index.
6. If the skill requires a new placeholder, add it to `prompts/prompt-placeholder-catalog.md`.
7. Run `make ai-sdlc-prompt-check` to verify no stale references.
