# AI-SDLC Skill Catalog

Each skill entry defines a bounded reasoning capability. Skills are invoked by agents and are
embedded in prompts. All skills are project-agnostic; project-specific adaptations are loaded
from `project-context.md` and `project-config.yaml`.

---

## SKL-001 — Requirement Clarification

**Purpose:** Identify gaps, ambiguities, conflicting assumptions, and missing acceptance criteria in a raw requirement.

| Field | Value |
|-------|-------|
| **Applicable stages** | REQUIREMENT |
| **Inputs** | Raw requirement text, project context, domain glossary |
| **Outputs** | Structured open questions list; conflicting assumptions identified; proposed resolutions |
| **Agents that use it** | Requirement Analyst, Clarification |
| **Governance rules** | No binding commitment; no silent assumption; all blocking questions surfaced before advancement |
| **Project context required** | Domain glossary; existing features list; API conventions |
| **Prompt/rule reference** | `prompts/clarify-requirement.prompt.md` |

---

## SKL-002 — Ambiguity Detection

**Purpose:** Scan a requirement, plan, or specification for language that is too vague to be implemented without interpretation (e.g., "fast", "secure", "improved", "appropriate").

| Field | Value |
|-------|-------|
| **Applicable stages** | REQUIREMENT, SPEC_DRAFTED, PLAN_DRAFTED |
| **Inputs** | Requirement or specification text |
| **Outputs** | List of ambiguous terms with proposed concrete replacements or questions |
| **Agents that use it** | Requirement Analyst, Clarification, Technical Planning |
| **Governance rules** | No silent assumption; every ambiguous term must be resolved or flagged |
| **Project context required** | Domain glossary |
| **Prompt/rule reference** | `prompts/clarify-requirement.prompt.md`, `prompts/technical-plan.prompt.md` |

---

## SKL-003 — Acceptance Criteria Generation

**Purpose:** Generate measurable, testable acceptance criteria from a structured requirement using Given/When/Then or equivalent format.

| Field | Value |
|-------|-------|
| **Applicable stages** | REQUIREMENT, SPEC_DRAFTED |
| **Inputs** | Structured requirement text; domain context; API conventions |
| **Outputs** | Acceptance criteria list (measurable, testable, non-ambiguous) |
| **Agents that use it** | Requirement Analyst, Clarification |
| **Governance rules** | Each criterion must be independently verifiable; no subjective criteria |
| **Project context required** | Domain model; test conventions |
| **Prompt/rule reference** | `prompts/clarify-requirement.prompt.md`, `prompts/create-spec.prompt.md` |

---

## SKL-004 — Work Tier Classification

**Purpose:** Propose a work tier (1–4) based on scope, blast radius, data sensitivity, security impact, and risk signals.

| Field | Value |
|-------|-------|
| **Applicable stages** | CLASSIFIED |
| **Inputs** | Structured requirement, project config (tier defaults), risk rules, data classification |
| **Outputs** | Proposed tier with evidence, required gates, required rigor level, risk flags |
| **Agents that use it** | Work Classification |
| **Governance rules** | Risk rule detection; Tier 1/2 boundary guard; classification is advisory (human confirms) |
| **Project context required** | `project-config.yaml` (tier overrides); data classification; security model |
| **Prompt/rule reference** | `prompts/classify-work.prompt.md`, `ai-sdlc/work-tiers.md` |

---

## SKL-005 — Risk Rule Detection

**Purpose:** Scan a requirement, plan, or diff for conditions that trigger mandatory tier elevation: PII access, authentication changes, payment paths, external API integration, data deletion, infrastructure changes.

| Field | Value |
|-------|-------|
| **Applicable stages** | CLASSIFIED, PLAN_DRAFTED, IMPLEMENTING, PR_OPEN |
| **Inputs** | Work description, diff, or plan; `governance/risk-rules.md` |
| **Outputs** | Risk flags with tier elevation recommendations; mandatory escalation triggers |
| **Agents that use it** | Work Classification, Security Review, PR Review |
| **Governance rules** | Risk detection is mandatory, not optional; elevation is not overridable by the agent |
| **Project context required** | `project-config.yaml` (data classification, security model) |
| **Prompt/rule reference** | `governance/risk-rules.md`, `prompts/classify-work.prompt.md` |

---

## SKL-006 — Impact Analysis

**Purpose:** Map the blast radius of a change: affected components, API contract surface, schema deltas, downstream dependencies, and rollback complexity.

| Field | Value |
|-------|-------|
| **Applicable stages** | CLASSIFIED |
| **Inputs** | Confirmed requirement and tier, repository structure, API contracts, data model |
| **Outputs** | Impact sketch: affected files/modules, API surface delta, schema changes, rollback approach, test targets |
| **Agents that use it** | Impact Analysis |
| **Governance rules** | Blast radius completeness check; dependency chain check; rollback feasibility |
| **Project context required** | Tech stack; component map; API contract registry; dependency graph |
| **Prompt/rule reference** | `prompts/impact-analysis.prompt.md` |

---

## SKL-007 — Dependency Analysis

**Purpose:** Identify transitive dependencies affected by a change, detect version conflicts, and flag breaking API changes in dependent services.

| Field | Value |
|-------|-------|
| **Applicable stages** | CLASSIFIED, PLAN_DRAFTED, PR_OPEN |
| **Inputs** | Dependency manifests (package.json, requirements.txt, pom.xml); change scope |
| **Outputs** | Affected dependency list; version conflict flags; breaking change warnings |
| **Agents that use it** | Impact Analysis, Security Review |
| **Governance rules** | Dependency discipline: minimum version upgrade; transitive review required |
| **Project context required** | Dependency manifests; service dependency map |
| **Prompt/rule reference** | `prompts/impact-analysis.prompt.md`, `prompts/cve-triage.prompt.md` |

---

## SKL-008 — Reuse-First Code Analysis

**Purpose:** Before generating new code, identify existing components, utilities, patterns, or libraries that already solve the problem.

| Field | Value |
|-------|-------|
| **Applicable stages** | PLAN_DRAFTED, IMPLEMENTING |
| **Inputs** | Requirement or implementation task; existing codebase context |
| **Outputs** | Existing reusable components identified; proposed reuse with adaptation notes; new component justified only if no reuse found |
| **Agents that use it** | Backend Implementation, Frontend Implementation, Technical Planning |
| **Governance rules** | Reuse-first principle: no new code if existing code solves the problem; DRY rule |
| **Project context required** | Repository structure; existing patterns; component library |
| **Prompt/rule reference** | `prompts/implement-step.prompt.md`, `rules/global-rule-index.md` |

---

## SKL-009 — Duplicate Logic Detection

**Purpose:** Detect when the proposed or existing implementation duplicates logic that is already present in the codebase.

| Field | Value |
|-------|-------|
| **Applicable stages** | PLAN_DRAFTED, IMPLEMENTING, PR_OPEN |
| **Inputs** | Proposed code or implementation task; codebase context |
| **Outputs** | Duplicate logic identified with existing location; consolidation recommendation |
| **Agents that use it** | Backend Implementation, Frontend Implementation, PR Review |
| **Governance rules** | DRY rule; no unnecessary abstraction |
| **Project context required** | Repository structure; existing utilities |
| **Prompt/rule reference** | `prompts/implement-step.prompt.md`, `prompts/pr-review.prompt.md` |

---

## SKL-010 — Minimal Safe Bug-Fix Analysis

**Purpose:** Determine the smallest change that safely fixes a defect without introducing regression risk or unrelated changes.

| Field | Value |
|-------|-------|
| **Applicable stages** | IMPLEMENTING (bug path), PR_OPEN |
| **Inputs** | Bug report with reproduction steps; relevant code section; test context |
| **Outputs** | Minimal fix proposal; risk assessment of broader change; regression test requirement |
| **Agents that use it** | Backend Implementation, Security Review (security bugs) |
| **Governance rules** | Minimal safe change rule; no bundled refactoring; regression test required |
| **Project context required** | Reproduction steps; affected code; test suite |
| **Prompt/rule reference** | `prompts/bug-triage.prompt.md`, `prompts/implement-step.prompt.md` |

---

## SKL-011 — Test Coverage Reasoning

**Purpose:** Assess whether proposed tests adequately cover the implemented behaviour, edge cases, and failure paths.

| Field | Value |
|-------|-------|
| **Applicable stages** | IMPLEMENTING, PR_OPEN |
| **Inputs** | Code diff, test additions, acceptance criteria, project test conventions |
| **Outputs** | Coverage assessment: covered behaviours, missing edge cases, coverage gap rating |
| **Agents that use it** | Test Strategy / Generation, PR Review |
| **Governance rules** | Behaviour over implementation; edge cases required; coverage threshold check |
| **Project context required** | Test framework; coverage thresholds; acceptance criteria |
| **Prompt/rule reference** | `prompts/generate-tests.prompt.md`, `prompts/pr-review.prompt.md` |

---

## SKL-012 — Regression Test Identification

**Purpose:** For a given code change, identify which existing tests are at risk of breaking and which new regression tests are required.

| Field | Value |
|-------|-------|
| **Applicable stages** | IMPLEMENTING, PR_OPEN |
| **Inputs** | Diff, existing test suite structure, component dependency map |
| **Outputs** | Regression risk map: tests at risk, suggested new regression tests |
| **Agents that use it** | Test Strategy / Generation, PR Review |
| **Governance rules** | Regression test required for every bug fix; CI must run regression suite before merge |
| **Project context required** | Test suite structure; component ownership |
| **Prompt/rule reference** | `prompts/generate-tests.prompt.md` |

---

## SKL-013 — API Contract Review

**Purpose:** Review proposed API changes for backward compatibility, RESTful semantics, versioning strategy, documentation completeness, and contract consistency.

| Field | Value |
|-------|-------|
| **Applicable stages** | PLAN_DRAFTED, IMPLEMENTING, PR_OPEN |
| **Inputs** | Proposed API changes or OpenAPI diff, `{{API_CONVENTIONS}}`, existing contract registry |
| **Outputs** | API review findings: breaking changes, versioning gaps, documentation gaps, semantic violations |
| **Agents that use it** | Architecture Review, Documentation/OpenAPI, PR Review |
| **Governance rules** | No breaking change without version bump; OpenAPI must reflect implementation; consumer-first design |
| **Project context required** | API conventions; existing OpenAPI spec; consumer list |
| **Prompt/rule reference** | `prompts/pr-review.prompt.md`, `prompts/update-docs.prompt.md` |

---

## SKL-014 — OpenAPI Consistency Review

**Purpose:** Verify that the OpenAPI specification remains consistent with the implemented endpoints: request/response shapes, status codes, security schemes, and field descriptions.

| Field | Value |
|-------|-------|
| **Applicable stages** | IMPLEMENTING, PR_OPEN |
| **Inputs** | Diff, current OpenAPI spec, implementation code |
| **Outputs** | Consistency report: mismatches between spec and implementation; missing documentation; stale endpoints |
| **Agents that use it** | Documentation/OpenAPI, PR Review |
| **Governance rules** | OpenAPI spec must be updated in the same PR as API changes; no stale endpoints |
| **Project context required** | OpenAPI spec location; API framework (FastAPI, Spring, Express, etc.) |
| **Prompt/rule reference** | `prompts/update-docs.prompt.md` |

---

## SKL-015 — Database Migration Risk Review

**Purpose:** Assess a proposed database migration for data integrity, zero-downtime compatibility, rollback safety, and production data volume risk.

| Field | Value |
|-------|-------|
| **Applicable stages** | PLAN_DRAFTED, IMPLEMENTING (DB step) |
| **Inputs** | Migration scripts (up + down), current schema, data volume estimates, DB migration conventions |
| **Outputs** | Risk rating; backward compatibility assessment; rollback feasibility; lock risk; data loss risk |
| **Agents that use it** | Database Migration, Architecture Review |
| **Governance rules** | Migration discipline: up+down required; no data loss without explicit approval; volume risk check |
| **Project context required** | DB platform; migration tool; zero-downtime requirements; production data estimates |
| **Prompt/rule reference** | `prompts/implement-step.prompt.md` (DB step) |

---

## SKL-016 — Security Risk Review

**Purpose:** Assess a proposed change for OWASP-relevant risks, threat model impact, authentication/authorization changes, and data exposure.

| Field | Value |
|-------|-------|
| **Applicable stages** | PLAN_DRAFTED, PR_OPEN |
| **Inputs** | Plan or diff, `{{SECURITY_MODEL}}`, `{{DATA_CLASSIFICATION}}`, OWASP Top 10 reference |
| **Outputs** | Security findings: must-fix, advisory, informational; tier elevation recommendation |
| **Agents that use it** | Security Review, Architecture Review, PR Review |
| **Governance rules** | No finding waiver by agent; tier elevation is mandatory on specific triggers; advisory only |
| **Project context required** | Security model; data classification; authentication scheme |
| **Prompt/rule reference** | `prompts/pr-review.prompt.md`, `prompts/cve-triage.prompt.md` |

---

## SKL-017 — Dependency / CVE Triage

**Purpose:** Assess a reported CVE or dependency alert: severity, exploitability in this codebase, upgrade path, breaking change risk, and license impact.

| Field | Value |
|-------|-------|
| **Applicable stages** | Any (event-driven: triggered by alert) |
| **Inputs** | CVE ID or dependency alert, current dependency versions, codebase usage context |
| **Outputs** | Triage assessment: severity rating, exploitability in context, upgrade path, breaking change risk, recommended action |
| **Agents that use it** | Security Review |
| **Governance rules** | Minimum version upgrade rule; one CVE per PR preference; license review on major bump |
| **Project context required** | Dependency manifests; language/framework context |
| **Prompt/rule reference** | `prompts/cve-triage.prompt.md` |

---

## SKL-018 — PR Diff Review

**Purpose:** Review a pull request diff for correctness, maintainability, security smells, style compliance, and policy alignment.

| Field | Value |
|-------|-------|
| **Applicable stages** | PR_OPEN |
| **Inputs** | PR diff, linked issue, self-review output, engineering guardrails |
| **Outputs** | Review findings: must-fix, advisory, informational; overall risk statement |
| **Agents that use it** | PR Review |
| **Governance rules** | 13-item must-fix criteria from `prompts/pr-review.prompt.md`; guardrails checklist |
| **Project context required** | Coding conventions; architecture constraints; project-specific guardrail overrides |
| **Prompt/rule reference** | `prompts/pr-review.prompt.md`, `prompts/self-review.prompt.md` |

---

## SKL-019 — Release Readiness Review

**Purpose:** Assess whether a set of merged changes is ready for production deployment: CI artifacts, rollback documentation, observability setup, and gate record completeness.

| Field | Value |
|-------|-------|
| **Applicable stages** | MERGED, DEPLOYING |
| **Inputs** | Merged changes, CI artifact checksums, rollback runbook, environment definitions |
| **Outputs** | Go/hold recommendation with evidence; missing items checklist; deployment sequencing |
| **Agents that use it** | Release Readiness |
| **Governance rules** | All artifacts present; CI green; rollback documented; G-DEPLOY gate not bypassed |
| **Project context required** | Deployment model; environment structure; rollback runbook |
| **Prompt/rule reference** | `prompts/release-verification.prompt.md` |

---

## SKL-020 — Monitoring Signal Interpretation

**Purpose:** Interpret post-deployment observability signals (metrics, traces, logs, alerts) against the expected baseline to detect regressions, anomalies, or performance degradation.

| Field | Value |
|-------|-------|
| **Applicable stages** | DEPLOYED, VERIFIED |
| **Inputs** | Observability data, deployment metadata, expected behaviour baseline, alert thresholds |
| **Outputs** | Signal interpretation: normal/anomaly assessment; anomaly characterisation; go/hold/escalate recommendation |
| **Agents that use it** | Monitoring / Feedback |
| **Governance rules** | Never triggers autonomous action; always produces human-reviewable output; evidence-based only |
| **Project context required** | Observability platform; SLOs; alert thresholds; deployment metadata |
| **Prompt/rule reference** | `prompts/monitoring-interpretation.prompt.md` |

---

## SKL-021 — Context Freshness Check

**Purpose:** Assess whether the `project-context.md` for a repository is current enough to be used for AI-assisted work. Flag stale context that may produce unreliable outputs.

| Field | Value |
|-------|-------|
| **Applicable stages** | Any (prerequisite check before any agent invocation) |
| **Inputs** | `project-context.md` with last-reviewed date; current date |
| **Outputs** | Freshness rating: current (0–30 days), review recommended (31–60 days), review required (61–90 days), stale (90+ days — block) |
| **Agents that use it** | Orchestrator (as prerequisite); all agents |
| **Governance rules** | 90-day maximum staleness; stale context blocks agent invocation |
| **Project context required** | `project-context.md` (last-reviewed date field) |
| **Prompt/rule reference** | `rules/global-rule-index.md` (context freshness rule) |

---

## SKL-022 — Documentation Gap Detection

**Purpose:** Identify documentation that is missing, stale, or inconsistent with the current implementation.

| Field | Value |
|-------|-------|
| **Applicable stages** | PR_OPEN, MERGED |
| **Inputs** | PR diff, existing documentation index, OpenAPI spec, runbook index |
| **Outputs** | Documentation gap list: missing docs, stale docs, inconsistencies with implementation |
| **Agents that use it** | Documentation/OpenAPI, Knowledge Update, PR Review |
| **Governance rules** | Documentation discipline: every new capability must have corresponding docs |
| **Project context required** | Documentation locations; doc ownership; OpenAPI spec location |
| **Prompt/rule reference** | `prompts/update-docs.prompt.md`, `prompts/pr-review.prompt.md` |
