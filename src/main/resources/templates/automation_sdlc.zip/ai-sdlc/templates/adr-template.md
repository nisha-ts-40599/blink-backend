# ADR-{{NUMBER}}: {{TITLE}}

## Status

{{PROPOSED_ACCEPTED_SUPERSEDED}}

## Date

{{DATE}}

## Context

{{CONTEXT_AND_FORCES}}

## Decision

{{DECISION_DESCRIPTION}}

## Alternatives considered

| Alternative | Pros | Cons | Outcome |
|-------------|------|------|---------|
| {{NAME}} | {{PROS}} | {{CONS}} | rejected / deferred |

## Consequences

**Positive:** {{LIST}}  
**Negative / trade-offs:** {{LIST}}  
**Operational:** {{LIST}}

## Compliance and security notes

{{NOTES_OR_NONE}}

## References

- Spec: {{SPEC_LINK}}
- Issues: {{ISSUE_LINKS}}
- Supersedes: {{ADR_PREVIOUS}}
