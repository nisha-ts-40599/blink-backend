# AI Code Review: {{PR_IDENTIFIER}}

| Field | Value |
|-------|-------|
| **Reviewer model / profile** | {{MODEL_OR_PROFILE}} |
| **Commit SHA** | {{COMMIT_SHA}} |
| **Date** | {{DATE}} |

## Executive summary

{{HIGH_LEVEL_VERDICT_AND_RISK}}

## Requirements alignment

- **Met:** {{LIST}}
- **Gaps / ambiguities:** {{LIST}}

## Correctness and edge cases

| Finding | Severity (must-fix / advisory) | Location | Recommendation |
|-----------|-------------------------------|----------|----------------|
| {{SUMMARY}} | {{SEV}} | {{FILE:LINE}} | {{REC}} |

## Security

| Finding | Severity | Category | Recommendation |
|-----------|----------|----------|----------------|
| {{SUMMARY}} | {{SEV}} | {{CATEGORY}} | {{REC}} |

## Performance and scalability

{{NOTES}}

## Reliability and operations

{{NOTES}}

## Maintainability

{{NOTES}}

## Test adequacy

{{ASSESSMENT}}

## Policy and governance

- **Tier-appropriate rigor:** {{ASSESSMENT}}
- **Approval / evidence gaps:** {{LIST_OR_NONE}}

## Suggested follow-ups (non-blocking)

- {{ITEM}}

## Disclaimer

This review is **assistive** and does not replace human PR approval or organizational security sign-off where required.
