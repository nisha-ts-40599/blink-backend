# Capability Map: {{ISSUE-ID}}

## Business capabilities

## Capability owners

## Current module/service mapping

## Target module/service mapping

## Shared capabilities

## Data ownership per capability

## Extraction priority

## Dependencies between capabilities

## Risks and open questions
