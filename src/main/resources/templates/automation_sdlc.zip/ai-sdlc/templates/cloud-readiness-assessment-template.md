# Cloud Readiness Assessment: {{ISSUE-ID}}

## Current hosting model

## Target cloud model

## Network and connectivity

## Identity and access

## Data residency and compliance

## Observability parity

## Cost and capacity signals

## Readiness gaps

## Recommended preparation steps
