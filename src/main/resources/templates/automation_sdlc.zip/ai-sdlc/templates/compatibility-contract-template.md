# Compatibility Contract: {{ISSUE-ID}}

## Existing behavior to preserve

## API contracts

## UI workflows

## Reports/exports

## Data compatibility

## Integration compatibility

## Explicit approved behavior changes
