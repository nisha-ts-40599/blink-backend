# AI-SDLC Context Loading Guide

> Location: `.cursor/ai-sdlc/context-loading.md` (workspace-local overlay)
> Framework prompts and tools should follow this order unless explicitly configured otherwise.

---

## Context load order

1. `.cursor/ai-sdlc/workspace-config.yaml` — `{{WORKSPACE_CONFIG}}`
2. `.cursor/ai-sdlc/workspace-context.md` — `{{WORKSPACE_CONTEXT}}`
3. `.cursor/ai-sdlc/project-config.yaml` — `{{PROJECT_CONFIG}}`
4. `.cursor/ai-sdlc/project-context.md` — `{{PROJECT_CONTEXT}}`
5. `.cursor/ai-sdlc/repos/<repo-id>/project-config.yaml` — per-repo machine config
6. `.cursor/ai-sdlc/repos/<repo-id>/project-context.md` — per-repo human context
7. `.cursor/ai-sdlc/workflow-state/<ISSUE-ID>/` — workflow state + issue artifacts
8. **Governance (recommended):** `ai-sdlc/governance/framework-protection-rule.md`, `ai-sdlc/governance/enterprise-engineering-guardrails.md`, `ai-sdlc/governance/public-reference-and-data-safety.md`
9. **Fallback only:** `automation_sdlc/ai-sdlc/...` or embedded `ai-sdlc/...` in framework repo

---

## What stays in the framework repo

| Category | Path (in framework repo) |
|----------|--------------------------|
| Prompts | `ai-sdlc/prompts/` |
| Templates | `ai-sdlc/templates/` |
| Governance | `ai-sdlc/governance/` |
| Schemas | `ai-sdlc/schemas/` |
| Orchestration tools | `ai-sdlc/tools/orchestration/` |
| Generic examples | `ai-sdlc/examples/` |

---

## What lives in `.cursor/ai-sdlc/`

| Category | Path |
|----------|------|
| Workspace map | `workspace-config.yaml`, `workspace-context.md` |
| Pilot/product config | `project-config.yaml`, `project-context.md` |
| Per-repo profiles | `repos/<repo-id>/project-config.yaml`, `project-context.md` |
| Issue artifacts | `workflow-state/<ISSUE-ID>/` |
| This guide | `context-loading.md` |

---

## Single-repo vs multi-repo

| Workspace type | Overlay location |
|----------------|------------------|
| **Single-repo** | `.cursor/ai-sdlc/` inside the product repo (or workspace root) |
| **Multi-repo** | `.cursor/ai-sdlc/` at workspace/control repo root (sibling to product repos) |

Mark `workspace.type` as `single-repo` or `multi-repo` in `workspace-config.yaml`.

---

## Generated artifact defaults

Save new groomed requirements and workflow state to:

```text
.cursor/ai-sdlc/workflow-state/{ISSUE-ID}/
  {ISSUE-ID}.yaml
  requirement.md
```

Do **not** store project-specific issue artifacts in the reusable framework repo unless explicitly configured.

---

## Safety rules

- Run `make ai-sdlc-guard-framework-clean` before product SDLC prompts (see `ai-sdlc/adoption/framework-guard-checkpoints.md`)
- Product source repos: **read-only** during requirement grooming
- Do not read or expose `.env.mcp`, credentials, tokens, or production customer data
- External system writes (Jira, GitHub, Confluence): disabled unless human approves
- Sanitize API captures and screenshots before saving to workflow-state

---

## Version control guidance

**Commit (sanitized):**

- `workspace-config.yaml`, `workspace-context.md`
- `project-config.yaml`, `project-context.md`
- `repos/*/project-config.yaml`, `project-context.md`
- `context-loading.md`
- Approved requirement artifacts and workflow state (when policy allows)

**Gitignore:**

- `.env.mcp`, secrets, tokens, cookies
- Raw API responses with PII
- Unsanitized logs and screenshots

**Optional:** Track overlay in a workspace meta-repo separate from `automation_sdlc`.

---

## Tooling

`build_context_bundle.py` and `context_paths.py` prefer overlay paths when explicit legacy paths are missing. See `ai-sdlc/tools/orchestration/context_paths.py`.
