# Current State Assessment: {{ISSUE-ID}}

## Architecture overview

## Repositories/modules

## Runtime stack

## Database/storage

## APIs/contracts

## Batch jobs/scheduled jobs

## Integrations

## Deployment topology

## Operational risks

## Known technical debt
