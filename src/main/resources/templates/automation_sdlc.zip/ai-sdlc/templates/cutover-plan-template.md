# Cutover Plan: {{ISSUE-ID}}

## Change summary

## Cutover scope

## Target environment

## Cutover window

## Preconditions

## Step-by-step cutover plan

## Traffic / data / identity switch steps

## Owners and approvers

## Communication plan

## Monitoring plan

## Rollback trigger points

## No-go conditions

## Status
