# Data Migration Plan: {{ISSUE-ID}}

## Source and target data stores

## Migration approach

## Phasing and batching

## Reconciliation strategy

## Rollback touchpoints

## Validation criteria

## Human approvals required
