# Dependency Map: {{ISSUE-ID}}

## Internal dependencies

## External dependencies

## Data dependencies

## Runtime dependencies

## Deployment dependencies

## Ownership and risk
