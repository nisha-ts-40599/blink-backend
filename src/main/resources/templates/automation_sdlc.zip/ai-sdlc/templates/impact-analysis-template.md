# Impact Analysis: {{ISSUE_OR_CHANGE_ID}}

| Field | Value |
|-------|-------|
| **Author** | {{AUTHOR}} |
| **Date** | {{DATE}} |
| **Work tier** | {{WORK_TIER}} |
| **Related plan** | {{PLAN_LINK}} |

## Summary of change

{{SHORT_SUMMARY}}

## Affected components

| Component | Change type (add/modify/remove) | Notes |
|-----------|----------------------------------|-------|
| {{COMPONENT}} | {{TYPE}} | {{NOTES}} |

## Dependency graph

- **Upstream dependencies:** {{LIST}}
- **Downstream consumers:** {{LIST}}
- **Shared libraries / contracts:** {{LIST}}

## Data and schema

- **Database / storage:** {{IMPACT}}
- **Migrations required:** {{YES_NO}} — {{DETAILS}}
- **Backfill / dual-write:** {{PLAN_OR_N_A}}

## API and event contract

- **Breaking changes:** {{YES_NO}}
- **Versioning strategy:** {{STRATEGY}}

## Operational impact

- **Performance:** {{EXPECTED_EFFECT}}
- **Capacity:** {{EXPECTED_EFFECT}}
- **Failure modes:** {{DESCRIPTION}}

## Security and compliance

- **Threat surface delta:** {{DESCRIPTION}}
- **New egress / third parties:** {{YES_NO}}
- **IAM / permission changes:** {{YES_NO}}

## Rollback

{{ROLLBACK_PLAN}}

## Test focus

| Area | Test types |
|------|------------|
| {{AREA}} | {{UNIT_INTEGRATION_E2E}} |

## Residual risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| {{RISK}} | L/M/H | L/M/H | {{MITIGATION}} |

## Approvals required (pre-implementation)

{{LIST_FROM_APPROVAL_RULES}}
