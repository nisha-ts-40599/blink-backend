# Implementation Evidence — {{ISSUE}}

## Summary

Brief description of what was implemented (not a substitute for diffs).

## Repositories

### {{repo_id}}

| Field | Value |
|-------|-------|
| Repo path | |
| Branch | |
| Local commit | |
| Pushed | yes / no |
| PR URL | |
| Working tree clean | |

**Files changed (tracked):**

- 

**Untracked files (separate from diff):**

- 

**Diff stat or summary:**

```text
(paste git diff --stat or equivalent)
```

## Validation snapshot

| Check | Status | Evidence |
|-------|--------|----------|
| Syntax | not_run / passed / failed / not_available / waived | |
| Unit tests | | |
| Runtime QA | | |

## Human action required

Evidence must come from the **product git repo**, not workspace overlay artifacts alone.
