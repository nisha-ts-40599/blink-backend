# {{ISSUE_TRACKER}} Issue Body Template

> Copy into your issue tracker. Replace `{{PLACEHOLDERS}}`.

## Summary

{{ONE_LINE_SUMMARY}}

## Type

- [ ] Feature
- [ ] Bug
- [ ] Tech debt
- [ ] Security
- [ ] Operational
- [ ] Documentation

## Work tier

**Tier:** {{WORK_TIER}} (1–4)  
**Rationale:** {{TIER_RATIONALE}}

## Background

{{CONTEXT_AND_LINKS_TO_REQUIREMENT_SPEC}}

## Acceptance criteria

- [ ] {{CRITERION_1}}
- [ ] {{CRITERION_2}}

## Technical notes (optional)

{{DESIGN_SKETCH_OR_POINTER_TO_PLAN}}

## Impact / blast radius

{{SHORT_IMPACT_SUMMARY}}

## Security / data classification

- **Touches PII / sensitive data:** {{YES_NO_UNKNOWN}}
- **Notes:** {{SECURITY_NOTES}}

## Definition of done (project-specific)

See `project-config.definition_of_done`; confirm:

- [ ] Tests commensurate with tier
- [ ] Docs / ADR updated if needed
- [ ] Observability if user-impacting
- [ ] Scans green or approved exceptions

## Approvals (if tier requires)

| Role | Approver | Date | Link |
|------|----------|------|------|
| {{ROLE}} | {{NAME}} | {{DATE}} | {{EVIDENCE_LINK}} |

## Links

- Requirement: {{REQUIREMENT_LINK}}
- Spec: {{SPEC_LINK}}
- PR: {{PR_LINK}}
