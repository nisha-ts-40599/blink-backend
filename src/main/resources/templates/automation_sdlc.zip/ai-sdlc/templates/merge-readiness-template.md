# Merge Readiness — {{ISSUE}}

## Checklist

- [ ] Implementation evidence recorded (diff/commit)
- [ ] PR URL registered
- [ ] PR review complete
- [ ] G-PR-MERGE / branch protection satisfied
- [ ] G-QA-POST approved (when required)
- [ ] Syntax / unit / runtime validation recorded (not `not_run` unless waived with approver)
- [ ] Structured `implementation.validation.*` synced from QA artifacts when available
- [ ] Tier 3+ logging/privacy review complete
- [ ] Rollback plan recorded (`rollback_plan`) when Tier 3+ or sensitive work requires it
- [ ] No pending runtime QA

## Validation status

| Check | Status | Waiver approver |
|-------|--------|-----------------|
| Syntax | | |
| Unit tests | | |
| Runtime QA | | |
| Integration tests | | |
| Security checks | | |

## Decision

- Merge ready: yes / no
- Blockers:

## Human action required

Merge is human-only. Do not claim merge-ready if runtime QA is pending for Tier 3+ work.
