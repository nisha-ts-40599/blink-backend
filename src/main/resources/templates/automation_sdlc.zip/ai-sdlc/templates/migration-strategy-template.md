# Migration Strategy: {{ISSUE-ID}}

## Selected strategy

## Alternatives considered

## Phases

## Strangler/parallel plan

## Compatibility strategy

## Regression strategy

## Data strategy

## Rollback touchpoints

## No-go conditions

## Human approvals required
