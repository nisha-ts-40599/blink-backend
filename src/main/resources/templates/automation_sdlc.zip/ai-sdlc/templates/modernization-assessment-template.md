# Modernization Assessment: {{ISSUE-ID}}

## Business driver

## Current product/system overview

## Current stack

## Pain points

## Critical flows

## Users/roles

## Integrations

## Data stores

## Deployment process

## Environments

## Observability

## Security/IAM

## Constraints

## Modernization type

## Initial tier recommendation

## Recommended next step
