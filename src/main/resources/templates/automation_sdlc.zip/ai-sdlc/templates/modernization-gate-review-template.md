# Modernization Gate Review: {{ISSUE-ID}}

## Artifacts reviewed

## Architecture decision

## Migration strategy decision

## Regression baseline decision

## Risk review

## Open decisions

## Human approval markers
