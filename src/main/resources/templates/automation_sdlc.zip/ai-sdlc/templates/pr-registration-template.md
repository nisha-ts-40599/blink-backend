# PR Registration — {{ISSUE}}

| Field | Value |
|-------|-------|
| Repo | |
| Branch | |
| PR URL | |
| Draft / Ready | draft / ready for review |
| Local commit | |

## workflow-state patch

```yaml
artifacts:
  implementation_prs:
    - "<PR URL>"
  pr_registration: ".cursor/ai-sdlc/workflow-state/{{ISSUE-ID}}/pr-registration.md"
implementation:
  status: pr_opened
  repos:
    - repo_id: ""
      branch: ""
      pr_url: ""
      local_commit: ""
```

## Human action required

Register PR URL only after the PR exists. AI must not create or merge PRs without explicit human approval.
