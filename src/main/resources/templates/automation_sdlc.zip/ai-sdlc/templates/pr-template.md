## Summary

{{SHORT_SUMMARY}}

## Related work

- Issue: {{ISSUE_LINK}}
- Requirement: {{REQUIREMENT_LINK}}
- Spec: {{SPEC_LINK}}
- Technical plan: {{PLAN_LINK}} (version {{PLAN_VERSION}})
- Impact analysis: {{IMPACT_LINK}}

## Work tier

**Tier:** {{WORK_TIER}}

## Type of change

- [ ] Feature
- [ ] Bug fix
- [ ] Refactor
- [ ] Chore / tooling
- [ ] Docs only

## Behavior

### Before

{{BEFORE}}

### After

{{AFTER}}

## Security / data

- **Touches sensitive data:** {{YES_NO}}
- **Notes:** {{SECURITY_NOTES}}

## Testing

- [ ] Unit tests added/updated
- [ ] Integration tests added/updated
- [ ] Manual verification: {{NOTES}}

## Observability

- [ ] Not applicable
- [ ] Metrics / logs / traces updated: {{DETAILS}}

## Rollout

{{FEATURE_FLAG_OR_MIGRATION_NOTES}}

## Screenshots / evidence (if UI)

{{OPTIONAL}}

## Checklist

- [ ] CI passing on latest commit
- [ ] No unintended file changes
- [ ] Documentation updated if behavior changed
- [ ] ADR linked if architectural decision introduced

## Reviewer hints

{{AREAS_TO_FOCUS}}
