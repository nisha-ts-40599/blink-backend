# Work Tier Classification

Work tiers align **scope**, **risk**, **approvals**, **documentation**, **testing**, and **automation** so teams apply consistent rigor. Tiers are orthogonal to priority: a small Tier 4 change can still be urgent. Classification should occur before substantial implementation (see `workflows/issue-to-plan.md`).

Use `prompts/classify-work.prompt.md` with `{{PROJECT_CONTEXT}}` and `{{REQUIREMENT}}` or `{{ISSUE}}` to support consistent labeling; humans retain authority to override with documented rationale.

**H9 test/QA strategy (Phase 1):** Tier 1 may embed strategy in the technical plan. Tier 2 requires a structured QA section; standalone `test-plan.md` when cross-repo, UI/runtime validation, migration, breaking API, or high regression risk applies. Tier 3–4 require standalone test plans by default. Runtime/visual QA applicability is explicit — UI changes do not default to `NOT_APPLICABLE`.

| Dimension | Tier 1 | Tier 2 | Tier 3 | Tier 4 |
|-----------|--------|--------|--------|--------|
| **Risk level** | Negligible to low | Low to moderate | Moderate to high | High to critical |
| **Typical blast radius** | Single component, reversible | Single service / bounded context | Multiple services or shared libraries | Platform, security boundary, data migration, regulated data |
| **Required approval** | Optional peer review | Engineering lead (or delegate) per policy | Engineering + security (or equivalent) | Engineering + security + platform/SRE + product/legal as applicable |
| **Required documentation** | Issue notes or lightweight ADR stub | Updated spec section or ADR for non-trivial behavior | Spec + ADR + rollout notes | Spec + ADR + threat model delta + runbook + comms plan |
| **Required testing** | Unit or static checks as available | Unit + targeted integration | Above + broader integration / contract tests | Above + performance or chaos slice where relevant + explicit rollback verification |
| **Automation level** | Assisted drafting; human executes most steps | Assisted + automated validation on PR | Assisted + automated scans + gated promotions | Same as Tier 3 plus stricter gates; production actions remain human |

---

## Tier 1 — Low Risk, Localized

**Intent:** Safe, reversible changes with minimal customer or security impact.

**Examples**

- Copy, tooltip, or non-behavioral UI text (no compliance-sensitive wording).
- Internal-only developer ergonomics (local scripts, non-production config samples).
- Typos in comments or documentation with no normative meaning change.
- Non-production test fixture updates that do not alter production code paths.

**Risk level:** Negligible to low.

**Required approval:** None mandatory beyond normal peer review culture; optional reviewer per team norm.

**Required documentation:** Issue description with acceptance check; ADR only if clarifying a decision for future readers.

**Required testing:** Available linters/formatters; unit tests if touching executable code.

**Automation level:** AI may draft; human merges per standard PR process. No additional gates beyond team defaults.

---

## Tier 2 — Moderate Scope, Standard Product Change

**Intent:** Everyday feature and defect work within a single service or application boundary.

**Examples**

- New API field behind contract versioning rules.
- Bug fix in isolated module with clear reproduction.
- Feature flag–gated behavior with default-off in production.
- Refactor with preserved external contracts and full unit coverage.

**Risk level:** Low to moderate.

**Required approval:** Engineering lead (or team-defined single approver) for merges affecting protected branches, per `project-config` approval rules.

**Required documentation:** Specification excerpt or issue-linked technical notes; ADR when introducing a durable architectural choice.

**Required testing:** Unit tests; integration tests for touched boundaries; CI must pass.

**Rollback (Phase 1):** Recommended — `rollback_plan` artifact warns at merge if missing; does not block by default.

**Modernization (Phase 2):** Lane **off** for normal Tier 2 bugs/features. Activates only when `work_type` or `modernization.enabled` indicates migration/modernization work. See `adoption/modernization-lane-guide.md`.

**Automation level:** AI-assisted spec/issue drafting, implementation suggestions, test generation, and PR review; human approves PR and merge.

---

## Tier 3 — Cross-Cutting or Elevated Risk

**Intent:** Changes spanning teams, shared contracts, sensitive data handling, or operational stress.

**Examples**

- Cross-service API or event schema changes.
- Authentication or authorization policy adjustments (non-breaking expansion may still be Tier 3).
- Performance-sensitive hot paths; caching semantics changes.
- Introduction of new third-party dependency with network egress.

**Risk level:** Moderate to high.

**Required approval:** Engineering lead **and** security champion (or mapped roles in `approval_rules.tier_approvals`).

**Required documentation:** Updated specification; ADR; impact analysis per `templates/impact-analysis-template.md`; rollout or feature-flag plan.

**Required testing:** Tier 2 tests plus contract/integration coverage across consumers; security scan review; optional load or soak slice documented in test plan.

**Rollback (Phase 1):** `artifacts.rollback_plan` **required** before merge readiness (`rollback_policy.enforcement.tier_3: block`). Use `rollback-plan.prompt.md`.

**Modernization (Phase 2):** Migration/modernization work typically Tier 3–4. After impact analysis, route through modernization lane (assessment → discovery → target architecture → migration strategy → gate review) before technical plan. Default strategy: strangler/phased/modular-monolith-first — not microservices-by-default.

**Cutover (Phase 3):** Tier 3–4 production cutover work requires cutover planning artifacts and production migration gates before cutover execution evidence. Tier 4 always requires `production_migration_approval`. Normal bug/feature deploy unchanged.

**Automation level:** AI may propose plans and diffs; automated security and dependency gates mandatory; staging validation before production promotion.

---

## Tier 4 — Critical Platform, Security, Data, or Regulatory

**Intent:** Changes that can cause widespread outage, data loss, compliance failure, or irreversible migration.

**Examples**

- Database schema migrations on large tables; destructive data migrations.
- Cryptographic algorithm, key handling, or secrets management changes.
- Network perimeter or IAM permission broadening.
- Changes affecting regulated data categories or audit evidence.
- Production topology or multi-region failover behavior.

**Risk level:** High to critical.

**Required approval:** Full set per organizational policy (typically engineering, security, platform/SRE, product; legal/compliance when indicated).

**Required documentation:** Full spec; ADR; threat model delta where applicable; detailed runbook; customer or stakeholder comms if user-visible.

**Required testing:** Tier 3 breadth plus explicit rollback drill or documented compensating controls; staged rollout (canary/blue-green) per deployment strategy.

**Automation level:** Maximum **assisted** automation for analysis, implementation drafts, and verification; **merge, production deploy, secret rotation, and infra apply remain human-gated** unless explicitly approved by enterprise exception process.

---

## Escalation and Downgrade

- **Escalate** a tier if uncertainty remains after clarification, if rollback is unclear, or if the change touches items listed in `governance/risk-rules.md`.
- **Downgrade** only with documented rationale (for example, stronger feature isolation proved) and approver sign-off when crossing from Tier 3+ to Tier 2.

## Deterministic Classification Rules

Apply the rules below in order. Final tier is the **maximum** tier produced by any matching rule.

| Rule Group | Condition | Minimum Tier |
|------------|-----------|--------------|
| Auth/security impact | AuthN/AuthZ logic, token/session semantics, cryptography, secrets handling | 3 |
| Database schema impact | Non-breaking index/additive schema in isolated service | 2 |
| Database schema impact | Breaking schema, wide-table migration, destructive DDL/DML | 4 |
| Shared library impact | Private library used by one service boundary | 2 |
| Shared library impact | Library consumed by multiple services or SDK clients | 3 |
| Public API impact | Additive versioned API change | 2 |
| Public API impact | Breaking public contract or cross-consumer contract migration | 3 |
| Infrastructure impact | Non-production infra tuning only | 2 |
| Infrastructure impact | Production networking/IAM/topology changes | 4 |
| Multi-service impact | Coordinated rollout across 2+ services | 3 |
| Migration impact | Stateful data migration with rollback uncertainty | 4 |
| Compliance impact | Any regulated control/data processing posture change | 4 |
| Production data impact | Reads only on existing patterns | 2 |
| Production data impact | Writes/transformations on sensitive/regulated data | 3 (or 4 if irreversible) |

## Default Up-Tier Conditions

Automatically up-tier to at least Tier 3 when any condition is true:

1. Requirement ambiguity remains in security, data handling, or rollback path.
2. Change crosses service ownership boundaries.
3. New external egress or third-party dependency is introduced.
4. Production incident history shows prior regressions in same area.

Automatically up-tier to Tier 4 when any condition is true:

1. Destructive migration or irreversible data transformation.
2. IAM perimeter, secret lifecycle, or cryptographic primitives are modified.
3. Compliance obligations or audit evidence model changes.

## Tier 1 vs Tier 2 — Boundary Guidance

This section exists specifically to prevent engineers from self-classifying risky work as Tier 1 to avoid the G-PLAN gate. When in doubt, classify upward.

### What genuinely qualifies as Tier 1

A change is Tier 1 only when **all** of the following are true:

- It affects a single, isolated component with no API surface, database involvement, or auth logic.
- The change is trivially reversible by reverting the commit — no migration, no deployed config change required.
- Failure of this change would not cause a user-visible incident or data problem.
- No new dependency is added and no existing dependency is updated.
- No business logic is introduced or modified.

### What is NOT Tier 1, even when it seems small

| Scenario | Actual tier | Reason |
|----------|------------|--------|
| Fix a bug in a service that customers rely on | **Tier 2** | Customer-visible behavior; regression risk; regression test required |
| Add a new field to an API response | **Tier 2** | API contract change; potential consumer impact |
| Update a dependency version | **Tier 2** | Dependency changes carry transitive risk and license changes |
| Fix a logic error in an authentication or authorization path | **Tier 3** | Auth logic triggers R-AUTH-001 regardless of change size |
| Add a new database column (even nullable) | **Tier 2** | Schema change: R-DB-001 applies; migration rollback must be verified |
| Change a configuration default that affects runtime behavior | **Tier 2** | Behavioral change with blast radius; requires plan review |
| Refactor a shared utility used by more than one service | **Tier 3** | Shared library; R-SHARED-001 applies |
| "Small" performance fix that modifies a SQL query | **Tier 2** | Database query change; requires integration test coverage |
| Fix a UI text string that contains a legal or compliance-sensitive term | **Tier 2** | Compliance risk; not purely cosmetic |
| Update a secret, API key, or connection string | **Tier 3/4** | Secret rotation; R-INFRA-001 or R-CRYPTO-001 may apply |

### Self-classification guard rules

Apply these checks before declaring Tier 1:

1. **The "incident test":** If this change ships a bug, would it create a user-visible incident or require a hotfix? If yes → at least Tier 2.
2. **The "API test":** Does this change affect any interface consumed by another component, service, or user? If yes → at least Tier 2.
3. **The "auth test":** Does this change touch any code path involved in authentication, authorisation, or session handling? If yes → at least Tier 3.
4. **The "data test":** Does this change read from or write to a persistent data store? If yes → at least Tier 2.
5. **The "dependency test":** Does this change add, remove, or update a dependency? If yes → at least Tier 2.
6. **The "shared code test":** Is the changed code used by more than one service or team? If yes → at least Tier 3.

If any test above returns yes and you still want to call it Tier 1: stop, escalate to your engineering lead, and document the rationale. "It's a small change" is not sufficient rationale.

### Examples — clear Tier 1

- Fix a typo in a README that has no normative meaning.
- Update a comment in a source file (no logic change).
- Add a new lint rule to `.eslintrc` that affects only the local dev workflow.
- Add a new entry to a developer-only `.env.example` (no secrets, no runtime config).
- Update a non-production test fixture name (no test logic change).

## Tier 2 vs Tier 3 Edge Cases

| Scenario | Tier 2 | Tier 3 |
|----------|--------|--------|
| API changes | additive, versioned, single-consumer impact | multi-consumer or contract-coordination required |
| Shared code refactor | internal module only | shared library consumed by multiple teams/services |
| Auth change | none (only UI text around auth) | any runtime auth decision path modification |
| Database change | additive non-breaking with clear rollback | migration requiring coordinated deploy or data backfill |
| Feature flag change | isolated flag default-off | global flag default change or cross-service dependency |

## Conflict Resolution Rules

1. **Highest-tier wins** when rules disagree.
2. If rule evaluation differs between human and agent, route to Engineering Lead for adjudication.
3. If security/compliance-related conflict exists, Security Champion co-sign is mandatory.
4. Conflicts must produce a `tier_classification_record` artifact with:
   - evaluated rules
   - proposed tiers
   - final tier
   - approver identities

## Mandatory Human Escalation Conditions

Escalate classification decision to humans when:

- Tier uncertainty persists after one clarification cycle.
- Proposed downgrade from Tier 3/4 to Tier 2.
- Any rule mapped to auth/security/compliance/production data is triggered.
- Rollback feasibility cannot be demonstrated.

## Classification Examples

- **Tier 2:** Add versioned optional field to internal API and update one consumer.
- **Tier 3:** Update shared authorization middleware across three services.
- **Tier 4:** Perform destructive production data migration with historical backfill.

---

## Cross-Repo Tier Classification

When a change spans two or more repositories in a multi-repo workspace, apply the
standard tier rules per repo and then apply the cross-repo rules below.
**The highest resulting tier governs the entire change.**

### Cross-repo minimum tier rules

| Condition | Minimum tier |
|-----------|-------------|
| Change touches 2+ repositories | 2 |
| Change touches 3+ repositories | 3 |
| Database schema change (any repo) | 3 |
| API contract additive change (new field, new endpoint, versioned) | 2 |
| API contract breaking change (remove/rename field, change semantics, break consumer) | 3 |
| Shared library change consumed by 2+ repos | 3 |
| Infrastructure change affecting multiple services | 3 |
| Auth/security/IAM change crossing service boundaries | 3 |
| Coordinated migration across repos with rollback dependency | 4 |
| Production topology or shared infrastructure change | 4 |

### Cross-repo tier examples

| Tier | Example scenario | Repos involved |
|------|-----------------|----------------|
| **Tier 1** | Fix typo in API documentation file (no contract change) | 1 |
| **Tier 2** | Add optional field to internal API; update frontend to display it | frontend + backend |
| **Tier 2** | Add a new environment variable consumed only by the backend | backend |
| **Tier 3** | Add new endpoint to REST API; update frontend consumer and shared API client | frontend + backend + shared-lib |
| **Tier 3** | Add additive migration to shared database; update backend query | database + backend |
| **Tier 3** | Update shared authentication library used by two services | shared-lib + service-a + service-b |
| **Tier 3** | Change internal event schema; update producer and consumer | event-producer + event-consumer |
| **Tier 4** | Destructive database migration requiring coordinated backend and frontend deploy | database + backend + frontend |
| **Tier 4** | Replace authentication mechanism across all services | auth-service + all consumers |
| **Tier 4** | Change cloud provider or multi-region topology affecting all services | infra + all services |

### Cross-repo approval chain

- **Tier 2 cross-repo:** Engineering lead approves plan (G-PLAN); standard PR merge gate per repo.
- **Tier 3 cross-repo:** Engineering lead + Security champion approve plan; all affected repo PRs reviewed before any merge.
- **Tier 4 cross-repo:** Full approval set; dual control for production steps; deployment order enforced.

### Cross-repo change coordination rules

1. A cross-repo change requires a parent tracking issue referencing all affected repo PRs.
2. All affected repo PRs must be approved and CI-green before the first merge.
3. Merges execute in deployment order; do not merge out of order.
4. If any affected repo PR fails CI after others have merged, the change is not complete and must be resolved before deployment.
5. A cross-repo change is done only when all repos are merged, deployed in order, and post-deploy smoke tests pass.

### Deployment order enforcement for cross-repo changes

Apply this sequence for coordinated deploys:

1. Infrastructure (if changed)
2. Database migrations (must be verified; rollback tested)
3. Shared library (must be published)
4. Backend / API (API must be backward-compatible with existing frontend until frontend is deployed)
5. Frontend / consumer

If this order cannot be followed, escalate to Tier 4 and require SRE co-sign on the deployment plan.

See `ai-sdlc/workspace-config.yaml` `deployment_order` and
`ai-sdlc/governance/multi-repo-merge-deploy-readiness.md` for workspace-specific sequencing.
